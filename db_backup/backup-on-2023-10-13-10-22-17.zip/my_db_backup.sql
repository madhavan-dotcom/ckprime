#
# TABLE STRUCTURE FOR: add_staff
#

DROP TABLE IF EXISTS `add_staff`;

CREATE TABLE `add_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `staff_name` varchar(255) NOT NULL,
  `mobileno` varchar(255) NOT NULL,
  `amobileno` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `referred` varchar(255) NOT NULL,
  `salary` varchar(255) NOT NULL,
  `salarytype` varchar(255) NOT NULL,
  `perdaysalary` varchar(255) NOT NULL,
  `ot` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: additem
#

DROP TABLE IF EXISTS `additem`;

CREATE TABLE `additem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` text CHARACTER SET utf8,
  `price` varchar(255) DEFAULT NULL,
  `taxtype` varchar(225) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `priceType` varchar(10) NOT NULL,
  `itemtype` varchar(255) NOT NULL,
  `purchaseNo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (1, '2023-07-28', '1', '850300', '0', '1080R2-2PM 70MM CLEATED STATOR', '1500', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (2, '2023-07-28', '1', '7204', '0', '1080R2-2PM STATOR STAMPING-GANG', '2000', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (3, '2023-10-11', '1', '0', '0', '1080R2-2PM STATOR STAMPING NEW', '100', '1', '9', '9', '18', '1', 'Inclusive', '', NULL);


#
# TABLE STRUCTURE FOR: attendance
#

DROP TABLE IF EXISTS `attendance`;

CREATE TABLE `attendance` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `attendancedate` date NOT NULL,
  `staff` varchar(255) NOT NULL,
  `attendances` varchar(255) NOT NULL,
  `intime` varchar(255) NOT NULL,
  `outtime` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `lastupdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: backup_details
#

DROP TABLE IF EXISTS `backup_details`;

CREATE TABLE `backup_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` longtext,
  `date_created` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (1, 'backup-on-2023-07-28-19-21-05.zip', '2023-07-28');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (2, 'backup-on-2023-07-29-10-41-28.zip', '2023-07-29');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (3, 'backup-on-2023-08-01-17-50-00.zip', '2023-08-01');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (4, 'backup-on-2023-08-03-12-03-37.zip', '2023-08-03');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (5, 'backup-on-2023-08-04-10-41-23.zip', '2023-08-04');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (6, 'backup-on-2023-08-07-12-44-36.zip', '2023-08-07');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (7, 'backup-on-2023-08-08-10-32-02.zip', '2023-08-08');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (8, 'backup-on-2023-08-09-15-39-08.zip', '2023-08-09');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (9, 'backup-on-2023-08-10-11-48-44.zip', '2023-08-10');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (10, 'backup-on-2023-08-14-16-56-52.zip', '2023-08-14');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (11, 'backup-on-2023-08-15-18-37-29.zip', '2023-08-15');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (12, 'backup-on-2023-08-16-12-09-05.zip', '2023-08-16');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (13, 'backup-on-2023-08-18-10-29-37.zip', '2023-08-18');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (14, 'backup-on-2023-08-22-14-49-33.zip', '2023-08-22');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (15, 'backup-on-2023-08-23-10-24-32.zip', '2023-08-23');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (16, 'backup-on-2023-08-24-10-18-49.zip', '2023-08-24');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (17, 'backup-on-2023-08-25-10-20-03.zip', '2023-08-25');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (18, 'backup-on-2023-08-29-16-51-09.zip', '2023-08-29');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (19, 'backup-on-2023-09-05-19-42-21.zip', '2023-09-05');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (20, 'backup-on-2023-09-08-10-27-16.zip', '2023-09-08');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (21, 'backup-on-2023-09-12-12-02-55.zip', '2023-09-12');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (22, 'backup-on-2023-09-19-10-52-39.zip', '2023-09-19');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (23, 'backup-on-2023-09-20-10-59-31.zip', '2023-09-20');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (24, 'backup-on-2023-09-25-12-15-03.zip', '2023-09-25');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (25, 'backup-on-2023-09-26-10-44-20.zip', '2023-09-26');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (26, 'backup-on-2023-09-27-13-31-25.zip', '2023-09-27');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (27, 'backup-on-2023-09-28-10-45-39.zip', '2023-09-28');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (28, 'backup-on-2023-09-29-11-57-29.zip', '2023-09-29');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (29, 'backup-on-2023-10-03-16-28-24.zip', '2023-10-03');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (30, 'backup-on-2023-10-05-15-33-29.zip', '2023-10-05');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (31, 'backup-on-2023-10-07-11-30-04.zip', '2023-10-07');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (32, 'backup-on-2023-10-11-11-12-39.zip', '2023-10-11');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (33, 'backup-on-2023-10-12-11-00-12.zip', '2023-10-12');


#
# TABLE STRUCTURE FOR: backup_url
#

DROP TABLE IF EXISTS `backup_url`;

CREATE TABLE `backup_url` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: bed_details
#

DROP TABLE IF EXISTS `bed_details`;

CREATE TABLE `bed_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `bed` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: card
#

DROP TABLE IF EXISTS `card`;

CREATE TABLE `card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cash_bill
#

DROP TABLE IF EXISTS `cash_bill`;

CREATE TABLE `cash_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cashbill_details
#

DROP TABLE IF EXISTS `cashbill_details`;

CREATE TABLE `cashbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `cust_mobno` varchar(255) NOT NULL,
  `address` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `systemDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `cashbill_details` (`id`, `date`, `invoicedate`, `taxtype`, `invoiceno`, `customerId`, `customername`, `cust_mobno`, `address`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `systemDate`) VALUES (1, '2023-08-23', '2023-08-23', 'with_tax', 'CB001', 1, 'KG Industries ', '9663214885', '', 'intrastate', 'sgst', 'cgst', '', '850300', '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '1500', '100', '150000.00', '', 'percent_wise', '', '150000.00', '9', '13500.00', '9', '13500.00', '18', '0', '177000.00', '177000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '177000.00', 'CB001230823', 'CB001-2023', 1, 1, '0000-00-00');


#
# TABLE STRUCTURE FOR: cashbill_reports
#

DROP TABLE IF EXISTS `cashbill_reports`;

CREATE TABLE `cashbill_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `systemDate` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `cashbill_reports` (`id`, `date`, `taxtype`, `systemDate`, `invoiceno`, `invoicedate`, `paymenttype`, `customerId`, `customername`, `mobileno`, `address`, `gsttype`, `hsnno`, `itemno`, `itemname`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '0000-00-00', 'with_tax', '2023-08-23', 'CB001', '2023-08-23', NULL, 0, 'KG Industries ', '9663214885', '', 'intrastate', '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '1500', '100', '177000.00', NULL, '177000.00', NULL, NULL, '177000.00', NULL, NULL, '1', 'CB001-2023', 'CB001230823', '1');


#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `category` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: collection_details
#

DROP TABLE IF EXISTS `collection_details`;

CREATE TABLE `collection_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `collection_details` (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2023-08-23', NULL, '2023-08-23', NULL, 'V/23-24/-001', 'SMK INDUSTRIES', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '1000', NULL, NULL, NULL);
INSERT INTO `collection_details` (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '2023-08-23', NULL, '2023-08-23', NULL, 'V/23-24/-003', 'SMK INDUSTRIES', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cheque INDIAN OVERSEAS 563966', NULL, NULL, NULL, NULL, '10000', NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: company_logo
#

DROP TABLE IF EXISTS `company_logo`;

CREATE TABLE `company_logo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `company_logo` (`id`, `date`, `image`, `status`) VALUES (1, '2023-08-07', '12832299_1579401915712151_5416626780361493206_n.png', '1');


#
# TABLE STRUCTURE FOR: customer_details
#

DROP TABLE IF EXISTS `customer_details`;

CREATE TABLE `customer_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `contactperson` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `old_openingBal` varchar(255) DEFAULT NULL,
  `salesamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  `accountpay` varchar(255) NOT NULL,
  `chequeno` varchar(100) NOT NULL,
  `last_modified` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (1, '2023-07-29', 'Inter customer', 'SMK INDUSTRIES', '7810028222', 'jp@idreamdevelopers.com', '3/226D, NADUPALAYAM ROAD', 'PATTANAM POST,ONDIPUDUR (VIA)', '', 'Tamil Nadu', 'COIMBATORE', '', '', NULL, '0.00', NULL, '2959976.9', '10000', '2963207.7', NULL, '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33ADXPT3291N2ZJ', '', '', '', '', '', '2023-07-29');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (2, '2023-08-18', 'Intra supplier', 'J.K INDUSTRIES', '96325417596', '', 'CHERAN NAGAR', 'Ganapathy', '', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '0.00', NULL, '217700', '10000', '182700', NULL, '', NULL, '641009', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2023-08-18');


#
# TABLE STRUCTURE FOR: customerpo_details
#

DROP TABLE IF EXISTS `customerpo_details`;

CREATE TABLE `customerpo_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `cuspodate` date DEFAULT NULL,
  `invoicetype` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `cuspono` varchar(255) DEFAULT NULL,
  `transport` varchar(255) DEFAULT NULL,
  `customerpodate` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `cstname` varchar(255) DEFAULT NULL,
  `cstamount` varchar(255) DEFAULT NULL,
  `pf` varchar(255) DEFAULT NULL,
  `freight` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `pfadjus` varchar(255) DEFAULT NULL,
  `freightadjus` varchar(255) DEFAULT NULL,
  `roundoff` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: dc_delivery
#

DROP TABLE IF EXISTS `dc_delivery`;

CREATE TABLE `dc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (1, '2023-08-23', 1, NULL, 'Direct DC', 'SDC/23-24/-001', '2023-08-23', 1, 'SMK INDUSTRIES', 'TN27V8009', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', NULL, NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '1', '', '100', '0', 'For Drilling', '850300', NULL, 'KGS', 'SDC/23-24/-001-23', 'SDC/23-24/-001230823', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (2, '2023-08-23', 2, 1, 'Against Inward', 'SDC/23-24/-002', '2023-08-23', 1, 'SMK INDUSTRIES', 'TN27V8009', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'I001', 'DC002', '2023-08-22', '1080R2-2PM 70MM CLEATED STATOR', '1', '', '100', '100', 'for drilling ', '850300', NULL, 'KGS', 'SDC/23-24/-002-23', 'SDC/23-24/-002230823', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (3, '2023-09-29', 3, 1, 'Against Inward', 'SDC/23-24/-003', '2023-09-29', 1, 'SMK INDUSTRIES', '', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'I001', 'DC002', '2023-08-22', '1080R2-2PM 70MM CLEATED STATOR', '1', '', '100', '100', 'for drilling ', '850300', NULL, 'KGS', 'SDC/23-24/-003-23', 'SDC/23-24/-003290923', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (4, '2023-10-03', 4, 4, 'Against Inward', 'SDC/23-24/-004', '2023-10-03', 1, 'SMK INDUSTRIES', 'TN 37 V 8009', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'I003', 'DC008', '2023-10-03', '1080R2-2PM 70MM CLEATED STATOR', '1', '', '10', '8', '-', '850300', NULL, 'KGS', 'SDC/23-24/-004-23', 'SDC/23-24/-004031023', 1, 1);


#
# TABLE STRUCTURE FOR: dcbill_details
#

DROP TABLE IF EXISTS `dcbill_details`;

CREATE TABLE `dcbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `itemid` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (1, '2023-08-23', 'Direct DC', 'SDC/23-24/-001', '2023-08-23', 1, 'SMK INDUSTRIES', 'TN27V8009', '10:41:AM', '', '', '', '5000', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', NULL, NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '1', '', '100', 'For Drilling', '850300', NULL, 'KGS', 'SDC/23-24/-001-23', 'SDC/23-24/-001230823', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (2, '2023-08-23', 'Against Inward', 'SDC/23-24/-002', '2023-08-23', 1, 'SMK INDUSTRIES', 'TN27V8009', '10:46:AM', '', '', '', NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'I001', 'DC002', '2023-08-22', '1080R2-2PM 70MM CLEATED STATOR', '1', '', '100', 'for drilling ', '850300', NULL, 'KGS', 'SDC/23-24/-002-23', 'SDC/23-24/-002230823', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (3, '2023-09-29', 'Against Inward', 'SDC/23-24/-003', '2023-09-29', 1, 'SMK INDUSTRIES', '', '12:58:PM', '', '', '', NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'I001', 'DC002', '2023-08-22', '1080R2-2PM 70MM CLEATED STATOR', '1', '', '100', 'for drilling ', '850300', NULL, 'KGS', 'SDC/23-24/-003-23', 'SDC/23-24/-003290923', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (4, '2023-10-03', 'Against Inward', 'SDC/23-24/-004', '2023-10-03', 1, 'SMK INDUSTRIES', 'TN 37 V 8009', '04:32:PM', 'Product', 'drilling', 'completed', NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'I003', 'DC008', '2023-10-03', '1080R2-2PM 70MM CLEATED STATOR', '1', '', '10', '-', '850300', NULL, 'KGS', 'SDC/23-24/-004-23', 'SDC/23-24/-004031023', 1, 1, '');


#
# TABLE STRUCTURE FOR: dcbill_details_backup
#

DROP TABLE IF EXISTS `dcbill_details_backup`;

CREATE TABLE `dcbill_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `itemid` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: einvoicetoken
#

DROP TABLE IF EXISTS `einvoicetoken`;

CREATE TABLE `einvoicetoken` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tokenexpiry` varchar(255) NOT NULL,
  `authtoken` varchar(255) NOT NULL,
  `sek` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `einvoicetoken` (`id`, `tokenexpiry`, `authtoken`, `sek`, `status`, `created_at`) VALUES (1, '2023-08-15 21:14:01', 'CoZ2Wiqb4jvqJq9XzaHcpuTja', '', 1, '2023-08-07 06:10:00');


#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS `expenses`;

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `expenses` (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (1, '2023-08-22', '001', 'Manager', '2023-08-22', 'Lunch', 'Cash', '0', '', '', '0', '', '15000', NULL, 'Cash', '15000', '1', 'Company staff', '');
INSERT INTO `expenses` (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (2, '2023-08-22', '002', 'Manager', '2023-08-22', 'Lunch', 'Cash', '0', '', '', '0', '', '15000', NULL, 'Cash', '15000', '1', 'Company staff', '');


#
# TABLE STRUCTURE FOR: expenses_backup
#

DROP TABLE IF EXISTS `expenses_backup`;

CREATE TABLE `expenses_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: headers
#

DROP TABLE IF EXISTS `headers`;

CREATE TABLE `headers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `headers` (`id`, `date`, `status`, `name`) VALUES (1, '2023-08-22', 1, 'Company staff');


#
# TABLE STRUCTURE FOR: hsnmaster
#

DROP TABLE IF EXISTS `hsnmaster`;

CREATE TABLE `hsnmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `party` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: invoice_details
#

DROP TABLE IF EXISTS `invoice_details`;

CREATE TABLE `invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `pono` varchar(255) DEFAULT NULL,
  `pino` varchar(255) DEFAULT NULL,
  `purchaseordernos` varchar(255) DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerdcnos'` varchar(100) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `removalDate` date NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToId` varchar(255) DEFAULT NULL,
  `shipToAddress` longtext,
  `deliveryAddress1` longtext,
  `deliveryAddress2` longtext,
  `mobileNo` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemcode` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `totalqty` varchar(255) DEFAULT NULL,
  `acno` varchar(255) NOT NULL,
  `acdate` varchar(255) NOT NULL,
  `irn` varchar(255) NOT NULL,
  `signedinvoice` longtext NOT NULL,
  `signedqrcode` longtext NOT NULL,
  `status_ein` longtext NOT NULL,
  `ewayno` varchar(255) NOT NULL,
  `ewaydate` varchar(255) NOT NULL,
  `ewbvalidtill` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `status_cd` varchar(255) NOT NULL,
  `status_desc` varchar(255) NOT NULL,
  `einvoice_status` int(11) NOT NULL,
  `eway_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=latin1;

INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (1, '2023-07-28', '2023-07-28', '', '1970-01-01', 'INV/23-24/-001', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-07-28', '04:04 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300||7204', NULL, '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', 'KGS||KGS', '1500||2000', '1||1', '1500.00||2000.00', '0||0', 'percent_wise', '0.00||0.00', '1500.00||2000.00', '9||9', '135.00||180.00', '9||9', '135.00||180.00', '18||18', '270.00||360.00', '1770.00||2360.00', '4130.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', NULL, '1||1', '4130.00', '3130', 1, 'INV/23-24/-001280723', 'INV/23-24/-001-2023', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (2, '2023-07-28', '2023-07-28', '', '1970-01-01', 'INV/23-24/-002', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-07-28', '07:03 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300||7204', NULL, '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', 'KGS||KGS', '1500||2000', '1||1', '1500.00||2000.00', '0||0', 'percent_wise', '0.00||0.00', '1500.00||2000.00', '9', '', '9', '', '18', '630.00', NULL, '3500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '4130.00', '4130.00', 1, 'INV/23-24/-002280723', 'INV/23-24/-002-2023', 1, 1, '4.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (3, '2023-07-29', '2023-07-29', '', '1970-01-01', 'INV/23-24/-003', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-07-29', '03:53 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300||7204', NULL, '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', 'KGS||KGS', '1500||2000', '1||1', '1500.00||2000.00', '0||0', 'percent_wise', '0.00||0.00', '1500.00||2000.00', '9', '', '9', '', '18', '630.00', NULL, '3500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '4130.00', '4130.00', 1, 'INV/23-24/-003290723', 'INV/23-24/-003-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (4, '2023-07-29', '2023-07-29', '', '1970-01-01', 'INV/23-24/-004', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-07-29', '03:56 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300||7204', NULL, '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', 'KGS||KGS', '1500||2000', '1||1', '1500.00||2000.00', '0||0', 'percent_wise', '0.00||0.00', '1500.00||2000.00', '9', '', '9', '', '18', '630.00', NULL, '3500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '4130.00', '4130.00', 1, 'INV/23-24/-004290723', 'INV/23-24/-004-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (5, '2023-07-29', '2023-07-29', '', '1970-01-01', 'INV/23-24/-005', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-07-29', '03:57 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204||850300', NULL, '1080R2-2PM STATOR STAMPING-GANG||1080R2-2PM 70MM CLEATED STATOR', '||', 'KGS||KGS', '2000||1500', '1||1', '2000.00||1500.00', '0||0', 'percent_wise', '0.00||0.00', '2000.00||1500.00', '9', '', '9', '', '18', '630.00', NULL, '3500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '4130.00', '4130.00', 1, 'INV/23-24/-005290723', 'INV/23-24/-005-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (6, '2023-07-29', '2023-07-29', '', '1970-01-01', 'INV/23-24/-006', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-07-29', '06:04 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300||7204', NULL, '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', 'KGS||KGS', '1500||2000', '1||1', '1500.00||2000.00', '0||0', 'percent_wise', '0.00||0.00', '1500.00||2000.00', '9', '', '9', '', '18', '630.00', NULL, '3500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '4130.00', '4130.00', 1, 'INV/23-24/-006290723', 'INV/23-24/-006-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (7, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-007', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '12:03 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-007030823', 'INV/23-24/-007-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (8, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-008', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '12:05 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-008030823', 'INV/23-24/-008-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (9, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-009', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '03:20 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-009030823', 'INV/23-24/-009-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (10, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-010', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '03:38 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-010030823', 'INV/23-24/-010-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (11, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-011', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '03:39 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-011030823', 'INV/23-24/-011-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (12, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-012', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '03:50 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-012030823', 'INV/23-24/-012-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (13, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-013', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '04:45 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-013030823', 'INV/23-24/-013-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (14, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-014', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '04:45 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-014030823', 'INV/23-24/-014-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (15, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-015', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '04:47 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-015030823', 'INV/23-24/-015-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (16, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-016', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '04:48 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-016030823', 'INV/23-24/-016-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (17, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-017', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '04:51 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-017030823', 'INV/23-24/-017-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (18, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-018', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '04:53 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-018030823', 'INV/23-24/-018-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (19, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-019', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '04:54 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-019030823', 'INV/23-24/-019-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (20, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-020', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '04:59 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-020030823', 'INV/23-24/-020-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (21, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-021', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '06:09 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-021030823', 'INV/23-24/-021-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (22, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-022', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:16 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-022030823', 'INV/23-24/-022-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (23, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-023', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:17 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-023030823', 'INV/23-24/-023-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (24, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-024', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:19 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-024030823', 'INV/23-24/-024-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (25, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-025', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:20 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-025030823', 'INV/23-24/-025-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (26, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-026', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:25 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-026030823', 'INV/23-24/-026-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (27, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-027', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:26 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-027030823', 'INV/23-24/-027-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (28, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-028', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:27 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-028030823', 'INV/23-24/-028-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (29, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-029', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:36 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-029030823', 'INV/23-24/-029-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (30, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-030', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:36 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-030030823', 'INV/23-24/-030-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (31, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-031', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:37 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-031030823', 'INV/23-24/-031-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (32, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-032', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:41 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-032030823', 'INV/23-24/-032-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (33, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-033', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:43 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-033030823', 'INV/23-24/-033-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (34, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-034', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:46 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-034030823', 'INV/23-24/-034-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (35, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-035', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '10:48 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-035040823', 'INV/23-24/-035-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (36, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-036', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '10:49 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-036040823', 'INV/23-24/-036-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (37, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-037', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '10:57 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-037040823', 'INV/23-24/-037-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (38, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-038', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '10:57 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-038040823', 'INV/23-24/-038-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (39, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-039', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '11:01 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-039040823', 'INV/23-24/-039-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (40, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-040', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '11:03 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-040040823', 'INV/23-24/-040-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (41, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-041', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '11:14 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-041040823', 'INV/23-24/-041-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (42, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-042', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '11:15 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-042040823', 'INV/23-24/-042-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (43, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-043', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '11:17 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-043040823', 'INV/23-24/-043-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (44, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-044', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '12:13 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-044040823', 'INV/23-24/-044-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (45, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-045', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '12:16 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-045040823', 'INV/23-24/-045-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (46, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-046', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '12:18 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-046040823', 'INV/23-24/-046-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (47, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-047', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '12:19 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-047040823', 'INV/23-24/-047-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (48, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-048', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '02:40 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-048040823', 'INV/23-24/-048-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (49, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-049', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '02:44 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-049040823', 'INV/23-24/-049-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (50, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-050', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '02:59 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-050040823', 'INV/23-24/-050-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (51, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-051', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '03:00 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-051040823', 'INV/23-24/-051-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (52, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-052', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '03:01 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-052040823', 'INV/23-24/-052-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (53, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-053', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '03:02 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-053040823', 'INV/23-24/-053-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (54, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-054', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '03:04 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-054040823', 'INV/23-24/-054-2023', 1, 1, '1.00', '112310168366820', '2023-08-04 15:07:00', 'ab4b654a5d42bc42719a38c036f53120ce7369bad7b316e606de289527df6ff6', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjgzNjY4MTksXCJBY2tEdFwiOlwiMjAyMy0wOC0wNCAxNTowNzowMFwiLFwiSXJuXCI6XCJhYjRiNjU0YTVkNDJiYzQyNzE5YTM4YzAzNmY1MzEyMGNlNzM2OWJhZDdiMzE2ZTYwNmRlMjg5NTI3ZGY2ZmY2XCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDU0XCIsXCJEdFwiOlwiMDQvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjg1MDMwMFwiLFwiUXR5XCI6MSxcIlVuaXRcIjpcIktHU1wiLFwiVW5pdFByaWNlXCI6MTUwMCxcIlRvdEFtdFwiOjE1MDAsXCJEaXNjb3VudFwiOjAsXCJBc3NBbXRcIjoxNTAwLFwiR3N0UnRcIjoxOCxcIklnc3RBbXRcIjoyNzAsXCJDZ3N0QW10XCI6MCxcIlNnc3RBbXRcIjowLFwiVG90SXRlbVZhbFwiOjE3NzB9XSxcIlZhbER0bHNcIjp7XCJBc3NWYWxcIjoxNTAwLFwiQ2dzdFZhbFwiOjAsXCJTZ3N0VmFsXCI6MCxcIklnc3RWYWxcIjoyNzAsXCJPdGhDaHJnXCI6MCxcIlJuZE9mZkFtdFwiOjAsXCJUb3RJbnZWYWxcIjoxNzcwfSxcIkFkZGxEb2NEdGxzXCI6W3tcIlVybFwiOlwiaHR0cHM6Ly9laW52LWFwaXNhbmRib3gubmljLmluXCIsXCJEb2NzXCI6XCJUZXN0IERvY1wiLFwiSW5mb1wiOlwiRG9jdW1lbnQgVGVzdFwifV19IiwiaXNzIjoiTklDIFNhbmRib3gifQ.dOCrWZ2Vk4bMlJy6BT241WqL5agq9e_L7btmB08zKIGxRAwzgdVl26-GpZ1sXSab09G5zdWkwY-JzFFfy5lEkEdCZ0VzfShDuCa_uCykeaNA5CxG4NDimJ9ybY56swXnPuFCglBIA49pDDwRoJlyHpFBgRI0VoL6TxgcvDn5NAgK4mdwhk9Fd7MP99AZ9ZmbiB9d16b7hIINQ2UOUBhyz0ECoe8sUYD4l0yiWkavsuqVYdw0AgfmGumHiTwYNuVQu54ATAmg5Cje88Lq11wjPe3GNwGq1BLH9rPS__-gRapyORRxG1RWq7NBBPbkEw-sCmgtqPm7qc9ty-QL4ZpQVw', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wNTRcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDQvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MTc3MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjg1MDMwMFwiLFwiSXJuXCI6XCJhYjRiNjU0YTVkNDJiYzQyNzE5YTM4YzAzNmY1MzEyMGNlNzM2OWJhZDdiMzE2ZTYwNmRlMjg5NTI3ZGY2ZmY2XCIsXCJJcm5EdFwiOlwiMjAyMy0wOC0wNCAxNTowNzowMFwifSIsImlzcyI6Ik5JQyBTYW5kYm94In0.NOyPWGv1GHQIa8W1n_PbgrCgzxI7D9qbEi3EXkqH6iWA3m5tIQNoYnZEo8VGgPzBahNE6HlENlzHf4fZFtfAPIKRyhStrOpvFb3T5VJctmB4QDbNiZzVh8lRg0m3OeMG1vY3L6wnB1o60MkXcjQyg0vZCBGzuSuw-RBHhH2sPvU_fMZ7P_7LdZN2H1Kv5lUvfkDMKabf6M74P8rxxdF6NZ6f1NWijhex30eqrQgy0xE_OxnIxWQzbogCOZAOPynYjt9kSl-svdBOYpCtgEcnmD5SbPP6QoMssn39mIgHh2fEYcc6fmBI79nPlAQLiFQ8fqpxiPo2Yu_mi5HGJZ9vOg', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (55, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-055', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '03:06 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-055040823', 'INV/23-24/-055-2023', 1, 1, '1.00', '112310168366890', '2023-08-04 15:09:00', 'ea72ff53d4727db553105da244ae013cde78dc450afe96f766581bb6de609fae', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjgzNjY4OTEsXCJBY2tEdFwiOlwiMjAyMy0wOC0wNCAxNTowOTowMFwiLFwiSXJuXCI6XCJlYTcyZmY1M2Q0NzI3ZGI1NTMxMDVkYTI0NGFlMDEzY2RlNzhkYzQ1MGFmZTk2Zjc2NjU4MWJiNmRlNjA5ZmFlXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDU1XCIsXCJEdFwiOlwiMDQvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjcyMDRcIixcIlF0eVwiOjEsXCJVbml0XCI6XCJLR1NcIixcIlVuaXRQcmljZVwiOjIwMDAsXCJUb3RBbXRcIjoyMDAwLFwiRGlzY291bnRcIjowLFwiQXNzQW10XCI6MjAwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6MzYwLFwiQ2dzdEFtdFwiOjAsXCJTZ3N0QW10XCI6MCxcIlRvdEl0ZW1WYWxcIjoyMzYwfV0sXCJWYWxEdGxzXCI6e1wiQXNzVmFsXCI6MjAwMCxcIkNnc3RWYWxcIjowLFwiU2dzdFZhbFwiOjAsXCJJZ3N0VmFsXCI6MzYwLFwiT3RoQ2hyZ1wiOjAsXCJSbmRPZmZBbXRcIjowLFwiVG90SW52VmFsXCI6MjM2MH0sXCJBZGRsRG9jRHRsc1wiOlt7XCJVcmxcIjpcImh0dHBzOi8vZWludi1hcGlzYW5kYm94Lm5pYy5pblwiLFwiRG9jc1wiOlwiVGVzdCBEb2NcIixcIkluZm9cIjpcIkRvY3VtZW50IFRlc3RcIn1dfSIsImlzcyI6Ik5JQyBTYW5kYm94In0.y9afKzE6YqANWnGhX8eK3MjLVPwqJKovjvOknca5xtENE-WODRZFJmB_i9ZtLICZxLOkCWPC9Q1w0JC9Jq9Fsji7NIecSCR_-PHSHjv-30-aFMstjgg_Z610ZOIRLbDVrLwtZinXBiCjknogE82aeZj1gU_9J3BIoa3NNmcEJy27Gl8jFWyoofQU-7P9tGE4HHuzFAxMUniO0kM8aDLtUvtgA4M5HOcbs5N1iaty6qZ69tYV5TntLfCiz5AUVAOyPYqLvZBb-2rwpVxBuGWmRqsq7vJiXEN2lRXWlE_mwWb1vfLQQWlfuL6HJWZZfL8MqbY4p4Pl0o1Cg8Phi450MA', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wNTVcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDQvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MjM2MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjcyMDRcIixcIklyblwiOlwiZWE3MmZmNTNkNDcyN2RiNTUzMTA1ZGEyNDRhZTAxM2NkZTc4ZGM0NTBhZmU5NmY3NjY1ODFiYjZkZTYwOWZhZVwiLFwiSXJuRHRcIjpcIjIwMjMtMDgtMDQgMTU6MDk6MDBcIn0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.WGfc-u-VxB4UQc1wo4tsKUJQ-UHOuG-TvOz542Rk1PYipqVNze1J-2alLQjCMeZPE-NG7NcE-vzHu1eA9A9NppSAGyyBnVLsb8gpOdIpNOcuq5FWyCydWmI6k0O9K85eyFo6VFjjogApgm3jMIelcJqGX8bRrSFQYPGEubP_WHZe16bxhvr5IrC8T6O6uqKsZXbCLi-xbD97fx81BQ-adExEU_nYLDysS7U2H-55z7-SZ727Y4OoaW7tx6e5LaBw80kfOlmKUa8v4CBCdxIXtZ66JEHJiG0RXaqBIFJxfRviOgyD-Wi4-A5Oijl-uiNP-pPEnLdPxB4GTtGrzl35nQ', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (56, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-056', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '03:06 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-056040823', 'INV/23-24/-056-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (57, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-057', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '03:54 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-057040823', 'INV/23-24/-057-2023', 1, 1, '1.00', '112310168367940', '2023-08-04 15:57:00', 'e26fbe175e71c773017565a1dd62fdb2102707aaa6b7830c2e4c3df6a96c97b3', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjgzNjc5NDIsXCJBY2tEdFwiOlwiMjAyMy0wOC0wNCAxNTo1NzowMFwiLFwiSXJuXCI6XCJlMjZmYmUxNzVlNzFjNzczMDE3NTY1YTFkZDYyZmRiMjEwMjcwN2FhYTZiNzgzMGMyZTRjM2RmNmE5NmM5N2IzXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDU3XCIsXCJEdFwiOlwiMDQvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjcyMDRcIixcIlF0eVwiOjEsXCJVbml0XCI6XCJLR1NcIixcIlVuaXRQcmljZVwiOjIwMDAsXCJUb3RBbXRcIjoyMDAwLFwiRGlzY291bnRcIjowLFwiQXNzQW10XCI6MjAwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6MzYwLFwiQ2dzdEFtdFwiOjAsXCJTZ3N0QW10XCI6MCxcIlRvdEl0ZW1WYWxcIjoyMzYwfV0sXCJWYWxEdGxzXCI6e1wiQXNzVmFsXCI6MjAwMCxcIkNnc3RWYWxcIjowLFwiU2dzdFZhbFwiOjAsXCJJZ3N0VmFsXCI6MzYwLFwiT3RoQ2hyZ1wiOjAsXCJSbmRPZmZBbXRcIjowLFwiVG90SW52VmFsXCI6MjM2MH0sXCJBZGRsRG9jRHRsc1wiOlt7XCJVcmxcIjpcImh0dHBzOi8vZWludi1hcGlzYW5kYm94Lm5pYy5pblwiLFwiRG9jc1wiOlwiVGVzdCBEb2NcIixcIkluZm9cIjpcIkRvY3VtZW50IFRlc3RcIn1dfSIsImlzcyI6Ik5JQyBTYW5kYm94In0.AMg_Lw_BHSzGgonxgqcILwSOaOLnKkmQuITo3ksYyjdg_nUcVZOvRl3pUFmh_xp9GWh1RYYfNjw2CAGpjqIt6_mfgwHM-BQaRx0QP-ZDoGXxikD6mhsYI2fDFtgu1-G4E5co9BDn3JByLN7EUk2iHsGrCSWd9IBtTxyKPOIlpZu1V_kzCS0IM1Binlz8vBXuvpXYg5HSEj78cuTy964DsBCts7dPSV7z8eUYvoHPwxW_RoIJpGbjkEbp3d_cerY8D6DFojqqRTE61ItSdFyyxHZo0wReKvcgiHKmCdPmVlnAfkTFF1A9Z-eEXiH9mnd0pkgu6MJoNzORiZcpk3z5FA', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wNTdcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDQvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MjM2MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjcyMDRcIixcIklyblwiOlwiZTI2ZmJlMTc1ZTcxYzc3MzAxNzU2NWExZGQ2MmZkYjIxMDI3MDdhYWE2Yjc4MzBjMmU0YzNkZjZhOTZjOTdiM1wiLFwiSXJuRHRcIjpcIjIwMjMtMDgtMDQgMTU6NTc6MDBcIn0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.KBNENzjnvH3f8jLotjZDWTrQ-twsSXjDAdwPi2lxxHHvs0CpvTSiHS_O1zcAqB-2-55Xg1UOxyJ2yfUqNjwTPoSyrGPHfLWB1C0wUXGiiiBNNG64NFDlzoNzbyUpJ1NRdTIAdOTXri3bdtwlNqNKBD817ChkW0-DKm2xBV7feZh3J5j4v93WEljlD2Mftm3tbOsEhGS6L5CEwttgvOUM0uKbccetatHEaL3ABmgDMZO94MG0w6QyUegOj7QIJ6H_k9CPmCl5u5ImVW8GY_HD-yi_H_4M4aqJym5On1kGpPFHwu6eT0zyh2zStav7JiG0QAIPJdTvhABv_aTsKWUtrA', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (58, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-058', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '04:55 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-058040823', 'INV/23-24/-058-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (59, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-059', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '04:57 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-059040823', 'INV/23-24/-059-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (60, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-060', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '04:57 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-060040823', 'INV/23-24/-060-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (61, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-061', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '03:52 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-061070823', 'INV/23-24/-061-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (62, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-062', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '03:53 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-062070823', 'INV/23-24/-062-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (63, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-063', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '03:59 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-063070823', 'INV/23-24/-063-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (64, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-064', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '04:00 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-064070823', 'INV/23-24/-064-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (65, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-065', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '04:03 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-065070823', 'INV/23-24/-065-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (66, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-066', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '04:03 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-066070823', 'INV/23-24/-066-2023', 1, 1, '1.00', '112310168521870', '2023-08-07 16:59:00', '36248801028c3873bc3921ffc06e412f40ee627894f92a73092012565b29b297', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjg1MjE4NjksXCJBY2tEdFwiOlwiMjAyMy0wOC0wNyAxNjo1OTowMFwiLFwiSXJuXCI6XCIzNjI0ODgwMTAyOGMzODczYmMzOTIxZmZjMDZlNDEyZjQwZWU2Mjc4OTRmOTJhNzMwOTIwMTI1NjViMjliMjk3XCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDY2XCIsXCJEdFwiOlwiMDcvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjg1MDMwMFwiLFwiUXR5XCI6MSxcIlVuaXRcIjpcIktHU1wiLFwiVW5pdFByaWNlXCI6MTUwMCxcIlRvdEFtdFwiOjE1MDAsXCJEaXNjb3VudFwiOjAsXCJBc3NBbXRcIjoxNTAwLFwiR3N0UnRcIjoxOCxcIklnc3RBbXRcIjoyNzAsXCJDZ3N0QW10XCI6MCxcIlNnc3RBbXRcIjowLFwiVG90SXRlbVZhbFwiOjE3NzB9XSxcIlZhbER0bHNcIjp7XCJBc3NWYWxcIjoxNTAwLFwiQ2dzdFZhbFwiOjAsXCJTZ3N0VmFsXCI6MCxcIklnc3RWYWxcIjoyNzAsXCJPdGhDaHJnXCI6MCxcIlJuZE9mZkFtdFwiOjAsXCJUb3RJbnZWYWxcIjoxNzcwfSxcIkFkZGxEb2NEdGxzXCI6W3tcIlVybFwiOlwiaHR0cHM6Ly9laW52LWFwaXNhbmRib3gubmljLmluXCIsXCJEb2NzXCI6XCJUZXN0IERvY1wiLFwiSW5mb1wiOlwiRG9jdW1lbnQgVGVzdFwifV19IiwiaXNzIjoiTklDIFNhbmRib3gifQ.yIkgqB2Hnn6i6xzeD8AbP1MqNmrfodm5DiH_IIyLa5HfmX3mKE5vrV0xHEzojM0SVdzGdURhEa5kPcmCq35NnmaKKAu1E-xKImekOFYwJTn-SBIWXLV_xb82aHQVoxm5060Z1139vvA1ccXwEc1MvEFdQ1ErJzDKn3evPTIY9Pugb3j9Q7RTI1R2bK8tROewifvc1BrZ8u4Za_853sDUSFyHjYsE2bExSS2onuVMtl9u8jkRCsFV3i28mfktd8dguP9wS5vPQOM0SNctnMhM-XJ3_KVra1mpNGDiurLaUQ9EKDXbF2_c6agxzRFCrIvpabRLWNMcZRjp8dtVps9WPg', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wNjZcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDcvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MTc3MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjg1MDMwMFwiLFwiSXJuXCI6XCIzNjI0ODgwMTAyOGMzODczYmMzOTIxZmZjMDZlNDEyZjQwZWU2Mjc4OTRmOTJhNzMwOTIwMTI1NjViMjliMjk3XCIsXCJJcm5EdFwiOlwiMjAyMy0wOC0wNyAxNjo1OTowMFwifSIsImlzcyI6Ik5JQyBTYW5kYm94In0.1DFkrWUw_ZizsCHQFIiXcb6z9ci4VV8GzhUoSg1ySoHuglHvYKUo2bf7547HTAhBPzz5UMGuX5fA2VCqmiquzZyzz8qz-98SgzjKYSMKp3Pxkor0ZS4b4UTX_WZaWJRvm5jjhTpZoM8nqrWojsCiOAEh6u9_3bythSSK1x-wHnfKyGKWv-O1lt0k0eYh9NqFJPCxyfRSB5TvQEkN4m3fZz01jMIi4S80lPXeiphi9uddwQ16zPWnC3wmkYHcPQRZhGl1F_IijvpMwAbUM0-7Yb9N-MdjFJo9osg9SwEdw_jaktYFUajW53wshAOWjiQ6hiGhuNsQyty1DedhXOCinQ', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (67, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-067', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '05:00 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-067070823', 'INV/23-24/-067-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (68, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-068', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '05:00 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-068070823', 'INV/23-24/-068-2023', 1, 1, '1.00', '112310168522340', '2023-08-07 17:26:00', '0aa7897a8d17eec182bedfd602c5e81778f9a848b436d9cc0fd7f6e445f1402e', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjg1MjIzNDUsXCJBY2tEdFwiOlwiMjAyMy0wOC0wNyAxNzoyNjowMFwiLFwiSXJuXCI6XCIwYWE3ODk3YThkMTdlZWMxODJiZWRmZDYwMmM1ZTgxNzc4ZjlhODQ4YjQzNmQ5Y2MwZmQ3ZjZlNDQ1ZjE0MDJlXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDY4XCIsXCJEdFwiOlwiMDcvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjg1MDMwMFwiLFwiUXR5XCI6MSxcIlVuaXRcIjpcIktHU1wiLFwiVW5pdFByaWNlXCI6MTUwMCxcIlRvdEFtdFwiOjE1MDAsXCJEaXNjb3VudFwiOjAsXCJBc3NBbXRcIjoxNTAwLFwiR3N0UnRcIjoxOCxcIklnc3RBbXRcIjoyNzAsXCJDZ3N0QW10XCI6MCxcIlNnc3RBbXRcIjowLFwiVG90SXRlbVZhbFwiOjE3NzB9XSxcIlZhbER0bHNcIjp7XCJBc3NWYWxcIjoxNTAwLFwiQ2dzdFZhbFwiOjAsXCJTZ3N0VmFsXCI6MCxcIklnc3RWYWxcIjoyNzAsXCJPdGhDaHJnXCI6MCxcIlJuZE9mZkFtdFwiOjAsXCJUb3RJbnZWYWxcIjoxNzcwfSxcIkFkZGxEb2NEdGxzXCI6W3tcIlVybFwiOlwiaHR0cHM6Ly9laW52LWFwaXNhbmRib3gubmljLmluXCIsXCJEb2NzXCI6XCJUZXN0IERvY1wiLFwiSW5mb1wiOlwiRG9jdW1lbnQgVGVzdFwifV19IiwiaXNzIjoiTklDIFNhbmRib3gifQ.K_I5PLuaMeLzICBIYNxChSh417Vkylk70FK_Kmq3T5SfRs7HkxTFVrbwH1nLAT9EDrxvwK7we_tTyYOsolWV6cFIHba5-_TORvdU6xB6bH5lsGWUqQsH1X9bhBzE96exEs5w-T-dBaYtbZfr2-tFtglOq06WPU9BAxgmb8enVmEoXNq-nYsj4KdA0rMQknK5X1qYoa8PhRFh9XrHXhJ7NR-rmM4lzu9bCkPJ50FiH5C-6lROBCh7MgeeawAr4Lt62gjGLVI42wj0Gy-CihVQ9Al3bs5IZnc9YLL46fsgD0P08rNqS8IsNAyaogyGEimvJAhZs7YTuDvkRXEXgvobuw', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wNjhcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDcvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MTc3MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjg1MDMwMFwiLFwiSXJuXCI6XCIwYWE3ODk3YThkMTdlZWMxODJiZWRmZDYwMmM1ZTgxNzc4ZjlhODQ4YjQzNmQ5Y2MwZmQ3ZjZlNDQ1ZjE0MDJlXCIsXCJJcm5EdFwiOlwiMjAyMy0wOC0wNyAxNzoyNjowMFwifSIsImlzcyI6Ik5JQyBTYW5kYm94In0.fRg968H_rDru2X30LLOixu2xMAdoieXDyYumDNaRWECYScis8CAF5ftwe4tHZmYxIWRfhApUStMaFL9vy6NeXLKu1P5wQtCh9IrpzCxjauMSa7T3uZGOeqkOBV_plXKVXQAvXPT32umZTZf-BObU150v8gilTA2iwa8LXb1C7x6ONxaCc6zS8I5TRCNvx5ep2mQ-BNUGhFQXegMx2l7G35H79a_wloY5nzScnEVq6MqVhgriVhxYwwmC6z6VJ0U6Dzk3CdKj_LoN0WD_hNIfhqnFrvHUEuh0tty81gnArA3YzPYT9XbIasgmupCkj-Q_yLDEksmNbiRKo9KVTxLE1g', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (69, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-069', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '06:10 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-069070823', 'INV/23-24/-069-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (70, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-070', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '06:12 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-070070823', 'INV/23-24/-070-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (71, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-071', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '06:13 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-071070823', 'INV/23-24/-071-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (72, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-072', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '06:22 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-072070823', 'INV/23-24/-072-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (73, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-073', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '06:26 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-073070823', 'INV/23-24/-073-2023', 1, 1, '1.00', '112310168523270', '2023-08-07 18:30:00', '4b70c4783a6a2cf9c3aa68e1b95dc3444b4408ed12ae48cbf92a3c9c48769d45', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjg1MjMyNzQsXCJBY2tEdFwiOlwiMjAyMy0wOC0wNyAxODozMDowMFwiLFwiSXJuXCI6XCI0YjcwYzQ3ODNhNmEyY2Y5YzNhYTY4ZTFiOTVkYzM0NDRiNDQwOGVkMTJhZTQ4Y2JmOTJhM2M5YzQ4NzY5ZDQ1XCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDczXCIsXCJEdFwiOlwiMDcvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjg1MDMwMFwiLFwiUXR5XCI6MSxcIlVuaXRcIjpcIktHU1wiLFwiVW5pdFByaWNlXCI6MTUwMCxcIlRvdEFtdFwiOjE1MDAsXCJEaXNjb3VudFwiOjAsXCJBc3NBbXRcIjoxNTAwLFwiR3N0UnRcIjoxOCxcIklnc3RBbXRcIjoyNzAsXCJDZ3N0QW10XCI6MCxcIlNnc3RBbXRcIjowLFwiVG90SXRlbVZhbFwiOjE3NzB9XSxcIlZhbER0bHNcIjp7XCJBc3NWYWxcIjoxNTAwLFwiQ2dzdFZhbFwiOjAsXCJTZ3N0VmFsXCI6MCxcIklnc3RWYWxcIjoyNzAsXCJPdGhDaHJnXCI6MCxcIlJuZE9mZkFtdFwiOjAsXCJUb3RJbnZWYWxcIjoxNzcwfSxcIkFkZGxEb2NEdGxzXCI6W3tcIlVybFwiOlwiaHR0cHM6Ly9laW52LWFwaXNhbmRib3gubmljLmluXCIsXCJEb2NzXCI6XCJUZXN0IERvY1wiLFwiSW5mb1wiOlwiRG9jdW1lbnQgVGVzdFwifV19IiwiaXNzIjoiTklDIFNhbmRib3gifQ.B0lgxk5sOxP0YxAZykh5t79toOFM5z5WNq6ipO3aXJnW5OlXhESVo5uwSHK2EpgKN6yZhCYCYZHgmSb8RORu6hZtMlycoKRcxUxwDHiA9BGgLIahTah_wv1kYUx-9vmbMEv5HYXHVKn11MBnTRySz_6t04sd468ei8fXnMk5u7lfhQnrSxQg856ie9Kvof8Ndnk1ge5AjXqdBvManw581cmazEb4fHRZNRCU9FJjWErWlDXKrmZEejALpVIXLVbdcZQ74hrh7AfBlr3Q7JzofQRBNsKfqLg4TQdVckjaPnL59nuStGVfDMV6IzqE3wRl7LxypbpngcC1AGWllqLmRQ', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wNzNcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDcvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MTc3MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjg1MDMwMFwiLFwiSXJuXCI6XCI0YjcwYzQ3ODNhNmEyY2Y5YzNhYTY4ZTFiOTVkYzM0NDRiNDQwOGVkMTJhZTQ4Y2JmOTJhM2M5YzQ4NzY5ZDQ1XCIsXCJJcm5EdFwiOlwiMjAyMy0wOC0wNyAxODozMDowMFwifSIsImlzcyI6Ik5JQyBTYW5kYm94In0.UmVBWQ-klLcIH-vi7XoNrHIOHPH2WcbBLlfWY02_3nq4FfVb-8BFO-zcWrhGGCtSdkg5Jwvcsl4BkxLI5qT7G2Zcq3zwZdFK3ZNC9Sr5OWqAM1K_I_8VGM7frCB2RtwlyS1_EMRqftdbIZqGPGfOyUp2t1GfiBnB1DtzinUXuBQwgegzZ7LLsMXkZs43muiSHu0Rl2AdiYL4Sj-xf4BCAtJRE_FDCvWtPcPq_8SK2HGiW2FJb1D6Wk2F6VNzwKW2_-oXRPlsgO4xK61FDAftQQ2hGbeJAUR9jZDqwpH2muOVcqDAOL9JXzsoNf1WC3US2B4QipJ-yNOzZES06sfrdQ', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (75, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-074', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '08:13 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '2', '4000.00', '0', 'percent_wise', '0.00', '4000.00', '9', '', '9', '', '18', '720.00', NULL, '4000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '4720.00', '4720.00', 1, 'INV/23-24/-074070823', 'INV/23-24/-074-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (78, '2023-08-08', '2023-08-08', '', '1970-01-01', 'INV/23-24/-076', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-08', '11:01 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-076080823', 'INV/23-24/-076-2023', 1, 1, '1.00', '112310168532080', '2023-08-08 11:08:00', '7b4401eee3305ece3af67db3a287f4d6955976f8099d909b7a6ed6151a672bb5', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjg1MzIwNzgsXCJBY2tEdFwiOlwiMjAyMy0wOC0wOCAxMTowODowMFwiLFwiSXJuXCI6XCI3YjQ0MDFlZWUzMzA1ZWNlM2FmNjdkYjNhMjg3ZjRkNjk1NTk3NmY4MDk5ZDkwOWI3YTZlZDYxNTFhNjcyYmI1XCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDc2XCIsXCJEdFwiOlwiMDgvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjcyMDRcIixcIlF0eVwiOjEsXCJVbml0XCI6XCJLR1NcIixcIlVuaXRQcmljZVwiOjIwMDAsXCJUb3RBbXRcIjoyMDAwLFwiRGlzY291bnRcIjowLFwiQXNzQW10XCI6MjAwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6MzYwLFwiQ2dzdEFtdFwiOjAsXCJTZ3N0QW10XCI6MCxcIlRvdEl0ZW1WYWxcIjoyMzYwfV0sXCJWYWxEdGxzXCI6e1wiQXNzVmFsXCI6MjAwMCxcIkNnc3RWYWxcIjowLFwiU2dzdFZhbFwiOjAsXCJJZ3N0VmFsXCI6MzYwLFwiT3RoQ2hyZ1wiOjAsXCJSbmRPZmZBbXRcIjowLFwiVG90SW52VmFsXCI6MjM2MH0sXCJBZGRsRG9jRHRsc1wiOlt7XCJVcmxcIjpcImh0dHBzOi8vZWludi1hcGlzYW5kYm94Lm5pYy5pblwiLFwiRG9jc1wiOlwiVGVzdCBEb2NcIixcIkluZm9cIjpcIkRvY3VtZW50IFRlc3RcIn1dfSIsImlzcyI6Ik5JQyBTYW5kYm94In0.BgBgJCOOWv5-5riYDvsmv9kb_etW2b_BHMcJtdoTLLskkKrE4MTRQiRV3CiO-l7p-wRV5dPK-cFXz5xWGv_b7ce68eqARx1NHcwZU5WlG1qiC5h-zci3R7vkPtkD36RAB6un6MudAHpT7MpX5Qwx-THsavr8ZoVz8Sdi4drPvCVVyoznwe2fY7X0OSLt_GD0_XhvlicnMtk_WTLmL2bPA6zlhTEDIaS_hNmEVHFxPVfRnLo4z5KyaXZbunomOi0cJFEt74oPWG78s55I8uEA86JXDgBu4rftQtwlNWy3jPG9DmogwtTIByXNhDXLwl1rYM_GPSJqQFKykYqvFHT4dg', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wNzZcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDgvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MjM2MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjcyMDRcIixcIklyblwiOlwiN2I0NDAxZWVlMzMwNWVjZTNhZjY3ZGIzYTI4N2Y0ZDY5NTU5NzZmODA5OWQ5MDliN2E2ZWQ2MTUxYTY3MmJiNVwiLFwiSXJuRHRcIjpcIjIwMjMtMDgtMDggMTE6MDg6MDBcIn0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.2EU1G9AnJtDLhU9prlEJU86MH-dEXQPc6bgxvBajWkmMC4OqjyOQv1bwe3l4UAJ7dYTcJf_uuKqlAuKHmfRnvoeqdbiU9ZCERgkzal0AjM4jPGzuNyTiRBY7u65IZ624YDQA9qd4KOkBaIu5Sw1daLQNTm4czZLB4ylzVQw8XFF5RLvCc346ldLgSefAIRZBA-MekT3d7M2It7FwYJnfj6hAfXxC19kGl1aV6IM5gvZw90EGCmotzLUxAGJEDwue_nwI5pe4D3KAgMgUxqSxg8WfwLjAIiwfGshVWHgyeGVRoHSfq9DA0O866rlxphl2-J0380svEWp7IqFV15fqWw', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (79, '2023-08-08', '2023-08-08', '', '1970-01-01', 'INV/23-24/-077', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-08', '11:10 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-077080823', 'INV/23-24/-077-2023', 1, 1, '1.00', '112310168532180', '2023-08-08 11:15:00', 'd1315471d05e0ad90f848123c752dfd3f84525ffe0b8dcf5864dcab1c77fbb32', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjg1MzIxNzUsXCJBY2tEdFwiOlwiMjAyMy0wOC0wOCAxMToxNTowMFwiLFwiSXJuXCI6XCJkMTMxNTQ3MWQwNWUwYWQ5MGY4NDgxMjNjNzUyZGZkM2Y4NDUyNWZmZTBiOGRjZjU4NjRkY2FiMWM3N2ZiYjMyXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDc3XCIsXCJEdFwiOlwiMDgvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjg1MDMwMFwiLFwiUXR5XCI6MSxcIlVuaXRcIjpcIktHU1wiLFwiVW5pdFByaWNlXCI6MTUwMCxcIlRvdEFtdFwiOjE1MDAsXCJEaXNjb3VudFwiOjAsXCJBc3NBbXRcIjoxNTAwLFwiR3N0UnRcIjoxOCxcIklnc3RBbXRcIjoyNzAsXCJDZ3N0QW10XCI6MCxcIlNnc3RBbXRcIjowLFwiVG90SXRlbVZhbFwiOjE3NzB9XSxcIlZhbER0bHNcIjp7XCJBc3NWYWxcIjoxNTAwLFwiQ2dzdFZhbFwiOjAsXCJTZ3N0VmFsXCI6MCxcIklnc3RWYWxcIjoyNzAsXCJPdGhDaHJnXCI6MCxcIlJuZE9mZkFtdFwiOjAsXCJUb3RJbnZWYWxcIjoxNzcwfSxcIkFkZGxEb2NEdGxzXCI6W3tcIlVybFwiOlwiaHR0cHM6Ly9laW52LWFwaXNhbmRib3gubmljLmluXCIsXCJEb2NzXCI6XCJUZXN0IERvY1wiLFwiSW5mb1wiOlwiRG9jdW1lbnQgVGVzdFwifV19IiwiaXNzIjoiTklDIFNhbmRib3gifQ.XHxUtENpqyC8jlhx9xKaRZgaor-pGFIKDl67E9Kj9kqsOt8cZMoeZhdcOXkgzVzLtJZdyBXq4W_HhuRpnttnog1amXB9OW7S0MRRhludMDK7DtuFz7ycLVgYPLM4Sie7mAkbpispnHL0omlVYXM_5pAufserEQvI1y6qWoz76mpu2NU-UU9Tthqzd_DClNMiAIRX02MRoC8FmGr76SpYEGP20mMsHzDvk6ME9DWV1KLJ90qqgtynY303hsv1ecS4AmTdCTxtCcKBxvdKmueazPvwSbO-VnDXWbLdCe_X29z15agNRT2LmbyyGPfNME_x0nZ2fQHkBxHLOHLsIQ8bww', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wNzdcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDgvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MTc3MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjg1MDMwMFwiLFwiSXJuXCI6XCJkMTMxNTQ3MWQwNWUwYWQ5MGY4NDgxMjNjNzUyZGZkM2Y4NDUyNWZmZTBiOGRjZjU4NjRkY2FiMWM3N2ZiYjMyXCIsXCJJcm5EdFwiOlwiMjAyMy0wOC0wOCAxMToxNTowMFwifSIsImlzcyI6Ik5JQyBTYW5kYm94In0.MdMXRGiwxftgA6MJ6K0ButP9AWgV8HGeJ-0gZEKkM9gPynQA8nr9B3M30-6V9sOXmhEtKCAHV3KesUPGwkqhEjxyI6_1pN-pCTfupNyKOOdLmUzPhEl_OuAeceB7s-mgk9ASdcR22LknDFIMYPpFRlJCF5c_XKHCtJMOBk7j9xMLUahPpNKYV-M_1Jxr15iEa75kvUgXhqBCj17dj_uVaM8oWOpT4d4sSOgTWNcoDDen0O0E1fQy7tg8oG56vP0ZvHQom0fwZYyN84qAYY7RSsL7_9cD_oh6EeZjDfCempk6t4B6cMk7DbtYA6DrvrcM4DhhM4-NYC4PeVoEb_c4UA', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (80, '2023-08-08', '2023-08-08', '', '1970-01-01', 'INV/23-24/-078', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-08', '11:27 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-078080823', 'INV/23-24/-078-2023', 1, 1, '1.00', '112310168533130', '2023-08-08 11:46:00', '6cad16a07be8df50a51ff4b2fefebaa6ca23d44388dda13824d9a8e81ad3c790', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjg1MzMxMjksXCJBY2tEdFwiOlwiMjAyMy0wOC0wOCAxMTo0NjowMFwiLFwiSXJuXCI6XCI2Y2FkMTZhMDdiZThkZjUwYTUxZmY0YjJmZWZlYmFhNmNhMjNkNDQzODhkZGExMzgyNGQ5YThlODFhZDNjNzkwXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDc4XCIsXCJEdFwiOlwiMDgvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjcyMDRcIixcIlF0eVwiOjEsXCJVbml0XCI6XCJLR1NcIixcIlVuaXRQcmljZVwiOjIwMDAsXCJUb3RBbXRcIjoyMDAwLFwiRGlzY291bnRcIjowLFwiQXNzQW10XCI6MjAwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6MzYwLFwiQ2dzdEFtdFwiOjAsXCJTZ3N0QW10XCI6MCxcIlRvdEl0ZW1WYWxcIjoyMzYwfV0sXCJWYWxEdGxzXCI6e1wiQXNzVmFsXCI6MjAwMCxcIkNnc3RWYWxcIjowLFwiU2dzdFZhbFwiOjAsXCJJZ3N0VmFsXCI6MzYwLFwiT3RoQ2hyZ1wiOjAsXCJSbmRPZmZBbXRcIjowLFwiVG90SW52VmFsXCI6MjM2MH0sXCJBZGRsRG9jRHRsc1wiOlt7XCJVcmxcIjpcImh0dHBzOi8vZWludi1hcGlzYW5kYm94Lm5pYy5pblwiLFwiRG9jc1wiOlwiVGVzdCBEb2NcIixcIkluZm9cIjpcIkRvY3VtZW50IFRlc3RcIn1dfSIsImlzcyI6Ik5JQyBTYW5kYm94In0.KSqsmaRPwuZMLYUULwofH6TcvztuufBBQzGZIVgSs_Yf_FxtvW4nkDJPHCauSwASj8R68a8v5jh1DAM2Df5CC4ptgI6TQO0z3umx9AJFtXBkWGctDUKodxB_B8cG-0_5mZbnnuuwq15uPxIUbX3DAoCyZsJfUs9WNl4InmoWsvl3e7swI6EEj5gEUgl3aocp80QbqGV23GdsLkSosjVk45cGV4pVZximQD6Ci1u28AFtvaTe8wN9esRhWubglsqM_i3d7qLkwxCX9KLeM7_qtB6mF9u64l35jUmiY59t2jqxMOiVLskklzhpF95g9uGoK1uUprMMdaO3mEJF1qU32Q', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wNzhcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDgvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MjM2MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjcyMDRcIixcIklyblwiOlwiNmNhZDE2YTA3YmU4ZGY1MGE1MWZmNGIyZmVmZWJhYTZjYTIzZDQ0Mzg4ZGRhMTM4MjRkOWE4ZTgxYWQzYzc5MFwiLFwiSXJuRHRcIjpcIjIwMjMtMDgtMDggMTE6NDY6MDBcIn0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.13s9El9wl2wr3l3E8PxGBd3FQiyqC4a9iHvGxFuxnX7PBPtvxJ6wkukjyjnOwXXDKeEi9m32TyGYUwkKgXv5q0itjmF_xlxZb8eXBOflSeqbujkGS7S9_ZbBM4-5JBS8W_vKiun9V1xYuDinQOYf9qkz06r2W4Cxs_ZOwRUlpOoMF1F0aDpmBjdjK6pwp68OpgeJ07-BaLPAqJtBmhRyf9DbmCtN61dauk93FUic5MkzS_NR8k2IrM5EyHoK_U5wdB6fxG9U4V47InrnRPOXQEO059nx5YkwCT0tbl67X1AWTi2wuwxY4rfJLj_xh2u1CWyyjrTlkv1WTn9OBSFaUg', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (85, '2023-08-08', '2023-08-08', '', '1970-01-01', 'INV/23-24/-083', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-08', '04:32 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '2', '4000.00', '0', 'percent_wise', '0.00', '4000.00', '9', '', '9', '', '18', '720.00', NULL, '4000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '4720.00', '4720.00', 1, 'INV/23-24/-083080823', 'INV/23-24/-083-2023', 1, 1, '2.00', '112310168540970', '2023-08-08 16:37:00', '151ce9d601e9d23e6a12919ac1cbea1ffd8a8579e411f950d54f18002269498c', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjg1NDA5NzAsXCJBY2tEdFwiOlwiMjAyMy0wOC0wOCAxNjozNzowMFwiLFwiSXJuXCI6XCIxNTFjZTlkNjAxZTlkMjNlNmExMjkxOWFjMWNiZWExZmZkOGE4NTc5ZTQxMWY5NTBkNTRmMTgwMDIyNjk0OThjXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDgzXCIsXCJEdFwiOlwiMDgvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjcyMDRcIixcIlF0eVwiOjIsXCJVbml0XCI6XCJLR1NcIixcIlVuaXRQcmljZVwiOjIwMDAsXCJUb3RBbXRcIjo0MDAwLFwiRGlzY291bnRcIjowLFwiQXNzQW10XCI6NDAwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6NzIwLFwiQ2dzdEFtdFwiOjAsXCJTZ3N0QW10XCI6MCxcIlRvdEl0ZW1WYWxcIjo0NzIwfV0sXCJWYWxEdGxzXCI6e1wiQXNzVmFsXCI6NDAwMCxcIkNnc3RWYWxcIjowLFwiU2dzdFZhbFwiOjAsXCJJZ3N0VmFsXCI6NzIwLFwiT3RoQ2hyZ1wiOjAsXCJSbmRPZmZBbXRcIjowLFwiVG90SW52VmFsXCI6NDcyMH0sXCJBZGRsRG9jRHRsc1wiOlt7XCJVcmxcIjpcImh0dHBzOi8vZWludi1hcGlzYW5kYm94Lm5pYy5pblwiLFwiRG9jc1wiOlwiVGVzdCBEb2NcIixcIkluZm9cIjpcIkRvY3VtZW50IFRlc3RcIn1dfSIsImlzcyI6Ik5JQyBTYW5kYm94In0.hX9ZmcPArxMce8XgBBad2V9ZrE0v54Tbcw4z1ilej8ByZpDMuw544fV5tFiA5snEeyiG-Xw7D2H3l25KtuF6gQ1ui5q5IAxjSZa86IErWd8j4wriHeG-r4A8GNxSGH6LktdVFjPG7dtjzGqFoZdIKSSZi_KBsih0GWFlbzSeCj1oaIKO8PFFYOYQn1yWrco_tbSrTrZIWT4Qms3Em8VRRDO2w_fmsa1942HBD_HLOtGbqbrh3NS4hJ0uj3CO4X8RrGaNDstxL0NbG8vtnnY04j2UTEG7hz1gxTYrF9tF_4EwQBPd7JR09snSNGIWoifIn3-HgCMXmFMowH2CGj0AeQ', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wODNcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDgvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6NDcyMCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjcyMDRcIixcIklyblwiOlwiMTUxY2U5ZDYwMWU5ZDIzZTZhMTI5MTlhYzFjYmVhMWZmZDhhODU3OWU0MTFmOTUwZDU0ZjE4MDAyMjY5NDk4Y1wiLFwiSXJuRHRcIjpcIjIwMjMtMDgtMDggMTY6Mzc6MDBcIn0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.zYmOFn07VTd32oL0FL7xzwjIckE1ppw0EH3rddIIyosH8S1OPgyNha_W5LFPo_sr-TSOrC1IjsiSPeH8kCLRDyPWE8XjXmYtFdhjCdwH3bicvO9_LuQ0e51ahEEut9S7WvzFqR5B04p1CVZMv-5Mif4gfbcBLPow4pZYo-sey5qefDGFBVEJoW166wQiQtgTDuwd7ocMl275_8mNhsrwWrPNjxFdibpIEX7_6yjVVGEt4L8SYnRBnooZ5CkBc1yhcPHtz3gbcLwZa1LMx69XPyT1vqQd-bDC6vFwGJaXhzzXkkGM6gS8ECti4OlwCgmBP31hYRxVUiR4eMRraI_hjQ', 'ACT', '171010257178', '2023-08-08 16:37:00', '2023-08-09 23:59:00', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (86, '2023-08-09', '2023-08-09', '', '1970-01-01', 'INV/23-24/-084', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-09', '03:39 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '2', '4000.00', '0', 'percent_wise', '0.00', '4000.00', '9', '', '9', '', '18', '720.00', NULL, '4000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '4720.00', '4720.00', 1, 'INV/23-24/-084090823', 'INV/23-24/-084-2023', 1, 1, '2.00', '112310168567550', '2023-08-09 15:44:00', '059469e84b98cd0a03db32dbd23bf9c161c7ce19dd1078f83342c5e1a442622a', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjg1Njc1NTEsXCJBY2tEdFwiOlwiMjAyMy0wOC0wOSAxNTo0NDowMFwiLFwiSXJuXCI6XCIwNTk0NjllODRiOThjZDBhMDNkYjMyZGJkMjNiZjljMTYxYzdjZTE5ZGQxMDc4ZjgzMzQyYzVlMWE0NDI2MjJhXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDg0XCIsXCJEdFwiOlwiMDkvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiTVlPRkZJQ0UgRVJQXCIsXCJBZGRyMVwiOlwiOTEsIERyLiBKYWdhbmF0aGFuIE5hZ2FyLCBDaXZpbCBBZXJvZHJvbWUgcG9zdCwgQ01DIG9wcFwiLFwiQWRkcjJcIjpcIkF2aW5hc2hpIFJvYWQsIEhvcGVzIENvbGxlZ2VcIixcIkxvY1wiOlwiQ29pbWJhdG9yZVwiLFwiUGluXCI6NTYwMDkxLFwiU3RjZFwiOlwiMjlcIixcIlBoXCI6XCI3MzczMzMzMzIxXCIsXCJFbVwiOlwiaW5mb0BpZHJlYW1kZXZlbG9wZXJzLmNvbVwifSxcIkJ1eWVyRHRsc1wiOntcIkdzdGluXCI6XCIzM0FEWFBUMzI5MU4yWkpcIixcIkxnbE5tXCI6XCJTTUsgSU5EVVNUUklFU1wiLFwiUG9zXCI6XCIzM1wiLFwiQWRkcjFcIjpcIjMvMjI2RCwgTkFEVVBBTEFZQU0gUk9BRFwiLFwiQWRkcjJcIjpcIlBBVFRBTkFNIFBPU1QsT05ESVBVRFVSIChWSUEpXCIsXCJMb2NcIjpcIkNPSU1CQVRPUkVcIixcIlBpblwiOjY0MTAxNCxcIlBoXCI6XCI3ODEwMDI4MjIyXCIsXCJFbVwiOlwianBAaWRyZWFtZGV2ZWxvcGVycy5jb21cIixcIlN0Y2RcIjpcIjMzXCJ9LFwiSXRlbUxpc3RcIjpbe1wiSXRlbU5vXCI6MCxcIlNsTm9cIjpcIjFcIixcIklzU2VydmNcIjpcIk5cIixcIkhzbkNkXCI6XCI3MjA0XCIsXCJRdHlcIjoyLFwiVW5pdFwiOlwiS0dTXCIsXCJVbml0UHJpY2VcIjoyMDAwLFwiVG90QW10XCI6NDAwMCxcIkRpc2NvdW50XCI6MCxcIkFzc0FtdFwiOjQwMDAsXCJHc3RSdFwiOjE4LFwiSWdzdEFtdFwiOjcyMCxcIkNnc3RBbXRcIjowLFwiU2dzdEFtdFwiOjAsXCJUb3RJdGVtVmFsXCI6NDcyMH1dLFwiVmFsRHRsc1wiOntcIkFzc1ZhbFwiOjQwMDAsXCJDZ3N0VmFsXCI6MCxcIlNnc3RWYWxcIjowLFwiSWdzdFZhbFwiOjcyMCxcIk90aENocmdcIjowLFwiUm5kT2ZmQW10XCI6MCxcIlRvdEludlZhbFwiOjQ3MjB9LFwiQWRkbERvY0R0bHNcIjpbe1wiVXJsXCI6XCJodHRwczovL2VpbnYtYXBpc2FuZGJveC5uaWMuaW5cIixcIkRvY3NcIjpcIlRlc3QgRG9jXCIsXCJJbmZvXCI6XCJEb2N1bWVudCBUZXN0XCJ9XX0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.usCF_IVCfEhZLrkmxcVbpHfKPMEilcab2a3NJJsb42f2Zc_dj31Nrl02cSy_rzEicuImGQrWjmtPg88rux3bnfFkpmsQFkrD2dtuLR5MdwICV_lsJkaD3mOdlRXvEbNlJPOmM7tiXDBz2tmb_LtRQetYBJ8_CWvPCHKflXW7W8C4puQDTNi9KcjfQr4Cr0j4DG71kIq7Mo0JSuzxiWm8NClSxWlCGzFd50_1g2HjwEmmvHtaf1iDO6ozbP1SDjaUXVbRfOzkIE-IWRyXLXy5s2RX0DUzw1ojk4tdfmMMIAgs7ajJ-810CEzXSri9qxWcZdE0IEpFSfDvDpWXaesevw', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wODRcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDkvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6NDcyMCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjcyMDRcIixcIklyblwiOlwiMDU5NDY5ZTg0Yjk4Y2QwYTAzZGIzMmRiZDIzYmY5YzE2MWM3Y2UxOWRkMTA3OGY4MzM0MmM1ZTFhNDQyNjIyYVwiLFwiSXJuRHRcIjpcIjIwMjMtMDgtMDkgMTU6NDQ6MDBcIn0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.vpnKl1QHFMLTwsobuMfBed8gcYhC2ScrzoqA8OliCNwkLhi5sTYnQXL7AuoTzlEx24TTv3aHRaRTSpSuZuI4DGIc5E5SOArI6WgY-EA3XaqFWRIbwiBrX0-rG1jJ9HYKL5bV9KAGw35CJss2-NcY68bpu1_XlXqQZV9fnaxQ8PfTAcITKBpe67nHc2iNkPMrjPfPsCdeH1BtcPJ39XkIj5wjThmCC9zHnzb9c6knSQPv_WWgGFLJw2Zpl5N6DBlX-9MuoCIB02GowfC1dx6i-1YHmHEEPS9y6f9i_2jpO6dqHdX3IPNj70kyro5uuBn9QXZHHKJ_Ex1HcuMqHkRjaw', 'ACT', '191010257707', '2023-08-09 15:44:00', '2023-08-10 23:59:00', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (87, '2023-08-10', '2023-08-10', '', '1970-01-01', 'INV/23-24/-085', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-10', '12:17 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300||7204', NULL, '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', 'KGS||KGS', '1500||2000', '2||2', '3000.00||4000.00', '0||0', 'percent_wise', '0.00||0.00', '3000.00||4000.00', '9||9', '270.00||360.00', '9||9', '270.00||360.00', '18||18', '540.00||720.00', '3540.00||4720.00', '8260.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', NULL, '1||1', '8260.00', '8260.00', 1, 'INV/23-24/-085100823', 'INV/23-24/-085-2023', 1, 1, NULL, '112310168579040', '2023-08-10 12:21:00', '04b431b8789a05cbfc80238f6063cfb990ee99e86df045c79acad1f69e5055cc', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjg1NzkwNDIsXCJBY2tEdFwiOlwiMjAyMy0wOC0xMCAxMjoyMTowMFwiLFwiSXJuXCI6XCIwNGI0MzFiODc4OWEwNWNiZmM4MDIzOGY2MDYzY2ZiOTkwZWU5OWU4NmRmMDQ1Yzc5YWNhZDFmNjllNTA1NWNjXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDg1XCIsXCJEdFwiOlwiMTAvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiTVlPRkZJQ0UgRVJQXCIsXCJBZGRyMVwiOlwiOTEsIERyLiBKYWdhbmF0aGFuIE5hZ2FyLCBDaXZpbCBBZXJvZHJvbWUgcG9zdCwgQ01DIG9wcFwiLFwiQWRkcjJcIjpcIkF2aW5hc2hpIFJvYWQsIEhvcGVzIENvbGxlZ2VcIixcIkxvY1wiOlwiQ29pbWJhdG9yZVwiLFwiUGluXCI6NTYwMDkxLFwiU3RjZFwiOlwiMjlcIixcIlBoXCI6XCI3MzczMzMzMzIxXCIsXCJFbVwiOlwiaW5mb0BpZHJlYW1kZXZlbG9wZXJzLmNvbVwifSxcIkJ1eWVyRHRsc1wiOntcIkdzdGluXCI6XCIzM0FEWFBUMzI5MU4yWkpcIixcIkxnbE5tXCI6XCJTTUsgSU5EVVNUUklFU1wiLFwiUG9zXCI6XCIzM1wiLFwiQWRkcjFcIjpcIjMvMjI2RCwgTkFEVVBBTEFZQU0gUk9BRFwiLFwiQWRkcjJcIjpcIlBBVFRBTkFNIFBPU1QsT05ESVBVRFVSIChWSUEpXCIsXCJMb2NcIjpcIkNPSU1CQVRPUkVcIixcIlBpblwiOjY0MTAxNCxcIlBoXCI6XCI3ODEwMDI4MjIyXCIsXCJFbVwiOlwianBAaWRyZWFtZGV2ZWxvcGVycy5jb21cIixcIlN0Y2RcIjpcIjMzXCJ9LFwiSXRlbUxpc3RcIjpbe1wiSXRlbU5vXCI6MCxcIlNsTm9cIjpcIjFcIixcIklzU2VydmNcIjpcIk5cIixcIkhzbkNkXCI6XCI4NTAzMDBcIixcIlF0eVwiOjIsXCJVbml0XCI6XCJLR1NcIixcIlVuaXRQcmljZVwiOjE1MDAsXCJUb3RBbXRcIjozMDAwLFwiRGlzY291bnRcIjowLFwiQXNzQW10XCI6MzAwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6NTQwLjAwLFwiQ2dzdEFtdFwiOjAsXCJTZ3N0QW10XCI6MCxcIlRvdEl0ZW1WYWxcIjozNTQwfSx7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMlwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjcyMDRcIixcIlF0eVwiOjIsXCJVbml0XCI6XCJLR1NcIixcIlVuaXRQcmljZVwiOjIwMDAsXCJUb3RBbXRcIjo0MDAwLFwiRGlzY291bnRcIjowLFwiQXNzQW10XCI6NDAwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6NzIwLjAwLFwiQ2dzdEFtdFwiOjAsXCJTZ3N0QW10XCI6MCxcIlRvdEl0ZW1WYWxcIjo0NzIwfV0sXCJWYWxEdGxzXCI6e1wiQXNzVmFsXCI6NzAwMCxcIkNnc3RWYWxcIjowLFwiU2dzdFZhbFwiOjAsXCJJZ3N0VmFsXCI6MTI2MCxcIk90aENocmdcIjowLFwiUm5kT2ZmQW10XCI6MCxcIlRvdEludlZhbFwiOjgyNjB9LFwiQWRkbERvY0R0bHNcIjpbe1wiVXJsXCI6XCJodHRwczovL2VpbnYtYXBpc2FuZGJveC5uaWMuaW5cIixcIkRvY3NcIjpcIlRlc3QgRG9jXCIsXCJJbmZvXCI6XCJEb2N1bWVudCBUZXN0XCJ9XX0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.5BKSHMzWY9mmASS38YwPnGC7KpE6rK7pzLYPC82VkES5rsPEmqtkFfTZxx555Ru4ZjL5njKVkYnXGasXB5IdtsP91-9_DAUiLGt3H3MnuB1mwBYBKLqopG7jnp0kTc50ZDMuFu6vNf1pQ5Fuce6SPrBEdl1StdRc3QdR1sb_WGKQS4YxsWUkGBiY7R7Qp2bHuu020oE0cBsCl3KDbCIW_2G78ccn_a_8h59tqNYterSEThhZsckbBma2yd04FtGp4Lx7Ns78HlhfU8jLJP1rpXIuW3gI-6R4FUgkz3p5OhbVX-WdpIzW6dlerxG65R3mo8OGHwy4SkesQwZ7SBRt8Q', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wODVcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMTAvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6ODI2MCxcIkl0ZW1DbnRcIjoyLFwiTWFpbkhzbkNvZGVcIjpcIjcyMDRcIixcIklyblwiOlwiMDRiNDMxYjg3ODlhMDVjYmZjODAyMzhmNjA2M2NmYjk5MGVlOTllODZkZjA0NWM3OWFjYWQxZjY5ZTUwNTVjY1wiLFwiSXJuRHRcIjpcIjIwMjMtMDgtMTAgMTI6MjE6MDBcIn0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.uZVds0Mve2YEJSPXbZOMQiYHPvSvkgJe62L9Uz5Z8G4q_OLDD7c7uKZ0hsef9j0Mm12f8Xfjx3RWiocBCgjdQZypa_gHvrEaICaQgf79y3QDIl_LlAkR4BF2npNgYgJ0-b2thucFfc_GwfpkSpDMU8rnDKqVIijy2y_vFGFysAhJgJyD5_6VtmdngwRX88ilYOaOt9e-_BWY0wyKQGcNA6uAHADFnhF3lCNuVhqR52VYzd1dyI7_3W8zQ6aeQWae6JDqxXqpP4kOWtG06kSTLzQGiGDls-A49WMkDMt-XIOiKjPl4_ps3YnRt13P2CrUKUi1rD-O69u341uVzRhLkA', 'ACT', '', '', '', '', '', '', 1, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (88, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-086', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '04:57 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '2', '3000.00', '0', 'percent_wise', '0.00', '3000.00', '9', '', '9', '', '18', '540.00', NULL, '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '3540.00', 1, 'INV/23-24/-086140823', 'INV/23-24/-086-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (89, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-087', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '05:01 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-087140823', 'INV/23-24/-087-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (90, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-088', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '05:26 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-088140823', 'INV/23-24/-088-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (91, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-089', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '05:27 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-089140823', 'INV/23-24/-089-2023', 1, 1, '1.00', '{', '{', '{', '{', '{', '{', '{', '{', '', '{', '{', '{', 1, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (92, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-090', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '05:29 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-090140823', 'INV/23-24/-090-2023', 1, 1, '1.00', '{', '{', '{', '{', '{', '{', '{', '{', '', '{', '{', '{', 1, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (93, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-091', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '05:29 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '2', '4000.00', '0', 'percent_wise', '0.00', '4000.00', '9', '', '9', '', '18', '720.00', NULL, '4000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '4720.00', '4720.00', 1, 'INV/23-24/-091140823', 'INV/23-24/-091-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (94, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-092', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '05:31 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '2', '4000.00', '0', 'percent_wise', '0.00', '4000.00', '9', '', '9', '', '18', '720.00', NULL, '4000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '4720.00', '4720.00', 1, 'INV/23-24/-092140823', 'INV/23-24/-092-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (95, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-093', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '05:32 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '2', '3000.00', '0', 'percent_wise', '0.00', '3000.00', '9', '', '9', '', '18', '540.00', NULL, '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '3540.00', 1, 'INV/23-24/-093140823', 'INV/23-24/-093-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (96, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-094', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '05:33 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '2', '3000.00', '0', 'percent_wise', '0.00', '3000.00', '9', '', '9', '', '18', '540.00', NULL, '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '3540.00', 1, 'INV/23-24/-094140823', 'INV/23-24/-094-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (97, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-095', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '05:34 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '2', '4000.00', '0', 'percent_wise', '0.00', '4000.00', '9', '', '9', '', '18', '720.00', NULL, '4000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '4720.00', '4720.00', 1, 'INV/23-24/-095140823', 'INV/23-24/-095-2023', 1, 1, '2.00', '{', '{', '{', '{', '{', '{', '{', '{', '', '{', '{', '{', 1, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (98, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-096', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '05:35 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '2', '4000.00', '0', 'percent_wise', '0.00', '4000.00', '9', '', '9', '', '18', '720.00', NULL, '4000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '4720.00', '4720.00', 1, 'INV/23-24/-096140823', 'INV/23-24/-096-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (99, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-097', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '06:16 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '2', '3000.00', '0', 'percent_wise', '0.00', '3000.00', '9', '', '9', '', '18', '540.00', NULL, '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '3540.00', 1, 'INV/23-24/-097140823', 'INV/23-24/-097-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (100, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-098', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '06:18 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '2', '4000.00', '0', 'percent_wise', '0.00', '4000.00', '9', '', '9', '', '18', '720.00', NULL, '4000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '4720.00', '4720.00', 1, 'INV/23-24/-098140823', 'INV/23-24/-098-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (101, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-099', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '06:18 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '2', '3000.00', '0', 'percent_wise', '0.00', '3000.00', '9', '', '9', '', '18', '540.00', NULL, '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '3540.00', 1, 'INV/23-24/-099140823', 'INV/23-24/-099-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (102, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-100', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '06:26 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '2', '3000.00', '0', 'percent_wise', '0.00', '3000.00', '9', '', '9', '', '18', '540.00', NULL, '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '3540.00', 1, 'INV/23-24/-100140823', 'INV/23-24/-100-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (103, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-101', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '06:27 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '2', '3000.00', '0', 'percent_wise', '0.00', '3000.00', '9', '', '9', '', '18', '540.00', NULL, '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '3540.00', 1, 'INV/23-24/-101140823', 'INV/23-24/-101-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (104, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-102', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '06:28 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '2', '3000.00', '0', 'percent_wise', '0.00', '3000.00', '9', '', '9', '', '18', '540.00', NULL, '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '3540.00', 1, 'INV/23-24/-102140823', 'INV/23-24/-102-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (105, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-103', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '06:30 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '3', '4500.00', '0', 'percent_wise', '0.00', '4500.00', '9', '', '9', '', '18', '810.00', NULL, '4500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '5310.00', '5310.00', 1, 'INV/23-24/-103140823', 'INV/23-24/-103-2023', 1, 1, '3.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (106, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-104', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '06:32 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '7', '10500.00', '0', 'percent_wise', '0.00', '10500.00', '9', '', '9', '', '18', '1890.00', NULL, '10500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '12390.00', '12390.00', 1, 'INV/23-24/-104140823', 'INV/23-24/-104-2023', 1, 1, '7.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (107, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-105', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '06:33 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '8', '16000.00', '0', 'percent_wise', '0.00', '16000.00', '9', '', '9', '', '18', '2880.00', NULL, '16000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '18880.00', '18880.00', 1, 'INV/23-24/-105140823', 'INV/23-24/-105-2023', 1, 1, '8.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (108, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-106', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '06:38 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '4', '6000.00', '0', 'percent_wise', '0.00', '6000.00', '9', '', '9', '', '18', '1080.00', NULL, '6000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '7080.00', '7080.00', 1, 'INV/23-24/-106140823', 'INV/23-24/-106-2023', 1, 1, '4.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (109, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-107', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '06:40 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '8', '12000.00', '0', 'percent_wise', '0.00', '12000.00', '9', '', '9', '', '18', '2160.00', NULL, '12000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '14160.00', '14160.00', 1, 'INV/23-24/-107140823', 'INV/23-24/-107-2023', 1, 1, '8.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (110, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-108', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '06:41 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '4', '6000.00', '0', 'percent_wise', '0.00', '6000.00', '9', '', '9', '', '18', '1080.00', NULL, '6000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '7080.00', '7080.00', 1, 'INV/23-24/-108140823', 'INV/23-24/-108-2023', 1, 1, '4.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (111, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-109', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '06:42 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '5', '7500.00', '0', 'percent_wise', '0.00', '7500.00', '9', '', '9', '', '18', '1350.00', NULL, '7500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '8850.00', '8850.00', 1, 'INV/23-24/-109140823', 'INV/23-24/-109-2023', 1, 1, '5.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (112, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-110', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '06:44 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '7', '14000.00', '0', 'percent_wise', '0.00', '14000.00', '9', '', '9', '', '18', '2520.00', NULL, '14000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '16520.00', '16520.00', 1, 'INV/23-24/-110140823', 'INV/23-24/-110-2023', 1, 1, '7.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (113, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-111', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '06:45 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '7', '10500.00', '0', 'percent_wise', '0.00', '10500.00', '9', '', '9', '', '18', '1890.00', NULL, '10500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '12390.00', '12390.00', 1, 'INV/23-24/-111140823', 'INV/23-24/-111-2023', 1, 1, '7.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (114, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-112', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '07:00 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '2', '3000.00', '0', 'percent_wise', '0.00', '3000.00', '9', '', '9', '', '18', '540.00', NULL, '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '3540.00', 1, 'INV/23-24/-112140823', 'INV/23-24/-112-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (115, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-113', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '07:05 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '2', '3000.00', '0', 'percent_wise', '0.00', '3000.00', '9', '', '9', '', '18', '540.00', NULL, '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '3540.00', 1, 'INV/23-24/-113140823', 'INV/23-24/-113-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (116, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-114', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '07:06 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '2', '3000.00', '0', 'percent_wise', '0.00', '3000.00', '9', '', '9', '', '18', '540.00', NULL, '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '3540.00', 1, 'INV/23-24/-114140823', 'INV/23-24/-114-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (117, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-115', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '07:08 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '2', '3000.00', '0', 'percent_wise', '0.00', '3000.00', '9', '', '9', '', '18', '540.00', NULL, '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '3540.00', 1, 'INV/23-24/-115140823', 'INV/23-24/-115-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (118, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-116', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '07:09 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '2', '3000.00', '0', 'percent_wise', '0.00', '3000.00', '9', '', '9', '', '18', '540.00', NULL, '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '3540.00', 1, 'INV/23-24/-116140823', 'INV/23-24/-116-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (119, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-117', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '07:12 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '5', '7500.00', '0', 'percent_wise', '0.00', '7500.00', '9', '', '9', '', '18', '1350.00', NULL, '7500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '8850.00', '8850.00', 1, 'INV/23-24/-117140823', 'INV/23-24/-117-2023', 1, 1, '5.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (120, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-118', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '07:21 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '2', '4000.00', '0', 'percent_wise', '0.00', '4000.00', '9', '', '9', '', '18', '720.00', NULL, '4000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '4720.00', '4720.00', 1, 'INV/23-24/-118140823', 'INV/23-24/-118-2023', 1, 1, '2.00', '152310022192181', '2023-08-14 19:25:15', 'f6e7fff13441e086f977990a0e7ef54a77919889fd983cd515bfec67241c5ea4', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxNTIzMTAwMjIxOTIxODEsXCJBY2tEdFwiOlwiMjAyMy0wOC0xNCAxOToyNToxNVwiLFwiSXJuXCI6XCJmNmU3ZmZmMTM0NDFlMDg2Zjk3Nzk5MGEwZTdlZjU0YTc3OTE5ODg5ZmQ5ODNjZDUxNWJmZWM2NzI0MWM1ZWE0XCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMTE4XCIsXCJEdFwiOlwiMTQvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMzRBQUNDQzE1OTZRMDAyXCIsXCJMZ2xObVwiOlwiTVlPRkZJQ0UgRVJQXCIsXCJBZGRyMVwiOlwiOTEsIERyLiBKYWdhbmF0aGFuIE5hZ2FyLCBDaXZpbCBBZXJvZHJvbWUgcG9zdCwgQ01DIG9wcFwiLFwiQWRkcjJcIjpcIkF2aW5hc2hpIFJvYWQsIEhvcGVzIENvbGxlZ2VcIixcIkxvY1wiOlwiQ29pbWJhdG9yZVwiLFwiUGluXCI6NjA1MDAxLFwiU3RjZFwiOlwiMzRcIixcIlBoXCI6XCI3MzczMzMzMzIxXCIsXCJFbVwiOlwiaW5mb0BpZHJlYW1kZXZlbG9wZXJzLmNvbVwifSxcIkJ1eWVyRHRsc1wiOntcIkdzdGluXCI6XCIzM0FEWFBUMzI5MU4yWkpcIixcIkxnbE5tXCI6XCJTTUsgSU5EVVNUUklFU1wiLFwiUG9zXCI6XCIzM1wiLFwiQWRkcjFcIjpcIjMvMjI2RCwgTkFEVVBBTEFZQU0gUk9BRFwiLFwiQWRkcjJcIjpcIlBBVFRBTkFNIFBPU1QsT05ESVBVRFVSIChWSUEpXCIsXCJMb2NcIjpcIkNPSU1CQVRPUkVcIixcIlBpblwiOjY0MTAxNCxcIlBoXCI6XCI3ODEwMDI4MjIyXCIsXCJFbVwiOlwianBAaWRyZWFtZGV2ZWxvcGVycy5jb21cIixcIlN0Y2RcIjpcIjMzXCJ9LFwiSXRlbUxpc3RcIjpbe1wiSXRlbU5vXCI6MCxcIlNsTm9cIjpcIjFcIixcIklzU2VydmNcIjpcIk5cIixcIkhzbkNkXCI6XCI3MjA0XCIsXCJRdHlcIjoyLFwiVW5pdFwiOlwiS0dTXCIsXCJVbml0UHJpY2VcIjoyMDAwLFwiVG90QW10XCI6NDAwMCxcIkRpc2NvdW50XCI6MCxcIkFzc0FtdFwiOjQwMDAsXCJHc3RSdFwiOjE4LFwiSWdzdEFtdFwiOjcyMCxcIkNnc3RBbXRcIjowLFwiU2dzdEFtdFwiOjAsXCJUb3RJdGVtVmFsXCI6NDcyMH1dLFwiVmFsRHRsc1wiOntcIkFzc1ZhbFwiOjQwMDAsXCJDZ3N0VmFsXCI6MCxcIlNnc3RWYWxcIjowLFwiSWdzdFZhbFwiOjcyMCxcIk90aENocmdcIjowLFwiUm5kT2ZmQW10XCI6MCxcIlRvdEludlZhbFwiOjQ3MjB9fSIsImlzcyI6Ik5JQyBTYW5kYm94In0.BsVEUJpPyHAnfdr6c8OV_OhcyLGxYSzgmuGyZiuD0OC2IofogfyXsYSao9xFeXUazfdrCeihHXXl_xxwUhhlUxJacwuYV9MvAon8nkEeFpUxccOdRtn3UehHUQls6j7fyZpYTOUsOK_GdxI2eoMCH5Hve3dpBr2g1yn_p2caMH4mLowoKzrsg_vCKWVlCUEsu4M_jwfgkVSrJNwQw5m-oVS20OU8bVJcOynx-AJnqmBHF7rQZa0E7Th1ic3Er6tZ-TNPyOwqv48e1OzWel-kxsYT3Z4DSMq_DdQ-G4UIC9M7GtAmdWFhFoPh0PjLrSKVF_hroQ7wFNJXIQpWQ1XVUg', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjM0QUFDQ0MxNTk2UTAwMlwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0xMThcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMTQvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6NDcyMCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjcyMDRcIixcIklyblwiOlwiZjZlN2ZmZjEzNDQxZTA4NmY5Nzc5OTBhMGU3ZWY1NGE3NzkxOTg4OWZkOTgzY2Q1MTViZmVjNjcyNDFjNWVhNFwiLFwiSXJuRHRcIjpcIjIwMjMtMDgtMTQgMTk6MjU6MTVcIn0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.lcZwflTJFMJQuBUKkiP45Zqo1eX1eEuDZSufE6sSA1eBTn0JY_gimELZ498aURiiKPrH4sSwg_PYlLy2G94C8lMcgfxvMGGkJYxeHfshRTPGv-i-8uRu4bpFSVrNH5-lze_MUqSB2Ef0i96pa4bwhBIJLDi4j0PIfnmJZTFTAt22Ik6VeVXz5CIvewic_wSaoguaftW3zD_10LIRonzROtARzwdbwVGBmuI8FT2rNT7nd0fE1lKk1w21s2oFFR9qgguKFOelECIYZdJUkxcB77H3f-oJHxs7qPFs52MC0ppSfaufDD4Hlv5z0vr84Igw5F2OP_KI8DICdXAM5TcQ0g', 'ACT', 'n', 'n', 'n', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (121, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-119', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '07:49 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '2', '3000.00', '0', 'percent_wise', '0.00', '3000.00', '9', '', '9', '', '18', '540.00', NULL, '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '3540.00', 1, 'INV/23-24/-119140823', 'INV/23-24/-119-2023', 1, 1, '2.00', '152310022192297', '2023-08-14 19:53:04', '4f75ba67765c8973ea6137599990c7c3f772e8889f3fd37bc411b709d5b22309', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxNTIzMTAwMjIxOTIyOTcsXCJBY2tEdFwiOlwiMjAyMy0wOC0xNCAxOTo1MzowNFwiLFwiSXJuXCI6XCI0Zjc1YmE2Nzc2NWM4OTczZWE2MTM3NTk5OTkwYzdjM2Y3NzJlODg4OWYzZmQzN2JjNDExYjcwOWQ1YjIyMzA5XCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMTE5XCIsXCJEdFwiOlwiMTQvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMzRBQUNDQzE1OTZRMDAyXCIsXCJMZ2xObVwiOlwiTVlPRkZJQ0UgRVJQXCIsXCJBZGRyMVwiOlwiOTEsIERyLiBKYWdhbmF0aGFuIE5hZ2FyLCBDaXZpbCBBZXJvZHJvbWUgcG9zdCwgQ01DIG9wcFwiLFwiQWRkcjJcIjpcIkF2aW5hc2hpIFJvYWQsIEhvcGVzIENvbGxlZ2VcIixcIkxvY1wiOlwiQ29pbWJhdG9yZVwiLFwiUGluXCI6NjA1MDAxLFwiU3RjZFwiOlwiMzRcIixcIlBoXCI6XCI3MzczMzMzMzIxXCIsXCJFbVwiOlwiaW5mb0BpZHJlYW1kZXZlbG9wZXJzLmNvbVwifSxcIkJ1eWVyRHRsc1wiOntcIkdzdGluXCI6XCIzM0FEWFBUMzI5MU4yWkpcIixcIkxnbE5tXCI6XCJTTUsgSU5EVVNUUklFU1wiLFwiUG9zXCI6XCIzM1wiLFwiQWRkcjFcIjpcIjMvMjI2RCwgTkFEVVBBTEFZQU0gUk9BRFwiLFwiQWRkcjJcIjpcIlBBVFRBTkFNIFBPU1QsT05ESVBVRFVSIChWSUEpXCIsXCJMb2NcIjpcIkNPSU1CQVRPUkVcIixcIlBpblwiOjY0MTAxNCxcIlBoXCI6XCI3ODEwMDI4MjIyXCIsXCJFbVwiOlwianBAaWRyZWFtZGV2ZWxvcGVycy5jb21cIixcIlN0Y2RcIjpcIjMzXCJ9LFwiSXRlbUxpc3RcIjpbe1wiSXRlbU5vXCI6MCxcIlNsTm9cIjpcIjFcIixcIklzU2VydmNcIjpcIk5cIixcIkhzbkNkXCI6XCI4NTAzMDBcIixcIlF0eVwiOjIsXCJVbml0XCI6XCJLR1NcIixcIlVuaXRQcmljZVwiOjE1MDAsXCJUb3RBbXRcIjozMDAwLFwiRGlzY291bnRcIjowLFwiQXNzQW10XCI6MzAwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6NTQwLFwiQ2dzdEFtdFwiOjAsXCJTZ3N0QW10XCI6MCxcIlRvdEl0ZW1WYWxcIjozNTQwfV0sXCJWYWxEdGxzXCI6e1wiQXNzVmFsXCI6MzAwMCxcIkNnc3RWYWxcIjowLFwiU2dzdFZhbFwiOjAsXCJJZ3N0VmFsXCI6NTQwLFwiT3RoQ2hyZ1wiOjAsXCJSbmRPZmZBbXRcIjowLFwiVG90SW52VmFsXCI6MzU0MH19IiwiaXNzIjoiTklDIFNhbmRib3gifQ.Vh8uncnv_dWvyUqofYtmpkLYR9Cvk0WzN5k0ODhhcHqAlWyrxITS40O66wdPCGelEb2S2hTBXuiBUGKMK0wpuT2s5mjqOG-C9SFiTEVDY3esnBJhe5NB3FiC_fIr6sdJO9o9YiZZH0G5IMJgmvUHsaTIoqhpz8XCzjq1awEwLdzZ9bcza3cb86btiifANth3-KytX4WDVLgRqrCwlRHv_SYBXWzvqIYatfBMvCJ34jh-ROE9IRMj39hrkcj-nHHWIPM9jfCcEOTjQw-KL9SXcbq-NsZNw2YF6L7WcHQX798m7jVzHr85GO7AJOB0W4s3hQdlZi1Jv1z_DmZ5CjNFSA', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjM0QUFDQ0MxNTk2UTAwMlwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0xMTlcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMTQvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MzU0MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjg1MDMwMFwiLFwiSXJuXCI6XCI0Zjc1YmE2Nzc2NWM4OTczZWE2MTM3NTk5OTkwYzdjM2Y3NzJlODg4OWYzZmQzN2JjNDExYjcwOWQ1YjIyMzA5XCIsXCJJcm5EdFwiOlwiMjAyMy0wOC0xNCAxOTo1MzowNFwifSIsImlzcyI6Ik5JQyBTYW5kYm94In0.ONjECuU18qwUaM3mWTDzPGItp87_xL7MuxtMcMD8HFLpqwFWNJ1f1IIuJ9ttzMrOscC-nMCUyopNbHvMuiqa_0SXJIx6phHsSDJTT7K9RwycwTsyzPMXW17FJQwJzUQ1O6Aa3OFUz-nx6OZyTPN1GHCnQ_QiNvTIcCtIcj24bm5sHgK10A3I9BRQZYFjxqkt0s0z58zW4cXyN3uy0S5EQcOlhLarWajzAFmOwwee1OxZ98MPAKb-17f9BAqFSQDblbnsbt1N6UznfDa7qqvfoo5Ut492K3vY-Jmjwtj-pyVLqll8gLExsTiU0vYlglXhsAOzuuI3h84MjqrYBHdjGQ', 'ACT', 'n', 'n', 'n', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (122, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-120', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '07:51 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '2', '4000.00', '0', 'percent_wise', '0.00', '4000.00', '9', '', '9', '', '18', '720.00', NULL, '4000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '4720.00', '4720.00', 1, 'INV/23-24/-120140823', 'INV/23-24/-120-2023', 1, 1, '2.00', '152310022192303', '2023-08-14 19:54:59', '01a83356f570b4546364d8ce38d019bdd2319112cefa484215a1518f3a385b8a', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxNTIzMTAwMjIxOTIzMDMsXCJBY2tEdFwiOlwiMjAyMy0wOC0xNCAxOTo1NDo1OVwiLFwiSXJuXCI6XCIwMWE4MzM1NmY1NzBiNDU0NjM2NGQ4Y2UzOGQwMTliZGQyMzE5MTEyY2VmYTQ4NDIxNWExNTE4ZjNhMzg1YjhhXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMTIwXCIsXCJEdFwiOlwiMTQvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMzRBQUNDQzE1OTZRMDAyXCIsXCJMZ2xObVwiOlwiTVlPRkZJQ0UgRVJQXCIsXCJBZGRyMVwiOlwiOTEsIERyLiBKYWdhbmF0aGFuIE5hZ2FyLCBDaXZpbCBBZXJvZHJvbWUgcG9zdCwgQ01DIG9wcFwiLFwiQWRkcjJcIjpcIkF2aW5hc2hpIFJvYWQsIEhvcGVzIENvbGxlZ2VcIixcIkxvY1wiOlwiQ29pbWJhdG9yZVwiLFwiUGluXCI6NjA1MDAxLFwiU3RjZFwiOlwiMzRcIixcIlBoXCI6XCI3MzczMzMzMzIxXCIsXCJFbVwiOlwiaW5mb0BpZHJlYW1kZXZlbG9wZXJzLmNvbVwifSxcIkJ1eWVyRHRsc1wiOntcIkdzdGluXCI6XCIzM0FEWFBUMzI5MU4yWkpcIixcIkxnbE5tXCI6XCJTTUsgSU5EVVNUUklFU1wiLFwiUG9zXCI6XCIzM1wiLFwiQWRkcjFcIjpcIjMvMjI2RCwgTkFEVVBBTEFZQU0gUk9BRFwiLFwiQWRkcjJcIjpcIlBBVFRBTkFNIFBPU1QsT05ESVBVRFVSIChWSUEpXCIsXCJMb2NcIjpcIkNPSU1CQVRPUkVcIixcIlBpblwiOjY0MTAxNCxcIlBoXCI6XCI3ODEwMDI4MjIyXCIsXCJFbVwiOlwianBAaWRyZWFtZGV2ZWxvcGVycy5jb21cIixcIlN0Y2RcIjpcIjMzXCJ9LFwiSXRlbUxpc3RcIjpbe1wiSXRlbU5vXCI6MCxcIlNsTm9cIjpcIjFcIixcIklzU2VydmNcIjpcIk5cIixcIkhzbkNkXCI6XCI3MjA0XCIsXCJRdHlcIjoyLFwiVW5pdFwiOlwiS0dTXCIsXCJVbml0UHJpY2VcIjoyMDAwLFwiVG90QW10XCI6NDAwMCxcIkRpc2NvdW50XCI6MCxcIkFzc0FtdFwiOjQwMDAsXCJHc3RSdFwiOjE4LFwiSWdzdEFtdFwiOjcyMCxcIkNnc3RBbXRcIjowLFwiU2dzdEFtdFwiOjAsXCJUb3RJdGVtVmFsXCI6NDcyMH1dLFwiVmFsRHRsc1wiOntcIkFzc1ZhbFwiOjQwMDAsXCJDZ3N0VmFsXCI6MCxcIlNnc3RWYWxcIjowLFwiSWdzdFZhbFwiOjcyMCxcIk90aENocmdcIjowLFwiUm5kT2ZmQW10XCI6MCxcIlRvdEludlZhbFwiOjQ3MjB9fSIsImlzcyI6Ik5JQyBTYW5kYm94In0.Q3o5Z1Bvv9cTpy1umxqkQsgQzmeGLTOLCDUcZbrLTAI5prJFM7cCtVS4tneIbhPCLwwQtw5aI_G50yOn32oFajua5maYktV6m3ZTmVhGOchWkQciEtIbjpjQqGr7VvZq7KEMYrOZjiuzCvQgRkD_9f4L0nX722eZRJ6a7W15TE6XulM2ntsqtOWBvSuwErI3nQaln5iGxv4hGE0-P-0xs7yNIy5UDkjram9kUrBzZYaCot7Rukfs1Ng1W4fSFlExccl3Ze6_RhbG1X3q9FfECbaMxtRI6Nna3oRFf9CqgjlOx_BPXlGT4xjm8HDphA2jTazOnoif8EroaroVkrUmbA', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjM0QUFDQ0MxNTk2UTAwMlwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0xMjBcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMTQvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6NDcyMCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjcyMDRcIixcIklyblwiOlwiMDFhODMzNTZmNTcwYjQ1NDYzNjRkOGNlMzhkMDE5YmRkMjMxOTExMmNlZmE0ODQyMTVhMTUxOGYzYTM4NWI4YVwiLFwiSXJuRHRcIjpcIjIwMjMtMDgtMTQgMTk6NTQ6NTlcIn0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.bOEPeT0V96eE921oCjZIyjkXIUymShIR_myUuGIhNc2RJo4forxhwyj1lXXE3CFXOTMVTdOnNe9fX3O7gPCOabD9xKd_vVi91FafPXzsnOWULO_ztsAtXBzbyEVA1yHBTSq63AhJNKbTA90CkHWNtCdPvRSTgZ12qx8Mc4jeQclTeMg-mVG2YgVRshrYLbEsBAj2NaJdBm3CeFdzXXC__lBEVqMqELnACo-bmda2ZmBChC7kKWNHFXvppJBfVHOzhxP6iPNR3DAdfvgDvwU7owyxctAxUOc-whuuqjdxbkpmJULKtTizwnBko4sjBQCtxeDjp-ALF1JlnuQwz-WSnQ', 'ACT', '{', '{', '{', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (123, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-121', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '07:54 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '54', '108000.00', '0', 'percent_wise', '0.00', '108000.00', '9', '', '9', '', '18', '19440.00', NULL, '108000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '127440.00', '127440.00', 1, 'INV/23-24/-121140823', 'INV/23-24/-121-2023', 1, 1, '54.00', '152310022192312', '2023-08-14 19:57:47', '9d1042a549d2f31f86214bf907b97ad0708ef9bedfc93c8f986ce069f3747596', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxNTIzMTAwMjIxOTIzMTIsXCJBY2tEdFwiOlwiMjAyMy0wOC0xNCAxOTo1Nzo0N1wiLFwiSXJuXCI6XCI5ZDEwNDJhNTQ5ZDJmMzFmODYyMTRiZjkwN2I5N2FkMDcwOGVmOWJlZGZjOTNjOGY5ODZjZTA2OWYzNzQ3NTk2XCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMTIxXCIsXCJEdFwiOlwiMTQvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMzRBQUNDQzE1OTZRMDAyXCIsXCJMZ2xObVwiOlwiTVlPRkZJQ0UgRVJQXCIsXCJBZGRyMVwiOlwiOTEsIERyLiBKYWdhbmF0aGFuIE5hZ2FyLCBDaXZpbCBBZXJvZHJvbWUgcG9zdCwgQ01DIG9wcFwiLFwiQWRkcjJcIjpcIkF2aW5hc2hpIFJvYWQsIEhvcGVzIENvbGxlZ2VcIixcIkxvY1wiOlwiQ29pbWJhdG9yZVwiLFwiUGluXCI6NjA1MDAxLFwiU3RjZFwiOlwiMzRcIixcIlBoXCI6XCI3MzczMzMzMzIxXCIsXCJFbVwiOlwiaW5mb0BpZHJlYW1kZXZlbG9wZXJzLmNvbVwifSxcIkJ1eWVyRHRsc1wiOntcIkdzdGluXCI6XCIzM0FEWFBUMzI5MU4yWkpcIixcIkxnbE5tXCI6XCJTTUsgSU5EVVNUUklFU1wiLFwiUG9zXCI6XCIzM1wiLFwiQWRkcjFcIjpcIjMvMjI2RCwgTkFEVVBBTEFZQU0gUk9BRFwiLFwiQWRkcjJcIjpcIlBBVFRBTkFNIFBPU1QsT05ESVBVRFVSIChWSUEpXCIsXCJMb2NcIjpcIkNPSU1CQVRPUkVcIixcIlBpblwiOjY0MTAxNCxcIlBoXCI6XCI3ODEwMDI4MjIyXCIsXCJFbVwiOlwianBAaWRyZWFtZGV2ZWxvcGVycy5jb21cIixcIlN0Y2RcIjpcIjMzXCJ9LFwiSXRlbUxpc3RcIjpbe1wiSXRlbU5vXCI6MCxcIlNsTm9cIjpcIjFcIixcIklzU2VydmNcIjpcIk5cIixcIkhzbkNkXCI6XCI3MjA0XCIsXCJRdHlcIjo1NCxcIlVuaXRcIjpcIktHU1wiLFwiVW5pdFByaWNlXCI6MjAwMCxcIlRvdEFtdFwiOjEwODAwMCxcIkRpc2NvdW50XCI6MCxcIkFzc0FtdFwiOjEwODAwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6MTk0NDAsXCJDZ3N0QW10XCI6MCxcIlNnc3RBbXRcIjowLFwiVG90SXRlbVZhbFwiOjEyNzQ0MH1dLFwiVmFsRHRsc1wiOntcIkFzc1ZhbFwiOjEwODAwMCxcIkNnc3RWYWxcIjowLFwiU2dzdFZhbFwiOjAsXCJJZ3N0VmFsXCI6MTk0NDAsXCJPdGhDaHJnXCI6MCxcIlJuZE9mZkFtdFwiOjAsXCJUb3RJbnZWYWxcIjoxMjc0NDB9fSIsImlzcyI6Ik5JQyBTYW5kYm94In0.cTUQX67fmj7Bp-vPDQ6KFyJNkU8sRJgweT8LfpWp7LrXB8v0wFXV30mUBSasyJD6GaA9cgTILhTrzLUe20Y733ghI98FF6pEyjyofVoCDZvX7HC2XJAuTDexLW-DstUXXLEkSZoa2u6vwqc6_MA-bMSLaHchPURvLFk3j3dQdRMzsq4QCITj8FPwix67On9V1ZC7VyiNH6wFgaveDs2j-30ZPoAthfdPxVr7sWxjh8crdJ1a8p_e0xevjJJNqdb1C5n377CKww0nKwtNEi2Ej9sYRPxi7uhcqAEHCOZe-i42ZEGGBaVNmFDnUJQkVHNjJGhf4ylcUuMsgurcUIY1EA', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjM0QUFDQ0MxNTk2UTAwMlwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0xMjFcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMTQvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MTI3NDQwLFwiSXRlbUNudFwiOjEsXCJNYWluSHNuQ29kZVwiOlwiNzIwNFwiLFwiSXJuXCI6XCI5ZDEwNDJhNTQ5ZDJmMzFmODYyMTRiZjkwN2I5N2FkMDcwOGVmOWJlZGZjOTNjOGY5ODZjZTA2OWYzNzQ3NTk2XCIsXCJJcm5EdFwiOlwiMjAyMy0wOC0xNCAxOTo1Nzo0N1wifSIsImlzcyI6Ik5JQyBTYW5kYm94In0.29voJPrc7pm31ixJnAG-e4RKDyMLT6Z1amfmNlYGrS5gVqWfG8YccAXSDOwX7o5cof38iowyzrwl_Kf6JYc8IyxZZv3UbsZf44L2r3r4oo5U8FtF3wqhBP-1aC6x3VG3j_-FoEzrwHEe1nFI40-EijTOtdSJAuxhXwL_e_bJJMpjr-F2G61ADj5AzGUPWxGOQkDlIbhwK-8OADSZJam-ImbgTzxWQdvRNOrvM-fFSvnGy84kam8GiGv6gdovWe_0WOP5IiQzXZQcUB1HJ389DNcwbZwbJaj70Q3v7uNUI4m4JQfOLvimfZ9b39nOuMfoou28Ptmu4vHFMRfhEgSMWA', 'ACT', '511008891171', '2023-08-14 19:58:00', '2023-08-15 23:59:00', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (124, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-122', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '07:56 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '5', '7500.00', '0', 'percent_wise', '0.00', '7500.00', '9', '', '9', '', '18', '1350.00', NULL, '7500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '8850.00', '8850.00', 1, 'INV/23-24/-122140823', 'INV/23-24/-122-2023', 1, 1, '5.00', '152310022192321', '2023-08-14 19:59:46', 'da5590f2f4534c40383a70d35b130743838bb18067af32b032f3983031a40a04', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxNTIzMTAwMjIxOTIzMjEsXCJBY2tEdFwiOlwiMjAyMy0wOC0xNCAxOTo1OTo0NlwiLFwiSXJuXCI6XCJkYTU1OTBmMmY0NTM0YzQwMzgzYTcwZDM1YjEzMDc0MzgzOGJiMTgwNjdhZjMyYjAzMmYzOTgzMDMxYTQwYTA0XCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMTIyXCIsXCJEdFwiOlwiMTQvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMzRBQUNDQzE1OTZRMDAyXCIsXCJMZ2xObVwiOlwiTVlPRkZJQ0UgRVJQXCIsXCJBZGRyMVwiOlwiOTEsIERyLiBKYWdhbmF0aGFuIE5hZ2FyLCBDaXZpbCBBZXJvZHJvbWUgcG9zdCwgQ01DIG9wcFwiLFwiQWRkcjJcIjpcIkF2aW5hc2hpIFJvYWQsIEhvcGVzIENvbGxlZ2VcIixcIkxvY1wiOlwiQ29pbWJhdG9yZVwiLFwiUGluXCI6NjA1MDAxLFwiU3RjZFwiOlwiMzRcIixcIlBoXCI6XCI3MzczMzMzMzIxXCIsXCJFbVwiOlwiaW5mb0BpZHJlYW1kZXZlbG9wZXJzLmNvbVwifSxcIkJ1eWVyRHRsc1wiOntcIkdzdGluXCI6XCIzM0FEWFBUMzI5MU4yWkpcIixcIkxnbE5tXCI6XCJTTUsgSU5EVVNUUklFU1wiLFwiUG9zXCI6XCIzM1wiLFwiQWRkcjFcIjpcIjMvMjI2RCwgTkFEVVBBTEFZQU0gUk9BRFwiLFwiQWRkcjJcIjpcIlBBVFRBTkFNIFBPU1QsT05ESVBVRFVSIChWSUEpXCIsXCJMb2NcIjpcIkNPSU1CQVRPUkVcIixcIlBpblwiOjY0MTAxNCxcIlBoXCI6XCI3ODEwMDI4MjIyXCIsXCJFbVwiOlwianBAaWRyZWFtZGV2ZWxvcGVycy5jb21cIixcIlN0Y2RcIjpcIjMzXCJ9LFwiSXRlbUxpc3RcIjpbe1wiSXRlbU5vXCI6MCxcIlNsTm9cIjpcIjFcIixcIklzU2VydmNcIjpcIk5cIixcIkhzbkNkXCI6XCI4NTAzMDBcIixcIlF0eVwiOjUsXCJVbml0XCI6XCJLR1NcIixcIlVuaXRQcmljZVwiOjE1MDAsXCJUb3RBbXRcIjo3NTAwLFwiRGlzY291bnRcIjowLFwiQXNzQW10XCI6NzUwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6MTM1MCxcIkNnc3RBbXRcIjowLFwiU2dzdEFtdFwiOjAsXCJUb3RJdGVtVmFsXCI6ODg1MH1dLFwiVmFsRHRsc1wiOntcIkFzc1ZhbFwiOjc1MDAsXCJDZ3N0VmFsXCI6MCxcIlNnc3RWYWxcIjowLFwiSWdzdFZhbFwiOjEzNTAsXCJPdGhDaHJnXCI6MCxcIlJuZE9mZkFtdFwiOjAsXCJUb3RJbnZWYWxcIjo4ODUwfX0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.UVkDhlm5WolT-Tb-Y_lTRzPr4UeeN7M75qevWZYm64aKV4EMvvok2CwnlcH9i1bj3gtopyjdyPr80glLyH6mp6-JBo_eWGgYISv594H8fY1b8J99vKVuEvVsCAEJsXj7q04sPR987WmVHNPZ7d0VjR-QTbtem6mkSsAPVs2zRUtkAAJq5zGDbb6PEhkumuNqLYL2uuKed24_0hOhNNej2MmE8QA7nEY4kYh-AZUwomd74xb9IPWiuH69rT97QlAw4TV5CrXMA1ikNVJzafAEbXyBb4KJdvHFGXHzC7v3XQzv6dbHgiXyb3HN8rKev_HTwF2QntPASleHzXCJ44zN1w', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjM0QUFDQ0MxNTk2UTAwMlwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0xMjJcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMTQvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6ODg1MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjg1MDMwMFwiLFwiSXJuXCI6XCJkYTU1OTBmMmY0NTM0YzQwMzgzYTcwZDM1YjEzMDc0MzgzOGJiMTgwNjdhZjMyYjAzMmYzOTgzMDMxYTQwYTA0XCIsXCJJcm5EdFwiOlwiMjAyMy0wOC0xNCAxOTo1OTo0NlwifSIsImlzcyI6Ik5JQyBTYW5kYm94In0.aHuh-JM80slmJ2OYRVSGBJXIb_6uBy0I7ZGrYrPJelV0QbwszKOCRnui3fmNISeKs4025owGSwIwP7ncGPC0UnCe6--HKOS8NzZUn-cepTlcxp-5uDlW4Hq8ksy9m7F1hHB5LUFUtdibTT09-g5DpsuoN7I3nAaQN0Pa-_epQKNKyMrWAzS1j91XaTCmm1tS6t0QDQpc3yaPiF78sPVG89aNCYWd3FYWr4eP9oqnoxA8TPTOtGcEkMEuRRsDAO53sVXK3WiDyixl4GDW48oBEcXuTPzYVlJFIv-ElhPJelt8sOqdMaTfu7uAUJaYoBQRzXAdjvsLGz2AcIGRuo58Ew', 'ACT', '581008891172', '2023-08-14 20:00:00', '2023-08-15 23:59:00', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (125, '2023-08-14', '2023-08-14', '', '1970-01-01', 'INV/23-24/-123', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-14', '10:56 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '2', '3000.00', '0', 'percent_wise', '0.00', '3000.00', '9', '', '9', '', '18', '540.00', NULL, '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '3540.00', 1, 'INV/23-24/-123140823', 'INV/23-24/-123-2023', 1, 1, '2.00', '152310022192853', '2023-08-15 10:37:21', '03b124f6a2dd502f064ace9d2bff6ceccacd1e82b788dc27e7715832b8d7c482', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxNTIzMTAwMjIxOTI4NTMsXCJBY2tEdFwiOlwiMjAyMy0wOC0xNSAxMDozNzoyMVwiLFwiSXJuXCI6XCIwM2IxMjRmNmEyZGQ1MDJmMDY0YWNlOWQyYmZmNmNlY2NhY2QxZTgyYjc4OGRjMjdlNzcxNTgzMmI4ZDdjNDgyXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMTIzXCIsXCJEdFwiOlwiMTQvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMzRBQUNDQzE1OTZRMDAyXCIsXCJMZ2xObVwiOlwiTVlPRkZJQ0UgRVJQXCIsXCJBZGRyMVwiOlwiOTEsIERyLiBKYWdhbmF0aGFuIE5hZ2FyLCBDaXZpbCBBZXJvZHJvbWUgcG9zdCwgQ01DIG9wcFwiLFwiQWRkcjJcIjpcIkF2aW5hc2hpIFJvYWQsIEhvcGVzIENvbGxlZ2VcIixcIkxvY1wiOlwiQ29pbWJhdG9yZVwiLFwiUGluXCI6NjA1MDAxLFwiU3RjZFwiOlwiMzRcIixcIlBoXCI6XCI3MzczMzMzMzIxXCIsXCJFbVwiOlwiaW5mb0BpZHJlYW1kZXZlbG9wZXJzLmNvbVwifSxcIkJ1eWVyRHRsc1wiOntcIkdzdGluXCI6XCIzM0FEWFBUMzI5MU4yWkpcIixcIkxnbE5tXCI6XCJTTUsgSU5EVVNUUklFU1wiLFwiUG9zXCI6XCIzM1wiLFwiQWRkcjFcIjpcIjMvMjI2RCwgTkFEVVBBTEFZQU0gUk9BRFwiLFwiQWRkcjJcIjpcIlBBVFRBTkFNIFBPU1QsT05ESVBVRFVSIChWSUEpXCIsXCJMb2NcIjpcIkNPSU1CQVRPUkVcIixcIlBpblwiOjY0MTAxNCxcIlBoXCI6XCI3ODEwMDI4MjIyXCIsXCJFbVwiOlwianBAaWRyZWFtZGV2ZWxvcGVycy5jb21cIixcIlN0Y2RcIjpcIjMzXCJ9LFwiSXRlbUxpc3RcIjpbe1wiSXRlbU5vXCI6MCxcIlNsTm9cIjpcIjFcIixcIklzU2VydmNcIjpcIk5cIixcIkhzbkNkXCI6XCI4NTAzMDBcIixcIlF0eVwiOjIsXCJVbml0XCI6XCJLR1NcIixcIlVuaXRQcmljZVwiOjE1MDAsXCJUb3RBbXRcIjozMDAwLFwiRGlzY291bnRcIjowLFwiQXNzQW10XCI6MzAwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6NTQwLFwiQ2dzdEFtdFwiOjAsXCJTZ3N0QW10XCI6MCxcIlRvdEl0ZW1WYWxcIjozNTQwfV0sXCJWYWxEdGxzXCI6e1wiQXNzVmFsXCI6MzAwMCxcIkNnc3RWYWxcIjowLFwiU2dzdFZhbFwiOjAsXCJJZ3N0VmFsXCI6NTQwLFwiT3RoQ2hyZ1wiOjAsXCJSbmRPZmZBbXRcIjowLFwiVG90SW52VmFsXCI6MzU0MH19IiwiaXNzIjoiTklDIFNhbmRib3gifQ.dtMtUs7Oi9-GXI_HU5P14HENOE6uQpGMbVtNGtbyU-Nvj2zBjQGoq55QwBZKxDQUT4f1DU57Q--M06ZPrgEsFr5L0Aes_2SDRRyZd7pa9FxMVEe1I1-e_7bXRG2lAVa4mhn9kJy4cEQ5-LRJXs_7UZ8To6fTtVp4yTGBOXYWHuUvD2jCEPD2Es-TOFpt5PBbkWXPCgXM1YZzR96od89pOV4EfhDa70n2eCN4QcDHnUQvR9nBEu4ZKN1CQozvCriJKHof9KwyHuAkIlHVflFOk_Y2NOkO7k9nryjm6ejvgCW21mUtFPWfXXuZlOFV4t61iysrVnH9XGp5D8lsf_REFw', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjM0QUFDQ0MxNTk2UTAwMlwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0xMjNcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMTQvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MzU0MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjg1MDMwMFwiLFwiSXJuXCI6XCIwM2IxMjRmNmEyZGQ1MDJmMDY0YWNlOWQyYmZmNmNlY2NhY2QxZTgyYjc4OGRjMjdlNzcxNTgzMmI4ZDdjNDgyXCIsXCJJcm5EdFwiOlwiMjAyMy0wOC0xNSAxMDozNzoyMVwifSIsImlzcyI6Ik5JQyBTYW5kYm94In0.d-M_4RhHUt1CvxVGVUfTFx6QjPhWEyJ98CDVmk8zwCgxwlr4vTHeX2srQTdpZ6y_U3St8_brcwdSyZb8w_viVl-2jv9JCeit8_YMUnI-8F2vR1xlAxAaPpu7ubwA_IpeSVltr3JhkNgyRXKUCWmp67RrQnNor6u-zRXKPZF9RXQpJuTnpK-0Z4x11q094i3ZNirsr0q-zYV8nbpD68_gbS3mRF1ZKpZrUWW6EBDP8PV1AOO0i6wqbhmzuqBw6DNvuFoLzV-MyA-hYssa3F6bHM88ARuMuOoZeu_9yY1Q0np0xZfiYflGxUEbUsbxLSFSIHkE_urbQxcUA3t8YQX2ig', 'ACT', '521008891202', '2023-08-15 18:40:00', '2023-08-16 23:59:00', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (126, '2023-08-15', '2023-08-15', '', '1970-01-01', 'INV/23-24/-124', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-15', '06:35 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '2', '3000.00', '0', 'percent_wise', '0.00', '3000.00', '9', '', '9', '', '18', '540.00', NULL, '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '3540.00', 1, 'INV/23-24/-124150823', 'INV/23-24/-124-2023', 1, 1, '2.00', '152310022193889', '2023-08-15 18:39:11', '57feead88b8f99ed3a25f8401ed3e92160bd6cb0664c8aacc290ee03f425a85e', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxNTIzMTAwMjIxOTM4ODksXCJBY2tEdFwiOlwiMjAyMy0wOC0xNSAxODozOToxMVwiLFwiSXJuXCI6XCI1N2ZlZWFkODhiOGY5OWVkM2EyNWY4NDAxZWQzZTkyMTYwYmQ2Y2IwNjY0YzhhYWNjMjkwZWUwM2Y0MjVhODVlXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMTI0XCIsXCJEdFwiOlwiMTUvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMzRBQUNDQzE1OTZRMDAyXCIsXCJMZ2xObVwiOlwiTVlPRkZJQ0UgRVJQXCIsXCJBZGRyMVwiOlwiOTEsIERyLiBKYWdhbmF0aGFuIE5hZ2FyLCBDaXZpbCBBZXJvZHJvbWUgcG9zdCwgQ01DIG9wcFwiLFwiQWRkcjJcIjpcIkF2aW5hc2hpIFJvYWQsIEhvcGVzIENvbGxlZ2VcIixcIkxvY1wiOlwiQ29pbWJhdG9yZVwiLFwiUGluXCI6NjA1MDAxLFwiU3RjZFwiOlwiMzRcIixcIlBoXCI6XCI3MzczMzMzMzIxXCIsXCJFbVwiOlwiaW5mb0BpZHJlYW1kZXZlbG9wZXJzLmNvbVwifSxcIkJ1eWVyRHRsc1wiOntcIkdzdGluXCI6XCIzM0FEWFBUMzI5MU4yWkpcIixcIkxnbE5tXCI6XCJTTUsgSU5EVVNUUklFU1wiLFwiUG9zXCI6XCIzM1wiLFwiQWRkcjFcIjpcIjMvMjI2RCwgTkFEVVBBTEFZQU0gUk9BRFwiLFwiQWRkcjJcIjpcIlBBVFRBTkFNIFBPU1QsT05ESVBVRFVSIChWSUEpXCIsXCJMb2NcIjpcIkNPSU1CQVRPUkVcIixcIlBpblwiOjY0MTAxNCxcIlBoXCI6XCI3ODEwMDI4MjIyXCIsXCJFbVwiOlwianBAaWRyZWFtZGV2ZWxvcGVycy5jb21cIixcIlN0Y2RcIjpcIjMzXCJ9LFwiSXRlbUxpc3RcIjpbe1wiSXRlbU5vXCI6MCxcIlNsTm9cIjpcIjFcIixcIklzU2VydmNcIjpcIk5cIixcIkhzbkNkXCI6XCI4NTAzMDBcIixcIlF0eVwiOjIsXCJVbml0XCI6XCJLR1NcIixcIlVuaXRQcmljZVwiOjE1MDAsXCJUb3RBbXRcIjozMDAwLFwiRGlzY291bnRcIjowLFwiQXNzQW10XCI6MzAwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6NTQwLFwiQ2dzdEFtdFwiOjAsXCJTZ3N0QW10XCI6MCxcIlRvdEl0ZW1WYWxcIjozNTQwfV0sXCJWYWxEdGxzXCI6e1wiQXNzVmFsXCI6MzAwMCxcIkNnc3RWYWxcIjowLFwiU2dzdFZhbFwiOjAsXCJJZ3N0VmFsXCI6NTQwLFwiT3RoQ2hyZ1wiOjAsXCJSbmRPZmZBbXRcIjowLFwiVG90SW52VmFsXCI6MzU0MH19IiwiaXNzIjoiTklDIFNhbmRib3gifQ.WdQ_fDSq8SwqUAgzq3D8hF_KOZjDzP-v0tPqkmh1eGOQdCYdETKGXTV9DbsjL_P6RVkc72tjI2k7P4a2U3CqGaKMd6Zyf7jAJkLOZAUoe3GBjF85ap3zbrGeTBDci13e297XTMWlRYEtV2PEjdPHtLGz2Z7iKaVT5cg4RgWVLXtvTPw03BGXuDDjXN2fvtVYT-GrBdo6xfxKS_Dj-xyMOch1OuXooTyA7pHRkPebXw92oscEICDPdgwvAhW6rxiaL152srsRPDQLTbblMpLzsED0k6tHaG2mrkdrmij9_K0vWXvIG8au2Ux3UC3Xv10xOe46b1e2eFPMFSnNUgqS-Q', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjM0QUFDQ0MxNTk2UTAwMlwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0xMjRcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMTUvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MzU0MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjg1MDMwMFwiLFwiSXJuXCI6XCI1N2ZlZWFkODhiOGY5OWVkM2EyNWY4NDAxZWQzZTkyMTYwYmQ2Y2IwNjY0YzhhYWNjMjkwZWUwM2Y0MjVhODVlXCIsXCJJcm5EdFwiOlwiMjAyMy0wOC0xNSAxODozOToxMVwifSIsImlzcyI6Ik5JQyBTYW5kYm94In0.CZ0bp2HDdFwwIY4iC1BeQlpAn0X0u7cJp-C8eV-dr0zS--6XGrEMZyASHuQMOpGgOdKihhMK4sm-JrQrBFckCzTgfsNC9_LhtCtHGVrDCKy-f1fI3IfGuN4NeES-QGLodZMzI3nQgmSPAo0L94S4F5sC20yGMTLHcRh9dhuZXJR4tfV7xTqNcovXt10Hwt5LttFfiLMJY9seYUKtduisg0LV79Ep4MRcgF5eEJpi3iPv5nbwFYrVyFtXo3z1-tYlplL1u7oTECTHDtCYskhn3d7YrUEuv5FaJLu6RzNQV8Tmz80ZkZ3jdlwRUO-xeTBx3ZJgaLntYx_zqi3H6luOXg', 'ACT', '551008891201', '2023-08-15 18:39:00', '2023-08-16 23:59:00', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (127, '2023-08-15', '2023-08-15', '', '1970-01-01', 'INV/23-24/-125', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-15', '08:23 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '5', '7500.00', '0', 'percent_wise', '0.00', '7500.00', '9', '', '9', '', '18', '1350.00', NULL, '7500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '8850.00', '8850.00', 1, 'INV/23-24/-125150823', 'INV/23-24/-125-2023', 1, 1, '5.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (128, '2023-08-18', '2023-08-18', '', '1970-01-01', 'INV/23-24/-126', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-18', '11:16 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '2000', '50', '100000.00', '0', 'percent_wise', '0.00', '100000.00', '9', '', '9', '', '18', '18000.00', NULL, '100000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '118000.00', '118000.00', 1, 'INV/23-24/-126180823', 'INV/23-24/-126-2023', 1, 1, '50.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (129, '2023-09-20', '2023-09-05', '', '1970-01-01', 'INV/23-24/-127', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-09-05', '07:43 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300||850300', NULL, '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM 70MM CLEATED STATOR', '||', 'KGS||KGS', '1500||1500', '5||5', '7500.00||7500.00', '0||0', 'percent_wise', '0.00||0.00', '7500.00||7500.00', '9', '', '9', '', '18', '2700.00', NULL, '15000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '17700.00', '17700.00', 1, 'INV/23-24/-127050923', 'INV/23-24/-127-2023', 1, 1, '10.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (130, '2023-09-29', '2023-09-29', '', '1970-01-01', 'INV/23-24/-128', 'SDC/23-24/-001', NULL, NULL, NULL, 'Tax Invoice', 'Against DC', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-09-29', '01:02 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', 'SDC/23-24/-001', '1', '1', '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '100', '150000.00', '0', 'percent_wise', '', '150000.00', '9', '', '9', '', '18', '27000.00', '150000.00', '150000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '177000.00', '177000.00', 1, 'INV/23-24/-128290923', 'INV/23-24/-128-2023', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (131, '2023-10-03', '2023-10-03', '', '1970-01-01', 'INV/23-24/-129', 'SDC/23-24/-004', NULL, NULL, NULL, 'Tax Invoice', 'Against DC', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-10-03', '04:35 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', 'SDC/23-24/-004', '4', '4', '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '15', '02', '30.00', '0', 'percent_wise', '0.00', '30.00', '9', '', '9', '', '18', '5.40', '3000.00', '30.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '35.40', '35.40', 1, 'INV/23-24/-129031023', 'INV/23-24/-129-2023', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (132, '2023-10-11', '2023-10-11', '', '1970-01-01', 'INV/23-24/-130', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-10-11', '10:56 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300||7204', NULL, '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', 'KGS||KGS', '1500||6055', '100||30', '150000.00||181650.00', '5||10', 'percent_wise', '7500.00||18165.00', '142500.00||163485.00', '9', '', '9', '', '18', '55077.30', NULL, '305985.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '361062.30', '361062.30', 1, 'INV/23-24/-130111023', 'INV/23-24/-130-2023', 1, 1, '376.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);


#
# TABLE STRUCTURE FOR: invoice_details_backup
#

DROP TABLE IF EXISTS `invoice_details_backup`;

CREATE TABLE `invoice_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `customerdcnos` varchar(100) DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `pino` varchar(100) NOT NULL,
  `purchaseordernos` varchar(255) DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `removalDate` date NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToId` varchar(255) DEFAULT NULL,
  `shipToAddress` longtext,
  `deliveryAddress1` longtext,
  `deliveryAddress2` longtext,
  `mobileNo` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `totalqty` varchar(255) NOT NULL,
  `poNumber` varchar(100) NOT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: invoice_party_statement
#

DROP TABLE IF EXISTS `invoice_party_statement`;

CREATE TABLE `invoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=138 DEFAULT CHARSET=latin1;

INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '-', '-', NULL, '2023-07-28', 'INV/23-24/-001', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', '', '', NULL, NULL, '', '', '1', '2023-07-28', '2023-07-28', '4130.00', '-', '-', '', '', '-', '-', NULL, '4130', '-', '-', '-', '-', '4130.00', '-', '4130.00', NULL, NULL, 'INV/23-24/-001-2023', 'INV/23-24/-001280723', '1');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (3, '-', '-', NULL, '2023-07-28', 'INV/23-24/-002', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', '', '', NULL, NULL, '', '', '1', '2023-07-28', '2023-07-28', '4130.00', '-', '-', '', '', '-', '-', NULL, '8260', '-', '-', '-', '-', '4130.00', '-', '4130.00', NULL, NULL, NULL, NULL, '2');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (4, '-', '-', NULL, '2023-07-29', 'INV/23-24/-003', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', '', '', NULL, NULL, '', '', '1', '2023-07-29', '2023-07-29', '4130.00', '-', '-', '', '', '-', '-', NULL, '12390', '-', '-', '-', '-', '4130.00', '-', '4130.00', NULL, NULL, 'INV/23-24/-003-2023', 'INV/23-24/-003290723', '3');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (5, '-', '-', NULL, '2023-07-29', 'INV/23-24/-004', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', '', '', NULL, NULL, '', '', '1', '2023-07-29', '2023-07-29', '4130.00', '-', '-', '', '', '-', '-', NULL, '16520', '-', '-', '-', '-', '4130.00', '-', '4130.00', NULL, NULL, 'INV/23-24/-004-2023', 'INV/23-24/-004290723', '4');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (6, '-', '-', NULL, '2023-07-29', 'INV/23-24/-005', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG||1080R2-2PM 70MM CLEATED STATOR', '||', '', '', NULL, NULL, '', '', '1', '2023-07-29', '2023-07-29', '4130.00', '-', '-', '', '', '-', '-', NULL, '20650', '-', '-', '-', '-', '4130.00', '-', '4130.00', NULL, NULL, 'INV/23-24/-005-2023', 'INV/23-24/-005290723', '5');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (7, '-', '-', NULL, '2023-07-29', 'INV/23-24/-006', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', '', '', NULL, NULL, '', '', '1', '2023-07-29', '2023-07-29', '4130.00', '-', '-', '', '', '-', '-', NULL, '24780', '-', '-', '-', '-', '4130.00', '-', '4130.00', NULL, NULL, 'INV/23-24/-006-2023', 'INV/23-24/-006290723', '6');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (8, '-', '-', NULL, '2023-08-03', 'INV/23-24/-007', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '26550', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-007-2023', 'INV/23-24/-007030823', '7');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (9, '-', '-', NULL, '2023-08-03', 'INV/23-24/-008', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '28320', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-008-2023', 'INV/23-24/-008030823', '8');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (10, '-', '-', NULL, '2023-08-03', 'INV/23-24/-009', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '30090', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-009-2023', 'INV/23-24/-009030823', '9');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (11, '-', '-', NULL, '2023-08-03', 'INV/23-24/-010', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '31860', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-010-2023', 'INV/23-24/-010030823', '10');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (12, '-', '-', NULL, '2023-08-03', 'INV/23-24/-011', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '33630', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-011-2023', 'INV/23-24/-011030823', '11');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (13, '-', '-', NULL, '2023-08-03', 'INV/23-24/-012', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '35400', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-012-2023', 'INV/23-24/-012030823', '12');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (14, '-', '-', NULL, '2023-08-03', 'INV/23-24/-013', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '37170', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-013-2023', 'INV/23-24/-013030823', '13');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (15, '-', '-', NULL, '2023-08-03', 'INV/23-24/-014', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '38940', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-014-2023', 'INV/23-24/-014030823', '14');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (16, '-', '-', NULL, '2023-08-03', 'INV/23-24/-015', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '2360.00', '-', '-', '', '', '-', '-', NULL, '41300', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-015-2023', 'INV/23-24/-015030823', '15');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (17, '-', '-', NULL, '2023-08-03', 'INV/23-24/-016', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '2360.00', '-', '-', '', '', '-', '-', NULL, '43660', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-016-2023', 'INV/23-24/-016030823', '16');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (18, '-', '-', NULL, '2023-08-03', 'INV/23-24/-017', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '2360.00', '-', '-', '', '', '-', '-', NULL, '46020', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-017-2023', 'INV/23-24/-017030823', '17');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (19, '-', '-', NULL, '2023-08-03', 'INV/23-24/-018', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '47790', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-018-2023', 'INV/23-24/-018030823', '18');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (20, '-', '-', NULL, '2023-08-03', 'INV/23-24/-019', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '49560', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-019-2023', 'INV/23-24/-019030823', '19');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (21, '-', '-', NULL, '2023-08-03', 'INV/23-24/-020', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '2360.00', '-', '-', '', '', '-', '-', NULL, '51920', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-020-2023', 'INV/23-24/-020030823', '20');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (22, '-', '-', NULL, '2023-08-03', 'INV/23-24/-021', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '53690', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-021-2023', 'INV/23-24/-021030823', '21');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (23, '-', '-', NULL, '2023-08-03', 'INV/23-24/-022', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '55460', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-022-2023', 'INV/23-24/-022030823', '22');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (24, '-', '-', NULL, '2023-08-03', 'INV/23-24/-023', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '2360.00', '-', '-', '', '', '-', '-', NULL, '57820', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-023-2023', 'INV/23-24/-023030823', '23');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (25, '-', '-', NULL, '2023-08-03', 'INV/23-24/-024', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '59590', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-024-2023', 'INV/23-24/-024030823', '24');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (26, '-', '-', NULL, '2023-08-03', 'INV/23-24/-025', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '61360', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-025-2023', 'INV/23-24/-025030823', '25');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (27, '-', '-', NULL, '2023-08-03', 'INV/23-24/-026', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '63130', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-026-2023', 'INV/23-24/-026030823', '26');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (28, '-', '-', NULL, '2023-08-03', 'INV/23-24/-027', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '64900', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-027-2023', 'INV/23-24/-027030823', '27');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (29, '-', '-', NULL, '2023-08-03', 'INV/23-24/-028', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '2360.00', '-', '-', '', '', '-', '-', NULL, '67260', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-028-2023', 'INV/23-24/-028030823', '28');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (30, '-', '-', NULL, '2023-08-03', 'INV/23-24/-029', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '69030', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-029-2023', 'INV/23-24/-029030823', '29');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (31, '-', '-', NULL, '2023-08-03', 'INV/23-24/-030', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '2360.00', '-', '-', '', '', '-', '-', NULL, '71390', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-030-2023', 'INV/23-24/-030030823', '30');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (32, '-', '-', NULL, '2023-08-03', 'INV/23-24/-031', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '73160', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-031-2023', 'INV/23-24/-031030823', '31');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (33, '-', '-', NULL, '2023-08-03', 'INV/23-24/-032', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '74930', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-032-2023', 'INV/23-24/-032030823', '32');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (34, '-', '-', NULL, '2023-08-03', 'INV/23-24/-033', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '76700', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-033-2023', 'INV/23-24/-033030823', '33');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (35, '-', '-', NULL, '2023-08-03', 'INV/23-24/-034', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '78470', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-034-2023', 'INV/23-24/-034030823', '34');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (36, '-', '-', NULL, '2023-08-04', 'INV/23-24/-035', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '80240', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-035-2023', 'INV/23-24/-035040823', '35');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (37, '-', '-', NULL, '2023-08-04', 'INV/23-24/-036', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '82600', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-036-2023', 'INV/23-24/-036040823', '36');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (38, '-', '-', NULL, '2023-08-04', 'INV/23-24/-037', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '84370', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-037-2023', 'INV/23-24/-037040823', '37');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (39, '-', '-', NULL, '2023-08-04', 'INV/23-24/-038', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '86730', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-038-2023', 'INV/23-24/-038040823', '38');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (40, '-', '-', NULL, '2023-08-04', 'INV/23-24/-039', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '88500', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-039-2023', 'INV/23-24/-039040823', '39');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (41, '-', '-', NULL, '2023-08-04', 'INV/23-24/-040', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '90270', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-040-2023', 'INV/23-24/-040040823', '40');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (42, '-', '-', NULL, '2023-08-04', 'INV/23-24/-041', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '92040', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-041-2023', 'INV/23-24/-041040823', '41');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (43, '-', '-', NULL, '2023-08-04', 'INV/23-24/-042', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '93810', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-042-2023', 'INV/23-24/-042040823', '42');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (44, '-', '-', NULL, '2023-08-04', 'INV/23-24/-043', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '95580', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-043-2023', 'INV/23-24/-043040823', '43');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (45, '-', '-', NULL, '2023-08-04', 'INV/23-24/-044', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '97940', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-044-2023', 'INV/23-24/-044040823', '44');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (46, '-', '-', NULL, '2023-08-04', 'INV/23-24/-045', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '100300', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-045-2023', 'INV/23-24/-045040823', '45');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (47, '-', '-', NULL, '2023-08-04', 'INV/23-24/-046', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '102070', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-046-2023', 'INV/23-24/-046040823', '46');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (48, '-', '-', NULL, '2023-08-04', 'INV/23-24/-047', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '104430', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-047-2023', 'INV/23-24/-047040823', '47');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (49, '-', '-', NULL, '2023-08-04', 'INV/23-24/-048', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '106200', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-048-2023', 'INV/23-24/-048040823', '48');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (50, '-', '-', NULL, '2023-08-04', 'INV/23-24/-049', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '108560', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-049-2023', 'INV/23-24/-049040823', '49');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (51, '-', '-', NULL, '2023-08-04', 'INV/23-24/-050', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '110330', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-050-2023', 'INV/23-24/-050040823', '50');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (52, '-', '-', NULL, '2023-08-04', 'INV/23-24/-051', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '112690', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-051-2023', 'INV/23-24/-051040823', '51');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (53, '-', '-', NULL, '2023-08-04', 'INV/23-24/-052', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '115050', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-052-2023', 'INV/23-24/-052040823', '52');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (54, '-', '-', NULL, '2023-08-04', 'INV/23-24/-053', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '117410', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-053-2023', 'INV/23-24/-053040823', '53');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (55, '-', '-', NULL, '2023-08-04', 'INV/23-24/-054', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '119180', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-054-2023', 'INV/23-24/-054040823', '54');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (56, '-', '-', NULL, '2023-08-04', 'INV/23-24/-055', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '121540', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-055-2023', 'INV/23-24/-055040823', '55');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (57, '-', '-', NULL, '2023-08-04', 'INV/23-24/-056', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '123900', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-056-2023', 'INV/23-24/-056040823', '56');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (58, '-', '-', NULL, '2023-08-04', 'INV/23-24/-057', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '126260', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-057-2023', 'INV/23-24/-057040823', '57');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (59, '-', '-', NULL, '2023-08-04', 'INV/23-24/-058', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '128620', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-058-2023', 'INV/23-24/-058040823', '58');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (60, '-', '-', NULL, '2023-08-04', 'INV/23-24/-059', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '130390', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-059-2023', 'INV/23-24/-059040823', '59');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (61, '-', '-', NULL, '2023-08-04', 'INV/23-24/-060', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '132750', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-060-2023', 'INV/23-24/-060040823', '60');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (62, '-', '-', NULL, '2023-08-07', 'INV/23-24/-061', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '134520', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-061-2023', 'INV/23-24/-061070823', '61');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (63, '-', '-', NULL, '2023-08-07', 'INV/23-24/-062', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '136290', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-062-2023', 'INV/23-24/-062070823', '62');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (64, '-', '-', NULL, '2023-08-07', 'INV/23-24/-063', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '138060', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-063-2023', 'INV/23-24/-063070823', '63');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (65, '-', '-', NULL, '2023-08-07', 'INV/23-24/-064', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '139830', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-064-2023', 'INV/23-24/-064070823', '64');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (66, '-', '-', NULL, '2023-08-07', 'INV/23-24/-065', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '141600', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-065-2023', 'INV/23-24/-065070823', '65');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (67, '-', '-', NULL, '2023-08-07', 'INV/23-24/-066', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '143370', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-066-2023', 'INV/23-24/-066070823', '66');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (68, '-', '-', NULL, '2023-08-07', 'INV/23-24/-067', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '145140', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-067-2023', 'INV/23-24/-067070823', '67');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (69, '-', '-', NULL, '2023-08-07', 'INV/23-24/-068', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '146910', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-068-2023', 'INV/23-24/-068070823', '68');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (70, '-', '-', NULL, '2023-08-07', 'INV/23-24/-069', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '148680', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-069-2023', 'INV/23-24/-069070823', '69');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (71, '-', '-', NULL, '2023-08-07', 'INV/23-24/-070', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '150450', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-070-2023', 'INV/23-24/-070070823', '70');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (72, '-', '-', NULL, '2023-08-07', 'INV/23-24/-071', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '152220', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-071-2023', 'INV/23-24/-071070823', '71');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (73, '-', '-', NULL, '2023-08-07', 'INV/23-24/-072', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '153990', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-072-2023', 'INV/23-24/-072070823', '72');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (74, '-', '-', NULL, '2023-08-07', 'INV/23-24/-073', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '155760', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-073-2023', 'INV/23-24/-073070823', '73');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (76, '-', '-', NULL, '2023-08-07', 'INV/23-24/-074', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '4720.00', '-', '-', '', '', '-', '-', NULL, '160480', '-', '-', '-', '-', '4720.00', '-', '4720.00', NULL, NULL, 'INV/23-24/-074-2023', 'INV/23-24/-074070823', '75');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (79, '-', '-', NULL, '2023-08-08', 'INV/23-24/-076', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-08', '2023-08-08', '2360.00', '-', '-', '', '', '-', '-', NULL, '164610', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-076-2023', 'INV/23-24/-076080823', '78');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (80, '-', '-', NULL, '2023-08-08', 'INV/23-24/-077', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-08', '2023-08-08', '1770.00', '-', '-', '', '', '-', '-', NULL, '166380', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-077-2023', 'INV/23-24/-077080823', '79');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (86, '-', '-', NULL, '2023-08-08', 'INV/23-24/-083', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-08', '2023-08-08', '4720.00', '-', '-', '', '', '-', '-', NULL, '195290', '-', '-', '-', '-', '4720.00', '-', '4720.00', NULL, NULL, 'INV/23-24/-083-2023', 'INV/23-24/-083080823', '85');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (87, '-', '-', NULL, '2023-08-09', 'INV/23-24/-084', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-09', '2023-08-09', '4720.00', '-', '-', '', '', '-', '-', NULL, '200010', '-', '-', '-', '-', '4720.00', '-', '4720.00', NULL, NULL, 'INV/23-24/-084-2023', 'INV/23-24/-084090823', '86');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (88, '-', '-', NULL, '2023-08-10', 'INV/23-24/-085', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', '', '', NULL, NULL, '', '', '1', '2023-08-10', '2023-08-10', '8260.00', '-', '-', '', '', '-', '-', NULL, '177000', '-', '-', '-', '-', '8260.00', '-', '8260.00', NULL, NULL, 'INV/23-24/-085-2023', 'INV/23-24/-085100823', '87');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (89, '-', '-', NULL, '2023-08-14', 'INV/23-24/-086', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '3540.00', '-', '-', '', '', '-', '-', NULL, '180540', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-086-2023', 'INV/23-24/-086140823', '88');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (90, '-', '-', NULL, '2023-08-14', 'INV/23-24/-087', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '1770.00', '-', '-', '', '', '-', '-', NULL, '182310', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-087-2023', 'INV/23-24/-087140823', '89');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (91, '-', '-', NULL, '2023-08-14', 'INV/23-24/-088', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '1770.00', '-', '-', '', '', '-', '-', NULL, '184080', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-088-2023', 'INV/23-24/-088140823', '90');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (92, '-', '-', NULL, '2023-08-14', 'INV/23-24/-089', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '1770.00', '-', '-', '', '', '-', '-', NULL, '185850', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-089-2023', 'INV/23-24/-089140823', '91');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (93, '-', '-', NULL, '2023-08-14', 'INV/23-24/-090', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '1770.00', '-', '-', '', '', '-', '-', NULL, '187620', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-090-2023', 'INV/23-24/-090140823', '92');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (94, '-', '-', NULL, '2023-08-14', 'INV/23-24/-091', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '4720.00', '-', '-', '', '', '-', '-', NULL, '192340', '-', '-', '-', '-', '4720.00', '-', '4720.00', NULL, NULL, 'INV/23-24/-091-2023', 'INV/23-24/-091140823', '93');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (95, '-', '-', NULL, '2023-08-14', 'INV/23-24/-092', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '4720.00', '-', '-', '', '', '-', '-', NULL, '197060', '-', '-', '-', '-', '4720.00', '-', '4720.00', NULL, NULL, 'INV/23-24/-092-2023', 'INV/23-24/-092140823', '94');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (96, '-', '-', NULL, '2023-08-14', 'INV/23-24/-093', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '3540.00', '-', '-', '', '', '-', '-', NULL, '200600', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-093-2023', 'INV/23-24/-093140823', '95');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (97, '-', '-', NULL, '2023-08-14', 'INV/23-24/-094', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '3540.00', '-', '-', '', '', '-', '-', NULL, '204140', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-094-2023', 'INV/23-24/-094140823', '96');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (98, '-', '-', NULL, '2023-08-14', 'INV/23-24/-095', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '4720.00', '-', '-', '', '', '-', '-', NULL, '208860', '-', '-', '-', '-', '4720.00', '-', '4720.00', NULL, NULL, 'INV/23-24/-095-2023', 'INV/23-24/-095140823', '97');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (99, '-', '-', NULL, '2023-08-14', 'INV/23-24/-096', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '4720.00', '-', '-', '', '', '-', '-', NULL, '213580', '-', '-', '-', '-', '4720.00', '-', '4720.00', NULL, NULL, 'INV/23-24/-096-2023', 'INV/23-24/-096140823', '98');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (100, '-', '-', NULL, '2023-08-14', 'INV/23-24/-097', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '3540.00', '-', '-', '', '', '-', '-', NULL, '217120', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-097-2023', 'INV/23-24/-097140823', '99');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (101, '-', '-', NULL, '2023-08-14', 'INV/23-24/-098', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '4720.00', '-', '-', '', '', '-', '-', NULL, '221840', '-', '-', '-', '-', '4720.00', '-', '4720.00', NULL, NULL, 'INV/23-24/-098-2023', 'INV/23-24/-098140823', '100');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (102, '-', '-', NULL, '2023-08-14', 'INV/23-24/-099', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '3540.00', '-', '-', '', '', '-', '-', NULL, '225380', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-099-2023', 'INV/23-24/-099140823', '101');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (103, '-', '-', NULL, '2023-08-14', 'INV/23-24/-100', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '3540.00', '-', '-', '', '', '-', '-', NULL, '228920', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-100-2023', 'INV/23-24/-100140823', '102');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (104, '-', '-', NULL, '2023-08-14', 'INV/23-24/-101', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '3540.00', '-', '-', '', '', '-', '-', NULL, '232460', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-101-2023', 'INV/23-24/-101140823', '103');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (105, '-', '-', NULL, '2023-08-14', 'INV/23-24/-102', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '3540.00', '-', '-', '', '', '-', '-', NULL, '236000', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-102-2023', 'INV/23-24/-102140823', '104');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (106, '-', '-', NULL, '2023-08-14', 'INV/23-24/-103', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '5310.00', '-', '-', '', '', '-', '-', NULL, '241310', '-', '-', '-', '-', '5310.00', '-', '5310.00', NULL, NULL, 'INV/23-24/-103-2023', 'INV/23-24/-103140823', '105');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (107, '-', '-', NULL, '2023-08-14', 'INV/23-24/-104', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '12390.00', '-', '-', '', '', '-', '-', NULL, '253700', '-', '-', '-', '-', '12390.00', '-', '12390.00', NULL, NULL, 'INV/23-24/-104-2023', 'INV/23-24/-104140823', '106');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (108, '-', '-', NULL, '2023-08-14', 'INV/23-24/-105', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '18880.00', '-', '-', '', '', '-', '-', NULL, '272580', '-', '-', '-', '-', '18880.00', '-', '18880.00', NULL, NULL, 'INV/23-24/-105-2023', 'INV/23-24/-105140823', '107');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (109, '-', '-', NULL, '2023-08-14', 'INV/23-24/-106', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '7080.00', '-', '-', '', '', '-', '-', NULL, '279660', '-', '-', '-', '-', '7080.00', '-', '7080.00', NULL, NULL, 'INV/23-24/-106-2023', 'INV/23-24/-106140823', '108');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (110, '-', '-', NULL, '2023-08-14', 'INV/23-24/-107', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '14160.00', '-', '-', '', '', '-', '-', NULL, '293820', '-', '-', '-', '-', '14160.00', '-', '14160.00', NULL, NULL, 'INV/23-24/-107-2023', 'INV/23-24/-107140823', '109');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (111, '-', '-', NULL, '2023-08-14', 'INV/23-24/-108', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '7080.00', '-', '-', '', '', '-', '-', NULL, '300900', '-', '-', '-', '-', '7080.00', '-', '7080.00', NULL, NULL, 'INV/23-24/-108-2023', 'INV/23-24/-108140823', '110');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (112, '-', '-', NULL, '2023-08-14', 'INV/23-24/-109', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '8850.00', '-', '-', '', '', '-', '-', NULL, '309750', '-', '-', '-', '-', '8850.00', '-', '8850.00', NULL, NULL, 'INV/23-24/-109-2023', 'INV/23-24/-109140823', '111');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (113, '-', '-', NULL, '2023-08-14', 'INV/23-24/-110', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '16520.00', '-', '-', '', '', '-', '-', NULL, '326270', '-', '-', '-', '-', '16520.00', '-', '16520.00', NULL, NULL, 'INV/23-24/-110-2023', 'INV/23-24/-110140823', '112');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (114, '-', '-', NULL, '2023-08-14', 'INV/23-24/-111', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '12390.00', '-', '-', '', '', '-', '-', NULL, '338660', '-', '-', '-', '-', '12390.00', '-', '12390.00', NULL, NULL, 'INV/23-24/-111-2023', 'INV/23-24/-111140823', '113');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (115, '-', '-', NULL, '2023-08-14', 'INV/23-24/-112', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '3540.00', '-', '-', '', '', '-', '-', NULL, '342200', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-112-2023', 'INV/23-24/-112140823', '114');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (116, '-', '-', NULL, '2023-08-14', 'INV/23-24/-113', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '3540.00', '-', '-', '', '', '-', '-', NULL, '345740', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-113-2023', 'INV/23-24/-113140823', '115');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (117, '-', '-', NULL, '2023-08-14', 'INV/23-24/-114', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '3540.00', '-', '-', '', '', '-', '-', NULL, '349280', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-114-2023', 'INV/23-24/-114140823', '116');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (118, '-', '-', NULL, '2023-08-14', 'INV/23-24/-115', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '3540.00', '-', '-', '', '', '-', '-', NULL, '352820', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-115-2023', 'INV/23-24/-115140823', '117');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (119, '-', '-', NULL, '2023-08-14', 'INV/23-24/-116', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '3540.00', '-', '-', '', '', '-', '-', NULL, '356360', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-116-2023', 'INV/23-24/-116140823', '118');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (120, '-', '-', NULL, '2023-08-14', 'INV/23-24/-117', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '8850.00', '-', '-', '', '', '-', '-', NULL, '365210', '-', '-', '-', '-', '8850.00', '-', '8850.00', NULL, NULL, 'INV/23-24/-117-2023', 'INV/23-24/-117140823', '119');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (121, '-', '-', NULL, '2023-08-14', 'INV/23-24/-118', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '4720.00', '-', '-', '', '', '-', '-', NULL, '369930', '-', '-', '-', '-', '4720.00', '-', '4720.00', NULL, NULL, 'INV/23-24/-118-2023', 'INV/23-24/-118140823', '120');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (122, '-', '-', NULL, '2023-08-14', 'INV/23-24/-119', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '3540.00', '-', '-', '', '', '-', '-', NULL, '373470', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-119-2023', 'INV/23-24/-119140823', '121');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (123, '-', '-', NULL, '2023-08-14', 'INV/23-24/-120', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '4720.00', '-', '-', '', '', '-', '-', NULL, '378190', '-', '-', '-', '-', '4720.00', '-', '4720.00', NULL, NULL, 'INV/23-24/-120-2023', 'INV/23-24/-120140823', '122');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (124, '-', '-', NULL, '2023-08-14', 'INV/23-24/-121', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '127440.00', '-', '-', '', '', '-', '-', NULL, '505630', '-', '-', '-', '-', '127440.00', '-', '127440.00', NULL, NULL, 'INV/23-24/-121-2023', 'INV/23-24/-121140823', '123');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (125, '-', '-', NULL, '2023-08-14', 'INV/23-24/-122', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '8850.00', '-', '-', '', '', '-', '-', NULL, '514480', '-', '-', '-', '-', '8850.00', '-', '8850.00', NULL, NULL, 'INV/23-24/-122-2023', 'INV/23-24/-122140823', '124');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (126, '-', '-', NULL, '2023-08-14', 'INV/23-24/-123', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-14', '2023-08-14', '3540.00', '-', '-', '', '', '-', '-', NULL, '518020', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-123-2023', 'INV/23-24/-123140823', '125');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (127, '-', '-', NULL, '2023-08-15', 'INV/23-24/-124', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-15', '2023-08-15', '3540.00', '-', '-', '', '', '-', '-', NULL, '521560', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-124-2023', 'INV/23-24/-124150823', '126');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (128, '-', '-', NULL, '2023-08-15', 'INV/23-24/-125', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-15', '2023-08-15', '8850.00', '-', '-', '', '', '-', '-', NULL, '530410', '-', '-', '-', '-', '8850.00', '-', '8850.00', NULL, NULL, 'INV/23-24/-125-2023', 'INV/23-24/-125150823', '127');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (129, '-', '-', NULL, '2023-08-18', 'INV/23-24/-126', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-18', '2023-08-18', '118000.00', '-', '-', '', '', '-', '-', NULL, '648410', '-', '-', '-', '-', '118000.00', '-', '118000.00', NULL, NULL, 'INV/23-24/-126-2023', 'INV/23-24/-126180823', '128');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (130, 'V/23-24/-001', '', NULL, '2023-08-23', '-', 0, 'SMK INDUSTRIES', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2023-08-23', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '2417410', NULL, NULL, NULL, 'Cash', NULL, '1000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (131, 'V/23-24/-003', '', NULL, '2023-08-23', '-', 0, 'SMK INDUSTRIES', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2023-08-23', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '2407410', NULL, NULL, NULL, 'Cheque INDIAN OVERSEAS 563966', NULL, '10000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (133, '-', '-', NULL, '2023-09-05', 'INV/23-24/-127', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM 70MM CLEATED STATOR', '||', '', '', NULL, NULL, '', '', '1', '2023-09-05', '2023-09-05', '17700.00', '-', '-', '', '', '-', '-', NULL, '2425110', '-', '-', '-', '-', '17700.00', '-', '17700.00', NULL, NULL, NULL, NULL, '129');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (134, '-', '-', NULL, '2023-09-29', 'INV/23-24/-128', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-09-29', '2023-09-29', '177000.00', '-', '-', '', '', '-', '-', NULL, '2602110', '-', '-', '-', '-', '177000.00', '-', '177000.00', NULL, NULL, 'INV/23-24/-128-2023', 'INV/23-24/-128290923', '130');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (136, '-', '-', NULL, '2023-10-03', 'INV/23-24/-129', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-10-03', '2023-10-03', '35.40', '-', '-', '', '', '-', '-', NULL, '2602145.4', '-', '-', '-', '-', '35.40', '-', '35.40', NULL, NULL, NULL, NULL, '131');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (137, '-', '-', NULL, '2023-10-11', 'INV/23-24/-130', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', '', '', NULL, NULL, '', '', '1', '2023-10-11', '2023-10-11', '361062.30', '-', '-', '', '', '-', '-', NULL, '2963207.7', '-', '-', '-', '-', '361062.30', '-', '361062.30', NULL, NULL, 'INV/23-24/-130-2023', 'INV/23-24/-130111023', '132');


#
# TABLE STRUCTURE FOR: invoice_party_statement_backup
#

DROP TABLE IF EXISTS `invoice_party_statement_backup`;

CREATE TABLE `invoice_party_statement_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: invoice_reports
#

DROP TABLE IF EXISTS `invoice_reports`;

CREATE TABLE `invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=latin1;

INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2023-07-28', 'INV/23-24/-001', '2023-07-28', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', '1', NULL, '4130.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-001-2023', 'INV/23-24/-001280723', '1');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '2023-07-28', 'INV/23-24/-001', '2023-07-28', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '5', '1', '7', NULL, '4130.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-001-2023', 'INV/23-24/-001280723', '1');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (5, '2023-07-28', 'INV/23-24/-002', '2023-07-28', NULL, NULL, 0, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1500', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', NULL, NULL, '2');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (6, '2023-07-28', 'INV/23-24/-002', '2023-07-28', NULL, NULL, 0, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2000', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', NULL, NULL, '2');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (7, '2023-07-29', 'INV/23-24/-003', '2023-07-29', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-003-2023', 'INV/23-24/-003290723', '3');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (8, '2023-07-29', 'INV/23-24/-003', '2023-07-29', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '5', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-003-2023', 'INV/23-24/-003290723', '3');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (9, '2023-07-29', 'INV/23-24/-004', '2023-07-29', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-004-2023', 'INV/23-24/-004290723', '4');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (10, '2023-07-29', 'INV/23-24/-004', '2023-07-29', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '5', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-004-2023', 'INV/23-24/-004290723', '4');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (11, '2023-07-29', 'INV/23-24/-005', '2023-07-29', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-005-2023', 'INV/23-24/-005290723', '5');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (12, '2023-07-29', 'INV/23-24/-005', '2023-07-29', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '0', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-005-2023', 'INV/23-24/-005290723', '5');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (13, '2023-07-29', 'INV/23-24/-006', '2023-07-29', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-006-2023', 'INV/23-24/-006290723', '6');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (14, '2023-07-29', 'INV/23-24/-006', '2023-07-29', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '5', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-006-2023', 'INV/23-24/-006290723', '6');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (15, '2023-08-03', 'INV/23-24/-007', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-007-2023', 'INV/23-24/-007030823', '7');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (16, '2023-08-03', 'INV/23-24/-008', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-008-2023', 'INV/23-24/-008030823', '8');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (17, '2023-08-03', 'INV/23-24/-009', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-009-2023', 'INV/23-24/-009030823', '9');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (18, '2023-08-03', 'INV/23-24/-010', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-010-2023', 'INV/23-24/-010030823', '10');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (19, '2023-08-03', 'INV/23-24/-011', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-011-2023', 'INV/23-24/-011030823', '11');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (20, '2023-08-03', 'INV/23-24/-012', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-012-2023', 'INV/23-24/-012030823', '12');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (21, '2023-08-03', 'INV/23-24/-013', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-013-2023', 'INV/23-24/-013030823', '13');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (22, '2023-08-03', 'INV/23-24/-014', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-014-2023', 'INV/23-24/-014030823', '14');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (23, '2023-08-03', 'INV/23-24/-015', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-015-2023', 'INV/23-24/-015030823', '15');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (24, '2023-08-03', 'INV/23-24/-016', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-016-2023', 'INV/23-24/-016030823', '16');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (25, '2023-08-03', 'INV/23-24/-017', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-017-2023', 'INV/23-24/-017030823', '17');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (26, '2023-08-03', 'INV/23-24/-018', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-018-2023', 'INV/23-24/-018030823', '18');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (27, '2023-08-03', 'INV/23-24/-019', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-019-2023', 'INV/23-24/-019030823', '19');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (28, '2023-08-03', 'INV/23-24/-020', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-020-2023', 'INV/23-24/-020030823', '20');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (29, '2023-08-03', 'INV/23-24/-021', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-021-2023', 'INV/23-24/-021030823', '21');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (30, '2023-08-03', 'INV/23-24/-022', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-022-2023', 'INV/23-24/-022030823', '22');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (31, '2023-08-03', 'INV/23-24/-023', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-023-2023', 'INV/23-24/-023030823', '23');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (32, '2023-08-03', 'INV/23-24/-024', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-024-2023', 'INV/23-24/-024030823', '24');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (33, '2023-08-03', 'INV/23-24/-025', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-025-2023', 'INV/23-24/-025030823', '25');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (34, '2023-08-03', 'INV/23-24/-026', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-026-2023', 'INV/23-24/-026030823', '26');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (35, '2023-08-03', 'INV/23-24/-027', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-027-2023', 'INV/23-24/-027030823', '27');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (36, '2023-08-03', 'INV/23-24/-028', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-028-2023', 'INV/23-24/-028030823', '28');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (37, '2023-08-03', 'INV/23-24/-029', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-029-2023', 'INV/23-24/-029030823', '29');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (38, '2023-08-03', 'INV/23-24/-030', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-030-2023', 'INV/23-24/-030030823', '30');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (39, '2023-08-03', 'INV/23-24/-031', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-031-2023', 'INV/23-24/-031030823', '31');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (40, '2023-08-03', 'INV/23-24/-032', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-032-2023', 'INV/23-24/-032030823', '32');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (41, '2023-08-03', 'INV/23-24/-033', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-033-2023', 'INV/23-24/-033030823', '33');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (42, '2023-08-03', 'INV/23-24/-034', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-034-2023', 'INV/23-24/-034030823', '34');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (43, '2023-08-04', 'INV/23-24/-035', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-035-2023', 'INV/23-24/-035040823', '35');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (44, '2023-08-04', 'INV/23-24/-036', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-036-2023', 'INV/23-24/-036040823', '36');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (45, '2023-08-04', 'INV/23-24/-037', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-037-2023', 'INV/23-24/-037040823', '37');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (46, '2023-08-04', 'INV/23-24/-038', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-038-2023', 'INV/23-24/-038040823', '38');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (47, '2023-08-04', 'INV/23-24/-039', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-039-2023', 'INV/23-24/-039040823', '39');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (48, '2023-08-04', 'INV/23-24/-040', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-040-2023', 'INV/23-24/-040040823', '40');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (49, '2023-08-04', 'INV/23-24/-041', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-041-2023', 'INV/23-24/-041040823', '41');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (50, '2023-08-04', 'INV/23-24/-042', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-042-2023', 'INV/23-24/-042040823', '42');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (51, '2023-08-04', 'INV/23-24/-043', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-043-2023', 'INV/23-24/-043040823', '43');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (52, '2023-08-04', 'INV/23-24/-044', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-044-2023', 'INV/23-24/-044040823', '44');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (53, '2023-08-04', 'INV/23-24/-045', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-045-2023', 'INV/23-24/-045040823', '45');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (54, '2023-08-04', 'INV/23-24/-046', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-046-2023', 'INV/23-24/-046040823', '46');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (55, '2023-08-04', 'INV/23-24/-047', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-047-2023', 'INV/23-24/-047040823', '47');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (56, '2023-08-04', 'INV/23-24/-048', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-048-2023', 'INV/23-24/-048040823', '48');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (57, '2023-08-04', 'INV/23-24/-049', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-049-2023', 'INV/23-24/-049040823', '49');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (58, '2023-08-04', 'INV/23-24/-050', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-050-2023', 'INV/23-24/-050040823', '50');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (59, '2023-08-04', 'INV/23-24/-051', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-051-2023', 'INV/23-24/-051040823', '51');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (60, '2023-08-04', 'INV/23-24/-052', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-052-2023', 'INV/23-24/-052040823', '52');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (61, '2023-08-04', 'INV/23-24/-053', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-053-2023', 'INV/23-24/-053040823', '53');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (62, '2023-08-04', 'INV/23-24/-054', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-054-2023', 'INV/23-24/-054040823', '54');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (63, '2023-08-04', 'INV/23-24/-055', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-055-2023', 'INV/23-24/-055040823', '55');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (64, '2023-08-04', 'INV/23-24/-056', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-056-2023', 'INV/23-24/-056040823', '56');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (65, '2023-08-04', 'INV/23-24/-057', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-057-2023', 'INV/23-24/-057040823', '57');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (66, '2023-08-04', 'INV/23-24/-058', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-058-2023', 'INV/23-24/-058040823', '58');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (67, '2023-08-04', 'INV/23-24/-059', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-059-2023', 'INV/23-24/-059040823', '59');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (68, '2023-08-04', 'INV/23-24/-060', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-060-2023', 'INV/23-24/-060040823', '60');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (69, '2023-08-07', 'INV/23-24/-061', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-061-2023', 'INV/23-24/-061070823', '61');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (70, '2023-08-07', 'INV/23-24/-062', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-062-2023', 'INV/23-24/-062070823', '62');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (71, '2023-08-07', 'INV/23-24/-063', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-063-2023', 'INV/23-24/-063070823', '63');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (72, '2023-08-07', 'INV/23-24/-064', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-064-2023', 'INV/23-24/-064070823', '64');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (73, '2023-08-07', 'INV/23-24/-065', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-065-2023', 'INV/23-24/-065070823', '65');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (74, '2023-08-07', 'INV/23-24/-066', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-066-2023', 'INV/23-24/-066070823', '66');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (75, '2023-08-07', 'INV/23-24/-067', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-067-2023', 'INV/23-24/-067070823', '67');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (76, '2023-08-07', 'INV/23-24/-068', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-068-2023', 'INV/23-24/-068070823', '68');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (77, '2023-08-07', 'INV/23-24/-069', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-069-2023', 'INV/23-24/-069070823', '69');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (78, '2023-08-07', 'INV/23-24/-070', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-070-2023', 'INV/23-24/-070070823', '70');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (79, '2023-08-07', 'INV/23-24/-071', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-071-2023', 'INV/23-24/-071070823', '71');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (80, '2023-08-07', 'INV/23-24/-072', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-072-2023', 'INV/23-24/-072070823', '72');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (81, '2023-08-07', 'INV/23-24/-073', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-073-2023', 'INV/23-24/-073070823', '73');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (83, '2023-08-07', 'INV/23-24/-074', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '2', NULL, NULL, '4000.00', NULL, NULL, '4720.00', NULL, NULL, '1', 'INV/23-24/-074-2023', 'INV/23-24/-074070823', '75');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (86, '2023-08-08', 'INV/23-24/-076', '2023-08-08', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-076-2023', 'INV/23-24/-076080823', '78');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (87, '2023-08-08', 'INV/23-24/-077', '2023-08-08', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-077-2023', 'INV/23-24/-077080823', '79');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (93, '2023-08-08', 'INV/23-24/-083', '2023-08-08', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '2', NULL, NULL, '4000.00', NULL, NULL, '4720.00', NULL, NULL, '1', 'INV/23-24/-083-2023', 'INV/23-24/-083080823', '85');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (94, '2023-08-09', 'INV/23-24/-084', '2023-08-09', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '2', NULL, NULL, '4000.00', NULL, NULL, '4720.00', NULL, NULL, '1', 'INV/23-24/-084-2023', 'INV/23-24/-084090823', '86');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (95, '2023-08-10', 'INV/23-24/-085', '2023-08-10', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '2', '3', NULL, '8260.00', NULL, NULL, '8260.00', NULL, NULL, '1', 'INV/23-24/-085-2023', 'INV/23-24/-085100823', '87');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (96, '2023-08-10', 'INV/23-24/-085', '2023-08-10', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '5', '2', '5', NULL, '8260.00', NULL, NULL, '8260.00', NULL, NULL, '1', 'INV/23-24/-085-2023', 'INV/23-24/-085100823', '87');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (97, '2023-08-14', 'INV/23-24/-086', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '2', NULL, NULL, '3000.00', NULL, NULL, '3540.00', NULL, NULL, '1', 'INV/23-24/-086-2023', 'INV/23-24/-086140823', '88');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (98, '2023-08-14', 'INV/23-24/-087', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-087-2023', 'INV/23-24/-087140823', '89');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (99, '2023-08-14', 'INV/23-24/-088', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-088-2023', 'INV/23-24/-088140823', '90');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (100, '2023-08-14', 'INV/23-24/-089', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-089-2023', 'INV/23-24/-089140823', '91');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (101, '2023-08-14', 'INV/23-24/-090', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-090-2023', 'INV/23-24/-090140823', '92');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (102, '2023-08-14', 'INV/23-24/-091', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '2', NULL, NULL, '4000.00', NULL, NULL, '4720.00', NULL, NULL, '1', 'INV/23-24/-091-2023', 'INV/23-24/-091140823', '93');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (103, '2023-08-14', 'INV/23-24/-092', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '2', NULL, NULL, '4000.00', NULL, NULL, '4720.00', NULL, NULL, '1', 'INV/23-24/-092-2023', 'INV/23-24/-092140823', '94');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (104, '2023-08-14', 'INV/23-24/-093', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '2', NULL, NULL, '3000.00', NULL, NULL, '3540.00', NULL, NULL, '1', 'INV/23-24/-093-2023', 'INV/23-24/-093140823', '95');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (105, '2023-08-14', 'INV/23-24/-094', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '2', NULL, NULL, '3000.00', NULL, NULL, '3540.00', NULL, NULL, '1', 'INV/23-24/-094-2023', 'INV/23-24/-094140823', '96');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (106, '2023-08-14', 'INV/23-24/-095', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '2', NULL, NULL, '4000.00', NULL, NULL, '4720.00', NULL, NULL, '1', 'INV/23-24/-095-2023', 'INV/23-24/-095140823', '97');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (107, '2023-08-14', 'INV/23-24/-096', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '2', NULL, NULL, '4000.00', NULL, NULL, '4720.00', NULL, NULL, '1', 'INV/23-24/-096-2023', 'INV/23-24/-096140823', '98');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (108, '2023-08-14', 'INV/23-24/-097', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '2', NULL, NULL, '3000.00', NULL, NULL, '3540.00', NULL, NULL, '1', 'INV/23-24/-097-2023', 'INV/23-24/-097140823', '99');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (109, '2023-08-14', 'INV/23-24/-098', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '2', NULL, NULL, '4000.00', NULL, NULL, '4720.00', NULL, NULL, '1', 'INV/23-24/-098-2023', 'INV/23-24/-098140823', '100');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (110, '2023-08-14', 'INV/23-24/-099', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '2', NULL, NULL, '3000.00', NULL, NULL, '3540.00', NULL, NULL, '1', 'INV/23-24/-099-2023', 'INV/23-24/-099140823', '101');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (111, '2023-08-14', 'INV/23-24/-100', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '2', NULL, NULL, '3000.00', NULL, NULL, '3540.00', NULL, NULL, '1', 'INV/23-24/-100-2023', 'INV/23-24/-100140823', '102');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (112, '2023-08-14', 'INV/23-24/-101', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '2', NULL, NULL, '3000.00', NULL, NULL, '3540.00', NULL, NULL, '1', 'INV/23-24/-101-2023', 'INV/23-24/-101140823', '103');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (113, '2023-08-14', 'INV/23-24/-102', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '2', NULL, NULL, '3000.00', NULL, NULL, '3540.00', NULL, NULL, '1', 'INV/23-24/-102-2023', 'INV/23-24/-102140823', '104');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (114, '2023-08-14', 'INV/23-24/-103', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '3', NULL, NULL, '4500.00', NULL, NULL, '5310.00', NULL, NULL, '1', 'INV/23-24/-103-2023', 'INV/23-24/-103140823', '105');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (115, '2023-08-14', 'INV/23-24/-104', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '7', NULL, NULL, '10500.00', NULL, NULL, '12390.00', NULL, NULL, '1', 'INV/23-24/-104-2023', 'INV/23-24/-104140823', '106');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (116, '2023-08-14', 'INV/23-24/-105', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '8', NULL, NULL, '16000.00', NULL, NULL, '18880.00', NULL, NULL, '1', 'INV/23-24/-105-2023', 'INV/23-24/-105140823', '107');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (117, '2023-08-14', 'INV/23-24/-106', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '4', NULL, NULL, '6000.00', NULL, NULL, '7080.00', NULL, NULL, '1', 'INV/23-24/-106-2023', 'INV/23-24/-106140823', '108');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (118, '2023-08-14', 'INV/23-24/-107', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '8', NULL, NULL, '12000.00', NULL, NULL, '14160.00', NULL, NULL, '1', 'INV/23-24/-107-2023', 'INV/23-24/-107140823', '109');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (119, '2023-08-14', 'INV/23-24/-108', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '4', NULL, NULL, '6000.00', NULL, NULL, '7080.00', NULL, NULL, '1', 'INV/23-24/-108-2023', 'INV/23-24/-108140823', '110');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (120, '2023-08-14', 'INV/23-24/-109', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '5', NULL, NULL, '7500.00', NULL, NULL, '8850.00', NULL, NULL, '1', 'INV/23-24/-109-2023', 'INV/23-24/-109140823', '111');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (121, '2023-08-14', 'INV/23-24/-110', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '7', NULL, NULL, '14000.00', NULL, NULL, '16520.00', NULL, NULL, '1', 'INV/23-24/-110-2023', 'INV/23-24/-110140823', '112');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (122, '2023-08-14', 'INV/23-24/-111', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '7', NULL, NULL, '10500.00', NULL, NULL, '12390.00', NULL, NULL, '1', 'INV/23-24/-111-2023', 'INV/23-24/-111140823', '113');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (123, '2023-08-14', 'INV/23-24/-112', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '2', NULL, NULL, '3000.00', NULL, NULL, '3540.00', NULL, NULL, '1', 'INV/23-24/-112-2023', 'INV/23-24/-112140823', '114');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (124, '2023-08-14', 'INV/23-24/-113', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '2', NULL, NULL, '3000.00', NULL, NULL, '3540.00', NULL, NULL, '1', 'INV/23-24/-113-2023', 'INV/23-24/-113140823', '115');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (125, '2023-08-14', 'INV/23-24/-114', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '2', NULL, NULL, '3000.00', NULL, NULL, '3540.00', NULL, NULL, '1', 'INV/23-24/-114-2023', 'INV/23-24/-114140823', '116');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (126, '2023-08-14', 'INV/23-24/-115', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '2', NULL, NULL, '3000.00', NULL, NULL, '3540.00', NULL, NULL, '1', 'INV/23-24/-115-2023', 'INV/23-24/-115140823', '117');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (127, '2023-08-14', 'INV/23-24/-116', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '2', NULL, NULL, '3000.00', NULL, NULL, '3540.00', NULL, NULL, '1', 'INV/23-24/-116-2023', 'INV/23-24/-116140823', '118');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (128, '2023-08-14', 'INV/23-24/-117', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '5', NULL, NULL, '7500.00', NULL, NULL, '8850.00', NULL, NULL, '1', 'INV/23-24/-117-2023', 'INV/23-24/-117140823', '119');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (129, '2023-08-14', 'INV/23-24/-118', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '2', NULL, NULL, '4000.00', NULL, NULL, '4720.00', NULL, NULL, '1', 'INV/23-24/-118-2023', 'INV/23-24/-118140823', '120');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (130, '2023-08-14', 'INV/23-24/-119', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '2', NULL, NULL, '3000.00', NULL, NULL, '3540.00', NULL, NULL, '1', 'INV/23-24/-119-2023', 'INV/23-24/-119140823', '121');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (131, '2023-08-14', 'INV/23-24/-120', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '2', NULL, NULL, '4000.00', NULL, NULL, '4720.00', NULL, NULL, '1', 'INV/23-24/-120-2023', 'INV/23-24/-120140823', '122');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (132, '2023-08-14', 'INV/23-24/-121', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '54', NULL, NULL, '108000.00', NULL, NULL, '127440.00', NULL, NULL, '1', 'INV/23-24/-121-2023', 'INV/23-24/-121140823', '123');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (133, '2023-08-14', 'INV/23-24/-122', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '5', NULL, NULL, '7500.00', NULL, NULL, '8850.00', NULL, NULL, '1', 'INV/23-24/-122-2023', 'INV/23-24/-122140823', '124');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (134, '2023-08-14', 'INV/23-24/-123', '2023-08-14', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '2', NULL, NULL, '3000.00', NULL, NULL, '3540.00', NULL, NULL, '1', 'INV/23-24/-123-2023', 'INV/23-24/-123140823', '125');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (135, '2023-08-15', 'INV/23-24/-124', '2023-08-15', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '2', NULL, NULL, '3000.00', NULL, NULL, '3540.00', NULL, NULL, '1', 'INV/23-24/-124-2023', 'INV/23-24/-124150823', '126');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (136, '2023-08-15', 'INV/23-24/-125', '2023-08-15', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '5', NULL, NULL, '7500.00', NULL, NULL, '8850.00', NULL, NULL, '1', 'INV/23-24/-125-2023', 'INV/23-24/-125150823', '127');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (137, '2023-08-18', 'INV/23-24/-126', '2023-08-18', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '2', '50', NULL, NULL, '100000.00', NULL, NULL, '118000.00', NULL, NULL, '1', 'INV/23-24/-126-2023', 'INV/23-24/-126180823', '128');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (140, '2023-09-20', 'INV/23-24/-127', '2023-09-05', NULL, NULL, 0, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1500', '5', NULL, NULL, '15000.00', NULL, NULL, '17700.00', NULL, NULL, '1', NULL, NULL, '129');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (141, '2023-09-20', 'INV/23-24/-127', '2023-09-05', NULL, NULL, 0, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1500', '5', NULL, NULL, '15000.00', NULL, NULL, '17700.00', NULL, NULL, '1', NULL, NULL, '129');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (142, '2023-09-29', 'INV/23-24/-128', '2023-09-29', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '100', '1', NULL, '150000.00', NULL, NULL, '177000.00', NULL, NULL, '1', 'INV/23-24/-128-2023', 'INV/23-24/-128290923', '130');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (144, '2023-10-03', 'INV/23-24/-129', '2023-10-03', NULL, NULL, 0, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '15', '02', NULL, NULL, '30.00', NULL, NULL, '35.40', NULL, NULL, '1', NULL, NULL, '131');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (145, '2023-10-11', 'INV/23-24/-130', '2023-10-11', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '100', NULL, NULL, '305985.00', NULL, NULL, '361062.30', NULL, NULL, '1', 'INV/23-24/-130-2023', 'INV/23-24/-130111023', '132');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (146, '2023-10-11', 'INV/23-24/-130', '2023-10-11', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '5', '30', NULL, NULL, '305985.00', NULL, NULL, '361062.30', NULL, NULL, '1', 'INV/23-24/-130-2023', 'INV/23-24/-130111023', '132');


#
# TABLE STRUCTURE FOR: inward_delivery
#

DROP TABLE IF EXISTS `inward_delivery`;

CREATE TABLE `inward_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insertid` int(11) NOT NULL,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `lastupdatedqty` int(11) NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `inward_status` int(11) DEFAULT NULL,
  `lastupdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (1, 1, '2023-08-22', 'I001', '2023-08-22', 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'DC002', '2023-08-22', '1', '1080R2-2PM 70MM CLEATED STATOR', '', '500', '300', 500, 'for drilling ', '850300', NULL, 'KGS', 'I001-23', 'I001220823', 1, 1, '2023-08-22 08:21:45');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (2, 2, '2023-08-24', 'I002', '2023-08-24', 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'DC003', '2023-08-24', '2', '1080R2-2PM STATOR STAMPING-GANG', '', '100', '100', 100, '', '7204', NULL, 'KGS', 'I002-23', 'I002240823', 1, 1, '2023-08-24 01:51:53');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (3, 2, '2023-08-24', 'I002', '2023-08-24', 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'DC003', '2023-08-24', '1', '1080R2-2PM 70MM CLEATED STATOR', '', '150', '150', 150, '', '850300', NULL, 'KGS', 'I002-23', 'I002240823', 1, 1, '2023-08-24 01:51:53');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (4, 3, '2023-10-03', 'I003', '2023-10-03', 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'DC008', '2023-10-03', '1', '1080R2-2PM 70MM CLEATED STATOR', '', '100', '90', 100, '-', '850300', NULL, 'KGS', 'I003-23', 'I003031023', 1, 1, '2023-10-03 06:01:57');


#
# TABLE STRUCTURE FOR: inward_details
#

DROP TABLE IF EXISTS `inward_details`;

CREATE TABLE `inward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (1, '2023-08-22', 'I001', '2023-08-22', 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'DC002', '2023-08-22', '1', '1080R2-2PM 70MM CLEATED STATOR', '', '500', 'for drilling ', '850300', NULL, 'KGS', 'I001-23', 'I001220823', 1, 0, '1');
INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (2, '2023-08-24', 'I002', '2023-08-24', 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'DC003', '2023-08-24', '2||1', '1080R2-2PM STATOR STAMPING-GANG||1080R2-2PM 70MM CLEATED STATOR', '', '100||150', '', '7204||850300', NULL, 'KGS||KGS', 'I002-23', 'I002240823', 1, 1, '2,3');
INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (3, '2023-10-03', 'I003', '2023-10-03', 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'DC008', '2023-10-03', '1', '1080R2-2PM 70MM CLEATED STATOR', '', '100', '-', '850300', NULL, 'KGS', 'I003-23', 'I003031023', 1, 0, '4');


#
# TABLE STRUCTURE FOR: inward_details_backup
#

DROP TABLE IF EXISTS `inward_details_backup`;

CREATE TABLE `inward_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: job_data
#

DROP TABLE IF EXISTS `job_data`;

CREATE TABLE `job_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: job_details
#

DROP TABLE IF EXISTS `job_details`;

CREATE TABLE `job_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `joborderdate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext,
  `category` longtext,
  `jobdescription` longtext,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobinward_data
#

DROP TABLE IF EXISTS `jobinward_data`;

CREATE TABLE `jobinward_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `joborderqty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobinward_details
#

DROP TABLE IF EXISTS `jobinward_details`;

CREATE TABLE `jobinward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `jobinwarddate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext,
  `joborderno` varchar(225) DEFAULT NULL,
  `category` longtext,
  `jobdescription` longtext,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobworkdc_delivery
#

DROP TABLE IF EXISTS `jobworkdc_delivery`;

CREATE TABLE `jobworkdc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobworkdc_delivery_backup
#

DROP TABLE IF EXISTS `jobworkdc_delivery_backup`;

CREATE TABLE `jobworkdc_delivery_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobworkdc_details
#

DROP TABLE IF EXISTS `jobworkdc_details`;

CREATE TABLE `jobworkdc_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobworkdc_details_backup
#

DROP TABLE IF EXISTS `jobworkdc_details_backup`;

CREATE TABLE `jobworkdc_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: login_details
#

DROP TABLE IF EXISTS `login_details`;

CREATE TABLE `login_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userType` char(1) NOT NULL,
  `date` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `sub_menu_link` text,
  `selectedMainMenu` text NOT NULL,
  `selectedSubMenu` text NOT NULL,
  `add_party` int(11) DEFAULT NULL,
  `add_expenses` int(11) DEFAULT NULL,
  `add_quotation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (1, 'A', '2017-01-26', 'admin', '', 'test@gmail.com', '876049652', '0000-00-00', 'admin', 'admin001', '1', '', '', '', NULL, NULL, NULL);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (5, 'U', '2018-05-02', 'purchase', 'Purchase Team', '', '', '1970-01-01', 'purchase', '123456', '1', 'purchase,inward,inward/view,inward/pending,stockmaster,daily_stockreports,customer/view', 'Purchase,Inward,Inward,Inward,Stock,Stock,Reports', 'Purchase Receipt,Add Inward,Inward Reports,Inward Pending,Add Stock,Daily Stock Reports,Party Reports', 1, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (6, 'U', '2018-05-02', 'Accounts', 'Accounts Team', '', '', '1970-01-01', 'Accounts', '123456', '1', 'invoice_statement/view,tax/view,cashbill/listing,purchase_statement/view,purchasetax/view,voucher,voucher/reports,stockmaster,daily_stockreports,itemwise_report,expenses/reports,quotation/view', 'Sales Invoice,Sales Invoice,Cash Bill,Purchase,Purchase,Voucher,Voucher,Stock,Stock,Stock,Reports,Reports', 'Invoice Party Statement,Invoice Tax Reports,Cash Bill Reports,Purchase Party Statement,Purchase Tax Reports,Add Voucher,Voucher Reports,Add Stock,Daily Stock Reports,Itemwise Reports,Expenses Reports,Quotation Reports', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (7, 'U', '2018-08-10', 'ramesh', 'developer', '', '', '1970-01-01', 'ramesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/reports,purchase_statement/view,purchasetax/view,stockmaster,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Stock,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Add Stock,Add Item', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (8, 'U', '2018-08-10', 'tester1', 'testing', '', '', '1970-01-01', 'tester1', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/view,purchase_statement/view,purchasetax/view,taxtype,uom,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Settings,Settings,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Tax Type,Add UOM,Add Item', 1, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (9, 'U', '2021-06-28', 'parmesh', 'developer', 'pshm956@gmail.com', '8344031191', '2021-06-28', 'parmesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,proforma_invoice/view', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Proforma Invoice Reports', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (10, 'U', '2023-09-12', 'jp', 'quotation', 'jp@idreamdevelopers.com', '7810028222', '2023-09-12', 'jp', '123456', '1', 'taxtype,uom,itemmaster,headers,profile,backup,support,usermaster', 'Settings,Settings,Settings,Settings,Settings,Settings,Settings,Settings', 'Tax Type,Add UOM,Add Item,Account Headers,Company Profile,Backup Settings,Support,User Manager', 1, 1, 1);


#
# TABLE STRUCTURE FOR: materialdc_delivery
#

DROP TABLE IF EXISTS `materialdc_delivery`;

CREATE TABLE `materialdc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: materialdc_details
#

DROP TABLE IF EXISTS `materialdc_details`;

CREATE TABLE `materialdc_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: materialdc_details_backup
#

DROP TABLE IF EXISTS `materialdc_details_backup`;

CREATE TABLE `materialdc_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: po_party_statements
#

DROP TABLE IF EXISTS `po_party_statements`;

CREATE TABLE `po_party_statements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (1, '2023-08-18', '2023-08-18', '-', 'P001', 2, 'J.K INDUSTRIES', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', NULL, '200000.00', '-', '-', '-', NULL, '-', '200000', NULL, '-', '-', '-', '-', '-', '200000.00', '-', NULL, '-', NULL, '200000.00', NULL, 'IN_001', '2023-08-18', '1', 'P001180823', 'P001-2023', '1');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (2, '2023-08-23', NULL, 'V/23-24/-002', NULL, 0, 'J.K INDUSTRIES', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '175000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Cash', NULL, '25000', NULL, '-', NULL, '-', NULL, '1', NULL, NULL, NULL);
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (3, '2023-08-23', NULL, 'V/23-24/-004', NULL, 0, 'J.K INDUSTRIES', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '165000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Cheque INDIAN BANK 563966', NULL, '10000', NULL, '-', NULL, '-', NULL, '1', NULL, NULL, NULL);
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (4, '2023-10-03', '2023-10-03', '-', 'P0002', 2, 'J.K INDUSTRIES', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', NULL, '17700.00', '-', '-', '-', NULL, '-', '182700', NULL, '-', '-', '-', '-', '-', '17700.00', '-', NULL, '-', NULL, '17700.00', NULL, 'IN_007', '2023-10-03', '1', 'P0002031023', 'P0002-2023', '2');


#
# TABLE STRUCTURE FOR: po_party_statements_backup
#

DROP TABLE IF EXISTS `po_party_statements_backup`;

CREATE TABLE `po_party_statements_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: preference_details
#

DROP TABLE IF EXISTS `preference_details`;

CREATE TABLE `preference_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `sed` varchar(255) DEFAULT NULL,
  `edc` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: preference_settings
#

DROP TABLE IF EXISTS `preference_settings`;

CREATE TABLE `preference_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotationPrefix` varchar(255) NOT NULL,
  `quotation` varchar(255) NOT NULL,
  `expenses` varchar(255) NOT NULL,
  `expensePrefix` varchar(255) NOT NULL,
  `dc` varchar(255) NOT NULL,
  `voucherPrefix` varchar(255) NOT NULL,
  `voucher` varchar(255) NOT NULL,
  `debitPrefix` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `creditPrefix` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `purchasePrefix` varchar(255) NOT NULL,
  `purchase` varchar(255) NOT NULL,
  `invoicePrefix` varchar(255) NOT NULL,
  `invoice` varchar(255) NOT NULL,
  `salesdcPrefix` varchar(255) NOT NULL,
  `materialdcPrefix` varchar(255) NOT NULL,
  `jobdcPrefix` varchar(255) NOT NULL,
  `proforma_invoicePrefix` varchar(255) NOT NULL,
  `proforma_invoice` varchar(255) NOT NULL,
  `inwardPrefix` varchar(255) NOT NULL,
  `inward` varchar(255) NOT NULL,
  `cashbillPrefix` varchar(255) NOT NULL,
  `cashbill_invoice` varchar(255) NOT NULL,
  `creditnote` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) NOT NULL,
  `supplierpurchaseorder` varchar(100) NOT NULL,
  `jobworkdc` varchar(255) DEFAULT NULL,
  `materialdc` varchar(255) DEFAULT NULL,
  `cmp_companyname` varchar(255) NOT NULL,
  `cmp_phoneno` varchar(255) NOT NULL,
  `cmp_mobileno` varchar(255) NOT NULL,
  `cmp_address1` varchar(255) NOT NULL,
  `cmp_address2` varchar(255) NOT NULL,
  `cmp_city` varchar(255) NOT NULL,
  `cmp_pincode` varchar(255) NOT NULL,
  `cmp_stateCode` varchar(255) NOT NULL,
  `cmp_website` varchar(255) NOT NULL,
  `cmp_emailid` varchar(255) NOT NULL,
  `cmp_logo` varchar(255) NOT NULL,
  `cont_companyname` varchar(255) NOT NULL,
  `cont_phoneno` varchar(255) NOT NULL,
  `cont_mobileno` varchar(255) NOT NULL,
  `cont_address1` varchar(255) NOT NULL,
  `cont_address2` varchar(255) NOT NULL,
  `cont_city` varchar(255) NOT NULL,
  `cont_pincode` varchar(255) NOT NULL,
  `cont_stateCode` varchar(255) NOT NULL,
  `cont_website` varchar(255) NOT NULL,
  `cont_emailid` varchar(255) NOT NULL,
  `cont_logo` varchar(255) NOT NULL,
  `discountBy` varchar(255) NOT NULL,
  `invoiceBy` varchar(255) NOT NULL,
  `itemType` varchar(255) NOT NULL,
  `bill_type` varchar(255) DEFAULT NULL,
  `quot_bill_type` varchar(255) DEFAULT NULL,
  `voucher_receivable` varchar(255) DEFAULT NULL,
  `voucher_payable` varchar(255) DEFAULT NULL,
  `last_backup` date NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `inward_add` varchar(255) NOT NULL,
  `cashbill_add` varchar(255) NOT NULL,
  `cashbill_tax_type` varchar(255) NOT NULL,
  `priceType` varchar(255) DEFAULT NULL,
  `priceType1` varchar(255) DEFAULT NULL,
  `sales_dc` int(11) NOT NULL,
  `material_dc` int(11) NOT NULL,
  `jobwork_dc` int(11) NOT NULL,
  `cpo_type` varchar(255) NOT NULL,
  `spo_type` varchar(255) NOT NULL,
  `proforma_type` varchar(255) NOT NULL,
  `attendance` int(11) NOT NULL,
  `status` int(10) NOT NULL,
  `einvoice` int(11) NOT NULL,
  `eway` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `preference_settings` (`id`, `quotationPrefix`, `quotation`, `expenses`, `expensePrefix`, `dc`, `voucherPrefix`, `voucher`, `debitPrefix`, `debit`, `creditPrefix`, `credit`, `purchasePrefix`, `purchase`, `invoicePrefix`, `invoice`, `salesdcPrefix`, `materialdcPrefix`, `jobdcPrefix`, `proforma_invoicePrefix`, `proforma_invoice`, `inwardPrefix`, `inward`, `cashbillPrefix`, `cashbill_invoice`, `creditnote`, `purchaseorder`, `supplierpurchaseorder`, `jobworkdc`, `materialdc`, `cmp_companyname`, `cmp_phoneno`, `cmp_mobileno`, `cmp_address1`, `cmp_address2`, `cmp_city`, `cmp_pincode`, `cmp_stateCode`, `cmp_website`, `cmp_emailid`, `cmp_logo`, `cont_companyname`, `cont_phoneno`, `cont_mobileno`, `cont_address1`, `cont_address2`, `cont_city`, `cont_pincode`, `cont_stateCode`, `cont_website`, `cont_emailid`, `cont_logo`, `discountBy`, `invoiceBy`, `itemType`, `bill_type`, `quot_bill_type`, `voucher_receivable`, `voucher_payable`, `last_backup`, `itemcode`, `inward_add`, `cashbill_add`, `cashbill_tax_type`, `priceType`, `priceType1`, `sales_dc`, `material_dc`, `jobwork_dc`, `cpo_type`, `spo_type`, `proforma_type`, `attendance`, `status`, `einvoice`, `eway`) VALUES (1, 'Q', '', '', 'E', '', 'V/23-24/-', '', 'D', '001', 'C', '001', 'P', '', 'INV/23-24/-', '', 'SDC/23-24/-', 'MDC/23-24/-', 'PDC/23-24/', 'PI/23-24/', '', 'I', '', 'CB', '', NULL, '', '', '001', '001', 'Myoffice Solutions', '7373333321', '8608701222', ' #91 Dr. Jaganathan Nagar', 'Civil Aerodrome Post, Coimbatore', 'Coimbatore', '641014', '33', 'www.idreamdevelopers.org', 'info@idreamdevelopers.com', '12832299_1579401915712151_5416626780361493206_n.png', 'IDREAMDEVELOPERS', '7373333321', '8608701333', ' #91 Dr. Jaganathan Nagar', 'Civil Aerodrome Post, Coimbatore', 'Coimbatore', '641014', '33', 'www.idreamdevelopers.com', 'info@idreamdevelopers.com', 'idream_logo.PNG', 'percent_wise', 'with_stock', 'with_item', 'Multiple Tax', 'Overall Tax', 'Without Invoice', 'Without Purchase', '2020-05-04', '0', 'With Inward', 'Without Cashbill', '', '0', '0', 1, 0, 0, 'Multiple Tax', 'Multiple Tax', 'Overall Tax', 0, 1, 0, 0);


#
# TABLE STRUCTURE FOR: profile
#

DROP TABLE IF EXISTS `profile`;

CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `companyname` varchar(255) DEFAULT NULL,
  `softwarename` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `stateCode` varchar(255) NOT NULL,
  `emailid` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `gstin` varchar(225) DEFAULT NULL,
  `aadharno` varchar(225) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `bankname` varchar(255) DEFAULT NULL,
  `accountno` varchar(255) DEFAULT NULL,
  `bankbranch` varchar(255) DEFAULT NULL,
  `ifsccode` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `profile` (`id`, `date`, `companyname`, `softwarename`, `mobileno`, `phoneno`, `address1`, `address2`, `city`, `pincode`, `stateCode`, `emailid`, `website`, `tinno`, `cstno`, `gstin`, `aadharno`, `status`, `username`, `password`, `bankname`, `accountno`, `bankbranch`, `ifsccode`, `state`) VALUES (1, NULL, 'MYOFFICE ERP', 'MYOFFICE ERP', '8608701222', '7373333321', '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp', 'Avinashi Road, Hopes College', 'Coimbatore', '605001', 'puducherry', 'info@idreamdevelopers.com', '', '12345', '54321', '34AACCC1596Q002', '', '1', 'admin', 'admin001', '', '', '', '', NULL);


#
# TABLE STRUCTURE FOR: proforma_invoice_details
#

DROP TABLE IF EXISTS `proforma_invoice_details`;

CREATE TABLE `proforma_invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `proforma_invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (1, '2023-08-22', '2023-08-22', '002', '2023-08-22', 'PI/23-24/001', NULL, 'Sales Invoice', NULL, 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '100', '200000.00', '0', 'percent_wise', '0.00', '200000.00', '9', '18000.00', '9', '18000.00', '18', '', NULL, '200000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '236000.00', 'PI/23-24/001220823', 'PI/23-24/001-2023', 1, 1);
INSERT INTO `proforma_invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (2, '2023-08-22', '2023-08-22', '002', '2023-08-22', 'PI/23-24/002', NULL, 'Sales Invoice', NULL, 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '100', '200000.00', '0', 'percent_wise', '0.00', '200000.00', '9', '18000.00', '9', '18000.00', '18', '', NULL, '200000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '236000.00', 'PI/23-24/002220823', 'PI/23-24/002-2023', 1, 1);
INSERT INTO `proforma_invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (3, '2023-08-22', '2023-08-22', '002', '2023-08-22', 'PI/23-24/002', NULL, 'Sales Invoice', NULL, 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '100', '200000.00', '0', 'percent_wise', '0.00', '200000.00', '9', '18000.00', '9', '18000.00', '18', '', NULL, '200000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '236000.00', 'PI/23-24/002220823', 'PI/23-24/002-2023', 1, 1);
INSERT INTO `proforma_invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (4, '2023-08-22', '2023-08-22', '002', '2023-08-22', 'PI/23-24/003', NULL, 'Sales Invoice', NULL, 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '150', '300000.00', '0', 'percent_wise', '0.00', '300000.00', '9', '27000.00', '9', '27000.00', '18', '', NULL, '300000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '354000.00', 'PI/23-24/003220823', 'PI/23-24/003-2023', 1, 1);


#
# TABLE STRUCTURE FOR: proforma_invoice_details_backup
#

DROP TABLE IF EXISTS `proforma_invoice_details_backup`;

CREATE TABLE `proforma_invoice_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) NOT NULL,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: proforma_invoice_reports
#

DROP TABLE IF EXISTS `proforma_invoice_reports`;

CREATE TABLE `proforma_invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2023-08-22', 'PI/23-24/002', '2023-08-22', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '2023-08-22', '002', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '100', 'KGS', NULL, NULL, '200000.00', NULL, NULL, '236000.00', NULL, NULL, '1', 'PI/23-24/002-2023', 'PI/23-24/002220823', '3');
INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '2023-08-22', 'PI/23-24/003', '2023-08-22', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '2023-08-22', '002', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '150', 'KGS', NULL, NULL, '300000.00', NULL, NULL, '354000.00', NULL, NULL, '1', 'PI/23-24/003-2023', 'PI/23-24/003220823', '4');


#
# TABLE STRUCTURE FOR: proinvoice_party_statement
#

DROP TABLE IF EXISTS `proinvoice_party_statement`;

CREATE TABLE `proinvoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `proinvoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '-', '-', NULL, '2023-08-22', 'PI/23-24/002', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-22', '2023-08-22', '236000.00', '-', '-', '', '', '-', '-', NULL, '2064410', '-', '-', '-', '-', '236000.00', '-', '236000.00', NULL, NULL, 'PI/23-24/002-2023', 'PI/23-24/002220823', '3');
INSERT INTO `proinvoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '-', '-', NULL, '2023-08-22', 'PI/23-24/003', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-22', '2023-08-22', '354000.00', '-', '-', '', '', '-', '-', NULL, '2418410', '-', '-', '-', '-', '354000.00', '-', '354000.00', NULL, NULL, 'PI/23-24/003-2023', 'PI/23-24/003220823', '4');


#
# TABLE STRUCTURE FOR: purchase_collection
#

DROP TABLE IF EXISTS `purchase_collection`;

CREATE TABLE `purchase_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `date_po` date NOT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) NOT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `currentlypaid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `purchase_collection` (`id`, `date`, `date_po`, `purchasedate`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `suppliername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bamount`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `purchaseno`, `currentlypaid`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `payment`, `paid`, `invoiceamt`, `invoiceno`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (1, '2023-08-23', '0000-00-00', NULL, NULL, '2023-08-23', NULL, 'V/23-24/-002', 'J.K INDUSTRIES', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, '25000', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `purchase_collection` (`id`, `date`, `date_po`, `purchasedate`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `suppliername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bamount`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `purchaseno`, `currentlypaid`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `payment`, `paid`, `invoiceamt`, `invoiceno`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (2, '2023-08-23', '0000-00-00', NULL, NULL, '2023-08-23', NULL, 'V/23-24/-004', 'J.K INDUSTRIES', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cheque INDIAN BANK 563966', NULL, NULL, NULL, '10000', NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: purchase_details
#

DROP TABLE IF EXISTS `purchase_details`;

CREATE TABLE `purchase_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (1, '2023-08-18', '2023-08-18', '2023-08-18', 'P001', 2, 'J.K INDUSTRIES', 'CHERAN NAGAR, Ganapathy, Coimbatore, Tamil Nadu', 'IN_001', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1000', '200', '200000.00', '0', 'percent_wise', '0.00', '200000.00', '', '', '', '', '', '', '200000.00', '200000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '200000.00', 'P001180823', 'P001-2023', 1, '175000', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (2, '2023-10-03', '2023-10-03', '2023-10-03', 'P002', 2, 'J.K INDUSTRIES', 'CHERAN NAGAR, Ganapathy, Coimbatore, Tamil Nadu', 'IN_007', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '1500', '10', '15000.00', '0', 'percent_wise', '0.00', '15000.00', '9', '1350.00', '9', '1350.00', '18', '2700.00', '17700.00', '17700.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '17700.00', 'P0002031023', 'P0002-2023', 1, '17700.00', 1, 1);


#
# TABLE STRUCTURE FOR: purchase_details_backup
#

DROP TABLE IF EXISTS `purchase_details_backup`;

CREATE TABLE `purchase_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchase_reports
#

DROP TABLE IF EXISTS `purchase_reports`;

CREATE TABLE `purchase_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (1, '1', '2023-08-18', 'P001', '2023-08-18', NULL, 2, 'J.K INDUSTRIES', 'CHERAN NAGAR, Ganapathy, Coimbatore, Tamil Nadu', 'IN_001', '2023-08-18', NULL, NULL, '', '1080R2-2PM 70MM CLEATED STATOR', '1', '200', '2', '200000.00', NULL, NULL, NULL, NULL, NULL, '200000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2023', 'P001180823');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (2, '2', '2023-10-03', 'P0002', '2023-10-03', NULL, 2, 'J.K INDUSTRIES', 'CHERAN NAGAR, Ganapathy, Coimbatore, Tamil Nadu', 'IN_007', '2023-10-03', NULL, NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', '1', '10', '1', '17700.00', NULL, NULL, NULL, NULL, NULL, '17700.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0002-2023', 'P0002031023');


#
# TABLE STRUCTURE FOR: purchaseorder_details
#

DROP TABLE IF EXISTS `purchaseorder_details`;

CREATE TABLE `purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` longtext,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` longtext NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` longtext,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

#
# TABLE STRUCTURE FOR: purchaseorder_details_backup
#

DROP TABLE IF EXISTS `purchaseorder_details_backup`;

CREATE TABLE `purchaseorder_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchaseorder_reports
#

DROP TABLE IF EXISTS `purchaseorder_reports`;

CREATE TABLE `purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: quotation_details
#

DROP TABLE IF EXISTS `quotation_details`;

CREATE TABLE `quotation_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `description` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `quotation_details` (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (1, '2023-08-22', '2023-08-22', NULL, NULL, 'Q001', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, 'intrastate', NULL, NULL, NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', NULL, 'KGS', '1500', '100', '150000.00', '0', '0', '150000.00', '9', '13500.00', '9', '13500.00', '18', '', '150000.00', '150000.00', NULL, NULL, NULL, NULL, '177000.00', NULL, NULL, 1, 1);
INSERT INTO `quotation_details` (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (2, '2023-09-12', '2023-09-12', NULL, NULL, 'Q002', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, 'intrastate', NULL, NULL, NULL, '7204', '1080R2-2PM STATOR STAMPING-GANG', NULL, 'KGS', '100', '2', '200.00', '0', '0', '200.00', '9', '18.00', '9', '18.00', '18', '', '200.00', '200.00', NULL, NULL, NULL, NULL, '236.00', NULL, NULL, 1, 1);


#
# TABLE STRUCTURE FOR: quotation_details_backup
#

DROP TABLE IF EXISTS `quotation_details_backup`;

CREATE TABLE `quotation_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `description` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sales_return
#

DROP TABLE IF EXISTS `sales_return`;

CREATE TABLE `sales_return` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext,
  `itemname` longtext,
  `rate` longtext,
  `qty` longtext,
  `uom` longtext,
  `amount` longtext,
  `discount` longtext,
  `taxableamount` longtext,
  `discountamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sales_return_backup
#

DROP TABLE IF EXISTS `sales_return_backup`;

CREATE TABLE `sales_return_backup` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext,
  `itemname` longtext,
  `rate` longtext,
  `qty` longtext,
  `uom` longtext,
  `amount` longtext,
  `discount` longtext,
  `taxableamount` longtext,
  `discountamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: statecode
#

DROP TABLE IF EXISTS `statecode`;

CREATE TABLE `statecode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) NOT NULL,
  `stateCode` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (1, 'Jammu & Kashmir', '01', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (2, 'Himachal Pradesh', '02', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (3, 'Punjab', '03', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (4, 'Chandigarh', '04', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (5, 'Uttarakhand', '05', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (6, 'Haryana', '06', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (7, 'Delhi', '07', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (8, 'Rajasthan', '08', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (9, 'Uttar Pradesh', '09', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (10, 'Bihar', '10', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (11, 'Sikkim', '11', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (12, 'Arunachal Pradesh', '12', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (13, 'Nagaland', '13', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (14, 'Manipur', '14', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (15, 'Mizoram', '15', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (16, 'Tripura', '16', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (17, 'Meghalaya', '17', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (18, 'Assam', '18', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (19, 'West Bengal', '19', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (20, 'Jharkhand', '20', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (21, 'odisha', '21', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (22, 'Chattisgarh', '22', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (23, 'Madhya Pradesh', '23', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (24, 'Daman & Diu', '25', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (25, 'Gujarat', '24', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (26, 'Dadra & Nagar Haveli', '26', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (27, 'Maharashtra', '27', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (28, 'Andhra Pradesh', '28', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (29, 'Karnataka', '29', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (30, 'Goa', '30', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (31, 'Lakshadweep', '31', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (32, 'Kerala', '32', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (33, 'Tamil Nadu', '33', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (34, 'Puducherry', '34', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (35, 'Andaman & Nicobar Islands', '35', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (36, 'Telengana', '36', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (37, 'Andrapradesh(New)', '37', 1);


#
# TABLE STRUCTURE FOR: stock
#

DROP TABLE IF EXISTS `stock`;

CREATE TABLE `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `updatestock` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `balance` varchar(255) NOT NULL,
  `oldqty` varchar(255) DEFAULT NULL,
  `currentstock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (1, '2023-10-11', '850300', NULL, '9', '9', '18', '1080R2-2PM 70MM CLEATED STATOR', '10', '1500', '10', '', '1', '146', NULL, NULL, '', '2023-10-03', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (2, '2023-08-18', '', NULL, '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '200', '1000', '200', '', '', '200', NULL, NULL, '', '2023-08-18', '');


#
# TABLE STRUCTURE FOR: stock_reports
#

DROP TABLE IF EXISTS `stock_reports`;

CREATE TABLE `stock_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `updatestock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  `balance` varchar(225) DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (1, '2023-08-18', '850300', '0', '1080R2-2PM 70MM CLEATED STATOR', '1', '500', 'FromAddStock', '2023-08-18', NULL, NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (2, '2023-08-18', '', NULL, '1080R2-2PM 70MM CLEATED STATOR', NULL, '200', '', '2023-08-18', '1', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (3, '2023-10-03', '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', NULL, '10', '', NULL, '2', NULL, 'Exclusive');


#
# TABLE STRUCTURE FOR: sup_purchaseorder_details
#

DROP TABLE IF EXISTS `sup_purchaseorder_details`;

CREATE TABLE `sup_purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `shipTo` varchar(255) NOT NULL,
  `shipToAddress` varchar(255) NOT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (1, '2023-08-18', '2023-08-18', NULL, 'Direct PO', 'P001', NULL, NULL, 2, 'J.K INDUSTRIES', 'CHERAN NAGAR, Ganapathy, Coimbatore, Tamil Nadu', '', '', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '850300', '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '1500', '20', '20', '', '30000.00', '', 'percent_wise', '', '30000.00', '9', '2700.00', '9', '2700.00', '0', '0', '35400.00', '35400.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '35400.00', 'P001180823', 'P001-2023', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (2, '2023-08-18', '2023-08-18', NULL, 'Direct PO', 'P002', NULL, NULL, 2, 'J.K INDUSTRIES', 'CHERAN NAGAR, Ganapathy, Coimbatore, Tamil Nadu', '', '', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '850300', '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '1500', '20', '20', '', '30000.00', '', 'percent_wise', '', '30000.00', '9', '2700.00', '9', '2700.00', '0', '0', '35400.00', '35400.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '35400.00', 'P001180823', 'P001-2023', 1, 1);


#
# TABLE STRUCTURE FOR: sup_purchaseorder_details_backup
#

DROP TABLE IF EXISTS `sup_purchaseorder_details_backup`;

CREATE TABLE `sup_purchaseorder_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sup_purchaseorder_reports
#

DROP TABLE IF EXISTS `sup_purchaseorder_reports`;

CREATE TABLE `sup_purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (1, '1', '2023-08-18', 'Direct PO', 'P001', NULL, NULL, '2023-08-18', NULL, 2, 'J.K INDUSTRIES', 'CHERAN NAGAR, Ganapathy, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '1', '20', '20', '', '35400.00', '35400.00', NULL, NULL, NULL, NULL, NULL, '35400.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2023', 'P001180823');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (2, '2', '2023-08-18', 'Direct PO', 'P001', NULL, NULL, '2023-08-18', NULL, 2, 'J.K INDUSTRIES', 'CHERAN NAGAR, Ganapathy, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '1', '20', '20', '', '35400.00', '35400.00', NULL, NULL, NULL, NULL, NULL, '35400.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2023', 'P001180823');


#
# TABLE STRUCTURE FOR: tbl_person
#

DROP TABLE IF EXISTS `tbl_person`;

CREATE TABLE `tbl_person` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: uom
#

DROP TABLE IF EXISTS `uom`;

CREATE TABLE `uom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (1, '2023-07-28', 'KGS', 1);


#
# TABLE STRUCTURE FOR: user_menu
#

DROP TABLE IF EXISTS `user_menu`;

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) NOT NULL,
  `main_menu` varchar(255) NOT NULL,
  `sub_menu` varchar(255) NOT NULL,
  `sub_menu_link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

INSERT INTO `user_menu` (`id`, `login_id`, `main_menu`, `sub_menu`, `sub_menu_link`) VALUES (37, 10, 'Settings', 'Tax Type', 'taxtype');
INSERT INTO `user_menu` (`id`, `login_id`, `main_menu`, `sub_menu`, `sub_menu_link`) VALUES (38, 10, 'Settings', 'Add UOM', 'uom');
INSERT INTO `user_menu` (`id`, `login_id`, `main_menu`, `sub_menu`, `sub_menu_link`) VALUES (39, 10, 'Settings', 'Add Item', 'itemmaster');
INSERT INTO `user_menu` (`id`, `login_id`, `main_menu`, `sub_menu`, `sub_menu_link`) VALUES (40, 10, 'Settings', 'Account Headers', 'headers');
INSERT INTO `user_menu` (`id`, `login_id`, `main_menu`, `sub_menu`, `sub_menu_link`) VALUES (41, 10, 'Settings', 'Company Profile', 'profile');
INSERT INTO `user_menu` (`id`, `login_id`, `main_menu`, `sub_menu`, `sub_menu_link`) VALUES (42, 10, 'Settings', 'Backup Settings', 'backup');
INSERT INTO `user_menu` (`id`, `login_id`, `main_menu`, `sub_menu`, `sub_menu_link`) VALUES (43, 10, 'Settings', 'Support', 'support');
INSERT INTO `user_menu` (`id`, `login_id`, `main_menu`, `sub_menu`, `sub_menu_link`) VALUES (44, 10, 'Settings', 'User Manager', 'usermaster');


#
# TABLE STRUCTURE FOR: vat_details
#

DROP TABLE IF EXISTS `vat_details`;

CREATE TABLE `vat_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `sgst` varchar(225) DEFAULT NULL,
  `cgst` varchar(225) DEFAULT NULL,
  `igst` varchar(225) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `vat_details` (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (1, '2023-07-28', 'GST', '18', 'GST @ 18 %', '9', '9', '18', '1');
INSERT INTO `vat_details` (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (2, '2023-10-11', 'gst', '24', 'gst @ 24 %', '12', '12', '24', '1');


#
# TABLE STRUCTURE FOR: vendor_details
#

DROP TABLE IF EXISTS `vendor_details`;

CREATE TABLE `vendor_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `vendorname` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: voucher
#

DROP TABLE IF EXISTS `voucher`;

CREATE TABLE `voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `tdsamount` varchar(100) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `balance_amt` varchar(255) DEFAULT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `voucher` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `tdsamount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (1, '2023-08-23', 'V/23-24/-001', 1, 'SMK INDUSTRIES', '2023-08-23', 'payment', 'Product', 'Cash', '0', '', '', '0', '', '1000', 'Cash', NULL, NULL, '1000', '1000', '', '1', 'INV/23-24/-001', NULL, '1000', 0);
INSERT INTO `voucher` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `tdsamount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (2, '2023-08-23', 'V/23-24/-002', 2, 'J.K INDUSTRIES', '2023-08-23', 'receipt', 'Product', 'Cash', '0', '', '', '0', '', '25000', 'Cash', NULL, NULL, '25000', '25000', '', '1', NULL, 'P001', '25000', 0);
INSERT INTO `voucher` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `tdsamount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (3, '2023-08-23', 'V/23-24/-003', 1, 'SMK INDUSTRIES', '2023-08-23', 'payment', 'Product', 'Cheque', 'INDIAN OVERSEAS', '563966', '10000', '0', '', '', 'Cheque INDIAN OVERSEAS 563966', NULL, '24-08-2023', '10000', '10000', '', '1', NULL, NULL, '', 0);
INSERT INTO `voucher` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `tdsamount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (4, '2023-08-23', 'V/23-24/-004', 2, 'J.K INDUSTRIES', '2023-08-23', 'receipt', 'Product', 'Cheque', 'INDIAN BANK', '563966', '10000', '0', '', '', 'Cheque INDIAN BANK 563966', NULL, '24-08-2023', '10000', '10000', '', '1', NULL, NULL, '', 0);


#
# TABLE STRUCTURE FOR: voucher_backup
#

DROP TABLE IF EXISTS `voucher_backup`;

CREATE TABLE `voucher_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `purchaseno` varchar(255) NOT NULL,
  `balance_amt` varchar(255) NOT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

