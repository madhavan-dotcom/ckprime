#
# TABLE STRUCTURE FOR: add_staff
#

DROP TABLE IF EXISTS `add_staff`;

CREATE TABLE `add_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `staff_name` varchar(255) NOT NULL,
  `mobileno` varchar(255) NOT NULL,
  `amobileno` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `referred` varchar(255) NOT NULL,
  `salary` varchar(255) NOT NULL,
  `salarytype` varchar(255) NOT NULL,
  `perdaysalary` varchar(255) NOT NULL,
  `ot` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: additem
#

DROP TABLE IF EXISTS `additem`;

CREATE TABLE `additem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` text CHARACTER SET utf8,
  `price` varchar(255) DEFAULT NULL,
  `taxtype` varchar(225) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `priceType` varchar(10) NOT NULL,
  `itemtype` varchar(255) NOT NULL,
  `purchaseNo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (1, '2023-07-28', '1', '850300', '0', '1080R2-2PM 70MM CLEATED STATOR', '1500', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (2, '2023-07-28', '1', '7204', '0', '1080R2-2PM STATOR STAMPING-GANG', '2000', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (3, '2023-10-11', '1', '0', '0', '1080R2-2PM STATOR STAMPING NEW', '100', '1', '9', '9', '18', '1', 'Inclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (4, '2023-10-13', '1', '01', '0', 'Air Compressor Motor ', '5000', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (5, '2023-10-13', '1', '02', '0', 'Metal Stamping', '1000', '1', '9', '9', '18', '1', 'Inclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (6, '2023-11-25', '1', '1001', '0', 'Compressor', '1000', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (7, '2023-11-25', '1', '1002', '0', 'drilling machine', '1500', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (8, '2024-01-08', '2', '7222', '0', 'SHAFT', '0', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (9, '2024-01-11', '2', '8503', '0', '20CL ROTAR', '12', '4', '6', '6', '12', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (10, '2024-01-11', '2', '8503', '0', '26CL ROTOR', '12', '4', '6', '6', '12', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (11, '2024-01-11', '2', '8503', '0', '30CL ROTOR', '30', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (12, '2024-01-11', '2', '8503', '0', '32CL ROTOR', '31', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (13, '2024-01-11', '2', '8503', '0', '35CL ROTOR', '32', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (14, '2024-01-11', '2', '8503', '0', '38CL ROTOR', '33', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (15, '2024-03-26', '2', '85171300', '0', 'redmi', '12499', '1', '9', '9', '18', '1', 'Inclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (16, '2024-07-03', '2', '124', '0', 'AC', '1000', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (17, '2024-08-23', '5', '9908', '0', 'demo', '100', '9', '15', '15', '30', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (18, '2024-08-24', '6', '002', '0', 'BLACK PAINT', '950', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (19, '2024-08-26', '1', '1212', '0', 'ddd', '221', '4', '6', '6', '12', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (20, '2024-09-04', '3', '32123212', '0', 'Oversized Tshirt', '200', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (21, '2024-09-04', '3', '456198543', '0', 'Cotton shirt', '150', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (22, '2024-09-04', '3', '894356754', '0', 'Cotton saree', '300', '1', '', '', '', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (27, '2025-02-06', '3', '99872323', '0', 'SOLAR LIGHT 3OOW', '12500', '4', '6', '6', '12', '1', 'Inclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (31, '2025-02-25', '2', '1234556', '0', '10886', '22', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (32, '2025-02-27', '3', '654654', '0', 'asus512gb', '100000', '5', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (33, '2025-05-07', '2', '853521', '0', 'DISPLAY BOARD (12\" x 14\" x 3mm)', '2000', '5', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (34, '2025-05-14', '7', '35654', '0', 'FLOOR CLEANER', '250', '5', '9', '9', '18', '1', 'Inclusive', '', NULL);


#
# TABLE STRUCTURE FOR: attendance
#

DROP TABLE IF EXISTS `attendance`;

CREATE TABLE `attendance` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `attendancedate` date NOT NULL,
  `staff` varchar(255) NOT NULL,
  `attendances` varchar(255) NOT NULL,
  `intime` varchar(255) NOT NULL,
  `outtime` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `lastupdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: backup_details
#

DROP TABLE IF EXISTS `backup_details`;

CREATE TABLE `backup_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` longtext,
  `date_created` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (1, 'backup-on-2025-03-01-13-15-59.zip', '2025-03-01');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (2, 'backup-on-2025-03-03-15-07-07.zip', '2025-03-03');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (3, 'backup-on-2025-03-05-17-12-41.zip', '2025-03-05');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (4, 'backup-on-2025-03-06-15-19-40.zip', '2025-03-06');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (5, 'backup-on-2025-03-07-17-01-21.zip', '2025-03-07');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (6, 'backup-on-2025-03-08-14-32-07.zip', '2025-03-08');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (7, 'backup-on-2025-03-10-12-06-19.zip', '2025-03-10');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (8, 'backup-on-2025-03-11-12-34-57.zip', '2025-03-11');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (9, 'backup-on-2025-03-14-10-33-02.zip', '2025-03-14');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (10, 'backup-on-2025-03-18-12-31-47.zip', '2025-03-18');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (11, 'backup-on-2025-03-21-13-01-51.zip', '2025-03-21');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (12, 'backup-on-2025-03-22-16-59-43.zip', '2025-03-22');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (13, 'backup-on-2025-03-26-20-36-21.zip', '2025-03-26');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (14, 'backup-on-2025-03-29-11-49-24.zip', '2025-03-29');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (15, 'backup-on-2025-03-31-14-36-30.zip', '2025-03-31');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (16, 'backup-on-2025-04-01-12-10-49.zip', '2025-04-01');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (17, 'backup-on-2025-04-03-12-46-21.zip', '2025-04-03');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (18, 'backup-on-2025-04-04-15-01-30.zip', '2025-04-04');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (19, 'backup-on-2025-04-08-12-51-25.zip', '2025-04-08');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (20, 'backup-on-2025-04-09-11-46-35.zip', '2025-04-09');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (21, 'backup-on-2025-04-11-12-55-55.zip', '2025-04-11');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (22, 'backup-on-2025-04-19-15-15-38.zip', '2025-04-19');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (23, 'backup-on-2025-04-23-14-32-47.zip', '2025-04-23');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (24, 'backup-on-2025-04-25-11-10-42.zip', '2025-04-25');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (25, 'backup-on-2025-05-05-14-38-40.zip', '2025-05-05');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (26, 'backup-on-2025-05-06-16-21-33.zip', '2025-05-06');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (27, 'backup-on-2025-05-07-10-09-40.zip', '2025-05-07');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (28, 'backup-on-2025-05-08-10-38-41.zip', '2025-05-08');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (29, 'backup-on-2025-05-09-21-37-15.zip', '2025-05-09');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (30, 'backup-on-2025-05-12-12-17-56.zip', '2025-05-12');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (31, 'backup-on-2025-05-13-15-47-24.zip', '2025-05-13');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (32, 'backup-on-2025-05-14-11-32-04.zip', '2025-05-14');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (33, 'backup-on-2025-05-15-15-30-43.zip', '2025-05-15');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (34, 'backup-on-2025-05-16-10-35-36.zip', '2025-05-16');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (35, 'backup-on-2025-05-17-11-00-10.zip', '2025-05-17');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (36, 'backup-on-2025-05-19-11-20-01.zip', '2025-05-19');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (37, 'backup-on-2025-05-20-20-01-04.zip', '2025-05-20');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (38, 'backup-on-2025-05-21-11-09-22.zip', '2025-05-21');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (39, 'backup-on-2025-05-24-19-59-37.zip', '2025-05-24');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (40, 'backup-on-2025-05-27-10-59-09.zip', '2025-05-27');


#
# TABLE STRUCTURE FOR: backup_url
#

DROP TABLE IF EXISTS `backup_url`;

CREATE TABLE `backup_url` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: bed_details
#

DROP TABLE IF EXISTS `bed_details`;

CREATE TABLE `bed_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `bed` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: card
#

DROP TABLE IF EXISTS `card`;

CREATE TABLE `card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cash_bill
#

DROP TABLE IF EXISTS `cash_bill`;

CREATE TABLE `cash_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cashbill_details
#

DROP TABLE IF EXISTS `cashbill_details`;

CREATE TABLE `cashbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `cust_mobno` varchar(255) NOT NULL,
  `address` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `systemDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cashbill_reports
#

DROP TABLE IF EXISTS `cashbill_reports`;

CREATE TABLE `cashbill_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `systemDate` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `category` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: collection_details
#

DROP TABLE IF EXISTS `collection_details`;

CREATE TABLE `collection_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `collection_details` (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2025-04-25', NULL, '2025-04-25', NULL, 'V/23-24/-001', 'IDREAMDEVELOPERS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '8850', NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: company_logo
#

DROP TABLE IF EXISTS `company_logo`;

CREATE TABLE `company_logo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `company_logo` (`id`, `date`, `image`, `status`) VALUES (1, '2023-08-07', '12832299_1579401915712151_5416626780361493206_n.png', '1');


#
# TABLE STRUCTURE FOR: customer_details
#

DROP TABLE IF EXISTS `customer_details`;

CREATE TABLE `customer_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `contactperson` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `old_openingBal` varchar(255) DEFAULT NULL,
  `salesamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  `accountpay` varchar(255) NOT NULL,
  `chequeno` varchar(100) NOT NULL,
  `last_modified` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (1, '2024-05-29', 'Inter customer', 'IDREAMDEVELOPERS', '7810028222', 'jp@idreamdevelopers.com', '91, jaganathan nagar,', ' civil aerodrome ', '', 'Tamil Nadu', 'COIMBATORE', '', '', NULL, '972920.4', '80800', '-13800.01', '', '-13800.01', '', '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33ADXPT3291N2ZJ', '', '', '', '', '', '2024-05-29');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (2, '2023-08-18', 'Intra supplier', 'J.K INDUSTRIES', '96325417596', '', 'CHERAN NAGAR', 'Ganapathy', '', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '59000', '', '', '', '', '', '', NULL, '641009', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2023-08-18');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (3, '2023-10-13', 'Inter supplier', 'RK Industries', '8552588544', 'RKIndustries@gmail.com', 'Avarampalayam', 'VOC Nagar', '', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '57723', '', '', '', '', '', '', NULL, '641000', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '22AAAAA0000A1Z5', '', '', '', '', '', '2023-10-13');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (4, '2023-10-13', 'Intra customer', 'MPK engineering works', '7451233888', '', 'Kalapatti road ', 'Kalapatti ', '', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '', '', '', '', '', '', '', NULL, '641009', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '22AAAAA0000A1Z5', '', '', '', '', '', '2023-10-13');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (5, '2023-11-30', 'Subcontract', 'MM Industries', '', '', '1C, Church Road, Athipalayam Pirivu, ', 'ondipudur', '', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '', '', '', '', '', '', '', NULL, '641009', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33ADXPT3291N2ZJ', '', '', '', '', '', '2023-11-30');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (6, '2024-01-08', 'Intra customer', 'HANDY THINK', '', '', '1/504, ', 'NEELAMBUR', '', 'Tamil Nadu', 'COIMBATORE', '', '', NULL, '64510', '', '', '', '', '', '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33AYAPV0462C1ZW', '', '', '', '', '', '2024-01-08');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (7, '2024-01-08', 'Subcontract', 'RAMYA GEARS', '', '', 'GANDHI NAGAR ', 'IRUGUR', '', 'Tamil Nadu', 'COIMBATORE', '', '', NULL, '', '', '', '', '', '', '', NULL, '641', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33DDCPM9264A1ZR', '', '', '', '', '', '2024-01-08');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (8, '2024-01-11', 'Intra customer', 'JAI SHREE SAI ENGINEERING', '', '', 'NO.42/62, ARUN NAGAR, 3rd STREET,', 'TVS NAGAR BEHIND, VELANDIPALAYAM POST', '', 'Tamil Nadu', 'COIMBATORE', '', '', NULL, '3540', '', '', '', '', '', '', NULL, '641025', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33BWRPM2313L1ZC', '', '', '', '', '', '2024-01-11');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (9, '2024-02-12', 'Intra customer', 'SELVAGANAPATHI', '', '', 'NERA BUSSTAND ', 'OPPTO INDIAN  BANK', '', 'Tamil Nadu', 'DHARMAPURI', '', '', NULL, '', '', '', '', '', '', '', NULL, '636701', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '22AAAAA0000A1Z5', '', '', '', '', '', '2024-02-12');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (10, '2024-02-12', 'Inter supplier', 'ATOMBERG TECHNOLOGY PVT', '', '', 'MUMBAI', 'MUMBAI', '', 'Maharashtra', 'mumbai', '', '', NULL, '60430', '', '', '', '', '', '', NULL, '636701', NULL, NULL, NULL, NULL, NULL, '1', '', '', '27', '22AAAAA0000A1Z5', '', '', '', '', '', '2024-02-12');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (11, '2024-03-27', 'Inter customer', 'shivamobiles', '9842298966', '', 'avanshi road annur', 'annur', 'vetri', 'Tamil Nadu', 'coimbatore', '', '', NULL, '88500', '', '', '', '', '', '', NULL, '641653', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33AHMPV2965Q1ZC', '78451', '', '', '', '', '2024-03-27');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (12, '2024-03-28', 'Inter customer', 'Jayaprakash', '', '', 'jaganathan nagar', 'Coimbatore', '', 'Tamil Nadu', 'coimabtore', '', '', NULL, '9032830', '13930', '25000.00', '', '9057830', '', '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2024-03-28');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (13, '2024-05-29', 'Intra customer', 'Idreamdevelopers', '9876543210', '', 'Hopes', 'peelamedu', '', 'Tamil Nadu', 'cbe', '', '', NULL, '-39976.8', '0.00', '-31500.01', '8850', '-40350.01', '', '', NULL, '641005', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2024-05-29');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (14, '2024-07-01', 'Intra customer', 'idream', '', '', 'gggg', 'bgg', '', 'Tamil Nadu', 'cbe', '', '', NULL, '0.00', '0.00', '', '', '', '', '', NULL, '641006', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2024-07-01');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (15, '2024-07-03', 'Intra customer', 'GRD', '', '', 'CBE', 'CBE', '', 'Tamil Nadu', 'CBE', '', '', NULL, '194360', '0.00', '', '', '', '', '', NULL, '6410011', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2024-07-03');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (16, '2024-07-03', 'Intra supplier', 'STAR GEARS', '', '', 'CBE', 'CBE', '', 'Tamil Nadu', 'CBE', '', '', NULL, '17405', '0.00', '', '', '', '', '', NULL, '641001', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2024-07-03');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (17, '2024-08-23', 'Intra customer', 'intra customer demo', '', '', 'idreamdevelopers', 'idreamdevelopers', '', 'Tamil Nadu', 'coimpatore', '', '', NULL, '131040', '0.00', '', '', '', '', '', NULL, '641004', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2024-08-23');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (18, '2024-09-04', 'Intra supplier', 'kee Enterprises', '9065322601', 'kee@gmail.com', '43,Ram nagar Street', 'Devakottai', 'keerthika Devi', 'Tamil Nadu', 'devakottai', '', '', NULL, '134500', '0.00', '8850.00', '', '143350', '', '987632095643', NULL, '630210', NULL, NULL, NULL, NULL, NULL, '1', 'curremt account', 'curremt account', '33', '33ADXPT3291N2ZJ', '253409872345', 'ICIC', '9087656875544', 'Keerthika Devi', 'ICI45F20345', '2024-09-04');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (19, '2024-09-04', 'Intra customer', 'DD & co', '9876457634', 'dd@gmail.com', '56,East Street,', 'SS kottai,madurai', 'Divaya Dharshni', 'Tamil Nadu', 'madurai', '', '', NULL, '76110', '0.00', '', '', '', '', '4563728165464', NULL, '601987', NULL, NULL, NULL, NULL, NULL, '1', 'curremt account', 'curremt account', '33', '33ADXPT3291N2ZJ', '574523674367', 'SBI ', '874365874023', 'Divaya Dharshni', 'SB97605K93045', '2024-09-04');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (20, '2025-01-27', 'Intra customer', 'Developers', '9047954835', '-', 'Hopes', '-', 'Vincent', 'Tamil Nadu', 'Coimbatore', '-', '-', NULL, NULL, '0.00', '', '', '', '', 'SA5466456', NULL, '641251', NULL, NULL, NULL, NULL, NULL, '1', 'Cash', 'Cash', 'T0001', '-', '7895645544', '-', '-', '', '-', '0000-00-00');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (21, '2025-02-25', 'Intra customer', 'VRN ENGINEERING', '9865303065', '', '137 OM SAKTHINAGAR', 'CHINNAVEDAMPATTI', '', 'Tamil Nadu', 'COIMBATORE', '', '', NULL, '0.00', '0.00', '20650', '', '20650', '', '', NULL, '641049', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33AQOPP5481E1ZL', '', '', '', '', '', '2025-02-25');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (22, '2025-03-03', 'Intra customer', 'thennarasdu', '', '', 'teachers colony', 'vennampatty main road', '', 'Tamil Nadu', 'dharmapuri', '', '', NULL, '0.00', NULL, '531000.00', NULL, '531000', NULL, '', NULL, '636701', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2025-03-03');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (24, '2025-04-03', 'Inter customer', 'Idream Developers new', '', '', 'jaganathan nagar', 'Civil Aerodeome Post', '', 'Maharashtra', 'Mumbai', '', '', NULL, '0.00', NULL, '-116407', NULL, '191750', NULL, '', NULL, '400001', NULL, NULL, NULL, NULL, NULL, '1', '', '', '27', '27GSPMH1881G1ZH', '', '', '', '', '', '2025-04-03');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (25, '2025-04-09', 'Intra customer', 'jack', '7806876370', '', 'cbe', 'cbe', 'maddy', 'Tamil Nadu', 'karaikudi', '', '', NULL, '0.00', NULL, '0', NULL, '0', NULL, '', NULL, '654616', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2025-04-09');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (26, '2025-05-14', 'Intra customer', 'EDWIN', '', '', 'KUMAERAN NAGAR', 'TRICHY', '', 'Tamil Nadu', 'TRICHY', '', '', NULL, '0.00', NULL, NULL, NULL, '0.00', NULL, '', NULL, '620017', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2025-05-14');


#
# TABLE STRUCTURE FOR: customerpo_details
#

DROP TABLE IF EXISTS `customerpo_details`;

CREATE TABLE `customerpo_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `cuspodate` date DEFAULT NULL,
  `invoicetype` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `cuspono` varchar(255) DEFAULT NULL,
  `transport` varchar(255) DEFAULT NULL,
  `customerpodate` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `cstname` varchar(255) DEFAULT NULL,
  `cstamount` varchar(255) DEFAULT NULL,
  `pf` varchar(255) DEFAULT NULL,
  `freight` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `pfadjus` varchar(255) DEFAULT NULL,
  `freightadjus` varchar(255) DEFAULT NULL,
  `roundoff` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: dc_delivery
#

DROP TABLE IF EXISTS `dc_delivery`;

CREATE TABLE `dc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (1, '2024-04-02', 1, NULL, 'Direct DC', 'SDC/23-24/-001', '2024-04-02', 8, 'JAI SHREE SAI ENGINEERING', '', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST', NULL, NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '2', '', '10', '10', 'machinning', '7204', NULL, 'KGS', 'SDC/23-24/-001-24', 'SDC/23-24/-001020424', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (4, '2024-04-10', 2, NULL, 'Direct DC', 'SDC/23-24/-002', '2024-04-10', 8, 'JAI SHREE SAI ENGINEERING', 'tn uuuuu66666', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST', NULL, NULL, NULL, 'SHAFT', '8', '', '15', '15', 'out for production', '7222', NULL, 'NOS', 'SDC/23-24/-002-24', 'SDC/23-24/-002100424', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (5, '2024-04-10', 2, NULL, 'Direct DC', 'SDC/23-24/-002', '2024-04-10', 8, 'JAI SHREE SAI ENGINEERING', 'tn uuuuu66666', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST', NULL, NULL, NULL, 'drilling machine', '7', '', '22', '22', 'out for production', '1002', NULL, 'KGS', 'SDC/23-24/-002-24', 'SDC/23-24/-002100424', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (6, '2024-04-10', 3, 1, 'Against Inward', 'SDC/23-24/-003', '2024-04-10', 8, 'JAI SHREE SAI ENGINEERING', 'tn uuuuu7489', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST', 'I001', 'DC1003', '2024-04-10', '20CL ROTAR', '9', '', '7', '7', 'Inhouse production', '8503', NULL, 'NOS', 'SDC/23-24/-003-24', 'SDC/23-24/-003100424', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (7, '2024-04-10', 3, 2, 'Against Inward', 'SDC/23-24/-003', '2024-04-10', 8, 'JAI SHREE SAI ENGINEERING', 'tn uuuuu7489', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST', NULL, 'DC1003', '2024-04-10', 'drilling machine', '7', '', '18', '18', 'Inhouse productions', '1002', NULL, 'KGS', 'SDC/23-24/-003-24', 'SDC/23-24/-003100424', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (8, '2024-05-29', 4, NULL, 'Direct DC', 'SDC/23-24/-004', '2024-05-29', 1, 'IDREAMDEVELOPERS', '', 'Hopes, peelamedu', NULL, NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '2', '', '10', '5', '', '7204', NULL, 'KGS', 'SDC/23-24/-004-24', 'SDC/23-24/-004290524', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (9, '2024-05-29', 5, 3, 'Against Inward', 'SDC/23-24/-005', '2024-05-29', 1, 'IDREAMDEVELOPERS', '', 'Hopes, peelamedu', 'I002', 'DC0012', '2024-05-29', '1080R2-2PM STATOR STAMPING-GANG', '2', '', '45', '45', '', '7204', NULL, 'KGS', 'SDC/23-24/-005-24', 'SDC/23-24/-005290524', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (10, '2024-07-03', 6, NULL, 'Direct DC', 'SDC/23-24/-006', '2024-07-03', 15, 'GRD', '', 'CBE, CBE', NULL, NULL, NULL, 'AC', '16', '', '5', '2', '', '124', NULL, 'NOS', 'SDC/23-24/-006-24', 'SDC/23-24/-006030724', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (11, '2024-08-20', 7, 3, 'Against Inward', 'SDC/23-24/-007', '2024-08-20', 1, 'IDREAMDEVELOPERS', '', 'Hopes, peelamedu', 'I002', 'DC0012', '2024-05-29', '1080R2-2PM STATOR STAMPING-GANG', '2', '', '20', '20', '', '7204', NULL, 'KGS', 'SDC/23-24/-007-24', 'SDC/23-24/-007200824', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (12, '2024-08-21', 8, 6, 'Against Inward', 'SDC/23-24/-008', '2024-08-21', 1, 'IDREAMDEVELOPERS', '', 'Hopes, peelamedu', 'I005', '001', '2024-08-21', '1080R2-2PM 70MM CLEATED STATOR', '1', '', '20', '0', '--', '850300', NULL, 'KGS', 'SDC/23-24/-008-24', 'SDC/23-24/-008210824', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (13, '2024-09-07', 9, NULL, 'Direct DC', 'SDC/23-24/-009', '2024-09-07', 19, 'DD & co', '', '56,East Street,, SS kottai,madurai', NULL, NULL, NULL, 'Oversized Tshirt', '20', '', '100', '100', '', '32123212', NULL, 'piece', 'SDC/23-24/-009-24', 'SDC/23-24/-009070924', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (14, '2024-09-07', 9, NULL, 'Direct DC', 'SDC/23-24/-009', '2024-09-07', 19, 'DD & co', '', '56,East Street,, SS kottai,madurai', NULL, NULL, NULL, 'Cotton saree', '22', '', '1000', '1000', '', '894356754', NULL, 'piece', 'SDC/23-24/-009-24', 'SDC/23-24/-009070924', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (16, '2025-02-27', 11, 9, 'Against Inward', 'SDC/23-24/-010', '2025-02-27', 12, 'Jayaprakash', 'tn67', 'jaganathan nagar, Coimbatore', 'I008', '001', '2025-02-27', 'asus512gb', '32', 'laptop', '10', '0', '10', '654654', NULL, 'piece', 'SDC/23-24/-010-25', 'SDC/23-24/-010270225', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (17, '2025-02-27', 12, 9, 'Against Inward', 'SDC/23-24/-011', '2025-02-27', 12, 'Jayaprakash', 'tn67', 'jaganathan nagar, Coimbatore', 'I008', '001', '2025-02-27', 'asus512gb', '32', 'laptop', '10', '0', '10', '654654', NULL, 'piece', 'SDC/23-24/-011-25', 'SDC/23-24/-011270225', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (18, '2025-02-27', 13, 10, 'Against Inward', 'SDC/23-24/-012', '2025-02-27', 11, 'shivamobiles', 'tn67', 'avanshi road annur, annur', 'I009', '002', '2025-02-27', 'Metal Stamping', '5', '', '25', '0', 'sales', '02', NULL, 'KGS', 'SDC/23-24/-012-25', 'SDC/23-24/-012270225', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (19, '2025-02-27', 14, 10, 'Against Inward', 'SDC/23-24/-013', '2025-02-27', 11, 'shivamobiles', 'tn67', 'avanshi road annur, annur', 'I009', '002', '2025-02-27', 'Metal Stamping', '5', '', '25', '0', 'sales', '02', NULL, 'KGS', 'SDC/23-24/-013-25', 'SDC/23-24/-013270225', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (20, '2025-02-27', 15, 11, 'Against Inward', 'SDC/23-24/-014', '2025-02-27', 12, 'Jayaprakash', 'tn67', 'jaganathan nagar, Coimbatore', 'I010', '003', '2025-02-27', 'asus512gb', '32', '', '25', '0', '000', '654654', NULL, 'piece', 'SDC/23-24/-014-25', 'SDC/23-24/-014270225', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (21, '2025-02-27', 15, 12, 'Against Inward', 'SDC/23-24/-014', '2025-02-27', 12, 'Jayaprakash', 'tn67', 'jaganathan nagar, Coimbatore', NULL, '003', '2025-02-27', 'Air Compressor Motor ', '4', '', '25', '0', '000', '01', NULL, 'KGS', 'SDC/23-24/-014-25', 'SDC/23-24/-014270225', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (22, '2025-02-27', 15, 13, 'Against Inward', 'SDC/23-24/-014', '2025-02-27', 12, 'Jayaprakash', 'tn67', 'jaganathan nagar, Coimbatore', NULL, '003', '2025-02-27', 'Metal Stamping', '5', '', '25', '0', '000', '02', NULL, 'KGS', 'SDC/23-24/-014-25', 'SDC/23-24/-014270225', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (23, '2025-02-27', 16, 11, 'Against Inward', 'SDC/23-24/-015', '2025-02-27', 12, 'Jayaprakash', 'tn67', 'jaganathan nagar, Coimbatore', 'I010', '003', '2025-02-27', 'asus512gb', '32', '', '25', '0', '000', '654654', NULL, 'piece', 'SDC/23-24/-015-25', 'SDC/23-24/-015270225', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (24, '2025-02-27', 16, 12, 'Against Inward', 'SDC/23-24/-015', '2025-02-27', 12, 'Jayaprakash', 'tn67', 'jaganathan nagar, Coimbatore', NULL, '003', '2025-02-27', 'Air Compressor Motor ', '4', '', '25', '0', '000', '01', NULL, 'KGS', 'SDC/23-24/-015-25', 'SDC/23-24/-015270225', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (25, '2025-02-27', 16, 13, 'Against Inward', 'SDC/23-24/-015', '2025-02-27', 12, 'Jayaprakash', 'tn67', 'jaganathan nagar, Coimbatore', NULL, '003', '2025-02-27', 'Metal Stamping', '5', '', '25', '0', '000', '02', NULL, 'KGS', 'SDC/23-24/-015-25', 'SDC/23-24/-015270225', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (26, '2025-02-27', 17, 4, 'Against Inward', 'SDC/23-24/-016', '2025-02-27', 1, 'IDREAMDEVELOPERS', '', 'Hopes, peelamedu', 'I003', '1022', '2024-07-01', 'Air Compressor Motor ', '4', '', '2', '2', 'CNC ', '01', NULL, 'KGS', 'SDC/23-24/-016-25', 'SDC/23-24/-016270225', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (27, '2025-02-27', 18, 14, 'Against Inward', 'SDC/23-24/-017', '2025-02-27', 1, 'IDREAMDEVELOPERS', '', 'Hopes, peelamedu', 'I011', '456', '2025-02-27', '10886', '31', '', '198', '198', 'CNC MACHINING COMPLETED', '1234556', NULL, 'NOS', 'SDC/23-24/-017-25', 'SDC/23-24/-017270225', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (28, '2025-02-27', 19, 15, 'Against Inward', 'SDC/23-24/-018', '2025-02-27', 1, 'IDREAMDEVELOPERS', '', 'Hopes, peelamedu', 'I012', '452', '2025-02-27', '1080R2-2PM STATOR STAMPING NEW', '3', '', '300', '100', '', '0', NULL, 'KGS', 'SDC/23-24/-018-25', 'SDC/23-24/-018270225', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (29, '2025-04-09', 1, NULL, 'Direct DC', 'SDC/23-24/-001', '2025-04-09', 25, 'jack', 'tn63ac8285', 'cbe, cbe', NULL, NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '1', 'metalstamping', '20', '20', '000', '850300', NULL, 'KGS', 'SDC/23-24/-001-25', 'SDC/23-24/-001090425', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (30, '2025-04-11', 2, 16, 'Against Inward', 'SDC/23-24/-002', '2025-04-11', 1, 'IDREAMDEVELOPERS', '', 'Hopes, peelamedu', 'I001', '001', '2025-04-11', '1080R2-2PM 70MM CLEATED STATOR', '1', '', '5', '5', '-', '850300', NULL, 'KGS', 'SDC/23-24/-002-25', 'SDC/23-24/-002110425', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (31, '2025-04-25', 3, 15, 'Against Inward', 'SDC/23-24/-003', '2025-04-25', 1, 'IDREAMDEVELOPERS', '', 'Hopes, peelamedu', 'I012', '452', '2025-02-27', '1080R2-2PM STATOR STAMPING NEW', '3', '', '100', '100', 'machining', '0', NULL, 'KGS', 'SDC/23-24/-003-25', 'SDC/23-24/-003250425', 1, 1);


#
# TABLE STRUCTURE FOR: dcbill_details
#

DROP TABLE IF EXISTS `dcbill_details`;

CREATE TABLE `dcbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `itemid` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (1, '2025-04-09', 'Direct DC', 'SDC/23-24/-001', '2025-04-09', 25, 'jack', 'tn63ac8285', '11:50:AM', 'del', '000', '000', '1000', 'cbe, cbe', NULL, NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '1', 'metalstamping', '20', '000', '850300', NULL, 'KGS', 'SDC/23-24/-001-25', 'SDC/23-24/-001090425', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (2, '2025-04-11', 'Against Inward', 'SDC/23-24/-002', '2025-04-11', 1, 'IDREAMDEVELOPERS', '', '12:56:PM', '', '', '', NULL, 'Hopes, peelamedu', 'I001', '001', '2025-04-11', '1080R2-2PM 70MM CLEATED STATOR', '1', '', '5', '-', '850300', NULL, 'KGS', 'SDC/23-24/-002-25', 'SDC/23-24/-002110425', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (3, '2025-04-25', 'Against Inward', 'SDC/23-24/-003', '2025-04-25', 1, 'IDREAMDEVELOPERS', '', '12:25:PM', '', '', '', NULL, 'Hopes, peelamedu', 'I012', '452', '2025-02-27', '1080R2-2PM STATOR STAMPING NEW', '3', '', '100', 'machining', '0', NULL, 'KGS', 'SDC/23-24/-003-25', 'SDC/23-24/-003250425', 1, 1, '');


#
# TABLE STRUCTURE FOR: dcbill_details_backup
#

DROP TABLE IF EXISTS `dcbill_details_backup`;

CREATE TABLE `dcbill_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `itemid` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (1, '2023-08-23', 'Direct DC', 'SDC/23-24/-001', '2023-08-23', 1, 'SMK INDUSTRIES', 'TN27V8009', '10:41:AM', '', '', '', '5000', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', NULL, NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '1', '', '100', 'For Drilling', '850300', NULL, 'KGS', 'SDC/23-24/-001-23', 'SDC/23-24/-001230823', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (2, '2023-08-23', 'Against Inward', 'SDC/23-24/-002', '2023-08-23', 1, 'SMK INDUSTRIES', 'TN27V8009', '10:46:AM', '', '', '', NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'I001', 'DC002', '2023-08-22', '1080R2-2PM 70MM CLEATED STATOR', '1', '', '100', 'for drilling ', '850300', NULL, 'KGS', 'SDC/23-24/-002-23', 'SDC/23-24/-002230823', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (3, '2023-09-29', 'Against Inward', 'SDC/23-24/-003', '2023-09-29', 1, 'SMK INDUSTRIES', '', '12:58:PM', '', '', '', NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'I001', 'DC002', '2023-08-22', '1080R2-2PM 70MM CLEATED STATOR', '1', '', '100', 'for drilling ', '850300', NULL, 'KGS', 'SDC/23-24/-003-23', 'SDC/23-24/-003290923', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (4, '2023-10-03', 'Against Inward', 'SDC/23-24/-004', '2023-10-03', 1, 'SMK INDUSTRIES', 'TN 37 V 8009', '04:32:PM', 'Product', 'drilling', 'completed', NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'I003', 'DC008', '2023-10-03', '1080R2-2PM 70MM CLEATED STATOR', '1', '', '10', '-', '850300', NULL, 'KGS', 'SDC/23-24/-004-23', 'SDC/23-24/-004031023', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (5, '2023-11-07', 'Direct DC', 'SDC/23-24/-005', '2023-11-07', 1, 'SMK INDUSTRIES', '', '03:47:PM', '', '', '', '', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', NULL, NULL, NULL, 'Air Compressor Motor ', '4', '', '5', '', '01', NULL, 'KGS', 'SDC/23-24/-005-23', 'SDC/23-24/-005071123', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (6, '2023-11-08', 'Against Inward', 'SDC/23-24/-006', '2023-11-08', 4, 'MPK engineering works', 'TN27V8009', '06:24:PM', '', '', '', NULL, 'Kalapatti road , Kalapatti ', 'I004', 'dc005||dc005', '2023-11-08||2023-11-08', '1080R2-2PM 70MM CLEATED STATOR||Air Compressor Motor ', '1||4', '||', '10||20', '||', '850300||01', NULL, 'KGS||KGS', 'SDC/23-24/-006-23', 'SDC/23-24/-006081123', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (7, '2024-01-09', 'Direct DC', 'SDC/23-24/-007', '2024-01-09', 4, 'MPK engineering works', '', '12:21:PM', '', '', '', '', 'Kalapatti road , Kalapatti ', NULL, NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '1||2', '||', '10||10', '||', '850300||7204', NULL, 'KGS||KGS', 'SDC/23-24/-007-24', 'SDC/23-24/-007090124', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (8, '2024-01-12', 'Direct DC', 'SDC/23-24/-008', '2024-01-11', 8, 'JAI SHREE SAI ENGINEERING', 'TN37CC6239', '10:56:AM', '', '', '', '10000', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST', NULL, NULL, NULL, '20CL ROTAR||26CL ROTOR||30CL ROTOR', '9||10||11', '||||', '300||63||312', '||||', '8503||8503||8503', NULL, 'NOS||NOS||NOS', 'SDC/23-24/-008-24', 'SDC/23-24/-008120124', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (9, '2024-02-16', 'Direct DC', 'SDC/23-24/-009', '2024-02-16', 1, 'SMK INDUSTRIES', '', '02:46:PM', '', '', '', '', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', NULL, NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '1', '', '10', '', '850300', NULL, 'KGS', 'SDC/23-24/-009-24', 'SDC/23-24/-009160224', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (10, '2024-04-02', 'Direct DC', 'SDC/23-24/-001', '2024-04-02', 8, 'JAI SHREE SAI ENGINEERING', '', '01:59:PM', '', '', '', '100', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST', NULL, NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '2', '', '10', 'machinning', '7204', NULL, 'KGS', 'SDC/23-24/-001-24', 'SDC/23-24/-001020424', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (11, '2024-04-10', 'Direct DC', 'SDC/23-24/-002', '2024-04-10', 8, 'JAI SHREE SAI ENGINEERING', 'tn uuuuu66666', '10:47:AM', 'outside sale', '', '', '1500000', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST', NULL, NULL, NULL, 'SHAFT||drilling machine', '8||7', '||', '15||22', 'out for production||out for production', '7222||1002', NULL, 'NOS||KGS', 'SDC/23-24/-002-24', 'SDC/23-24/-002100424', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (12, '2024-04-10', 'Against Inward', 'SDC/23-24/-003', '2024-04-10', 8, 'JAI SHREE SAI ENGINEERING', 'tn uuuuu7489', '10:52:AM', 'outgoing', '', '', NULL, 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST', 'I001', 'DC1003||DC1003', '2024-04-10||2024-04-10', '20CL ROTAR||drilling machine', '9||7', '||', '7||18', 'Inhouse production||Inhouse productions', '8503||1002', NULL, 'NOS||KGS', 'SDC/23-24/-003-24', 'SDC/23-24/-003100424', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (13, '2024-05-29', 'Direct DC', 'SDC/23-24/-004', '2024-05-29', 1, 'IDREAMDEVELOPERS', '', '01:24:PM', '', '', '', '150000', 'Hopes, peelamedu', NULL, NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '2', '', '10', '', '7204', NULL, 'KGS', 'SDC/23-24/-004-24', 'SDC/23-24/-004290524', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (14, '2024-05-29', 'Against Inward', 'SDC/23-24/-005', '2024-05-29', 1, 'IDREAMDEVELOPERS', '', '01:28:PM', '', '', '', NULL, 'Hopes, peelamedu', 'I002', 'DC0012', '2024-05-29', '1080R2-2PM STATOR STAMPING-GANG', '2', '', '45', '', '7204', NULL, 'KGS', 'SDC/23-24/-005-24', 'SDC/23-24/-005290524', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (15, '2024-07-03', 'Direct DC', 'SDC/23-24/-006', '2024-07-03', 15, 'GRD', '', '11:08:AM', '', '', '', '1500', 'CBE, CBE', NULL, NULL, NULL, 'AC', '16', '', '5', '', '124', NULL, 'NOS', 'SDC/23-24/-006-24', 'SDC/23-24/-006030724', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (16, '2024-08-20', 'Against Inward', 'SDC/23-24/-007', '2024-08-20', 1, 'IDREAMDEVELOPERS', '', '02:41:PM', '', '', '', NULL, 'Hopes, peelamedu', 'I002', 'DC0012', '2024-05-29', '1080R2-2PM STATOR STAMPING-GANG', '2', '', '20', '', '7204', NULL, 'KGS', 'SDC/23-24/-007-24', 'SDC/23-24/-007200824', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (17, '2024-08-21', 'Against Inward', 'SDC/23-24/-008', '2024-08-21', 1, 'IDREAMDEVELOPERS', '', '01:30:PM', '', '', '', NULL, 'Hopes, peelamedu', 'I005', '001', '2024-08-21', '1080R2-2PM 70MM CLEATED STATOR', '1', '', '20', '--', '850300', NULL, 'KGS', 'SDC/23-24/-008-24', 'SDC/23-24/-008210824', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (18, '2024-09-07', 'Direct DC', 'SDC/23-24/-009', '2024-09-07', 19, 'DD & co', '', '10:34:AM', '', '', '', '', '56,East Street,, SS kottai,madurai', NULL, NULL, NULL, 'Oversized Tshirt||Cotton saree', '20||22', '||', '100||1000', '||', '32123212||894356754', NULL, 'piece||piece', 'SDC/23-24/-009-24', 'SDC/23-24/-009070924', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (19, '2025-02-27', 'Against Inward', 'SDC/23-24/-010', '2025-02-27', 12, 'Jayaprakash', 'tn67', '11:59:AM', 'laptop', 'repair', '10', NULL, 'jaganathan nagar, Coimbatore', 'I008', '001', '2025-02-27', 'asus512gb', '32', 'laptop', '10', '10', '654654', NULL, 'piece', 'SDC/23-24/-010-25', 'SDC/23-24/-010270225', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (20, '2025-02-27', 'Against Inward', 'SDC/23-24/-011', '2025-02-27', 12, 'Jayaprakash', 'tn67', '12:19:PM', 'laptop', 'repair', '10', NULL, 'jaganathan nagar, Coimbatore', 'I008', '001', '2025-02-27', 'asus512gb', '32', 'laptop', '10', '10', '654654', NULL, 'piece', 'SDC/23-24/-011-25', 'SDC/23-24/-011270225', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (21, '2025-02-27', 'Against Inward', 'SDC/23-24/-012', '2025-02-27', 11, 'shivamobiles', 'tn67', '12:24:PM', 'laptop', 'repair', 'sales', NULL, 'avanshi road annur, annur', 'I009', '002', '2025-02-27', 'Metal Stamping', '5', '', '25', 'sales', '02', NULL, 'KGS', 'SDC/23-24/-012-25', 'SDC/23-24/-012270225', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (22, '2025-02-27', 'Against Inward', 'SDC/23-24/-013', '2025-02-27', 11, 'shivamobiles', 'tn67', '12:41:PM', 'laptop', 'repair', 'sales', NULL, 'avanshi road annur, annur', 'I009', '002', '2025-02-27', 'Metal Stamping', '5', '', '25', 'sales', '02', NULL, 'KGS', 'SDC/23-24/-013-25', 'SDC/23-24/-013270225', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (23, '2025-02-27', 'Against Inward', 'SDC/23-24/-014', '2025-02-27', 12, 'Jayaprakash', 'tn67', '03:50:PM', 'laptop', 'repair', 'sales', NULL, 'jaganathan nagar, Coimbatore', 'I010', '003||003||003', '2025-02-27||2025-02-27||2025-02-27', 'asus512gb||Air Compressor Motor ||Metal Stamping', '32||4||5', '||||', '25||25||25', '000||000||000', '654654||01||02', NULL, 'piece||KGS||KGS', 'SDC/23-24/-014-25', 'SDC/23-24/-014270225', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (24, '2025-02-27', 'Against Inward', 'SDC/23-24/-015', '2025-02-27', 12, 'Jayaprakash', 'tn67', '03:52:PM', 'laptop', 'repair', 'sales', NULL, 'jaganathan nagar, Coimbatore', 'I010', '003||003||003', '2025-02-27||2025-02-27||2025-02-27', 'asus512gb||Air Compressor Motor ||Metal Stamping', '32||4||5', '||||', '25||25||25', '000||000||000', '654654||01||02', NULL, 'piece||KGS||KGS', 'SDC/23-24/-015-25', 'SDC/23-24/-015270225', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (25, '2025-02-27', 'Against Inward', 'SDC/23-24/-016', '2025-02-27', 1, 'IDREAMDEVELOPERS', '', '05:31:PM', '', '', '', NULL, 'Hopes, peelamedu', 'I003', '1022', '2024-07-01', 'Air Compressor Motor ', '4', '', '2', 'CNC ', '01', NULL, 'KGS', 'SDC/23-24/-016-25', 'SDC/23-24/-016270225', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (26, '2025-02-27', 'Against Inward', 'SDC/23-24/-017', '2025-02-27', 1, 'IDREAMDEVELOPERS', '', '05:33:PM', '', 'CNC MACHINING', '', NULL, 'Hopes, peelamedu', 'I011', '456', '2025-02-27', '10886', '31', '', '198', 'CNC MACHINING COMPLETED', '1234556', NULL, 'NOS', 'SDC/23-24/-017-25', 'SDC/23-24/-017270225', 1, 1, '');
INSERT INTO `dcbill_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (27, '2025-02-27', 'Against Inward', 'SDC/23-24/-018', '2025-02-27', 1, 'IDREAMDEVELOPERS', '', '05:40:PM', '', '', '', NULL, 'Hopes, peelamedu', 'I012', '452', '2025-02-27', '1080R2-2PM STATOR STAMPING NEW', '3', '', '300', '', '0', NULL, 'KGS', 'SDC/23-24/-018-25', 'SDC/23-24/-018270225', 1, 1, '');


#
# TABLE STRUCTURE FOR: einvoicetoken
#

DROP TABLE IF EXISTS `einvoicetoken`;

CREATE TABLE `einvoicetoken` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tokenexpiry` varchar(255) NOT NULL,
  `authtoken` varchar(255) NOT NULL,
  `sek` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `einvoicetoken` (`id`, `tokenexpiry`, `authtoken`, `sek`, `status`, `created_at`) VALUES (1, '', '', '', 1, '2023-08-07 06:10:00');


#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS `expenses`;

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: expenses_backup
#

DROP TABLE IF EXISTS `expenses_backup`;

CREATE TABLE `expenses_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `expenses_backup` (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (1, '2023-08-22', '001', 'Manager', '2023-08-22', 'Lunch', NULL, '0', '', '', '0', '', '15000', NULL, 'Cash', '15000', '1', 'Company staff', '');
INSERT INTO `expenses_backup` (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (2, '2023-08-22', '002', 'Manager', '2023-08-22', 'Lunch', NULL, '0', '', '', '0', '', '15000', NULL, 'Cash', '15000', '1', 'Company staff', '');


#
# TABLE STRUCTURE FOR: headers
#

DROP TABLE IF EXISTS `headers`;

CREATE TABLE `headers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `headers` (`id`, `date`, `status`, `name`) VALUES (1, '2023-08-22', 1, 'Company staff');
INSERT INTO `headers` (`id`, `date`, `status`, `name`) VALUES (2, '2024-09-04', 1, 'Sudharsan');


#
# TABLE STRUCTURE FOR: hsnmaster
#

DROP TABLE IF EXISTS `hsnmaster`;

CREATE TABLE `hsnmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `party` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: invoice_details
#

DROP TABLE IF EXISTS `invoice_details`;

CREATE TABLE `invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `pono` varchar(255) DEFAULT NULL,
  `pino` varchar(255) DEFAULT NULL,
  `purchaseordernos` varchar(255) DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerdcnos` varchar(100) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `removalDate` date NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToId` varchar(255) DEFAULT NULL,
  `shipToAddress` longtext,
  `deliveryAddress1` longtext,
  `deliveryAddress2` longtext,
  `mobileNo` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemcode` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `totalqty` varchar(255) DEFAULT NULL,
  `acno` varchar(255) NOT NULL,
  `acdate` varchar(255) NOT NULL,
  `irn` varchar(255) NOT NULL,
  `signedinvoice` longtext NOT NULL,
  `signedqrcode` longtext NOT NULL,
  `status_ein` longtext NOT NULL,
  `ewayno` varchar(255) NOT NULL,
  `ewaydate` varchar(255) NOT NULL,
  `ewbvalidtill` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `status_cd` varchar(255) NOT NULL,
  `status_desc` varchar(255) NOT NULL,
  `einvoice_status` int(11) NOT NULL,
  `eway_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (1, '2025-03-01', '2025-03-01', '', '1970-01-01', 'INV/23-24/-0001', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 21, 'VRN ENGINEERING', '137 OM SAKTHINAGAR, CHINNAVEDAMPATTI, COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-03-01', '05:08 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '5', '7500.00', '0', 'percent_wise', '0.00', '7500.00', '9', '675.00', '9', '675.00', '18', '', NULL, '7500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '8850.00', '8850.00', 1, 'INV/23-24/-0001010325', 'INV/23-24/-0001-2025', 1, 1, '5.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (2, '2025-03-03', '2025-03-03', '', '1970-01-01', 'INV/23-24/-0002', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 22, 'thennarasdu', 'teachers colony, vennampatty main road, dharmapuri, Tamil Nadu', NULL, NULL, '', '2025-03-03', '03:14 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '84158210||84158210', NULL, 'daikin cassette ac||daikin cassette ac', '||', 'NOS||NOS', '75000||75000', '2||4', '150000.00||300000.00', '0||0', 'percent_wise', '0.00||0.00', '150000.00||300000.00', '9', '40500.00', '9', '40500.00', '18', '', NULL, '450000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '531000.00', '531000.00', 1, 'INV/23-24/-0002030325', 'INV/23-24/-0002-2025', 1, 1, '6.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (4, '2025-03-11', '2025-03-11', '', '1970-01-01', 'INV/23-24/-0003', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 12, 'Jayaprakash', 'jaganathan nagar, Coimbatore, coimabtore, Tamil Nadu', NULL, NULL, '', '2025-03-11', '12:43 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '654654', NULL, 'asus512gb', '', 'piece', '5000', '5', '25000.00', '0', 'amount_wise', '0', '25000.00', '9', '', '9', '', '18', '', NULL, '25000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '25000.00', '25000.00', 1, 'INV/23-24/-0003110325', 'INV/23-24/-0003-2025', 1, 1, '5.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (5, '2025-04-03', '2025-04-03', '', '1970-01-01', 'INV/25-26/-001', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 21, 'VRN ENGINEERING', '137 OM SAKTHINAGAR, CHINNAVEDAMPATTI, COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-04-03', '12:53 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '5', '10000.00', '0', 'amount_wise', '0', '10000.00', '9', '900.00', '9', '900.00', '18', '', NULL, '10000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '11800.00', '11800.00', 1, 'INV/25-26/-001030425', 'INV/25-26/-001-2025', 1, 1, '5.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (6, '2025-04-03', '2025-04-03', '', '1970-01-01', 'INV/25-26/-002', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 24, 'Idream Developers new', 'jaganathan nagar, Civil Aerodeome Post, Mumbai, Maharashtra', NULL, NULL, '', '2025-04-03', '01:07 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '10', '15000.00', '0', 'amount_wise', '0', '15000.00', '9', '', '9', '', '18', '2700.00', NULL, '15000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '17700.00', '17700.00', 1, 'INV/25-26/-002030425', 'INV/25-26/-002-2025', 1, 1, '10.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (7, '2025-04-03', '2025-04-03', '', '1970-01-01', 'INV/25-26/-003', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 24, 'Idream Developers new', 'jaganathan nagar, Civil Aerodeome Post, Mumbai, Maharashtra', NULL, NULL, '', '2025-04-03', '01:10 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '5', '7500.00', '0', 'amount_wise', '0', '7500.00', '9', '', '9', '', '18', '1350.00', NULL, '7500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '8850.00', '8850.00', 1, 'INV/25-26/-003030425', 'INV/25-26/-003-2025', 1, 1, '5.00', '112510223076239', '2025-04-03 13:10:00', 'fb541c5831ba024d212c64e6d2db96672bbb083e1f81a2fecd19ff9b5686265e', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjNCRTE3RTUxNDE5MjUyMjY0N0YwMUZEQkZGNTI3MUFENTI2OEQ3MzUiLCJ4NXQiOiJPLUYtVVVHU1VpWkg4Ql9iXzFKeHJWSm8xelUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJOSUMgU2FuZGJveCIsImRhdGEiOiJ7XCJBY2tOb1wiOjExMjUxMDIyMzA3NjIzOSxcIkFja0R0XCI6XCIyMDI1LTA0LTAzIDEzOjEwOjAwXCIsXCJJcm5cIjpcImZiNTQxYzU4MzFiYTAyNGQyMTJjNjRlNmQyZGI5NjY3MmJiYjA4M2UxZjgxYTJmZWNkMTlmZjliNTY4NjI2NWVcIixcIlZlcnNpb25cIjpcIjEuMVwiLFwiVHJhbkR0bHNcIjp7XCJUYXhTY2hcIjpcIkdTVFwiLFwiU3VwVHlwXCI6XCJCMkJcIixcIklnc3RPbkludHJhXCI6XCJOXCJ9LFwiRG9jRHRsc1wiOntcIlR5cFwiOlwiSU5WXCIsXCJOb1wiOlwiSU5WLzI1LTI2Ly0wMDNcIixcIkR0XCI6XCIwMy8wNC8yMDI1XCJ9LFwiU2VsbGVyRHRsc1wiOntcIkdzdGluXCI6XCIyOUFBQkNUMTMzMkwwMDBcIixcIkxnbE5tXCI6XCJNWU9GRklDRSBFUlBcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwMDEsXCJTdGNkXCI6XCIyOVwifSxcIkJ1eWVyRHRsc1wiOntcIkdzdGluXCI6XCIyN0dTUE1IMTg4MUcxWkhcIixcIkxnbE5tXCI6XCJJZHJlYW0gRGV2ZWxvcGVycyBuZXdcIixcIlBvc1wiOlwiMjdcIixcIkFkZHIxXCI6XCJqYWdhbmF0aGFuIG5hZ2FyXCIsXCJBZGRyMlwiOlwiQ2l2aWwgQWVyb2Rlb21lIFBvc3RcIixcIkxvY1wiOlwiTXVtYmFpXCIsXCJQaW5cIjo0MDAwMDEsXCJTdGNkXCI6XCIyN1wifSxcIkl0ZW1MaXN0XCI6W3tcIkl0ZW1Ob1wiOjAsXCJTbE5vXCI6XCIxXCIsXCJJc1NlcnZjXCI6XCJOXCIsXCJIc25DZFwiOlwiODUwMzAwXCIsXCJRdHlcIjo1LFwiVW5pdFwiOlwiS0dTXCIsXCJVbml0UHJpY2VcIjoxNTAwLFwiVG90QW10XCI6NzUwMCxcIkRpc2NvdW50XCI6MCxcIkFzc0FtdFwiOjc1MDAsXCJHc3RSdFwiOjE4LFwiSWdzdEFtdFwiOjEzNTAsXCJDZ3N0QW10XCI6MCxcIlNnc3RBbXRcIjowLFwiVG90SXRlbVZhbFwiOjg4NTB9XSxcIlZhbER0bHNcIjp7XCJBc3NWYWxcIjo3NTAwLjAwLFwiQ2dzdFZhbFwiOjAsXCJTZ3N0VmFsXCI6MCxcIklnc3RWYWxcIjoxMzUwLjAwLFwiT3RoQ2hyZ1wiOjAsXCJSbmRPZmZBbXRcIjowLFwiVG90SW52VmFsXCI6ODg1MH0sXCJBZGRsRG9jRHRsc1wiOlt7XCJVcmxcIjpcImh0dHBzOi8vZWludi1hcGlzYW5kYm94Lm5pYy5pblwiLFwiRG9jc1wiOlwiVGVzdCBEb2NcIixcIkluZm9cIjpcIkRvY3VtZW50IFRlc3RcIn1dfSJ9.koM4biPGOBuY_rnxf-k6cINqOQC0V8el88yP0GBcT1w6jCwxo9PyZ4VF2-wvYltMjnqth1crQNVzcz5Lbvs3rPzfY2f4Hg3wMgPvHGkCXlIUs8uaakhdlos0QmQs63qrwGsvW83l7fJLx8Tluie8wOU3MB3bRgKUTiU3Fin6JuqzlJyJM25O53RQZ2022MYD2Xc56xWBif23CoxbOaWuQTgywMhwnc8RQc7gDw4BKtv-7mEq5zvyhfUQNPyJjGxaA5WYCEmZ6ITAUpZjXdabdth7RLknxDNHQIWZAEwjRbY0u-gLKpLr1yzh9kj5osTW6sksWHQy0InLpwvo0buwPA', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjNCRTE3RTUxNDE5MjUyMjY0N0YwMUZEQkZGNTI3MUFENTI2OEQ3MzUiLCJ4NXQiOiJPLUYtVVVHU1VpWkg4Ql9iXzFKeHJWSm8xelUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJOSUMgU2FuZGJveCIsImRhdGEiOiJ7XCJTZWxsZXJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJCdXllckdzdGluXCI6XCIyN0dTUE1IMTg4MUcxWkhcIixcIkRvY05vXCI6XCJJTlYvMjUtMjYvLTAwM1wiLFwiRG9jVHlwXCI6XCJJTlZcIixcIkRvY0R0XCI6XCIwMy8wNC8yMDI1XCIsXCJUb3RJbnZWYWxcIjo4ODUwLFwiSXRlbUNudFwiOjEsXCJNYWluSHNuQ29kZVwiOlwiODUwMzAwXCIsXCJJcm5cIjpcImZiNTQxYzU4MzFiYTAyNGQyMTJjNjRlNmQyZGI5NjY3MmJiYjA4M2UxZjgxYTJmZWNkMTlmZjliNTY4NjI2NWVcIixcIklybkR0XCI6XCIyMDI1LTA0LTAzIDEzOjEwOjAwXCJ9In0.k6JnIN8yUtZ5zyCjPbUxudsD-zK68kNBggsEiCBUSFhl3P0PfJHTSWwHlm7QFNRa9jzYPMeEZhZp7UKM961zNBcbFFgR4LuKyuuNub-bNS7hBxYUms_58AKJcwq_IHgq_KWkezrWMcdMenfRCXdg0OyJwNzDUeHy2hXRtLdYRqjjVkLc5iOTY4Gr1z1iQwSeqA1rtRzoaWxUX1ewWpT93ByaPtFCrfrBFvOrEpqwmv3LZw9uZELoFqpKvxJe_iTQ2nWwlj7iXRwxInZAFCQW2lZSDNfoMYi-EQZfAypJpYMYxZc_20dpezBKf9_p3askpC1rs6HM0JQjVIWrt44S_A', 'ACT', '', '', '', '', '', '', 1, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (8, '2025-04-03', '2025-04-03', '', '1970-01-01', 'INV/25-26/-004', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 24, 'Idream Developers new', 'jaganathan nagar, Civil Aerodeome Post, Mumbai, Maharashtra', NULL, NULL, '', '2025-04-03', '01:18 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300||7204', NULL, '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', 'KGS||KGS', '1500||2000', '5||5', '7500.00||10000.00', '0||0', 'amount_wise', '0||0', '7500.00||10000.00', '9||9', '675.00||900.00', '9||9', '675.00||900.00', '18||18', '1350.00||1800.00', '8850.00||11800.00', '20650.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', NULL, '1||1', '20650.00', '20650.00', 1, 'INV/25-26/-004030425', 'INV/25-26/-004-2025', 1, 1, NULL, '112510223076266', '2025-04-03 13:19:00', '7269d4185c36005d30d1b07f3d0539d7cc82f61638f4f65cbeeb361cdf5ac0f8', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjNCRTE3RTUxNDE5MjUyMjY0N0YwMUZEQkZGNTI3MUFENTI2OEQ3MzUiLCJ4NXQiOiJPLUYtVVVHU1VpWkg4Ql9iXzFKeHJWSm8xelUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJOSUMgU2FuZGJveCIsImRhdGEiOiJ7XCJBY2tOb1wiOjExMjUxMDIyMzA3NjI2NixcIkFja0R0XCI6XCIyMDI1LTA0LTAzIDEzOjE5OjAwXCIsXCJJcm5cIjpcIjcyNjlkNDE4NWMzNjAwNWQzMGQxYjA3ZjNkMDUzOWQ3Y2M4MmY2MTYzOGY0ZjY1Y2JlZWIzNjFjZGY1YWMwZjhcIixcIlZlcnNpb25cIjpcIjEuMVwiLFwiVHJhbkR0bHNcIjp7XCJUYXhTY2hcIjpcIkdTVFwiLFwiU3VwVHlwXCI6XCJCMkJcIixcIklnc3RPbkludHJhXCI6XCJOXCJ9LFwiRG9jRHRsc1wiOntcIlR5cFwiOlwiSU5WXCIsXCJOb1wiOlwiSU5WLzI1LTI2Ly0wMDRcIixcIkR0XCI6XCIwMy8wNC8yMDI1XCJ9LFwiU2VsbGVyRHRsc1wiOntcIkdzdGluXCI6XCIyOUFBQkNUMTMzMkwwMDBcIixcIkxnbE5tXCI6XCJNWU9GRklDRSBFUlBcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwMDEsXCJTdGNkXCI6XCIyOVwifSxcIkJ1eWVyRHRsc1wiOntcIkdzdGluXCI6XCIyN0dTUE1IMTg4MUcxWkhcIixcIkxnbE5tXCI6XCJJZHJlYW0gRGV2ZWxvcGVycyBuZXdcIixcIlBvc1wiOlwiMjdcIixcIkFkZHIxXCI6XCJqYWdhbmF0aGFuIG5hZ2FyXCIsXCJBZGRyMlwiOlwiQ2l2aWwgQWVyb2Rlb21lIFBvc3RcIixcIkxvY1wiOlwiTXVtYmFpXCIsXCJQaW5cIjo0MDAwMDEsXCJTdGNkXCI6XCIyN1wifSxcIkl0ZW1MaXN0XCI6W3tcIkl0ZW1Ob1wiOjAsXCJTbE5vXCI6XCIxXCIsXCJJc1NlcnZjXCI6XCJOXCIsXCJIc25DZFwiOlwiODUwMzAwXCIsXCJRdHlcIjo1LFwiVW5pdFwiOlwiS0dTXCIsXCJVbml0UHJpY2VcIjoxNTAwLFwiVG90QW10XCI6NzUwMCxcIkRpc2NvdW50XCI6MCxcIkFzc0FtdFwiOjc1MDAsXCJHc3RSdFwiOjE4LFwiSWdzdEFtdFwiOjEzNTAuMDAsXCJDZ3N0QW10XCI6MCxcIlNnc3RBbXRcIjowLFwiVG90SXRlbVZhbFwiOjg4NTB9LHtcIkl0ZW1Ob1wiOjAsXCJTbE5vXCI6XCIyXCIsXCJJc1NlcnZjXCI6XCJOXCIsXCJIc25DZFwiOlwiNzIwNFwiLFwiUXR5XCI6NSxcIlVuaXRcIjpcIktHU1wiLFwiVW5pdFByaWNlXCI6MjAwMCxcIlRvdEFtdFwiOjEwMDAwLFwiRGlzY291bnRcIjowLFwiQXNzQW10XCI6MTAwMDAsXCJHc3RSdFwiOjE4LFwiSWdzdEFtdFwiOjE4MDAuMDAsXCJDZ3N0QW10XCI6MCxcIlNnc3RBbXRcIjowLFwiVG90SXRlbVZhbFwiOjExODAwfV0sXCJWYWxEdGxzXCI6e1wiQXNzVmFsXCI6MTc1MDAuMDAsXCJDZ3N0VmFsXCI6MCxcIlNnc3RWYWxcIjowLFwiSWdzdFZhbFwiOjMxNTAuMDAsXCJPdGhDaHJnXCI6MCxcIlJuZE9mZkFtdFwiOjAsXCJUb3RJbnZWYWxcIjoyMDY1MH0sXCJBZGRsRG9jRHRsc1wiOlt7XCJVcmxcIjpcImh0dHBzOi8vZWludi1hcGlzYW5kYm94Lm5pYy5pblwiLFwiRG9jc1wiOlwiVGVzdCBEb2NcIixcIkluZm9cIjpcIkRvY3VtZW50IFRlc3RcIn1dfSJ9.gv1YuZVC5Q4EhkwyeVTUoVvFe459KfUWJxvBl2tjYSLuR8Bky0r419oaAHjfYBSpQqS3Lxv611GzdhN3qEjnYrRw6AM-qyR-tdVkH7cE1JR7_Veuy9JVxY-MhY6GPzrWyj-VToKcQko328X3hqkguEF-6ILhXWv_hsbLQDGA9995BxFW3qILNM9CVfPJA-ZFxKQpqKujkQEaTlkPq7prkhvZeWpIUCXw7tK_fO6EMhOALcHvhmLQt2BQ1e4DMrKRMxYAlRgosO2UeV2D_segJbO7Y0E_H0EfdGB6TTPaAJiu8x6pxZlvK_A3M4Mc0Jvl1o9g90cAN-4G9fqrQYrK6Q', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjNCRTE3RTUxNDE5MjUyMjY0N0YwMUZEQkZGNTI3MUFENTI2OEQ3MzUiLCJ4NXQiOiJPLUYtVVVHU1VpWkg4Ql9iXzFKeHJWSm8xelUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJOSUMgU2FuZGJveCIsImRhdGEiOiJ7XCJTZWxsZXJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJCdXllckdzdGluXCI6XCIyN0dTUE1IMTg4MUcxWkhcIixcIkRvY05vXCI6XCJJTlYvMjUtMjYvLTAwNFwiLFwiRG9jVHlwXCI6XCJJTlZcIixcIkRvY0R0XCI6XCIwMy8wNC8yMDI1XCIsXCJUb3RJbnZWYWxcIjoyMDY1MCxcIkl0ZW1DbnRcIjoyLFwiTWFpbkhzbkNvZGVcIjpcIjcyMDRcIixcIklyblwiOlwiNzI2OWQ0MTg1YzM2MDA1ZDMwZDFiMDdmM2QwNTM5ZDdjYzgyZjYxNjM4ZjRmNjVjYmVlYjM2MWNkZjVhYzBmOFwiLFwiSXJuRHRcIjpcIjIwMjUtMDQtMDMgMTM6MTk6MDBcIn0ifQ.HbgMLJa0FBCqaaVGZ9uvgeWoFxfM2KAtVPio-t1XqcgtLJsW3gma9HGz_25-kqWdD02ksVyfVVxgunYXjXz1wRfiusBAZIJj-FF2Al3DwWgBHUNRsfe-skQrPXJVr3YR279IPJbufcNaFmpe-uzs30kTfIoL8Bm1qxWGq3YzaCv-y9n1kdSK1VKlpk74f2mbzzUPqkeq8P98nG7fnf46tbShjTqs1dUenAFWBHn2y3NDpNmt0aO2mBO0EDcEKReDPG3AT1rSmr1zX5_TQXdzd9OrIkh28QGaqDT1EYfOYv_EBBj2MsOr9eegP3Htz6EMP2D4UbE5t3NMAwNsDdtr7Q', 'ACT', '', '', '', '', '', '', 1, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (12, '2025-04-25', '2025-04-25', '', '1970-01-01', 'INV/25-26/-005', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-04-25', '12:19 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '5', '7500.00', '0', 'amount_wise', '0', '7500.00', '9', '', '9', '', '18', '1350.00', NULL, '7500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '8850.00', '0', 0, 'INV/25-26/-005250425', 'INV/25-26/-005-2025', 1, 1, '5.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (13, '2025-05-07', '2025-05-07', '', '1970-01-01', 'INV/25-26/-006', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 24, 'Idream Developers new', 'jaganathan nagar, Civil Aerodeome Post, Mumbai, Maharashtra', NULL, NULL, '', '2025-05-07', '12:12 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '853521', NULL, 'DISPLAY BOARD (12\" x 14\" x 3mm)', '', 'NOS', '1000', '115', '115000.00', '0', 'amount_wise', '0', '115000.00', '9', '', '9', '', '18', '20700.00', NULL, '115000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '135700.00', '135700.00', 1, 'INV/25-26/-006070525', 'INV/25-26/-006-2025', 1, 1, '100.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (14, '2025-05-14', '2025-05-14', '', '1970-01-01', 'INV/25-26/-007', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 24, 'Idream Developers new', 'jaganathan nagar, Civil Aerodeome Post, Mumbai, Maharashtra', NULL, NULL, '', '2025-05-14', '12:59 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '5', '7500.00', '0', 'amount_wise', '0', '7500.00', '9', '', '9', '', '18', '1350.00', NULL, '7500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '8850.00', '8850.00', 1, 'INV/25-26/-007140525', 'INV/25-26/-007-2025', 1, 1, '5.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);


#
# TABLE STRUCTURE FOR: invoice_details_backup
#

DROP TABLE IF EXISTS `invoice_details_backup`;

CREATE TABLE `invoice_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `pono` varchar(255) DEFAULT NULL,
  `pino` varchar(255) DEFAULT NULL,
  `purchaseordernos` varchar(255) DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerdcnos` varchar(100) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `removalDate` date NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToId` varchar(255) DEFAULT NULL,
  `shipToAddress` longtext,
  `deliveryAddress1` longtext,
  `deliveryAddress2` longtext,
  `mobileNo` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemcode` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `totalqty` varchar(255) DEFAULT NULL,
  `acno` varchar(255) NOT NULL,
  `acdate` varchar(255) NOT NULL,
  `irn` varchar(255) NOT NULL,
  `signedinvoice` longtext NOT NULL,
  `signedqrcode` longtext NOT NULL,
  `status_ein` longtext NOT NULL,
  `ewayno` varchar(255) NOT NULL,
  `ewaydate` varchar(255) NOT NULL,
  `ewbvalidtill` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `status_cd` varchar(255) NOT NULL,
  `status_desc` varchar(255) NOT NULL,
  `einvoice_status` int(11) NOT NULL,
  `eway_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=latin1;

INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (1, '2024-03-28', '2024-03-28', '', '1970-01-01', 'INV/23-24/-001', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 12, 'Jayaprakash', 'jaganathan nagar, Coimbatore, coimabtore, Tamil Nadu', NULL, NULL, '', '2024-03-28', '05:46 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '5', '7500.00', '0', 'percent_wise', '0.00', '7500.00', '9', '', '9', '', '18', '1350.00', NULL, '7500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '8850.00', '8850.00', 1, 'INV/23-24/-001280324', 'INV/23-24/-001-2024', 1, 1, '5.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (2, '2024-03-28', '2024-03-28', '', '1970-01-01', 'INV/23-24/-002', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-03-28', '06:24 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '6', '9000.00', '0', 'percent_wise', '0.00', '9000.00', '9', '', '9', '', '18', '1620.00', NULL, '9000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '10620.00', '0', 0, 'INV/23-24/-002280324', 'INV/23-24/-002-2024', 1, 1, '6.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (3, '2024-03-28', '2024-03-28', '', '1970-01-01', 'INV/23-24/-003', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-03-28', '06:29 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '1001', NULL, 'Compressor', '', 'KGS', '1000', '10', '10000.00', '0', 'percent_wise', '0.00', '10000.00', '9', '', '9', '', '18', '1800.00', NULL, '10000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '11800.00', '0', 0, 'INV/23-24/-003280324', 'INV/23-24/-003-2024', 1, 1, '10.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (4, '2024-03-28', '2024-03-28', '', '1970-01-01', 'INV/23-24/-10001', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-03-28', '06:32 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '2', '3000.00', '0', 'percent_wise', '0.00', '3000.00', '9', '', '9', '', '18', '540.00', NULL, '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '0', 0, 'INV/23-24/-10001280324', 'INV/23-24/-10001-2024', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (5, '2024-03-28', '2024-03-28', '', '1970-01-01', 'INV/23-24/-10002', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-03-28', '06:34 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '1001', NULL, 'Compressor', '', 'KGS', '1000', '2', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '0', 0, 'INV/23-24/-10002280324', 'INV/23-24/-10002-2024', 1, 1, '2.00', '112410189325199', '2024-03-28 18:35:00', '1adb18d45605d7040ff5e4301af9e7c2bf993ba3a5f814d197eedbdd3cd4e4d8', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTI0MTAxODkzMjUxOTksXCJBY2tEdFwiOlwiMjAyNC0wMy0yOCAxODozNTowMFwiLFwiSXJuXCI6XCIxYWRiMThkNDU2MDVkNzA0MGZmNWU0MzAxYWY5ZTdjMmJmOTkzYmEzYTVmODE0ZDE5N2VlZGJkZDNjZDRlNGQ4XCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMTAwMDJcIixcIkR0XCI6XCIyOC8wMy8yMDI0XCJ9LFwiU2VsbGVyRHRsc1wiOntcIkdzdGluXCI6XCIyOUFBQkNUMTMzMkwwMDBcIixcIkxnbE5tXCI6XCJNWU9GRklDRSBFUlBcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwMDEsXCJTdGNkXCI6XCIyOVwifSxcIkJ1eWVyRHRsc1wiOntcIkdzdGluXCI6XCIzM0FEWFBUMzI5MU4yWkpcIixcIkxnbE5tXCI6XCJTTUsgSU5EVVNUUklFU1wiLFwiUG9zXCI6XCIzM1wiLFwiQWRkcjFcIjpcIjMvMjI2RCwgTkFEVVBBTEFZQU0gUk9BRFwiLFwiQWRkcjJcIjpcIlBBVFRBTkFNIFBPU1QsT05ESVBVRFVSIChWSUEpXCIsXCJMb2NcIjpcIkNPSU1CQVRPUkVcIixcIlBpblwiOjY0MTAxNCxcIlN0Y2RcIjpcIjMzXCJ9LFwiSXRlbUxpc3RcIjpbe1wiSXRlbU5vXCI6MCxcIlNsTm9cIjpcIjFcIixcIklzU2VydmNcIjpcIk5cIixcIkhzbkNkXCI6XCIxMDAxXCIsXCJRdHlcIjoyLFwiVW5pdFwiOlwiS0dTXCIsXCJVbml0UHJpY2VcIjoxMDAwLFwiVG90QW10XCI6MjAwMCxcIkRpc2NvdW50XCI6MCxcIkFzc0FtdFwiOjIwMDAsXCJHc3RSdFwiOjE4LFwiSWdzdEFtdFwiOjM2MCxcIkNnc3RBbXRcIjowLFwiU2dzdEFtdFwiOjAsXCJUb3RJdGVtVmFsXCI6MjM2MH1dLFwiVmFsRHRsc1wiOntcIkFzc1ZhbFwiOjIwMDAuMDAsXCJDZ3N0VmFsXCI6MCxcIlNnc3RWYWxcIjowLFwiSWdzdFZhbFwiOjM2MC4wMCxcIk90aENocmdcIjowLFwiUm5kT2ZmQW10XCI6MCxcIlRvdEludlZhbFwiOjIzNjB9LFwiQWRkbERvY0R0bHNcIjpbe1wiVXJsXCI6XCJodHRwczovL2VpbnYtYXBpc2FuZGJveC5uaWMuaW5cIixcIkRvY3NcIjpcIlRlc3QgRG9jXCIsXCJJbmZvXCI6XCJEb2N1bWVudCBUZXN0XCJ9XX0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.OBPw1kweZpeiEj2O6VFyoUftJTg9Z3oc_YKs7hRwhPgrH4HGlKBWUJ03I30fDcu-QL-Yx4Z6N8z_gDOHVuBltjUv5mumUWdrEAr3GMNt04vwHxXeJbSNoWEnZiziZSEADjb-Q5H-nz8oODcqH1gox0iQTFBFqNNuSnqOxU9KjUmojFAY4v1ab0mfXYiM-FwddTF3SS5JsO7mnUq86gUyx7-G2Op-RcHvsCHnsodNEJGD6mE7EhhcMppuvcw8KFNnswPB4nuFYOPsMtC2Ow1ChLC42q-iFgrS0DhacJ5SPqGD2ON_ou4yVuK54rSLf9hbuCy-reAzflCJbhbqjxPL_g', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0xMDAwMlwiLFwiRG9jVHlwXCI6XCJJTlZcIixcIkRvY0R0XCI6XCIyOC8wMy8yMDI0XCIsXCJUb3RJbnZWYWxcIjoyMzYwLFwiSXRlbUNudFwiOjEsXCJNYWluSHNuQ29kZVwiOlwiMTAwMVwiLFwiSXJuXCI6XCIxYWRiMThkNDU2MDVkNzA0MGZmNWU0MzAxYWY5ZTdjMmJmOTkzYmEzYTVmODE0ZDE5N2VlZGJkZDNjZDRlNGQ4XCIsXCJJcm5EdFwiOlwiMjAyNC0wMy0yOCAxODozNTowMFwifSIsImlzcyI6Ik5JQyBTYW5kYm94In0.GOEcyNcqfcEzCMkqRuMnP_3w_E2nxBreTxF8DNXbljtPQ4ZqEuPg5TrLeAD-inKxHFNvmfrWhgKoldo__YgFmc09wKQ_gtg5B2KLHjFjp5LvjUAUfz00CwlHJxFr_ydHF6UrBl7xzBt1sNSWvg5gEtxp3sCYQPg1CMCKBuGYCAgCdnMivF63qt-1ILJyobJIfC4XvJxdCklw1c3V__6wg4N21DPr_OxIMX8MRsS2bgv3KFrSccdb3QAPiBE8AjD7toq1goEZbAWB4Q-SlJmKkzK6NeTvL9RPhKW7pO5xeyJZctXUnhxJm_yAn4nI74S1Zi_VvMiDrGI7htgeDUDNUg', 'ACT', '', '', '', '', '', '', 1, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (6, '2024-03-28', '2024-03-28', '', '1970-01-01', 'INV/23-24/-10003', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-03-28', '09:05 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '10', '15000.00', '0', 'percent_wise', '0.00', '15000.00', '9', '', '9', '', '18', '2700.00', NULL, '15000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '17700.00', '700', 1, 'INV/23-24/-10003280324', 'INV/23-24/-10003-2024', 1, 1, '10.00', '112410189350450', '2024-03-28 21:05:00', 'fc32a5148047fd899cb7f519aa9ee8c0c82a695f76cdaf0bae08c330eb6c9c4e', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTI0MTAxODkzNTA0NTAsXCJBY2tEdFwiOlwiMjAyNC0wMy0yOCAyMTowNTowMFwiLFwiSXJuXCI6XCJmYzMyYTUxNDgwNDdmZDg5OWNiN2Y1MTlhYTllZThjMGM4MmE2OTVmNzZjZGFmMGJhZTA4YzMzMGViNmM5YzRlXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMTAwMDNcIixcIkR0XCI6XCIyOC8wMy8yMDI0XCJ9LFwiU2VsbGVyRHRsc1wiOntcIkdzdGluXCI6XCIyOUFBQkNUMTMzMkwwMDBcIixcIkxnbE5tXCI6XCJNWU9GRklDRSBFUlBcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwMDEsXCJTdGNkXCI6XCIyOVwifSxcIkJ1eWVyRHRsc1wiOntcIkdzdGluXCI6XCIzM0FEWFBUMzI5MU4yWkpcIixcIkxnbE5tXCI6XCJTTUsgSU5EVVNUUklFU1wiLFwiUG9zXCI6XCIzM1wiLFwiQWRkcjFcIjpcIjMvMjI2RCwgTkFEVVBBTEFZQU0gUk9BRFwiLFwiQWRkcjJcIjpcIlBBVFRBTkFNIFBPU1QsT05ESVBVRFVSIChWSUEpXCIsXCJMb2NcIjpcIkNPSU1CQVRPUkVcIixcIlBpblwiOjY0MTAxNCxcIlN0Y2RcIjpcIjMzXCJ9LFwiSXRlbUxpc3RcIjpbe1wiSXRlbU5vXCI6MCxcIlNsTm9cIjpcIjFcIixcIklzU2VydmNcIjpcIk5cIixcIkhzbkNkXCI6XCI4NTAzMDBcIixcIlF0eVwiOjEwLFwiVW5pdFwiOlwiS0dTXCIsXCJVbml0UHJpY2VcIjoxNTAwLFwiVG90QW10XCI6MTUwMDAsXCJEaXNjb3VudFwiOjAsXCJBc3NBbXRcIjoxNTAwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6MjcwMCxcIkNnc3RBbXRcIjowLFwiU2dzdEFtdFwiOjAsXCJUb3RJdGVtVmFsXCI6MTc3MDB9XSxcIlZhbER0bHNcIjp7XCJBc3NWYWxcIjoxNTAwMC4wMCxcIkNnc3RWYWxcIjowLFwiU2dzdFZhbFwiOjAsXCJJZ3N0VmFsXCI6MjcwMC4wMCxcIk90aENocmdcIjowLFwiUm5kT2ZmQW10XCI6MCxcIlRvdEludlZhbFwiOjE3NzAwfSxcIkFkZGxEb2NEdGxzXCI6W3tcIlVybFwiOlwiaHR0cHM6Ly9laW52LWFwaXNhbmRib3gubmljLmluXCIsXCJEb2NzXCI6XCJUZXN0IERvY1wiLFwiSW5mb1wiOlwiRG9jdW1lbnQgVGVzdFwifV19IiwiaXNzIjoiTklDIFNhbmRib3gifQ.Z7Dgbh1b6Q-AH0esjd_E0d8oenX3iioXcFgeFIDU95os4nZ7o_4q1KvRdDczs-DjQrLcP5lvsWHm1aggNjzzOFJs-8o5V1A2YCGRNEWcKbt9voJgOD6tnt3CNlwpMk3A56hKcjUkEgOAC1MvwYc9-n-5II_k8nKuQH7FzeUSPVWhi9JcObJNHO5xCV9PJhA_BTRgTxq6ZOah60_ESkfgykdrQ9684QGeNNxMqV5dL49SMvmypltj9zvwvIW5LXivw6ztnZpBIb5cUHpQZo50T2zgdCHRPQNRea-p_15fnEMpxBBbnzOSnGxFomcfP52YE7kJHlncq1Lm7zOLNLeCbw', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0xMDAwM1wiLFwiRG9jVHlwXCI6XCJJTlZcIixcIkRvY0R0XCI6XCIyOC8wMy8yMDI0XCIsXCJUb3RJbnZWYWxcIjoxNzcwMCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjg1MDMwMFwiLFwiSXJuXCI6XCJmYzMyYTUxNDgwNDdmZDg5OWNiN2Y1MTlhYTllZThjMGM4MmE2OTVmNzZjZGFmMGJhZTA4YzMzMGViNmM5YzRlXCIsXCJJcm5EdFwiOlwiMjAyNC0wMy0yOCAyMTowNTowMFwifSIsImlzcyI6Ik5JQyBTYW5kYm94In0.IzK-dMGYi_SB-gWYBPHgML3LN2lMDS3gyK5ROybNQP9oguIoygjDL03UPMjgHUHAjJrrGnGql7AzFCaYErRpgkQQTxwa6L4U3N54kGUhm4JNBT3Dj0cfyak5z1Xe0pNyzuCHXThht-W-5KWXMi8p5EtED_HCAfcfZ9tQU6c05T-bzTi94_t5u0XLGseoIDodHPsvW8RoH5bMpBV8v-Ym3TAkoL0UXdJf_veUkQsUwegQWLsBC1LF7SQgJ-3LWcdkQpNQ3dX1VzVwVyMmiDllmlcxliPuZF68Pl0wU6klOYODTKdfXY6b17brmCVtcQnyBguwOjSreHQvO_fE_-M8ag', 'ACT', '', '', '', '', '', '', 1, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (7, '2024-03-28', '2024-03-28', '', '1970-01-01', 'INV/23-24/-10004', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-03-28', '09:06 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '20', '30000.00', '0', 'percent_wise', '0.00', '30000.00', '9', '', '9', '', '18', '5400.00', NULL, '30000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '35400.00', '35400.00', 1, 'INV/23-24/-10004280324', 'INV/23-24/-10004-2024', 1, 1, '20.00', '112410189350469', '2024-03-28 21:07:00', '1f6c12542288ebd472d53cd244366614e0501aa9f1cd70bbc975fbc67da3230c', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTI0MTAxODkzNTA0NjksXCJBY2tEdFwiOlwiMjAyNC0wMy0yOCAyMTowNzowMFwiLFwiSXJuXCI6XCIxZjZjMTI1NDIyODhlYmQ0NzJkNTNjZDI0NDM2NjYxNGUwNTAxYWE5ZjFjZDcwYmJjOTc1ZmJjNjdkYTMyMzBjXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMTAwMDRcIixcIkR0XCI6XCIyOC8wMy8yMDI0XCJ9LFwiU2VsbGVyRHRsc1wiOntcIkdzdGluXCI6XCIyOUFBQkNUMTMzMkwwMDBcIixcIkxnbE5tXCI6XCJNWU9GRklDRSBFUlBcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwMDEsXCJTdGNkXCI6XCIyOVwifSxcIkJ1eWVyRHRsc1wiOntcIkdzdGluXCI6XCIzM0FEWFBUMzI5MU4yWkpcIixcIkxnbE5tXCI6XCJTTUsgSU5EVVNUUklFU1wiLFwiUG9zXCI6XCIzM1wiLFwiQWRkcjFcIjpcIjMvMjI2RCwgTkFEVVBBTEFZQU0gUk9BRFwiLFwiQWRkcjJcIjpcIlBBVFRBTkFNIFBPU1QsT05ESVBVRFVSIChWSUEpXCIsXCJMb2NcIjpcIkNPSU1CQVRPUkVcIixcIlBpblwiOjY0MTAxNCxcIlN0Y2RcIjpcIjMzXCJ9LFwiSXRlbUxpc3RcIjpbe1wiSXRlbU5vXCI6MCxcIlNsTm9cIjpcIjFcIixcIklzU2VydmNcIjpcIk5cIixcIkhzbkNkXCI6XCI4NTAzMDBcIixcIlF0eVwiOjIwLFwiVW5pdFwiOlwiS0dTXCIsXCJVbml0UHJpY2VcIjoxNTAwLFwiVG90QW10XCI6MzAwMDAsXCJEaXNjb3VudFwiOjAsXCJBc3NBbXRcIjozMDAwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6NTQwMCxcIkNnc3RBbXRcIjowLFwiU2dzdEFtdFwiOjAsXCJUb3RJdGVtVmFsXCI6MzU0MDB9XSxcIlZhbER0bHNcIjp7XCJBc3NWYWxcIjozMDAwMC4wMCxcIkNnc3RWYWxcIjowLFwiU2dzdFZhbFwiOjAsXCJJZ3N0VmFsXCI6NTQwMC4wMCxcIk90aENocmdcIjowLFwiUm5kT2ZmQW10XCI6MCxcIlRvdEludlZhbFwiOjM1NDAwfSxcIkFkZGxEb2NEdGxzXCI6W3tcIlVybFwiOlwiaHR0cHM6Ly9laW52LWFwaXNhbmRib3gubmljLmluXCIsXCJEb2NzXCI6XCJUZXN0IERvY1wiLFwiSW5mb1wiOlwiRG9jdW1lbnQgVGVzdFwifV19IiwiaXNzIjoiTklDIFNhbmRib3gifQ.1nkGbCZnotZA8G1Coz79U9y5eeKopp4gWCB-YikH4iJYSNabIH0d-0S4tUq_jYLtAbaViwznmNjsUcMepBoOtfmT1Z5WpfZMJovWmWFLVrq-1NcktqcQ5vtj8j99RzGs3hRDQe9FIJW7aTScUX24h6EtWHUYfpbom5z0HgQRFDRc38dhLswMvNnYjHFDhFqGvg7DeNhrKltfQnhXKPse6hfAwC9g7tdJzYcu1e6vF-BvcMuXhP1kJzWeIe8wggwpmvP-8P9m0ZEMFemHrTfjm4UYf6slZY4eToyuh_4bTQSh1vZ8tDxIKEMCT7oYPRMCcZNmt5NxjkUxcm3ZB7S4tQ', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0xMDAwNFwiLFwiRG9jVHlwXCI6XCJJTlZcIixcIkRvY0R0XCI6XCIyOC8wMy8yMDI0XCIsXCJUb3RJbnZWYWxcIjozNTQwMCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjg1MDMwMFwiLFwiSXJuXCI6XCIxZjZjMTI1NDIyODhlYmQ0NzJkNTNjZDI0NDM2NjYxNGUwNTAxYWE5ZjFjZDcwYmJjOTc1ZmJjNjdkYTMyMzBjXCIsXCJJcm5EdFwiOlwiMjAyNC0wMy0yOCAyMTowNzowMFwifSIsImlzcyI6Ik5JQyBTYW5kYm94In0.WQVPRWHZ8EGpwVn9qgaQIfMY525VXn6Y2gEtlV8ja7nyqbZzcwgUfTpsKtjmOz3xK7luYtTeeJl3lujIl9Jm88NnmQCBcxOIoejGmGHFOWLFl43NvylRaogyBBNNhRN8CG0jwlGYSwlIFw7ojEreD5g43QqTqguyQGzkWhbwsL0DTPK3zccY3jlAER9mrt2UDlRCMchx3cRR2AM9hnhgypE040EorSBByH6kH0_hYGDXKfqoVr5gDkHa0zgY3i8WWgpB9nhAkHt1-OPGCq-6Gxn9Vh7ONuNrsxrgOwnTtw31fn5O-uEhplGmIoyvmCboZc5-dUr-px0QCuc4y4Dppw', 'ACT', '', '', '', '', '', '', 1, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (8, '2024-03-28', '2024-03-28', '', '1970-01-01', 'INV/23-24/-0001', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-03-28', '09:27 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '5', '7500.00', '0', 'percent_wise', '0.00', '7500.00', '9', '', '9', '', '18', '1350.00', NULL, '7500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '0', '8850.00', '0', 0, 'INV/23-24/-0001280324', 'INV/23-24/-0001-2024', 1, 0, '5.00', '112410189369661', '2024-03-29 17:33:00', '9239f6e58c0615497ad6f21d58a6fc56d710f903ad6c73bd47e0398cf551b3ce', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTI0MTAxODkzNjk2NjEsXCJBY2tEdFwiOlwiMjAyNC0wMy0yOSAxNzozMzowMFwiLFwiSXJuXCI6XCI5MjM5ZjZlNThjMDYxNTQ5N2FkNmYyMWQ1OGE2ZmM1NmQ3MTBmOTAzYWQ2YzczYmQ0N2UwMzk4Y2Y1NTFiM2NlXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDAwMVwiLFwiRHRcIjpcIjI4LzAzLzIwMjRcIn0sXCJTZWxsZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiTGdsTm1cIjpcIk1ZT0ZGSUNFIEVSUFwiLFwiQWRkcjFcIjpcIjkxLCBEci4gSmFnYW5hdGhhbiBOYWdhciwgQ2l2aWwgQWVyb2Ryb21lIHBvc3QsIENNQyBvcHBcIixcIkFkZHIyXCI6XCJBdmluYXNoaSBSb2FkLCBIb3BlcyBDb2xsZWdlXCIsXCJMb2NcIjpcIkNvaW1iYXRvcmVcIixcIlBpblwiOjU2MDAwMSxcIlN0Y2RcIjpcIjI5XCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjg1MDMwMFwiLFwiUXR5XCI6NSxcIlVuaXRcIjpcIktHU1wiLFwiVW5pdFByaWNlXCI6MTUwMCxcIlRvdEFtdFwiOjc1MDAsXCJEaXNjb3VudFwiOjAsXCJBc3NBbXRcIjo3NTAwLFwiR3N0UnRcIjoxOCxcIklnc3RBbXRcIjoxMzUwLFwiQ2dzdEFtdFwiOjAsXCJTZ3N0QW10XCI6MCxcIlRvdEl0ZW1WYWxcIjo4ODUwfV0sXCJWYWxEdGxzXCI6e1wiQXNzVmFsXCI6NzUwMC4wMCxcIkNnc3RWYWxcIjowLFwiU2dzdFZhbFwiOjAsXCJJZ3N0VmFsXCI6MTM1MC4wMCxcIk90aENocmdcIjowLFwiUm5kT2ZmQW10XCI6MCxcIlRvdEludlZhbFwiOjg4NTB9LFwiQWRkbERvY0R0bHNcIjpbe1wiVXJsXCI6XCJodHRwczovL2VpbnYtYXBpc2FuZGJveC5uaWMuaW5cIixcIkRvY3NcIjpcIlRlc3QgRG9jXCIsXCJJbmZvXCI6XCJEb2N1bWVudCBUZXN0XCJ9XX0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.RQIBCaMGfY3PBAWn8cYCkzT9JYuyAKh4pA5Vt5sx9MszCPWbYAIn00UmxB30x8Ly81WW1dGNh6wnFY7nWXzBD_67vMy7QUnlXOSOr0C58PdCmc-u_4TPNQUtkDzaT_4Tdi5Zrr0s5EqN4w1xUBs3D6gmRVCZlAtuD4NoP1gyZ8R01xaZBJwfv0dGxvZP3xlsH3aJ2ALRhP_TY50lIGo8GqULnaiLx48nkQWn_K3QM_pD4vCYWz5BpCW6XYiIIHzM2xP_Qmw2XXo9KETMjuLAXDxVrzLpMQEq7_UsqRyqlRL1oBmhxI32z1t-FPifVI_pEfjvdEto3tkCeNHIy8RlzA', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wMDAxXCIsXCJEb2NUeXBcIjpcIklOVlwiLFwiRG9jRHRcIjpcIjI4LzAzLzIwMjRcIixcIlRvdEludlZhbFwiOjg4NTAsXCJJdGVtQ250XCI6MSxcIk1haW5Ic25Db2RlXCI6XCI4NTAzMDBcIixcIklyblwiOlwiOTIzOWY2ZTU4YzA2MTU0OTdhZDZmMjFkNThhNmZjNTZkNzEwZjkwM2FkNmM3M2JkNDdlMDM5OGNmNTUxYjNjZVwiLFwiSXJuRHRcIjpcIjIwMjQtMDMtMjkgMTc6MzM6MDBcIn0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.j4JzEPy45zDko8gljvvmPijtHGKeDicN1Z_yST75eqisNaFn7I7GO_I3Ui1tuTuWK5YKK75g3Lj7SDeRL094hWpBx-z5Srg-H3FSDBSfuyw03cOzRHDToUCpKm9rGG4P--CU-VfYT9T7u_Uqo90t05Y-h6QhoALH1u12fXqGVIWsx6Kp1F5fsfavHYu1VKU0GN8YTaUuYwDBe--4Lw1VFato6-gUN1M2WvpmDI7WjXtxnDKK05wPRtfOTsY8nZPMUiS4ciPCZh5j1UWOKihGKNJopdUbUGdIrcoZCZKxmE2sgWyAkPVM1ZfWB_0SmlYwFcU0oETMyKV0Arc2ONLL1A', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (9, '2024-04-03', '2024-04-03', '', '1970-01-01', 'INV/23-24/-', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-04-03', '07:00 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '01', NULL, 'Air Compressor Motor ', '', 'KGS', '5000', '3', '15000.00', '0', 'percent_wise', '0.00', '15000.00', '9', '1350.00', '9', '1350.00', '18', '', NULL, '15000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '17700.00', '17700.00', 1, 'INV/23-24/-030424', 'INV/23-24/--2024', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (10, '2024-05-03', '2024-05-03', '', '1970-01-01', 'INV/23-24/-1', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-05-03', '02:52 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '01', NULL, 'Air Compressor Motor ', '', 'KGS', '5000', '10', '50000.00', '0', 'percent_wise', '0.00', '50000.00', '9', '', '9', '', '18', '9000.00', NULL, '50000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '59000.00', '59000.00', 1, 'INV/23-24/-1030524', 'INV/23-24/-1-2024', 1, 1, '10.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (11, '2024-05-03', '2024-05-03', '', '1970-01-01', 'INV/23-24/-2', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-05-03', '03:42 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '10', '15000.00', '0', 'percent_wise', '0.00', '15000.00', '9', '1350.00', '9', '1350.00', '18', '2700.00', '17700.00', '17700.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', NULL, '1', '17700.00', '17700.00', 1, 'INV/23-24/-2030524', 'INV/23-24/-2-2024', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (12, '2024-05-29', '2024-05-29', '', '1970-01-01', 'INV/23-24/-3', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-05-29', '12:33 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '10', '15000.00', '0', 'percent_wise', '0.00', '15000.00', '9', '', '9', '', '18', '2700.00', NULL, '15000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '17700.00', '17700.00', 1, 'INV/23-24/-3290524', 'INV/23-24/-3-2024', 1, 1, '10.00', '112410191355342', '2024-05-29 12:33:00', '0ff835a70bc1163f11732d331d2de8e57f723e3e6e3af7fc04ffec5ef37b49f4', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTI0MTAxOTEzNTUzNDIsXCJBY2tEdFwiOlwiMjAyNC0wNS0yOSAxMjozMzowMFwiLFwiSXJuXCI6XCIwZmY4MzVhNzBiYzExNjNmMTE3MzJkMzMxZDJkZThlNTdmNzIzZTNlNmUzYWY3ZmMwNGZmZWM1ZWYzN2I0OWY0XCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tM1wiLFwiRHRcIjpcIjI5LzA1LzIwMjRcIn0sXCJTZWxsZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiTGdsTm1cIjpcIk1ZT0ZGSUNFIEVSUFwiLFwiQWRkcjFcIjpcIjkxLCBEci4gSmFnYW5hdGhhbiBOYWdhciwgQ2l2aWwgQWVyb2Ryb21lIHBvc3QsIENNQyBvcHBcIixcIkFkZHIyXCI6XCJBdmluYXNoaSBSb2FkLCBIb3BlcyBDb2xsZWdlXCIsXCJMb2NcIjpcIkNvaW1iYXRvcmVcIixcIlBpblwiOjU2MDAwMSxcIlN0Y2RcIjpcIjI5XCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjg1MDMwMFwiLFwiUXR5XCI6MTAsXCJVbml0XCI6XCJLR1NcIixcIlVuaXRQcmljZVwiOjE1MDAsXCJUb3RBbXRcIjoxNTAwMCxcIkRpc2NvdW50XCI6MCxcIkFzc0FtdFwiOjE1MDAwLFwiR3N0UnRcIjoxOCxcIklnc3RBbXRcIjoyNzAwLFwiQ2dzdEFtdFwiOjAsXCJTZ3N0QW10XCI6MCxcIlRvdEl0ZW1WYWxcIjoxNzcwMH1dLFwiVmFsRHRsc1wiOntcIkFzc1ZhbFwiOjE1MDAwLjAwLFwiQ2dzdFZhbFwiOjAsXCJTZ3N0VmFsXCI6MCxcIklnc3RWYWxcIjoyNzAwLjAwLFwiT3RoQ2hyZ1wiOjAsXCJSbmRPZmZBbXRcIjowLFwiVG90SW52VmFsXCI6MTc3MDB9LFwiQWRkbERvY0R0bHNcIjpbe1wiVXJsXCI6XCJodHRwczovL2VpbnYtYXBpc2FuZGJveC5uaWMuaW5cIixcIkRvY3NcIjpcIlRlc3QgRG9jXCIsXCJJbmZvXCI6XCJEb2N1bWVudCBUZXN0XCJ9XX0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.yoUuLolV-3CQhqkbdSccCBMrY7E4f0zrPoXYJ59G3W4UkiW9h8c73tzd5lu-SOirjZVFeEk-6I_oROkFXwGxg__mBQuHmqrgl0l6NyyA5EVdFTjx-hEVXPJUZCkr_g3I6GzbtjU4DdKZv8vBBcBn7kuKQZ2Kdzf8-fLEsAitevTK2dv4YHgsyHBW6p655HUMiXb7UvqS--_0wBxJp62PKRccX9s43r_Y941Q4U1ATw_N2JkhG0uA77_v0XHB2atdOmjd6elCrgmZ6zEydKac7prcxj56STxA7Iqd3VnbJ8ILOoc9iCyROIJ4IBzZURXF6H1HFuueOnyRy3r8ue5S5Q', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0zXCIsXCJEb2NUeXBcIjpcIklOVlwiLFwiRG9jRHRcIjpcIjI5LzA1LzIwMjRcIixcIlRvdEludlZhbFwiOjE3NzAwLFwiSXRlbUNudFwiOjEsXCJNYWluSHNuQ29kZVwiOlwiODUwMzAwXCIsXCJJcm5cIjpcIjBmZjgzNWE3MGJjMTE2M2YxMTczMmQzMzFkMmRlOGU1N2Y3MjNlM2U2ZTNhZjdmYzA0ZmZlYzVlZjM3YjQ5ZjRcIixcIklybkR0XCI6XCIyMDI0LTA1LTI5IDEyOjMzOjAwXCJ9IiwiaXNzIjoiTklDIFNhbmRib3gifQ.SmFMbNQYuhGK5rijCIGHYkEDqmiMt9n7SJbs3qwtEWtdp39EOM60zCdAYYjaEhA6lxJB7qg4WHC9CT0-uYNhMzX126iDSdzg84JODh6w4c8npi0YXrJzzAi2rsoXHu9zXaC6HkqDvoPNiwpx6VDc0n08_j4pLjIAfUot9XDiWQGvvEV0uiBRWQyJspSj81ZHkkqkXo42ps5g33BMOdkdaDyrJN36uryk5DkukZI3U7NoG9svtamBZuDcGV8VoiXtgIAYyrw9Bzcdjbclgu5KJEaM2Kqh7IqnMTH8w_ajX9caWmu5ES65XBaG5SeKP3iXJXlxamKSkFlOx46WrJvN9Q', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (13, '2024-05-29', '2024-05-29', '', '1970-01-01', 'INV/23-24/-4', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-05-29', '12:51 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '45', '67500.00', '0', 'percent_wise', '0.00', '67500.00', '9', '', '9', '', '18', '12150.00', NULL, '67500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '79650.00', '79650.00', 1, 'INV/23-24/-4290524', 'INV/23-24/-4-2024', 1, 1, '45.00', '112410191355573', '2024-05-29 12:52:00', 'eaef169178ddc0132c540865d9a890b35682011b3f45d2d334dacca1d2cedac6', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTI0MTAxOTEzNTU1NzMsXCJBY2tEdFwiOlwiMjAyNC0wNS0yOSAxMjo1MjowMFwiLFwiSXJuXCI6XCJlYWVmMTY5MTc4ZGRjMDEzMmM1NDA4NjVkOWE4OTBiMzU2ODIwMTFiM2Y0NWQyZDMzNGRhY2NhMWQyY2VkYWM2XCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tNFwiLFwiRHRcIjpcIjI5LzA1LzIwMjRcIn0sXCJTZWxsZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiTGdsTm1cIjpcIk1ZT0ZGSUNFIEVSUFwiLFwiQWRkcjFcIjpcIjkxLCBEci4gSmFnYW5hdGhhbiBOYWdhciwgQ2l2aWwgQWVyb2Ryb21lIHBvc3QsIENNQyBvcHBcIixcIkFkZHIyXCI6XCJBdmluYXNoaSBSb2FkLCBIb3BlcyBDb2xsZWdlXCIsXCJMb2NcIjpcIkNvaW1iYXRvcmVcIixcIlBpblwiOjU2MDAwMSxcIlN0Y2RcIjpcIjI5XCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIklEUkVBTURFVkVMT1BFUlNcIixcIlBvc1wiOlwiMzNcIixcIkFkZHIxXCI6XCI5MSwgamFnYW5hdGhhbiBuYWdhcixcIixcIkFkZHIyXCI6XCIgY2l2aWwgYWVyb2Ryb21lIFwiLFwiTG9jXCI6XCJDT0lNQkFUT1JFXCIsXCJQaW5cIjo2NDEwMTQsXCJTdGNkXCI6XCIzM1wifSxcIkl0ZW1MaXN0XCI6W3tcIkl0ZW1Ob1wiOjAsXCJTbE5vXCI6XCIxXCIsXCJJc1NlcnZjXCI6XCJOXCIsXCJIc25DZFwiOlwiODUwMzAwXCIsXCJRdHlcIjo0NSxcIlVuaXRcIjpcIktHU1wiLFwiVW5pdFByaWNlXCI6MTUwMCxcIlRvdEFtdFwiOjY3NTAwLFwiRGlzY291bnRcIjowLFwiQXNzQW10XCI6Njc1MDAsXCJHc3RSdFwiOjE4LFwiSWdzdEFtdFwiOjEyMTUwLFwiQ2dzdEFtdFwiOjAsXCJTZ3N0QW10XCI6MCxcIlRvdEl0ZW1WYWxcIjo3OTY1MH1dLFwiVmFsRHRsc1wiOntcIkFzc1ZhbFwiOjY3NTAwLjAwLFwiQ2dzdFZhbFwiOjAsXCJTZ3N0VmFsXCI6MCxcIklnc3RWYWxcIjoxMjE1MC4wMCxcIk90aENocmdcIjowLFwiUm5kT2ZmQW10XCI6MCxcIlRvdEludlZhbFwiOjc5NjUwfSxcIkFkZGxEb2NEdGxzXCI6W3tcIlVybFwiOlwiaHR0cHM6Ly9laW52LWFwaXNhbmRib3gubmljLmluXCIsXCJEb2NzXCI6XCJUZXN0IERvY1wiLFwiSW5mb1wiOlwiRG9jdW1lbnQgVGVzdFwifV19IiwiaXNzIjoiTklDIFNhbmRib3gifQ.llU84NB7mDz-RBLLiVl2kfu9zPYFjHaIC2SrbRceK3SfiXYcJxSeAifoTfuqDrIDfShyqNV-pSdcIzE9E0zclRtTHvBgIvpqLg5VMTXisReF8FSxLS9e77Y-UqpdhNZeOEdwAG8NPlHt2dAZopGXexdqu5tbeTNLFURu8ttrBgMBDFTBNPLrcBUfYDI-8BPLvKLgnamQnrhInhwSmdhpGTaKplCkUgn502VVhxNyLjwLFLtUi6J-z_-y3OJHCDVLiN8zxwJw7JRez1ppgRXrEWxDK6MaGRutHkmEBPA2IJejtsXKvCTNlZZ26KcsvT973T2dn7mUgL3Hy5GXXHvthQ', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly00XCIsXCJEb2NUeXBcIjpcIklOVlwiLFwiRG9jRHRcIjpcIjI5LzA1LzIwMjRcIixcIlRvdEludlZhbFwiOjc5NjUwLFwiSXRlbUNudFwiOjEsXCJNYWluSHNuQ29kZVwiOlwiODUwMzAwXCIsXCJJcm5cIjpcImVhZWYxNjkxNzhkZGMwMTMyYzU0MDg2NWQ5YTg5MGIzNTY4MjAxMWIzZjQ1ZDJkMzM0ZGFjY2ExZDJjZWRhYzZcIixcIklybkR0XCI6XCIyMDI0LTA1LTI5IDEyOjUyOjAwXCJ9IiwiaXNzIjoiTklDIFNhbmRib3gifQ.WT01zxxwhsdxYH3pM3JnHWMqyf3T4j23VvTOWMttQM07b1yzmqfX3cENmxR18CEu45lBtaIm2hbiS6eYJFoQCnJ4h7yZiAilye6ZTLOWrO9975luxqGLLFb1bL79M6uQEx9ins0zVwrmyT5SO7ITHmGjlMCAzUOEcqUsZbUbWRkZEQ_rFq34p53HvFJek081pyUSVgwaw1IDdn2ddmxMxFbxAbo-BC36Jy9Wug7YYR_f_x0FOdYpf76Ww3wSphvgr4nORHYLlbaqLUwIZ2ncVky4OjIXSGG07Q-v2cSNpwpAbXsJg2TuN0AzMxbUIbEU04qgUVZZSXINKGMW6h1NBA', 'ACT', '', '', '', '', '', '', 1, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (14, '2024-07-01', '2024-07-01', '', '1970-01-01', 'INV/23-24/-5', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-07-01', '06:17 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '01', NULL, 'Air Compressor Motor ', '', 'KGS', '5000', '3', '15000.00', '0', 'percent_wise', '0.00', '15000.00', '9', '', '9', '', '18', '2700.00', NULL, '15000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '17700.00', '17700.00', 1, 'INV/23-24/-5010724', 'INV/23-24/-5-2024', 1, 1, '3.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 1);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (15, '2024-07-01', '2024-07-01', '', '1970-01-01', 'INV/23-24/-6', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 13, 'Idreamdevelopers', 'Hopes, peelamedu, cbe, Tamil Nadu', NULL, NULL, '', '2024-07-01', '06:47 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '01', NULL, 'Air Compressor Motor ', '', 'KGS', '5000', '10', '50000.00', '0', 'percent_wise', '0.00', '50000.00', '9', '4500.00', '9', '4500.00', '18', '', NULL, '50000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '59000.00', '59000.00', 1, 'INV/23-24/-6010724', 'INV/23-24/-6-2024', 1, 1, '10.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (16, '2024-07-03', '2024-07-03', '', '1970-01-01', 'INV/23-24/-7', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 15, 'GRD', 'CBE, CBE, CBE, Tamil Nadu', NULL, NULL, '', '2024-07-03', '10:55 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '124', NULL, 'AC', '12254,34555,677,', 'NOS', '10000', '10', '100000.00', '0', 'percent_wise', '0.00', '100000.00', '9', '9000.00', '9', '9000.00', '18', '', NULL, '100000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '118000.00', '118000.00', 1, 'INV/23-24/-7030724', 'INV/23-24/-7-2024', 1, 1, '10.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (17, '2024-07-03', '2024-07-03', '', '1970-01-01', 'INV/23-24/-8', NULL, 'P001', NULL, 'P001', 'Tax Invoice', 'Against PO', '', 15, 'GRD', 'CBE, CBE, CBE, Tamil Nadu', NULL, NULL, '', '2024-07-03', '11:01 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, '2', '124', '', 'AC', '1224', 'NOS', '1000', '5', '5000.00', '0', 'percent_wise', NULL, '5000.00', '9', '450.00', '9', '450.00', '18', '', NULL, '5000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '5900.00', '5900.00', 1, 'INV/23-24/-8030724', 'INV/23-24/-8-2024', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (18, '2024-07-03', '2024-07-03', '', '1970-01-01', 'INV/23-24/-9', 'SDC/23-24/-006', NULL, NULL, NULL, 'Tax Invoice', 'Against DC', '', 15, 'GRD', 'CBE, CBE, CBE, Tamil Nadu', NULL, NULL, '', '2024-07-03', '11:10 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', 'SDC/23-24/-006', '6', '10', '124', NULL, 'AC', '', 'NOS', '1000', '3', '3000.00', '0', 'percent_wise', '', '3000.00', '9', '270.00', '9', '270.00', '18', '', '3000.00', '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '3540.00', 1, 'INV/23-24/-9030724', 'INV/23-24/-9-2024', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (19, '2024-07-31', '2024-07-31', '', '1970-01-01', 'INV/23-24/-10', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-07-31', '04:22 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '01||850300||1002', NULL, 'Air Compressor Motor ||1080R2-2PM 70MM CLEATED STATOR||drilling machine', '||||', 'KGS||KGS||KGS', '5000||1500||1500', '2||3||4', '10000.00||4500.00||6000.00', '0||0||0', 'percent_wise', '0.00||0.00||0.00', '10000.00||4500.00||6000.00', '9', '', '9', '', '18', '3690.00', NULL, '20500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1||1', '24190.00', '0', 0, 'INV/23-24/-10310724', 'INV/23-24/-10-2024', 1, 1, '9.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (20, '2024-08-03', '2024-08-03', '', '1970-01-01', 'INV/23-24/-11', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-08-03', '10:33 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '135.00', '9', '135.00', '18', '270.00', '1770.00', '1770.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-11030824', 'INV/23-24/-11-2024', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (21, '2024-08-20', '2024-08-20', '', '1970-01-01', 'INV/23-24/-12', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 13, 'Idreamdevelopers', 'Hopes, peelamedu, cbe, Tamil Nadu', NULL, NULL, '', '2024-08-20', '02:35 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '01', NULL, 'Air Compressor Motor ', '', 'KGS', '5000', '1', '5000.00', '0', 'percent_wise', '0.00', '5000.00', '9', '450.00', '9', '450.00', '18', '', NULL, '5000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '5900.00', '5900.00', 1, 'INV/23-24/-12200824', 'INV/23-24/-12-2024', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 1);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (22, '2024-08-21', '2024-08-21', '1', '2024-08-16', 'INV/23-24/-13', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-08-21', '12:40 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '1002', NULL, 'drilling machine', '', 'KGS', '1500', '2', '3000.00', '0', 'percent_wise', '0.00', '3000.00', '9', '', '9', '', '18', '540.00', NULL, '3000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '3540.00', '3540.00', 1, 'INV/23-24/-13210824', 'INV/23-24/-13-2024', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 1);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (23, '2024-08-21', '2024-08-21', '1', '2024-08-21', 'INV/23-24/-14', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-08-21', '12:44 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '1002', NULL, 'drilling machine', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-14210824', 'INV/23-24/-14-2024', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (24, '2024-08-21', '2024-08-21', '', '1970-01-01', 'INV/23-24/-15', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-08-21', '01:24 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '01', NULL, 'Air Compressor Motor ', '', 'KGS', '5000', '1', '5000.00', '0', 'percent_wise', '0.00', '5000.00', '9', '', '9', '', '18', '936.00', NULL, '5000.00', '100', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '100', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '6136.00', '6136.00', 1, 'INV/23-24/-15210824', 'INV/23-24/-15-2024', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (25, '2024-08-21', '2024-08-21', '', '1970-01-01', 'INV/23-24/-16', 'SDC/23-24/-008', NULL, NULL, NULL, 'Tax Invoice', 'Against DC', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-08-21', '01:32 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', 'SDC/23-24/-008', '8', '12', '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '20', '30000.00', '0', 'percent_wise', '', '30000.00', '9', '', '9', '', '18', '5400.00', '30000.00', '30000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '35400.00', '35400.00', 1, 'INV/23-24/-16210824', 'INV/23-24/-16-2024', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (26, '2024-08-24', '2024-08-23', '', '1970-01-01', 'INV/23-24/-17', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 17, 'intra customer demo', 'idreamdevelopers, idreamdevelopers, coimpatore, Tamil Nadu', NULL, NULL, '', '2024-08-23', '03:22 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '9908', NULL, 'demo', '', 'UNIT', '100', '1008', '100800.00', '0', 'percent_wise', '0.00', '100800.00', '15', '15120.00', '15', '15120.00', '30', '', NULL, '100800.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '131040.00', '131040.00', 1, 'INV/23-24/-17230824', 'INV/23-24/-17-2024', 1, 1, '100.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 1);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (27, '2024-08-24', '2024-08-24', '', '1970-01-01', 'INV/23-24/-18', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-08-24', '04:21 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '01', NULL, 'Air Compressor Motor ', '', 'KGS', '5000', '-3', '-15000.00', '0', 'percent_wise', '0.00', '-15000.00', '9', '', '9', '', '18', '-2700.00', NULL, '-15000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '-17700.00', '-17700.00', 1, 'INV/23-24/-18240824', 'INV/23-24/-18-2024', 1, 1, '-6.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (28, '2024-08-24', '2024-08-24', '', '1970-01-01', 'INV/23-24/-19', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-08-24', '04:25 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '124', NULL, 'AC', '', 'NOS', '1000', '7', '7000.00', '0', 'percent_wise', '0.00', '7000.00', '9', '', '9', '', '18', '1260.00', NULL, '7000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '8260.00', '8260.00', 1, 'INV/23-24/-19240824', 'INV/23-24/-19-2024', 1, 1, '14.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (29, '2024-08-24', '2024-08-24', '', '1970-01-01', 'INV/23-24/-20', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-08-24', '04:27 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '124', NULL, 'AC', '', 'NOS', '1000', '8', '8000.00', '0', 'percent_wise', '0.00', '8000.00', '9', '', '9', '', '18', '1440.00', NULL, '8000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '9440.00', '9440.00', 1, 'INV/23-24/-20240824', 'INV/23-24/-20-2024', 1, 1, '18.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (30, '2024-08-24', '2024-08-24', '', '1970-01-01', 'INV/23-24/-21', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 6, 'HANDY THINK', '1/504, , NEELAMBUR, COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-08-24', '04:30 PM', '', '1', '', NULL, NULL, NULL, 'Intra customer', 'Intra customer', NULL, NULL, NULL, NULL, NULL, NULL, '002', NULL, 'BLACK PAINT', '', 'lITRE', '1050', '21', '22050.00', '0', 'percent_wise', '0.00', '22050.00', '9', '', '9', '', '18', '', NULL, '22050.00', '15', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '25', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '22050.00', '22050.00', 1, 'INV/23-24/-21240824', 'INV/23-24/-21-2024', 1, 1, '25.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (31, '2024-08-24', '2024-08-24', '', '1970-01-01', 'INV/23-24/-22', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 13, 'Idreamdevelopers', 'Hopes, peelamedu, cbe, Tamil Nadu', NULL, NULL, '', '2024-08-24', '04:43 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '002', NULL, 'BLACK PAINT', '', 'lITRE', '950', '20', '19000.00', '0', 'percent_wise', '0.00', '19000.00', '9', '1713.60', '9', '1713.60', '18', '', NULL, '19000.00', '015', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '25', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '22467.20', '22467.20', 1, 'INV/23-24/-22240824', 'INV/23-24/-22-2024', 1, 1, '25.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (32, '2024-09-04', '2024-09-04', '21', '2024-09-05', 'INV/23-24/-23', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 19, 'DD & co', '56,East Street,, SS kottai,madurai, madurai, Tamil Nadu', NULL, NULL, '', '2024-09-04', '03:11 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '32123212', NULL, 'Oversized Tshirt', '', 'piece', '125', '500', '62500.00', '0', 'percent_wise', '0.00', '62500.00', '9', '5805.00', '9', '5805.00', '18', '', NULL, '62500.00', '1000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '76110.00', '76110.00', 1, 'INV/23-24/-23040924', 'INV/23-24/-23-2024', 1, 1, '1500.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (33, '2024-11-25', '2024-11-25', '', '1970-01-01', 'INV/23-24/-24', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 15, 'GRD', 'CBE, CBE, CBE, Tamil Nadu', NULL, NULL, '', '2024-11-25', '04:16 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '7222||01', NULL, 'SHAFT||Air Compressor Motor ', '||', 'NOS||KGS', '1500||5000', '10||10', '15000.00||50000.00', '0||0', 'percent_wise', '0.00||0.00', '15000.00||50000.00', '9||9', '1350.00||4500.00', '9||9', '1350.00||4500.00', '18||18', '2700.00||9000.00', '17700.00||59000.00', '76920.00', '100', '5', '5.00', '5', '5.00', '10', '10.00', '110.00', '100', '5', '5.00', '5', '5.00', '10', '10.00', '110.00', '0', NULL, '1||1', '76920.00', '76920.00', 1, 'INV/23-24/-24251124', 'INV/23-24/-24-2024', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (34, '2024-11-25', '2024-11-25', '', '1970-01-01', 'INV/23-24/-25', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2024-11-25', '05:10 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7222', NULL, 'SHAFT', '', 'NOS', '1500', '10', '15000.00', '5', 'percent_wise', '750.00', '14250.00', '9', '1282.50', '9', '1282.50', '18', '2565.00', '16815.00', '16815.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', NULL, '1', '16815.00', '16815.00', 1, 'INV/23-24/-25251124', 'INV/23-24/-25-2024', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (35, '2025-01-21', '2025-01-21', '', '1970-01-01', 'INV/23-24/-26', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 8, 'JAI SHREE SAI ENGINEERING', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST, COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-01-21', '11:10 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '850300||850300', NULL, '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM 70MM CLEATED STATOR', '||', 'KGS||KGS', '1500||1500', '1||1', '1500.00||1500.00', '0||0', 'percent_wise', '0.00||0.00', '1500.00||1500.00', '9||9', '135.00||135.00', '9||9', '135.00||135.00', '18||18', '270.00||270.00', '1770.00||1770.00', '3540.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', NULL, '1||1', '3540.00', '3540.00', 1, 'INV/23-24/-26210125', 'INV/23-24/-26-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (36, '2025-01-27', '2025-01-27', '', '1970-01-01', 'INV/23-24/-27', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 12, 'Jayaprakash', 'jaganathan nagar, Coimbatore, coimabtore, Tamil Nadu', NULL, NULL, '', '2025-01-27', '11:09 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '01', NULL, 'Air Compressor Motor ', '', 'KGS', '5000', '2', '10000.00', '0', 'percent_wise', '0.00', '10000.00', '9', '900.00', '9', '900.00', '18', '1800.00', '11800.00', '13000.00', '200', '100', '200.00', '100', '200.00', '200', '400.00', '600.00', '200', '10', '200.00', '100', '200.00', '200', '400.00', '600.00', '0', NULL, '1', '13000.00', '13000.00', 1, 'INV/23-24/-27270125', 'INV/23-24/-27-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (37, '2025-02-06', '2025-02-06', '', '1970-01-01', 'INV/23-24/-28', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-02-06', '11:00 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '01', NULL, 'Air Compressor Motor ', '', 'KGS', '5000', '5', '25000.00', '0', 'percent_wise', '0.00', '25000.00', '9', '', '9', '', '18', '4500.00', NULL, '25000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '29500.00', '29500.00', 1, 'INV/23-24/-28060225', 'INV/23-24/-28-2025', 1, 1, '9993.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (38, '2025-02-06', '2025-02-06', '', '1970-01-01', 'INV/23-24/-29', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 6, 'HANDY THINK', '1/504, , NEELAMBUR, COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-02-06', '11:01 AM', 'IDREAMDEVELOPERS', '1', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, NULL, 'Inter customer', 'Inter customer', NULL, NULL, NULL, NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '11', '16500.00', '0', 'percent_wise', '0.00', '16500.00', '9', '', '9', '', '18', '', NULL, '16500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '16500.00', '16500.00', 1, 'INV/23-24/-29060225', 'INV/23-24/-29-2025', 1, 1, '5.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (39, '2025-02-06', '2025-02-06', '', '1970-01-01', 'INV/23-24/-30', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-02-06', '11:18 AM', 'HANDY THINK', '6', '1/504, , NEELAMBUR, COIMBATORE, Tamil Nadu', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '10', '15000.00', '0', 'percent_wise', '0.00', '15000.00', '9', '', '9', '', '18', '2700.00', NULL, '15000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '17700.00', '17700.00', 1, 'INV/23-24/-30060225', 'INV/23-24/-30-2025', 1, 1, '5.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (40, '2025-02-06', '2025-02-06', '', '1970-01-01', 'INV/23-24/-31', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 6, 'HANDY THINK', '1/504, , NEELAMBUR, COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-02-06', '11:35 AM', 'IDREAMDEVELOPERS', '1', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '10', '20000.00', '0', 'percent_wise', '0.00', '20000.00', '9', '1800.00', '9', '1800.00', '18', '', NULL, '20000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '23600.00', '23600.00', 1, 'INV/23-24/-31060225', 'INV/23-24/-31-2025', 1, 1, '10003.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (41, '2025-02-06', '2025-02-06', '', '1970-01-01', 'INV/23-24/-32', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-02-06', '03:31 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '99872323', NULL, 'SOLAR LIGHT 3OOW', '', 'piece', '12500', '18', '200892.86', '0', 'percent_wise', '0.00', '225000.00', '6', '12053.57', '6', '12053.57', '12', '24107.14', '225000.00', '225000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', NULL, '1', '225000.00', '225000.00', 1, 'INV/23-24/-32060225', 'INV/23-24/-32-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (42, '2025-02-23', '2025-02-23', '', '1970-01-01', 'INV/23-24/-33', NULL, 'P002', NULL, 'P002||P002', 'Tax Invoice', 'Against PO', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-02-23', '12:21 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, '3||4', '850300||7204', '||', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', 'KGS||KGS', '1500||2000', '5||5', '7500.00||10000.00', '0||0', 'percent_wise', NULL, '7500.00||10000.00', '9', '', '9', '', '18', '3150.00', NULL, '17500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '20650.00', '20650.00', 1, 'INV/23-24/-33230225', 'INV/23-24/-33-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (43, '2025-02-25', '2025-02-25', '', '1970-01-01', 'INV/23-24/-34', NULL, 'P003', NULL, 'P003||P003', 'Tax Invoice', 'Against PO', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-02-25', '12:38 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, '5||6', '850300||7204', '||', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', 'KGS||KGS', '1500||2000', '5||5', '7500.00||10000.00', '0||0', 'percent_wise', NULL, '7500.00||10000.00', '9', '', '9', '', '18', '3150.00', NULL, '17500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '20650.00', '20650.00', 1, 'INV/23-24/-34250225', 'INV/23-24/-34-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (44, '2025-02-25', '2025-02-25', '', '1970-01-01', 'INV/23-24/-35', NULL, 'P||P002', NULL, 'P||P002||P002', 'Tax Invoice', 'Against PO', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-02-25', '01:05 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, '1||3||4', '850300||850300||7204', '||||', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||||', 'KGS||KGS||KGS', '1500||1500||2000', '0||0||0', '0.00||0.00||0.00', '0||0||0', 'percent_wise', NULL, '0.00||0.00||0.00', '9', '', '9', '', '18', '0.00', NULL, '0.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1||1', '0.00', '0.00', 1, 'INV/23-24/-35250225', 'INV/23-24/-35-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (45, '2025-02-25', '2025-02-25', '', '1970-01-01', 'INV/23-24/-36', NULL, 'P002||P003', NULL, 'P002||P002||P003||P003', 'Tax Invoice', 'Against PO', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-02-25', '01:06 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, '3||4||5||6', '850300||7204||850300||7204', '||||||', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG||1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||||||', 'KGS||KGS||KGS||KGS', '1500||2000||1500||2000', '04||05||03||02', '6000.00||10000.00||4500.00||4000.00', '0||0||0||0', 'percent_wise', NULL, '6000.00||10000.00||4500.00||4000.00', '9', '', '9', '', '18', '4410.00', NULL, '24500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1||1||1', '28910.00', '28910.00', 1, 'INV/23-24/-36250225', 'INV/23-24/-36-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (46, '2025-02-25', '2025-02-25', '', '1970-01-01', 'INV/23-24/-37', NULL, 'P002', NULL, 'P002', 'Labour Bill', 'Against PO', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-02-25', '01:17 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, '3', '850300', '', '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '01', '1500.00', '0', 'percent_wise', NULL, '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-37250225', 'INV/23-24/-37-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (47, '2025-02-25', '2025-02-25', '', '1970-01-01', 'INV/23-24/-38', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-02-25', '03:04 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '1234556', NULL, '10886', '', 'NOS', '22', '5', '110.00', '0', 'percent_wise', '0.00', '110.00', '9', '', '9', '', '18', '19.80', NULL, '110.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '129.80', '129.80', 1, 'INV/23-24/-38250225', 'INV/23-24/-38-2025', 1, 1, '505.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (48, '2025-02-25', '2025-02-25', '', '1970-01-01', 'INV/23-24/-39', NULL, 'P004', NULL, 'P004', 'Tax Invoice', 'Against PO', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-02-25', '03:05 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, '7', '1234556', '', '10886', '', 'NOS', '22', '10', '220.00', '0', 'percent_wise', NULL, '220.00', '9', '', '9', '', '18', '39.60', NULL, '220.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '259.60', '259.60', 1, 'INV/23-24/-39250225', 'INV/23-24/-39-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (49, '2025-02-26', '2025-02-26', '', '1970-01-01', 'INV/23-24/-40', 'SDC/23-24/-004', NULL, NULL, NULL, 'Tax Invoice', 'Against DC', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-02-26', '07:53 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', 'SDC/23-24/-004', '4', '8', '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '05', '10000.00', '0', 'percent_wise', '', '10000.00', '9', '', '9', '', '18', '1800.00', '10000.00', '10000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '11800.00', '11800.00', 1, 'INV/23-24/-40260225', 'INV/23-24/-40-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (50, '2025-02-26', '2025-02-26', '', '1970-01-01', 'INV/23-24/-41', NULL, 'P005', NULL, 'P005', 'Tax Invoice', 'Against PO', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-02-26', '08:00 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, '8', '7204', '', '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '85', '170000.00', '0', 'percent_wise', NULL, '170000.00', '9', '', '9', '', '18', '30600.00', NULL, '170000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '200600.00', '200600.00', 1, 'INV/23-24/-41260225', 'INV/23-24/-41-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (51, '2025-02-27', '2025-02-27', '6556', '2025-02-27', 'INV/23-24/-42', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 12, 'Jayaprakash', 'jaganathan nagar, Coimbatore, coimabtore, Tamil Nadu', NULL, NULL, 'TN67', '2025-02-27', '11:10 AM', 'JAI SHREE SAI ENGINEERING', '8', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST, COIMBATORE, Tamil Nadu', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '654654||654654', NULL, 'asus512gb||asus512gb', '||', 'piece||piece', '100000||100000', '2||2', '200000.00||200000.00', '10||10', 'percent_wise', '20000.00||20000.00', '180000.00||180000.00', '9', '', '9', '', '9', '32400.00', NULL, '360000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '392400.00', '392400.00', 1, 'INV/23-24/-42270225', 'INV/23-24/-42-2025', 1, 1, '4.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (52, '2025-02-27', '2025-02-27', '', '1970-01-01', 'INV/23-24/-43', 'SDC/23-24/-010', NULL, NULL, NULL, 'Tax Invoice', 'Against DC', '', 12, 'Jayaprakash', 'jaganathan nagar, Coimbatore, coimabtore, Tamil Nadu', NULL, NULL, '', '2025-02-27', '12:09 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', 'SDC/23-24/-010', '11', '16', '654654', NULL, 'asus512gb', 'laptop', 'piece', '100000', '5', '500000.00', '0', 'percent_wise', '', '500000.00', '9', '', '9', '', '18', '90000.00', '500000.00', '500000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '590000.00', '590000.00', 1, 'INV/23-24/-43270225', 'INV/23-24/-43-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (53, '2025-02-27', '2025-02-27', '', '1970-01-01', 'INV/23-24/-44', 'SDC/23-24/-010', NULL, NULL, NULL, 'Tax Invoice', 'Against DC', '', 12, 'Jayaprakash', 'jaganathan nagar, Coimbatore, coimabtore, Tamil Nadu', NULL, NULL, '', '2025-02-27', '12:18 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', 'SDC/23-24/-010', '11', '16', '654654', NULL, 'asus512gb', 'laptop', 'piece', '100000', '5', '500000.00', '0', 'percent_wise', '', '500000.00', '9', '', '9', '', '18', '90000.00', '500000.00', '500000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '590000.00', '590000.00', 1, 'INV/23-24/-44270225', 'INV/23-24/-44-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (54, '2025-02-27', '2025-02-27', '6556', '2025-02-27', 'INV/23-24/-45', 'SDC/23-24/-011', NULL, NULL, NULL, 'Tax Invoice', 'Against DC', '', 12, 'Jayaprakash', 'jaganathan nagar, Coimbatore, coimabtore, Tamil Nadu', NULL, NULL, 'TN67', '2025-02-27', '12:20 PM', 'JAI SHREE SAI ENGINEERING', '8', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST, COIMBATORE, Tamil Nadu', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', 'SDC/23-24/-011', '12', '17', '654654', NULL, 'asus512gb', 'laptop', 'piece', '100000', '10', '1000000.00', '0', 'percent_wise', '', '1000000.00', '9', '', '9', '', '18', '180000.00', '1000000.00', '1000000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1180000.00', '1180000.00', 1, 'INV/23-24/-45270225', 'INV/23-24/-45-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (55, '2025-02-27', '2025-02-27', '6556', '2025-02-27', 'INV/23-24/-46', 'SDC/23-24/-012', NULL, NULL, NULL, 'Tax Invoice', 'Against DC', '', 11, 'shivamobiles', 'avanshi road annur, annur, coimbatore, Tamil Nadu', NULL, NULL, 'TN67', '2025-02-27', '12:37 PM', 'JAI SHREE SAI ENGINEERING', '8', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST, COIMBATORE, Tamil Nadu', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', 'SDC/23-24/-012', '13', '18', '02', NULL, 'Metal Stamping', '', 'KGS', '1000', '25', '25000.00', '0', 'percent_wise', '', '25000.00', '9', '', '9', '', '18', '4500.00', '25000.00', '25000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '29500.00', '29500.00', 1, 'INV/23-24/-46270225', 'INV/23-24/-46-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (56, '2025-02-27', '2025-02-27', '6556', '2025-02-27', 'INV/23-24/-47', 'SDC/23-24/-012', NULL, NULL, NULL, 'Tax Invoice', 'Against DC', '', 11, 'shivamobiles', 'avanshi road annur, annur, coimbatore, Tamil Nadu', NULL, NULL, 'TN67', '2025-02-27', '12:37 PM', 'JAI SHREE SAI ENGINEERING', '8', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST, COIMBATORE, Tamil Nadu', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', 'SDC/23-24/-012', '13', '18', '02', NULL, 'Metal Stamping', '', 'KGS', '1000', '25', '25000.00', '0', 'percent_wise', '', '25000.00', '9', '', '9', '', '18', '4500.00', '25000.00', '25000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '29500.00', '29500.00', 1, 'INV/23-24/-46270225', 'INV/23-24/-46-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (57, '2025-02-27', '2025-02-27', '6556', '2025-02-27', 'INV/23-24/-48', 'SDC/23-24/-013', NULL, NULL, NULL, 'Tax Invoice', 'Against DC', '', 11, 'shivamobiles', 'avanshi road annur, annur, coimbatore, Tamil Nadu', NULL, NULL, '', '2025-02-27', '12:50 PM', 'JAI SHREE SAI ENGINEERING', '8', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST, COIMBATORE, Tamil Nadu', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', 'SDC/23-24/-013', '14', '19', '02', NULL, 'Metal Stamping', '', 'KGS', '1000', '25', '25000.00', '0', 'percent_wise', '', '25000.00', '9', '', '9', '', '18', '4500.00', '25000.00', '25000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '29500.00', '29500.00', 1, 'INV/23-24/-48270225', 'INV/23-24/-48-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (58, '2025-02-27', '2025-02-27', '6556', '2025-02-27', 'INV/23-24/-49', 'SDC/23-24/-014', NULL, NULL, NULL, 'Tax Invoice', 'Against DC', '', 12, 'Jayaprakash', 'jaganathan nagar, Coimbatore, coimabtore, Tamil Nadu', NULL, NULL, 'TN67', '2025-02-27', '03:57 PM', 'JAI SHREE SAI ENGINEERING', '8', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST, COIMBATORE, Tamil Nadu', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', 'SDC/23-24/-014||SDC/23-24/-014||SDC/23-24/-014', '15', '20||21||22', '654654||01||02', NULL, 'asus512gb||Air Compressor Motor ||Metal Stamping', '||||', 'piece||KGS||KGS', '100000||5000||1000', '25||25||25', '2500000.00||125000.00||25000.00', '0||0||0', 'percent_wise', '||||', '2500000.00||125000.00||25000.00', '9', '', '9', '', '18', '477000.00', '2500000.00||125000.00||25000.00', '2650000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1||1', '3127000.00', '3127000.00', 1, 'INV/23-24/-49270225', 'INV/23-24/-49-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (59, '2025-02-27', '2025-02-27', '6556', '2025-02-27', 'INV/23-24/-50', 'SDC/23-24/-015', NULL, NULL, NULL, 'Tax Invoice', 'Against DC', '', 12, 'Jayaprakash', 'jaganathan nagar, Coimbatore, coimabtore, Tamil Nadu', NULL, NULL, 'TN67', '2025-02-27', '04:11 PM', 'JAI SHREE SAI ENGINEERING', '8', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST, COIMBATORE, Tamil Nadu', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', 'SDC/23-24/-015||SDC/23-24/-015||SDC/23-24/-015', '16', '23||24||25', '654654||01||02', NULL, 'asus512gb||Air Compressor Motor ||Metal Stamping', '||||', 'piece||KGS||KGS', '100000||5000||1000', '25||25||25', '2500000.00||125000.00||25000.00', '0||0||0', 'percent_wise', '||||', '2500000.00||125000.00||25000.00', '9', '', '9', '', '18', '477000.00', '2500000.00||125000.00||25000.00', '2650000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1||1', '3127000.00', '3127000.00', 1, 'INV/23-24/-50270225', 'INV/23-24/-50-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (60, '2025-02-27', '2025-02-27', '', '1970-01-01', 'INV/23-24/-51', 'SDC/23-24/-018', NULL, NULL, NULL, 'Tax Invoice', 'Against DC', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-02-27', '05:44 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', 'SDC/23-24/-018', '19', '28', '0', NULL, '1080R2-2PM STATOR STAMPING NEW', '', 'KGS', '100', '0200', '20000.00', '0', 'percent_wise', '', '20000.00', '9', '', '9', '', '18', '3600.00', '20000.00', '20000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '23600.00', '23600.00', 1, 'INV/23-24/-51270225', 'INV/23-24/-51-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (61, '2025-02-27', '2025-02-27', '', '1970-01-01', 'INV/23-24/-52', NULL, 'P003', NULL, 'P003||P003', 'Tax Invoice', 'Against PO', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-02-27', '05:49 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, '5||6', '850300||7204', '||', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', 'KGS||KGS', '1500||2000', '01||01', '1500.00||2000.00', '0||0', 'percent_wise', NULL, '1500.00||2000.00', '9', '', '9', '', '18', '630.00', NULL, '3500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '4130.00', '4130.00', 1, 'INV/23-24/-52270225', 'INV/23-24/-52-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (62, '2025-02-27', '2025-02-27', '', '1970-01-01', 'INV/23-24/-53', NULL, 'P', NULL, 'P', 'Tax Invoice', 'Against PO', '', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, '', '2025-02-27', '06:02 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, '1', '850300', '', '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '01', '1500.00', '0', 'percent_wise', NULL, '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-53270225', 'INV/23-24/-53-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);


#
# TABLE STRUCTURE FOR: invoice_party_statement
#

DROP TABLE IF EXISTS `invoice_party_statement`;

CREATE TABLE `invoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '-', '-', NULL, '2025-03-01', 'INV/23-24/-0001', 21, 'VRN ENGINEERING', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2025-03-01', '2025-03-01', '8850.00', '-', '-', '', '', '-', '-', NULL, '8850', '-', '-', '-', '-', '8850.00', '-', '8850.00', NULL, NULL, 'INV/23-24/-0001-2025', 'INV/23-24/-0001010325', '1');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '-', '-', NULL, '2025-03-03', 'INV/23-24/-0002', 22, 'thennarasdu', '', '', '', 'daikin cassette ac||daikin cassette ac', '||', '', '', NULL, NULL, '', '', '1', '2025-03-03', '2025-03-03', '531000.00', '-', '-', '', '', '-', '-', NULL, '531000', '-', '-', '-', '-', '531000.00', '-', '531000.00', NULL, NULL, 'INV/23-24/-0002-2025', 'INV/23-24/-0002030325', '2');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (4, '-', '-', NULL, '2025-03-11', 'INV/23-24/-0003', 12, 'Jayaprakash', '', '', '', 'asus512gb', '', '', '', NULL, NULL, '', '', '1', '2025-03-11', '2025-03-11', '25000.00', '-', '-', '', '', '-', '-', NULL, '9057830', '-', '-', '-', '-', '25000.00', '-', '25000.00', NULL, NULL, 'INV/23-24/-0003-2025', 'INV/23-24/-0003110325', '4');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (5, '-', '-', NULL, '2025-04-03', 'INV/25-26/-001', 21, 'VRN ENGINEERING', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2025-04-03', '2025-04-03', '11800.00', '-', '-', '', '', '-', '-', NULL, '20650', '-', '-', '-', '-', '11800.00', '-', '11800.00', NULL, NULL, 'INV/25-26/-001-2025', 'INV/25-26/-001030425', '5');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (6, '-', '-', NULL, '2025-04-03', 'INV/25-26/-002', 24, 'Idream Developers new', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2025-04-03', '2025-04-03', '17700.00', '-', '-', '', '', '-', '-', NULL, '17700', '-', '-', '-', '-', '17700.00', '-', '17700.00', NULL, NULL, 'INV/25-26/-002-2025', 'INV/25-26/-002030425', '6');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (7, '-', '-', NULL, '2025-04-03', 'INV/25-26/-003', 24, 'Idream Developers new', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2025-04-03', '2025-04-03', '8850.00', '-', '-', '', '', '-', '-', NULL, '26550', '-', '-', '-', '-', '8850.00', '-', '8850.00', NULL, NULL, 'INV/25-26/-003-2025', 'INV/25-26/-003030425', '7');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (8, '-', '-', NULL, '2025-04-03', 'INV/25-26/-004', 24, 'Idream Developers new', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', '', '', NULL, NULL, '', '', '1', '2025-04-03', '2025-04-03', '20650.00', '-', '-', '', '', '-', '-', NULL, '47200', '-', '-', '-', '-', '20650.00', '-', '20650.00', NULL, NULL, 'INV/25-26/-004-2025', 'INV/25-26/-004030425', '8');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (12, '-', '-', NULL, '2025-04-25', 'INV/25-26/-005', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2025-04-25', '2025-04-25', '8850.00', '-', '-', '', '', '-', '-', NULL, '-22650.01', '-', '-', '-', '-', '8850.00', '-', '8850.00', NULL, NULL, 'INV/25-26/-005-2025', 'INV/25-26/-005250425', '12');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (13, 'V/23-24/-001', '', NULL, '2025-04-25', '-', 0, 'IDREAMDEVELOPERS', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2025-04-25', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '-40350.01', NULL, NULL, NULL, 'Cash', NULL, '8850', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (17, '-', '-', NULL, '2025-05-07', 'INV/25-26/-006', 24, 'Idream Developers new', '', '', '', 'DISPLAY BOARD (12\" x 14\" x 3mm)', '', '', '', NULL, NULL, '', '', '1', '2025-05-07', '2025-05-07', '135700.00', '-', '-', '', '', '-', '-', NULL, '182900', '-', '-', '-', '-', '135700.00', '-', '135700.00', NULL, NULL, NULL, NULL, '13');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (18, '-', '-', NULL, '2025-05-14', 'INV/25-26/-007', 24, 'Idream Developers new', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2025-05-14', '2025-05-14', '8850.00', '-', '-', '', '', '-', '-', NULL, '191750', '-', '-', '-', '-', '8850.00', '-', '8850.00', NULL, NULL, 'INV/25-26/-007-2025', 'INV/25-26/-007140525', '14');


#
# TABLE STRUCTURE FOR: invoice_party_statement_backup
#

DROP TABLE IF EXISTS `invoice_party_statement_backup`;

CREATE TABLE `invoice_party_statement_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=latin1;

INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '-', '-', NULL, '2024-03-28', 'INV/23-24/-001', 12, 'Jayaprakash', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2024-03-28', '2024-03-28', '8850.00', '-', '-', '', '', '-', '-', NULL, '13930', '-', '-', '-', '-', '8850.00', '-', '8850.00', NULL, NULL, 'INV/23-24/-001-2024', 'INV/23-24/-001280324', '1');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '-', '-', NULL, '2024-03-28', 'INV/23-24/-002', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2024-03-28', '2024-03-28', '10620.00', '-', '-', '', '', '-', '-', NULL, '10620', '-', '-', '-', '-', '10620.00', '-', '10620.00', NULL, NULL, 'INV/23-24/-002-2024', 'INV/23-24/-002280324', '2');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (3, '-', '-', NULL, '2024-03-28', 'INV/23-24/-003', 1, 'SMK INDUSTRIES', '', '', '', 'Compressor', '', '', '', NULL, NULL, '', '', '1', '2024-03-28', '2024-03-28', '11800.00', '-', '-', '', '', '-', '-', NULL, '22420', '-', '-', '-', '-', '11800.00', '-', '11800.00', NULL, NULL, 'INV/23-24/-003-2024', 'INV/23-24/-003280324', '3');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (4, '-', '-', NULL, '2024-03-28', 'INV/23-24/-10001', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2024-03-28', '2024-03-28', '3540.00', '-', '-', '', '', '-', '-', NULL, '25960', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-10001-2024', 'INV/23-24/-10001280324', '4');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (5, '-', '-', NULL, '2024-03-28', 'INV/23-24/-10002', 1, 'SMK INDUSTRIES', '', '', '', 'Compressor', '', '', '', NULL, NULL, '', '', '1', '2024-03-28', '2024-03-28', '2360.00', '-', '-', '', '', '-', '-', NULL, '28320', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-10002-2024', 'INV/23-24/-10002280324', '5');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (6, '-', '-', NULL, '2024-03-28', 'INV/23-24/-10003', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2024-03-28', '2024-03-28', '17700.00', '-', '-', '', '', '-', '-', NULL, '46020', '-', '-', '-', '-', '17700.00', '-', '17700.00', NULL, NULL, 'INV/23-24/-10003-2024', 'INV/23-24/-10003280324', '6');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (7, '-', '-', NULL, '2024-03-28', 'INV/23-24/-10004', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2024-03-28', '2024-03-28', '35400.00', '-', '-', '', '', '-', '-', NULL, '81420', '-', '-', '-', '-', '35400.00', '-', '35400.00', NULL, NULL, 'INV/23-24/-10004-2024', 'INV/23-24/-10004280324', '7');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (8, 'V/23-24/-001', '', NULL, '2024-03-28', '-', 0, 'SMK INDUSTRIES', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2024-03-28', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '80800', NULL, NULL, NULL, 'Cash', NULL, '10620', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (9, 'V/23-24/-001', '', NULL, '2024-03-28', '-', 0, 'IDREAMDEVELOPERS', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2024-03-28', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '-11800', NULL, NULL, NULL, 'Cash', NULL, '11800', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (10, '-', '-', NULL, '2024-03-28', 'INV/23-24/-0001', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2024-03-28', '2024-03-28', '8850.00', '-', '-', '', '', '-', '-', NULL, '-2950', '-', '-', '-', '-', '8850.00', '-', '8850.00', NULL, NULL, 'INV/23-24/-0001-2024', 'INV/23-24/-0001280324', '1');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (11, 'V/23-24/-002', '', NULL, '2024-03-28', '-', 0, 'IDREAMDEVELOPERS', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2024-03-28', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '-11800', NULL, NULL, NULL, 'Cash', NULL, '8850', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (12, 'V/23-24/-003', '', NULL, '2024-03-28', '-', 0, 'IDREAMDEVELOPERS', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2024-03-28', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '-17700', NULL, NULL, NULL, 'Cash', NULL, '5900', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (13, '-', '-', NULL, '2024-04-03', 'INV/23-24/-', 1, 'IDREAMDEVELOPERS', '', '', '', 'Air Compressor Motor ', '', '', '', NULL, NULL, '', '', '1', '2024-04-03', '2024-04-03', '17700.00', '-', '-', '', '', '-', '-', NULL, '48970', '-', '-', '-', '-', '17700.00', '-', '17700.00', NULL, NULL, NULL, NULL, '2');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (14, 'V/23-24/-004', '', NULL, '2024-04-09', '-', 0, 'IDREAMDEVELOPERS', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2024-04-09', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '31970', NULL, NULL, NULL, 'Cheque ANDHRA BANK 123455', NULL, '17000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (15, '-', '-', NULL, '2024-05-03', 'INV/23-24/-1', 1, 'IDREAMDEVELOPERS', '', '', '', 'Air Compressor Motor ', '', '', '', NULL, NULL, '', '', '1', '2024-05-03', '2024-05-03', '59000.00', '-', '-', '', '', '-', '-', NULL, '90970', '-', '-', '-', '-', '59000.00', '-', '59000.00', NULL, NULL, 'INV/23-24/-1-2024', 'INV/23-24/-1030524', '3');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (16, 'V/23-24/-005', '', NULL, '2024-05-03', '-', 0, 'IDREAMDEVELOPERS', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2024-05-03', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '18670', NULL, NULL, NULL, 'Cash', NULL, '90000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (17, '-', '-', NULL, '2024-05-03', 'INV/23-24/-2', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2024-05-03', '2024-05-03', '17700.00', '-', '-', '', '', '-', '-', NULL, '8670', '-', '-', '-', '-', '17700.00', '-', '17700.00', NULL, NULL, 'INV/23-24/-2-2024', 'INV/23-24/-2030524', '4');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (18, 'V/23-24/-006', '', NULL, '2024-05-16', '-', 0, 'IDREAMDEVELOPERS', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2024-05-16', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '18170', NULL, NULL, NULL, 'Cash', NULL, '500', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (19, '-', '-', NULL, '2024-05-29', 'INV/23-24/-3', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2024-05-29', '2024-05-29', '17700.00', '-', '-', '', '', '-', '-', NULL, '35870', '-', '-', '-', '-', '17700.00', '-', '17700.00', NULL, NULL, 'INV/23-24/-3-2024', 'INV/23-24/-3290524', '5');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (20, '-', '-', NULL, '2024-05-29', 'INV/23-24/-4', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2024-05-29', '2024-05-29', '79650.00', '-', '-', '', '', '-', '-', NULL, '296830', '-', '-', '-', '-', '79650.00', '-', '79650.00', NULL, NULL, 'INV/23-24/-4-2024', 'INV/23-24/-4290524', '6');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (21, '-', '-', NULL, '2024-07-01', 'INV/23-24/-5', 1, 'IDREAMDEVELOPERS', '', '', '', 'Air Compressor Motor ', '', '', '', NULL, NULL, '', '', '1', '2024-07-01', '2024-07-01', '17700.00', '-', '-', '', '', '-', '-', NULL, '314530', '-', '-', '-', '-', '17700.00', '-', '17700.00', NULL, NULL, 'INV/23-24/-5-2024', 'INV/23-24/-5010724', '7');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (22, '-', '-', NULL, '2024-07-01', 'INV/23-24/-6', 13, 'Idreamdevelopers', '', '', '', 'Air Compressor Motor ', '', '', '', NULL, NULL, '', '', '1', '2024-07-01', '2024-07-01', '59000.00', '-', '-', '', '', '-', '-', NULL, '59000', '-', '-', '-', '-', '59000.00', '-', '59000.00', NULL, NULL, 'INV/23-24/-6-2024', 'INV/23-24/-6010724', '8');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (23, 'V/23-24/-007', '', NULL, '2024-07-01', '-', 0, 'IDREAMDEVELOPERS', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2024-07-01', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '49000', NULL, NULL, NULL, 'Cash', NULL, '10000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (24, '-', '-', NULL, '2024-07-03', 'INV/23-24/-7', 15, 'GRD', '', '', '', 'AC', '', '', '', NULL, NULL, '', '', '1', '2024-07-03', '2024-07-03', '118000.00', '-', '-', '', '', '-', '-', NULL, '118000', '-', '-', '-', '-', '118000.00', '-', '118000.00', NULL, NULL, 'INV/23-24/-7-2024', 'INV/23-24/-7030724', '9');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (25, '-', '-', NULL, '2024-07-03', 'INV/23-24/-8', 15, 'GRD', '', '', '', 'AC', '', '', '', NULL, NULL, '', '', '1', '2024-07-03', '2024-07-03', '5900.00', '-', '-', '', '', '-', '-', NULL, '123900', '-', '-', '-', '-', '5900.00', '-', '5900.00', NULL, NULL, 'INV/23-24/-8-2024', 'INV/23-24/-8030724', '10');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (26, 'V/23-24/-008', '', NULL, '2024-07-03', '-', 0, 'GRD', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2024-07-03', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '113900', NULL, NULL, NULL, 'Cash', NULL, '10000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (27, '-', '-', NULL, '2024-07-03', 'INV/23-24/-9', 15, 'GRD', '', '', '', 'AC', '', '', '', NULL, NULL, '', '', '1', '2024-07-03', '2024-07-03', '3540.00', '-', '-', '', '', '-', '-', NULL, '117440', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-9-2024', 'INV/23-24/-9030724', '11');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (28, '-', '-', NULL, '2024-07-31', 'INV/23-24/-10', 1, 'IDREAMDEVELOPERS', '', '', '', 'Air Compressor Motor ||1080R2-2PM 70MM CLEATED STATOR||drilling machine', '', '', '', NULL, NULL, '', '', '1', '2024-07-31', '2024-07-31', '24190.00', '-', '-', '', '', '-', '-', NULL, '338720', '-', '-', '-', '-', '24190.00', '-', '24190.00', NULL, NULL, 'INV/23-24/-10-2024', 'INV/23-24/-10310724', '12');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (29, '-', '-', NULL, '2024-08-03', 'INV/23-24/-11', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2024-08-03', '2024-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '340490', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-11-2024', 'INV/23-24/-11030824', '13');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (30, 'D001', '', NULL, '2024-08-09', 'INV/23-24/-0001', 1, 'IDREAMDEVELOPERS', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2024-08-09', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '331640', NULL, NULL, NULL, 'sales', NULL, NULL, NULL, '8850.00', NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (31, '-', '-', NULL, '2024-08-20', 'INV/23-24/-12', 13, 'Idreamdevelopers', '', '', '', 'Air Compressor Motor ', '', '', '', NULL, NULL, '', '', '1', '2024-08-20', '2024-08-20', '5900.00', '-', '-', '', '', '-', '-', NULL, '54900', '-', '-', '-', '-', '5900.00', '-', '5900.00', NULL, NULL, 'INV/23-24/-12-2024', 'INV/23-24/-12200824', '14');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (32, 'V/23-24/-009', '', NULL, '2024-08-20', '-', 0, 'IDREAMDEVELOPERS', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2024-08-20', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '52900', NULL, NULL, NULL, 'Cash', NULL, '2000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (33, 'V/23-24/-010', '', NULL, '2024-08-20', '-', 0, 'IDREAMDEVELOPERS', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2024-08-20', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '28710', NULL, NULL, NULL, 'Cash', NULL, '24190', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (34, '-', '-', NULL, '2024-08-21', 'INV/23-24/-13', 1, 'IDREAMDEVELOPERS', '', '', '', 'drilling machine', '', '', '', NULL, NULL, '', '', '1', '2024-08-21', '2024-08-21', '3540.00', '-', '-', '', '', '-', '-', NULL, '335180', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-13-2024', 'INV/23-24/-13210824', '15');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (35, '-', '-', NULL, '2024-08-21', 'INV/23-24/-14', 1, 'IDREAMDEVELOPERS', '', '', '', 'drilling machine', '', '', '', NULL, NULL, '', '', '1', '2024-08-21', '2024-08-21', '1770.00', '-', '-', '', '', '-', '-', NULL, '336950', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-14-2024', 'INV/23-24/-14210824', '16');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (36, '-', '-', NULL, '2024-08-21', 'INV/23-24/-15', 1, 'IDREAMDEVELOPERS', '', '', '', 'Air Compressor Motor ', '', '', '', NULL, NULL, '', '', '1', '2024-08-21', '2024-08-21', '6136.00', '-', '-', '', '', '-', '-', NULL, '343086', '-', '-', '-', '-', '6136.00', '-', '6136.00', NULL, NULL, 'INV/23-24/-15-2024', 'INV/23-24/-15210824', '17');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (37, '-', '-', NULL, '2024-08-21', 'INV/23-24/-16', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2024-08-21', '2024-08-21', '35400.00', '-', '-', '', '', '-', '-', NULL, '378486', '-', '-', '-', '-', '35400.00', '-', '35400.00', NULL, NULL, 'INV/23-24/-16-2024', 'INV/23-24/-16210824', '18');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (38, 'V/23-24/-012', '', NULL, '2024-08-24', '-', 0, 'IDREAMDEVELOPERS', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2024-08-24', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '28706', NULL, NULL, NULL, 'Cash', NULL, '4', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (39, '-', '-', NULL, '2024-08-23', 'INV/23-24/-17', 17, 'intra customer demo', '', '', '', 'demo', '', '', '', NULL, NULL, '', '', '1', '2024-08-23', '2024-08-23', '131040.00', '-', '-', '', '', '-', '-', NULL, '131040', '-', '-', '-', '-', '131040.00', '-', '131040.00', NULL, NULL, NULL, NULL, '19');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (40, '-', '-', NULL, '2024-08-24', 'INV/23-24/-18', 1, 'IDREAMDEVELOPERS', '', '', '', 'Air Compressor Motor ', '', '', '', NULL, NULL, '', '', '1', '2024-08-24', '2024-08-24', '-17700.00', '-', '-', '', '', '-', '-', NULL, '360786', '-', '-', '-', '-', '-17700.00', '-', '-17700.00', NULL, NULL, 'INV/23-24/-18-2024', 'INV/23-24/-18240824', '20');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (41, '-', '-', NULL, '2024-08-24', 'INV/23-24/-19', 1, 'IDREAMDEVELOPERS', '', '', '', 'AC', '', '', '', NULL, NULL, '', '', '1', '2024-08-24', '2024-08-24', '8260.00', '-', '-', '', '', '-', '-', NULL, '369046', '-', '-', '-', '-', '8260.00', '-', '8260.00', NULL, NULL, 'INV/23-24/-19-2024', 'INV/23-24/-19240824', '21');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (42, '-', '-', NULL, '2024-08-24', 'INV/23-24/-20', 1, 'IDREAMDEVELOPERS', '', '', '', 'AC', '', '', '', NULL, NULL, '', '', '1', '2024-08-24', '2024-08-24', '9440.00', '-', '-', '', '', '-', '-', NULL, '378486', '-', '-', '-', '-', '9440.00', '-', '9440.00', NULL, NULL, 'INV/23-24/-20-2024', 'INV/23-24/-20240824', '22');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (43, '-', '-', NULL, '2024-08-24', 'INV/23-24/-21', 6, 'HANDY THINK', '', '', '', 'BLACK PAINT', '', '', '', NULL, NULL, '', '', '1', '2024-08-24', '2024-08-24', '22050.00', '-', '-', '', '', '-', '-', NULL, '24410', '-', '-', '-', '-', '22050.00', '-', '22050.00', NULL, NULL, NULL, NULL, '23');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (44, '-', '-', NULL, '2024-08-24', 'INV/23-24/-22', 13, 'Idreamdevelopers', '', '', '', 'BLACK PAINT', '', '', '', NULL, NULL, '', '', '1', '2024-08-24', '2024-08-24', '22467.20', '-', '-', '', '', '-', '-', NULL, '51173.2', '-', '-', '-', '-', '22467.20', '-', '22467.20', NULL, NULL, NULL, NULL, '24');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (45, '-', '-', NULL, '2024-09-04', 'INV/23-24/-23', 19, 'DD & co', '', '', '', 'Oversized Tshirt', '', '', '', NULL, NULL, '', '', '1', '2024-09-04', '2024-09-04', '76110.00', '-', '-', '', '', '-', '-', NULL, '76110', '-', '-', '-', '-', '76110.00', '-', '76110.00', NULL, NULL, 'INV/23-24/-23-2024', 'INV/23-24/-23040924', '25');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (46, '-', '-', NULL, '2024-11-25', 'INV/23-24/-24', 15, 'GRD', '', '', '', 'SHAFT||Air Compressor Motor ', '', '', '', NULL, NULL, '', '', '1', '2024-11-25', '2024-11-25', '76920.00', '-', '-', '', '', '-', '-', NULL, '194360', '-', '-', '-', '-', '76920.00', '-', '76920.00', NULL, NULL, 'INV/23-24/-24-2024', 'INV/23-24/-24251124', '26');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (47, '-', '-', NULL, '2024-11-25', 'INV/23-24/-25', 1, 'IDREAMDEVELOPERS', '', '', '', 'SHAFT', '', '', '', NULL, NULL, '', '', '1', '2024-11-25', '2024-11-25', '16815.00', '-', '-', '', '', '-', '-', NULL, '395301', '-', '-', '-', '-', '16815.00', '-', '16815.00', NULL, NULL, 'INV/23-24/-25-2024', 'INV/23-24/-25251124', '27');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (48, '-', '-', NULL, '2025-01-21', 'INV/23-24/-26', 8, 'JAI SHREE SAI ENGINEERING', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2025-01-21', '2025-01-21', '3540.00', '-', '-', '', '', '-', '-', NULL, '3540', '-', '-', '-', '-', '3540.00', '-', '3540.00', NULL, NULL, 'INV/23-24/-26-2025', 'INV/23-24/-26210125', '28');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (49, '-', '-', NULL, '2025-01-27', 'INV/23-24/-27', 12, 'Jayaprakash', '', '', '', 'Air Compressor Motor ', '', '', '', NULL, NULL, '', '', '1', '2025-01-27', '2025-01-27', '13000.00', '-', '-', '', '', '-', '-', NULL, '26930', '-', '-', '-', '-', '13000.00', '-', '13000.00', NULL, NULL, 'INV/23-24/-27-2025', 'INV/23-24/-27270125', '29');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (50, '-', '-', NULL, '2025-02-06', 'INV/23-24/-28', 1, 'IDREAMDEVELOPERS', '', '', '', 'Air Compressor Motor ', '', '', '', NULL, NULL, '', '', '1', '2025-02-06', '2025-02-06', '29500.00', '-', '-', '', '', '-', '-', NULL, '424801', '-', '-', '-', '-', '29500.00', '-', '29500.00', NULL, NULL, 'INV/23-24/-28-2025', 'INV/23-24/-28060225', '30');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (51, '-', '-', NULL, '2025-02-06', 'INV/23-24/-29', 6, 'HANDY THINK', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2025-02-06', '2025-02-06', '16500.00', '-', '-', '', '', '-', '-', NULL, '40910', '-', '-', '-', '-', '16500.00', '-', '16500.00', NULL, NULL, NULL, NULL, '31');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (52, 'V/23-24/-013', '', NULL, '2025-02-06', '-', 0, 'IDREAMDEVELOPERS', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2025-02-06', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '-48826.8', NULL, NULL, NULL, 'Cash', NULL, '100000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (53, '-', '-', NULL, '2025-02-06', 'INV/23-24/-30', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2025-02-06', '2025-02-06', '17700.00', '-', '-', '', '', '-', '-', NULL, '-39976.8', '-', '-', '-', '-', '17700.00', '-', '17700.00', NULL, NULL, NULL, NULL, '32');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (54, '-', '-', NULL, '2025-02-06', 'INV/23-24/-31', 6, 'HANDY THINK', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2025-02-06', '2025-02-06', '23600.00', '-', '-', '', '', '-', '-', NULL, '64510', '-', '-', '-', '-', '23600.00', '-', '23600.00', NULL, NULL, NULL, NULL, '33');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (55, '-', '-', NULL, '2025-02-06', 'INV/23-24/-32', 1, 'IDREAMDEVELOPERS', '', '', '', 'SOLAR LIGHT 3OOW', '', '', '', NULL, NULL, '', '', '1', '2025-02-06', '2025-02-06', '225000.00', '-', '-', '', '', '-', '-', NULL, '658651', '-', '-', '-', '-', '225000.00', '-', '225000.00', NULL, NULL, 'INV/23-24/-32-2025', 'INV/23-24/-32060225', '34');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (56, 'V/23-24/-015', '', NULL, '2025-02-19', '-', 0, 'Jayaprakash', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2025-02-19', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '26430', NULL, NULL, NULL, 'Cash', NULL, '500', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (57, '-', '-', NULL, '2025-02-23', 'INV/23-24/-33', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2025-02-23', '2025-02-23', '20650.00', '-', '-', '', '', '-', '-', NULL, '679301', '-', '-', '-', '-', '20650.00', '-', '20650.00', NULL, NULL, 'INV/23-24/-33-2025', 'INV/23-24/-33230225', '35');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (58, '-', '-', NULL, '2025-02-25', 'INV/23-24/-34', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2025-02-25', '2025-02-25', '20650.00', '-', '-', '', '', '-', '-', NULL, '699951', '-', '-', '-', '-', '20650.00', '-', '20650.00', NULL, NULL, 'INV/23-24/-34-2025', 'INV/23-24/-34250225', '36');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (59, '-', '-', NULL, '2025-02-25', 'INV/23-24/-35', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2025-02-25', '2025-02-25', '0.00', '-', '-', '', '', '-', '-', NULL, '699951', '-', '-', '-', '-', '0.00', '-', '0.00', NULL, NULL, 'INV/23-24/-35-2025', 'INV/23-24/-35250225', '37');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (60, '-', '-', NULL, '2025-02-25', 'INV/23-24/-36', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG||1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2025-02-25', '2025-02-25', '28910.00', '-', '-', '', '', '-', '-', NULL, '728861', '-', '-', '-', '-', '28910.00', '-', '28910.00', NULL, NULL, 'INV/23-24/-36-2025', 'INV/23-24/-36250225', '38');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (61, '-', '-', NULL, '2025-02-25', 'INV/23-24/-37', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2025-02-25', '2025-02-25', '1770.00', '-', '-', '', '', '-', '-', NULL, '730631', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-37-2025', 'INV/23-24/-37250225', '39');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (62, '-', '-', NULL, '2025-02-25', 'INV/23-24/-38', 1, 'IDREAMDEVELOPERS', '', '', '', '10886', '', '', '', NULL, NULL, '', '', '1', '2025-02-25', '2025-02-25', '129.80', '-', '-', '', '', '-', '-', NULL, '730760.8', '-', '-', '-', '-', '129.80', '-', '129.80', NULL, NULL, 'INV/23-24/-38-2025', 'INV/23-24/-38250225', '40');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (63, '-', '-', NULL, '2025-02-25', 'INV/23-24/-39', 1, 'IDREAMDEVELOPERS', '', '', '', '10886', '', '', '', NULL, NULL, '', '', '1', '2025-02-25', '2025-02-25', '259.60', '-', '-', '', '', '-', '-', NULL, '731020.4', '-', '-', '-', '-', '259.60', '-', '259.60', NULL, NULL, 'INV/23-24/-39-2025', 'INV/23-24/-39250225', '41');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (64, '-', '-', NULL, '2025-02-26', 'INV/23-24/-40', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2025-02-26', '2025-02-26', '11800.00', '-', '-', '', '', '-', '-', NULL, '742820.4', '-', '-', '-', '-', '11800.00', '-', '11800.00', NULL, NULL, 'INV/23-24/-40-2025', 'INV/23-24/-40260225', '42');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (65, '-', '-', NULL, '2025-02-26', 'INV/23-24/-41', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2025-02-26', '2025-02-26', '200600.00', '-', '-', '', '', '-', '-', NULL, '943420.4', '-', '-', '-', '-', '200600.00', '-', '200600.00', NULL, NULL, 'INV/23-24/-41-2025', 'INV/23-24/-41260225', '43');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (66, '-', '-', NULL, '2025-02-27', 'INV/23-24/-42', 12, 'Jayaprakash', '', '', '', 'asus512gb||asus512gb', '', '', '', NULL, NULL, '', '', '1', '2025-02-27', '2025-02-27', '392400.00', '-', '-', '', '', '-', '-', NULL, '418830', '-', '-', '-', '-', '392400.00', '-', '392400.00', NULL, NULL, 'INV/23-24/-42-2025', 'INV/23-24/-42270225', '44');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (67, '-', '-', NULL, '2025-02-27', 'INV/23-24/-43', 12, 'Jayaprakash', '', '', '', 'asus512gb', '', '', '', NULL, NULL, '', '', '1', '2025-02-27', '2025-02-27', '590000.00', '-', '-', '', '', '-', '-', NULL, '1008830', '-', '-', '-', '-', '590000.00', '-', '590000.00', NULL, NULL, 'INV/23-24/-43-2025', 'INV/23-24/-43270225', '45');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (68, '-', '-', NULL, '2025-02-27', 'INV/23-24/-44', 12, 'Jayaprakash', '', '', '', 'asus512gb', '', '', '', NULL, NULL, '', '', '1', '2025-02-27', '2025-02-27', '590000.00', '-', '-', '', '', '-', '-', NULL, '1598830', '-', '-', '-', '-', '590000.00', '-', '590000.00', NULL, NULL, 'INV/23-24/-44-2025', 'INV/23-24/-44270225', '46');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (69, '-', '-', NULL, '2025-02-27', 'INV/23-24/-45', 12, 'Jayaprakash', '', '', '', 'asus512gb', '', '', '', NULL, NULL, '', '', '1', '2025-02-27', '2025-02-27', '1180000.00', '-', '-', '', '', '-', '-', NULL, '2778830', '-', '-', '-', '-', '1180000.00', '-', '1180000.00', NULL, NULL, 'INV/23-24/-45-2025', 'INV/23-24/-45270225', '47');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (70, '-', '-', NULL, '2025-02-27', 'INV/23-24/-46', 11, 'shivamobiles', '', '', '', 'Metal Stamping', '', '', '', NULL, NULL, '', '', '1', '2025-02-27', '2025-02-27', '29500.00', '-', '-', '', '', '-', '-', NULL, '29500', '-', '-', '-', '-', '29500.00', '-', '29500.00', NULL, NULL, 'INV/23-24/-46-2025', 'INV/23-24/-46270225', '48');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (71, '-', '-', NULL, '2025-02-27', 'INV/23-24/-46', 11, 'shivamobiles', '', '', '', 'Metal Stamping', '', '', '', NULL, NULL, '', '', '1', '2025-02-27', '2025-02-27', '29500.00', '-', '-', '', '', '-', '-', NULL, '59000', '-', '-', '-', '-', '29500.00', '-', '29500.00', NULL, NULL, 'INV/23-24/-46-2025', 'INV/23-24/-46270225', '49');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (72, '-', '-', NULL, '2025-02-27', 'INV/23-24/-48', 11, 'shivamobiles', '', '', '', 'Metal Stamping', '', '', '', NULL, NULL, '', '', '1', '2025-02-27', '2025-02-27', '29500.00', '-', '-', '', '', '-', '-', NULL, '88500', '-', '-', '-', '-', '29500.00', '-', '29500.00', NULL, NULL, 'INV/23-24/-48-2025', 'INV/23-24/-48270225', '50');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (73, '-', '-', NULL, '2025-02-27', 'INV/23-24/-49', 12, 'Jayaprakash', '', '', '', 'asus512gb||Air Compressor Motor ||Metal Stamping', '', '', '', NULL, NULL, '', '', '1', '2025-02-27', '2025-02-27', '3127000.00', '-', '-', '', '', '-', '-', NULL, '5905830', '-', '-', '-', '-', '3127000.00', '-', '3127000.00', NULL, NULL, 'INV/23-24/-49-2025', 'INV/23-24/-49270225', '51');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (74, '-', '-', NULL, '2025-02-27', 'INV/23-24/-50', 12, 'Jayaprakash', '', '', '', 'asus512gb||Air Compressor Motor ||Metal Stamping', '', '', '', NULL, NULL, '', '', '1', '2025-02-27', '2025-02-27', '3127000.00', '-', '-', '', '', '-', '-', NULL, '9032830', '-', '-', '-', '-', '3127000.00', '-', '3127000.00', NULL, NULL, 'INV/23-24/-50-2025', 'INV/23-24/-50270225', '52');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (75, '-', '-', NULL, '2025-02-27', 'INV/23-24/-51', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM STATOR STAMPING NEW', '', '', '', NULL, NULL, '', '', '1', '2025-02-27', '2025-02-27', '23600.00', '-', '-', '', '', '-', '-', NULL, '967020.4', '-', '-', '-', '-', '23600.00', '-', '23600.00', NULL, NULL, 'INV/23-24/-51-2025', 'INV/23-24/-51270225', '53');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (76, '-', '-', NULL, '2025-02-27', 'INV/23-24/-52', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2025-02-27', '2025-02-27', '4130.00', '-', '-', '', '', '-', '-', NULL, '971150.4', '-', '-', '-', '-', '4130.00', '-', '4130.00', NULL, NULL, 'INV/23-24/-52-2025', 'INV/23-24/-52270225', '54');
INSERT INTO `invoice_party_statement_backup` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (77, '-', '-', NULL, '2025-02-27', 'INV/23-24/-53', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2025-02-27', '2025-02-27', '1770.00', '-', '-', '', '', '-', '-', NULL, '972920.4', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-53-2025', 'INV/23-24/-53270225', '55');


#
# TABLE STRUCTURE FOR: invoice_reports
#

DROP TABLE IF EXISTS `invoice_reports`;

CREATE TABLE `invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2025-03-01', 'INV/23-24/-0001', '2025-03-01', NULL, NULL, 21, 'VRN ENGINEERING', NULL, NULL, NULL, '137 OM SAKTHINAGAR, CHINNAVEDAMPATTI, COIMBATORE, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '5', NULL, NULL, '7500.00', NULL, NULL, '8850.00', NULL, NULL, '1', 'INV/23-24/-0001-2025', 'INV/23-24/-0001010325', '1');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '2025-03-03', 'INV/23-24/-0002', '2025-03-03', NULL, NULL, 22, 'thennarasdu', NULL, NULL, NULL, 'teachers colony, vennampatty main road, dharmapuri, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '84158210', NULL, NULL, 'daikin cassette ac', '', '7', '2', NULL, NULL, '450000.00', NULL, NULL, '531000.00', NULL, NULL, '1', 'INV/23-24/-0002-2025', 'INV/23-24/-0002030325', '2');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (3, '2025-03-03', 'INV/23-24/-0002', '2025-03-03', NULL, NULL, 22, 'thennarasdu', NULL, NULL, NULL, 'teachers colony, vennampatty main road, dharmapuri, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '84158210', NULL, NULL, 'daikin cassette ac', '', '5', '4', NULL, NULL, '450000.00', NULL, NULL, '531000.00', NULL, NULL, '1', 'INV/23-24/-0002-2025', 'INV/23-24/-0002030325', '2');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (5, '2025-03-11', 'INV/23-24/-0003', '2025-03-11', NULL, NULL, 12, 'Jayaprakash', NULL, NULL, NULL, 'jaganathan nagar, Coimbatore, coimabtore, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '654654', NULL, NULL, 'asus512gb', '', '5', '5', NULL, NULL, '25000.00', NULL, NULL, '25000.00', NULL, NULL, '1', 'INV/23-24/-0003-2025', 'INV/23-24/-0003110325', '4');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (6, '2025-04-03', 'INV/25-26/-001', '2025-04-03', NULL, NULL, 21, 'VRN ENGINEERING', NULL, NULL, NULL, '137 OM SAKTHINAGAR, CHINNAVEDAMPATTI, COIMBATORE, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '5', NULL, NULL, '10000.00', NULL, NULL, '11800.00', NULL, NULL, '1', 'INV/25-26/-001-2025', 'INV/25-26/-001030425', '5');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (7, '2025-04-03', 'INV/25-26/-002', '2025-04-03', NULL, NULL, 24, 'Idream Developers new', NULL, NULL, NULL, 'jaganathan nagar, Civil Aerodeome Post, Mumbai, Maharashtra', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '10', NULL, NULL, '15000.00', NULL, NULL, '17700.00', NULL, NULL, '1', 'INV/25-26/-002-2025', 'INV/25-26/-002030425', '6');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (8, '2025-04-03', 'INV/25-26/-003', '2025-04-03', NULL, NULL, 24, 'Idream Developers new', NULL, NULL, NULL, 'jaganathan nagar, Civil Aerodeome Post, Mumbai, Maharashtra', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '5', NULL, NULL, '7500.00', NULL, NULL, '8850.00', NULL, NULL, '1', 'INV/25-26/-003-2025', 'INV/25-26/-003030425', '7');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (9, '2025-04-03', 'INV/25-26/-004', '2025-04-03', NULL, NULL, 24, 'Idream Developers new', NULL, NULL, NULL, 'jaganathan nagar, Civil Aerodeome Post, Mumbai, Maharashtra', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '5', '8', NULL, '20650.00', NULL, NULL, '20650.00', NULL, NULL, '1', 'INV/25-26/-004-2025', 'INV/25-26/-004030425', '8');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (10, '2025-04-03', 'INV/25-26/-004', '2025-04-03', NULL, NULL, 24, 'Idream Developers new', NULL, NULL, NULL, 'jaganathan nagar, Civil Aerodeome Post, Mumbai, Maharashtra', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '5', '5', '8', NULL, '20650.00', NULL, NULL, '20650.00', NULL, NULL, '1', 'INV/25-26/-004-2025', 'INV/25-26/-004030425', '8');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (16, '2025-04-25', 'INV/25-26/-005', '2025-04-25', NULL, NULL, 1, 'IDREAMDEVELOPERS', NULL, NULL, NULL, '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '5', NULL, NULL, '7500.00', NULL, NULL, '8850.00', NULL, NULL, '1', 'INV/25-26/-005-2025', 'INV/25-26/-005250425', '12');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (20, '2025-05-07', 'INV/25-26/-006', '2025-05-07', NULL, NULL, 0, 'Idream Developers new', NULL, NULL, NULL, 'jaganathan nagar, Civil Aerodeome Post, Mumbai, Maharashtra', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '853521', NULL, NULL, 'DISPLAY BOARD (12\" x 14\" x 3mm)', '', '1000', '115', NULL, NULL, '115000.00', NULL, NULL, '135700.00', NULL, NULL, '1', NULL, NULL, '13');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (21, '2025-05-14', 'INV/25-26/-007', '2025-05-14', NULL, NULL, 24, 'Idream Developers new', NULL, NULL, NULL, 'jaganathan nagar, Civil Aerodeome Post, Mumbai, Maharashtra', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '5', NULL, NULL, '7500.00', NULL, NULL, '8850.00', NULL, NULL, '1', 'INV/25-26/-007-2025', 'INV/25-26/-007140525', '14');


#
# TABLE STRUCTURE FOR: inward_delivery
#

DROP TABLE IF EXISTS `inward_delivery`;

CREATE TABLE `inward_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insertid` int(11) NOT NULL,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `lastupdatedqty` int(11) NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `inward_status` int(11) DEFAULT NULL,
  `lastupdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (1, 1, '2024-04-10', 'I001', '2024-04-10', 'JAI SHREE SAI ENGINEERING', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST', 'DC1003', '2024-04-10', '9', '20CL ROTAR', '', '15', '8', 15, 'Inhouse production', '8503', NULL, 'NOS', 'I001-24', 'I001100424', 1, 1, '2024-04-10 00:22:48');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (2, 1, '2024-04-10', 'I001', '2024-04-10', 'JAI SHREE SAI ENGINEERING', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST', 'DC1003', '2024-04-10', '7', 'drilling machine', '', '25', '7', 25, 'Inhouse productions', '1002', NULL, 'KGS', 'I001-24', 'I001100424', 1, 1, '2024-04-10 00:22:48');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (3, 2, '2024-05-29', 'I002', '2024-05-29', 'IDREAMDEVELOPERS', 'Hopes, peelamedu', 'DC0012', '2024-05-29', '2', '1080R2-2PM STATOR STAMPING-GANG', '', '85', '20', 85, '', '7204', NULL, 'KGS', 'I002-24', 'I002290524', 1, 1, '2024-05-29 02:58:53');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (4, 3, '2024-07-01', 'I003', '2024-07-01', 'IDREAMDEVELOPERS', 'Hopes, peelamedu', '1022', '2024-07-01', '4', 'Air Compressor Motor ', '', '10', '8', 10, '', '01', NULL, 'KGS', 'I003-24', 'I003010724', 1, 1, '2024-07-01 08:20:00');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (5, 4, '2024-08-20', 'I004', '2024-08-20', 'Idreamdevelopers', 'Hopes, peelamedu', '001', '2024-08-20', '4', 'Air Compressor Motor ', '', '12', '12', 12, '', '01', NULL, 'KGS', 'I004-24', 'I004200824', 1, 1, '2024-08-20 04:11:22');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (6, 5, '2024-08-21', 'I005', '2024-08-21', 'IDREAMDEVELOPERS', 'Hopes, peelamedu', '001', '2024-08-21', '1', '1080R2-2PM 70MM CLEATED STATOR', '', '100', '80', 100, '--', '850300', NULL, 'KGS', 'I005-24', 'I005210824', 1, 1, '2024-08-21 02:59:17');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (7, 6, '2024-09-04', 'I006', '2024-09-04', 'IDREAMDEVELOPERS', 'Hopes, peelamedu', '001', '2024-09-04', '7', 'drilling machine', '', '12', '12', 12, 'asdsa', '1002', NULL, 'KGS', 'I006-24', 'I006040924', 1, 1, '2024-09-04 02:47:09');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (8, 7, '2024-09-07', 'I007', '2024-09-07', 'DD & co', '56,East Street,, SS kottai,madurai', 'd-001', '2024-09-07', '20', 'Oversized Tshirt', '', '1000', '1000', 1000, '', '32123212', NULL, 'piece', 'I007-24', 'I007070924', 1, 1, '2024-09-07 00:08:32');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (9, 8, '2025-02-27', 'I008', '2025-02-27', 'Jayaprakash', 'jaganathan nagar, Coimbatore', '001', '2025-02-27', '32', 'asus512gb', 'laptop', '20', '0', 20, '10', '654654', NULL, 'piece', 'I008-25', 'I008270225', 1, 0, '2025-02-27 00:19:19');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (10, 9, '2025-02-27', 'I009', '2025-02-27', 'shivamobiles', 'avanshi road annur, annur', '002', '2025-02-27', '5', 'Metal Stamping', '', '50', '0', 50, 'sales', '02', NULL, 'KGS', 'I009-25', 'I009270225', 1, 0, '2025-02-27 00:53:24');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (11, 10, '2025-02-27', 'I010', '2025-02-27', 'Jayaprakash', 'jaganathan nagar, Coimbatore', '003', '2025-02-27', '32', 'asus512gb', '', '50', '0', 50, '000', '654654', NULL, 'piece', 'I010-25', 'I010270225', 1, 0, '2025-02-27 04:19:34');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (12, 10, '2025-02-27', 'I010', '2025-02-27', 'Jayaprakash', 'jaganathan nagar, Coimbatore', '003', '2025-02-27', '4', 'Air Compressor Motor ', '', '50', '0', 50, '000', '01', NULL, 'KGS', 'I010-25', 'I010270225', 1, 0, '2025-02-27 04:19:34');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (13, 10, '2025-02-27', 'I010', '2025-02-27', 'Jayaprakash', 'jaganathan nagar, Coimbatore', '003', '2025-02-27', '5', 'Metal Stamping', '', '50', '0', 50, '000', '02', NULL, 'KGS', 'I010-25', 'I010270225', 1, 0, '2025-02-27 04:19:34');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (14, 11, '2025-02-27', 'I011', '2025-02-27', 'IDREAMDEVELOPERS', 'Hopes, peelamedu', '456', '2025-02-27', '31', '10886', '', '200', '2', 200, 'CNC MACHINING COMPLETED', '1234556', NULL, 'NOS', 'I011-25', 'I011270225', 1, 1, '2025-02-27 06:01:36');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (15, 12, '2025-02-27', 'I012', '2025-02-27', 'IDREAMDEVELOPERS', 'Hopes, peelamedu', '452', '2025-02-27', '3', '1080R2-2PM STATOR STAMPING NEW', '', '500', '100', 500, '', '0', NULL, 'KGS', 'I012-25', 'I012270225', 1, 1, '2025-02-27 06:10:53');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (16, 1, '2025-04-11', 'I001', '2025-04-11', 'IDREAMDEVELOPERS', 'Hopes, peelamedu', '001', '2025-04-11', '1', '1080R2-2PM 70MM CLEATED STATOR', '', '10', '5', 10, '-', '850300', NULL, 'KGS', 'I001-25', 'I001110425', 1, 1, '2025-04-11 02:26:43');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (17, 2, '2025-04-25', 'I002', '2025-04-25', 'IDREAMDEVELOPERS', 'Hopes, peelamedu', '001', '2025-04-25', '1', '1080R2-2PM 70MM CLEATED STATOR', '', '500', '500', 500, 'machining', '850300', NULL, 'KGS', 'I002-25', 'I002250425', 1, 1, '2025-04-25 01:54:54');


#
# TABLE STRUCTURE FOR: inward_details
#

DROP TABLE IF EXISTS `inward_details`;

CREATE TABLE `inward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (1, '2025-04-11', 'I001', '2025-04-11', 'IDREAMDEVELOPERS', 'Hopes, peelamedu', '001', '2025-04-11', '1', '1080R2-2PM 70MM CLEATED STATOR', '', '10', '-', '850300', NULL, 'KGS', 'I001-25', 'I001110425', 1, 0, '16');
INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (2, '2025-04-25', 'I002', '2025-04-25', 'IDREAMDEVELOPERS', 'Hopes, peelamedu', '001', '2025-04-25', '1', '1080R2-2PM 70MM CLEATED STATOR', '', '500', 'machining', '850300', NULL, 'KGS', 'I002-25', 'I002250425', 1, 1, '17');


#
# TABLE STRUCTURE FOR: inward_details_backup
#

DROP TABLE IF EXISTS `inward_details_backup`;

CREATE TABLE `inward_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (1, '2023-08-22', 'I001', '2023-08-22', 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'DC002', '2023-08-22', '1', '1080R2-2PM 70MM CLEATED STATOR', '', '500', 'for drilling ', '850300', NULL, 'KGS', 'I001-23', 'I001220823', 1, 0, '1');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (2, '2023-08-24', 'I002', '2023-08-24', 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'DC003', '2023-08-24', '2||1', '1080R2-2PM STATOR STAMPING-GANG||1080R2-2PM 70MM CLEATED STATOR', '', '100||150', '', '7204||850300', NULL, 'KGS||KGS', 'I002-23', 'I002240823', 1, 1, '2,3');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (3, '2023-10-03', 'I003', '2023-10-03', 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA)', 'DC008', '2023-10-03', '1', '1080R2-2PM 70MM CLEATED STATOR', '', '100', '-', '850300', NULL, 'KGS', 'I003-23', 'I003031023', 1, 0, '4');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (4, '2023-11-08', 'I004', '2023-11-08', 'MPK engineering works', 'Kalapatti road , Kalapatti ', 'dc005', '2023-11-08', '1||4', '1080R2-2PM 70MM CLEATED STATOR||Air Compressor Motor ', '', '30||40', '', '850300||01', NULL, 'KGS||KGS', 'I004-23', 'I004081123', 1, 0, '5,6');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (5, '2024-01-08', 'I005', '2024-01-08', 'HANDY THINK', '1/504, , NEELAMBUR', '1', '2024-01-08', '8', 'SHAFT', '29*298', '350', '', '7222', NULL, 'NOS', 'I005-24', 'I005080124', 1, 1, '7');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (6, '2024-01-08', 'I006', '2024-01-08', 'HANDY THINK', '1/504, , NEELAMBUR', '2', '2024-01-08', '8', 'SHAFT', '30*300', ' 300', '', '7222', NULL, 'NOS', 'I006-24', 'I006080124', 1, 1, '8');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (7, '2024-01-11', 'I007', '2024-01-10', 'JAI SHREE SAI ENGINEERING', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST', '256', '2024-01-10', '9', '20CL ROTAR||26CL ROTOR||30CL ROTOR||32CL ROTOR||35CL ROTOR||38CL ROTOR', '', '500||63||312||102||35||113', '', '8503||8503||8503||8503||8503||8503', NULL, 'NOS||NOS||NOS||NOS||NOS||NOS', 'I007-24', 'I007110124', 1, 1, '9,10,11,12,13,14');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (8, '2024-03-25', 'I008', '2024-03-25', 'HANDY THINK', '1/504, , NEELAMBUR', 'DCIN002', '2024-03-25', '5||7', 'Metal Stamping||drilling machine', '', '15||25', '', '02||1002', NULL, 'KGS||KGS', 'I008-24', 'I008250324', 1, 1, '15,16');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (9, '2024-04-10', 'I001', '2024-04-10', 'JAI SHREE SAI ENGINEERING', 'NO.42/62, ARUN NAGAR, 3rd STREET,, TVS NAGAR BEHIND, VELANDIPALAYAM POST', 'DC1003', '2024-04-10', '9||7', '20CL ROTAR||drilling machine', '', '15||25', 'Inhouse production||Inhouse productions', '8503||1002', NULL, 'NOS||KGS', 'I001-24', 'I001100424', 1, 0, '1,2');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (10, '2024-05-29', 'I002', '2024-05-29', 'IDREAMDEVELOPERS', 'Hopes, peelamedu', 'DC0012', '2024-05-29', '2', '1080R2-2PM STATOR STAMPING-GANG', '', '85', '', '7204', NULL, 'KGS', 'I002-24', 'I002290524', 1, 0, '3');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (11, '2024-07-01', 'I003', '2024-07-01', 'IDREAMDEVELOPERS', 'Hopes, peelamedu', '1022', '2024-07-01', '4', 'Air Compressor Motor ', '', '10', '', '01', NULL, 'KGS', 'I003-24', 'I003010724', 1, 0, '4');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (12, '2024-08-20', 'I004', '2024-08-20', 'Idreamdevelopers', 'Hopes, peelamedu', '001', '2024-08-20', '4', 'Air Compressor Motor ', '', '12', '', '01', NULL, 'KGS', 'I004-24', 'I004200824', 1, 1, '5');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (13, '2024-08-21', 'I005', '2024-08-21', 'IDREAMDEVELOPERS', 'Hopes, peelamedu', '001', '2024-08-21', '1', '1080R2-2PM 70MM CLEATED STATOR', '', '100', '--', '850300', NULL, 'KGS', 'I005-24', 'I005210824', 1, 0, '6');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (14, '2024-09-04', 'I006', '2024-09-04', 'IDREAMDEVELOPERS', 'Hopes, peelamedu', '001', '2024-09-04', '7', 'drilling machine', '', '12', 'asdsa', '1002', NULL, 'KGS', 'I006-24', 'I006040924', 1, 1, '7');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (15, '2024-09-07', 'I007', '2024-09-07', 'DD & co', '56,East Street,, SS kottai,madurai', 'd-001', '2024-09-07', '20', 'Oversized Tshirt', '', '1000', '', '32123212', NULL, 'piece', 'I007-24', 'I007070924', 1, 1, '8');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (16, '2025-02-27', 'I008', '2025-02-27', 'Jayaprakash', 'jaganathan nagar, Coimbatore', '001', '2025-02-27', '32', 'asus512gb', 'laptop', '20', '10', '654654', NULL, 'piece', 'I008-25', 'I008270225', 1, 0, '9');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (17, '2025-02-27', 'I009', '2025-02-27', 'shivamobiles', 'avanshi road annur, annur', '002', '2025-02-27', '5', 'Metal Stamping', '', '50', 'sales', '02', NULL, 'KGS', 'I009-25', 'I009270225', 1, 0, '10');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (18, '2025-02-27', 'I010', '2025-02-27', 'Jayaprakash', 'jaganathan nagar, Coimbatore', '003', '2025-02-27', '32||4||5', 'asus512gb||Air Compressor Motor ||Metal Stamping', '', '50||50||50', '000||000||000', '654654||01||02', NULL, 'piece||KGS||KGS', 'I010-25', 'I010270225', 1, 0, '11,12,13');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (19, '2025-02-27', 'I011', '2025-02-27', 'IDREAMDEVELOPERS', 'Hopes, peelamedu', '456', '2025-02-27', '31', '10886', '', '200', 'CNC MACHINING COMPLETED', '1234556', NULL, 'NOS', 'I011-25', 'I011270225', 1, 0, '14');
INSERT INTO `inward_details_backup` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (20, '2025-02-27', 'I012', '2025-02-27', 'IDREAMDEVELOPERS', 'Hopes, peelamedu', '452', '2025-02-27', '3', '1080R2-2PM STATOR STAMPING NEW', '', '500', '', '', NULL, 'KGS', 'I012-25', 'I012270225', 1, 0, '15');


#
# TABLE STRUCTURE FOR: job_data
#

DROP TABLE IF EXISTS `job_data`;

CREATE TABLE `job_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: job_details
#

DROP TABLE IF EXISTS `job_details`;

CREATE TABLE `job_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `joborderdate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext,
  `category` longtext,
  `jobdescription` longtext,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobinward_data
#

DROP TABLE IF EXISTS `jobinward_data`;

CREATE TABLE `jobinward_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `joborderqty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobinward_details
#

DROP TABLE IF EXISTS `jobinward_details`;

CREATE TABLE `jobinward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `jobinwarddate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext,
  `joborderno` varchar(225) DEFAULT NULL,
  `category` longtext,
  `jobdescription` longtext,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobworkdc_delivery
#

DROP TABLE IF EXISTS `jobworkdc_delivery`;

CREATE TABLE `jobworkdc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `jobworkdc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (1, '2023-11-30', 1, NULL, 'Direct DC', 'PDC/23-24/001', '2023-11-30', 5, 'MM Industries', 'TN27V8009', '1C, Church Road, Athipalayam Pirivu, , ondipudur', NULL, NULL, NULL, 'drilling machine', '', '20', '20', 'DRILLING', '1002', NULL, 'KGS', 'PDC/23-24/001-23', 'PDC/23-24/001301123', 1, 1);
INSERT INTO `jobworkdc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (2, '2025-02-27', 1, NULL, 'Direct DC', 'PDC/23-24/001', '2025-02-27', 5, 'MM Industries', '', '1C, Church Road, Athipalayam Pirivu, , ondipudur', NULL, NULL, NULL, '10886', '', '100', '100', '', '1234556', NULL, 'NOS', 'PDC/23-24/001-25', 'PDC/23-24/001270225', 1, 1);


#
# TABLE STRUCTURE FOR: jobworkdc_delivery_backup
#

DROP TABLE IF EXISTS `jobworkdc_delivery_backup`;

CREATE TABLE `jobworkdc_delivery_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobworkdc_details
#

DROP TABLE IF EXISTS `jobworkdc_details`;

CREATE TABLE `jobworkdc_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobworkdc_details_backup
#

DROP TABLE IF EXISTS `jobworkdc_details_backup`;

CREATE TABLE `jobworkdc_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `jobworkdc_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (1, '2023-11-30', 'Direct DC', 'PDC/23-24/001', '2023-11-30', 5, 'MM Industries', 'TN27V8009', '05:16:AM', 'Product', 'drilling', 'completed', '5000', '1C, Church Road, Athipalayam Pirivu, , ondipudur', NULL, NULL, NULL, 'drilling machine', '', '20', 'DRILLING', '1002', NULL, 'KGS', 'PDC/23-24/001-23', 'PDC/23-24/001301123', 1, 1, '');
INSERT INTO `jobworkdc_details_backup` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (2, '2025-02-27', 'Direct DC', 'PDC/23-24/001', '2025-02-27', 5, 'MM Industries', '', '06:05:AM', '', 'CNC MACHINING', '', '', '1C, Church Road, Athipalayam Pirivu, , ondipudur', NULL, NULL, NULL, '10886', '', '100', '', '1234556', NULL, 'NOS', 'PDC/23-24/001-25', 'PDC/23-24/001270225', 1, 1, '');


#
# TABLE STRUCTURE FOR: login_details
#

DROP TABLE IF EXISTS `login_details`;

CREATE TABLE `login_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userType` char(1) NOT NULL,
  `date` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `sub_menu_link` text,
  `selectedMainMenu` text NOT NULL,
  `selectedSubMenu` text NOT NULL,
  `add_party` int(11) DEFAULT NULL,
  `add_expenses` int(11) DEFAULT NULL,
  `add_quotation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (1, 'A', '2017-01-26', 'admin', '', 'test@gmail.com', '876049652', '0000-00-00', 'admin', 'admin001', '1', '', '', '', NULL, NULL, NULL);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (5, 'U', '2018-05-02', 'purchase', 'Purchase Team', '', '', '1970-01-01', 'purchase', '123456', '1', 'purchase,inward,inward/view,inward/pending,stockmaster,daily_stockreports,customer/view', 'Purchase,Inward,Inward,Inward,Stock,Stock,Reports', 'Purchase Receipt,Add Inward,Inward Reports,Inward Pending,Add Stock,Daily Stock Reports,Party Reports', 1, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (6, 'U', '2018-05-02', 'Accounts', 'Accounts Team', '', '', '1970-01-01', 'Accounts', '123456', '1', 'invoice_statement/view,tax/view,cashbill/listing,purchase_statement/view,purchasetax/view,voucher,voucher/reports,stockmaster,daily_stockreports,itemwise_report,expenses/reports,quotation/view', 'Sales Invoice,Sales Invoice,Cash Bill,Purchase,Purchase,Voucher,Voucher,Stock,Stock,Stock,Reports,Reports', 'Invoice Party Statement,Invoice Tax Reports,Cash Bill Reports,Purchase Party Statement,Purchase Tax Reports,Add Voucher,Voucher Reports,Add Stock,Daily Stock Reports,Itemwise Reports,Expenses Reports,Quotation Reports', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (7, 'U', '2018-08-10', 'ramesh', 'developer', '', '', '1970-01-01', 'ramesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/reports,purchase_statement/view,purchasetax/view,stockmaster,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Stock,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Add Stock,Add Item', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (8, 'U', '2018-08-10', 'tester1', 'testing', '', '', '1970-01-01', 'tester1', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/view,purchase_statement/view,purchasetax/view,taxtype,uom,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Settings,Settings,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Tax Type,Add UOM,Add Item', 1, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (9, 'U', '2021-06-28', 'parmesh', 'developer', 'pshm956@gmail.com', '8344031191', '2021-06-28', 'parmesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,proforma_invoice/view', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Proforma Invoice Reports', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (10, 'U', '2023-09-12', 'jp', 'quotation', 'jp@idreamdevelopers.com', '7810028222', '2023-09-12', 'jp', '123456', '1', 'taxtype,uom,itemmaster,headers,profile,backup,support,usermaster', 'Settings,Settings,Settings,Settings,Settings,Settings,Settings,Settings', 'Tax Type,Add UOM,Add Item,Account Headers,Company Profile,Backup Settings,Support,User Manager', 1, 1, 1);


#
# TABLE STRUCTURE FOR: materialdc_delivery
#

DROP TABLE IF EXISTS `materialdc_delivery`;

CREATE TABLE `materialdc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: materialdc_details
#

DROP TABLE IF EXISTS `materialdc_details`;

CREATE TABLE `materialdc_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: materialdc_details_backup
#

DROP TABLE IF EXISTS `materialdc_details_backup`;

CREATE TABLE `materialdc_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: po_party_statements
#

DROP TABLE IF EXISTS `po_party_statements`;

CREATE TABLE `po_party_statements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (2, '2025-04-25', '2025-04-25', '-', 'P', 18, 'kee Enterprises', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', NULL, '8850.00', '-', '-', '-', NULL, '-', '143350', NULL, '-', '-', '-', '-', '-', '8850.00', '-', NULL, '-', NULL, '8850.00', NULL, '001', '2025-04-25', '1', 'P250425', 'P-2025', '2');


#
# TABLE STRUCTURE FOR: po_party_statements_backup
#

DROP TABLE IF EXISTS `po_party_statements_backup`;

CREATE TABLE `po_party_statements_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (1, '2023-08-18', '2023-08-18', '-', 'P001', 2, 'J.K INDUSTRIES', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', NULL, '200000.00', '-', '-', '-', NULL, '-', '200000', NULL, '-', '-', '-', '-', '-', '200000.00', '-', NULL, '-', NULL, '200000.00', NULL, 'IN_001', '2023-08-18', '1', 'P001180823', 'P001-2023', '1');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (2, '2023-08-23', NULL, 'V/23-24/-002', NULL, 0, 'J.K INDUSTRIES', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '175000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Cash', NULL, '25000', NULL, '-', NULL, '-', NULL, '1', NULL, NULL, NULL);
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (3, '2023-08-23', NULL, 'V/23-24/-004', NULL, 0, 'J.K INDUSTRIES', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '165000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Cheque INDIAN BANK 563966', NULL, '10000', NULL, '-', NULL, '-', NULL, '1', NULL, NULL, NULL);
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (4, '2023-10-03', '2023-10-03', '-', 'P0002', 2, 'J.K INDUSTRIES', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', NULL, '17700.00', '-', '-', '-', NULL, '-', '182700', NULL, '-', '-', '-', '-', '-', '17700.00', '-', NULL, '-', NULL, '17700.00', NULL, 'IN_007', '2023-10-03', '1', 'P0002031023', 'P0002-2023', '2');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (5, '2023-11-08', '2023-11-08', '-', 'P0003', 3, 'RK Industries', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', NULL, '177000.00', '-', '-', '-', NULL, '-', '177000', NULL, '-', '-', '-', '-', '-', '177000.00', '-', NULL, '-', NULL, '177000.00', NULL, '004', '2023-11-08', '1', 'P0003081123', 'P0003-2023', '3');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (6, '2023-11-20', '2023-11-20', '-', 'P0004', 2, 'J.K INDUSTRIES', NULL, NULL, 'Air Compressor Motor ', NULL, '55000.00', '-', '-', '-', NULL, '-', '237700', NULL, '-', '-', '-', '-', '-', '55000.00', '-', NULL, '-', NULL, '55000.00', NULL, '0045', '2023-11-20', '1', 'P0004201123', 'P0004-2023', '4');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (7, '2023-11-20', '2023-11-20', '-', 'P0005', 2, 'J.K INDUSTRIES', NULL, NULL, 'Air Compressor Motor ', NULL, '45000.00', '-', '-', '-', NULL, '-', '282700', NULL, '-', '-', '-', '-', '-', '45000.00', '-', NULL, '-', NULL, '45000.00', NULL, '0046', '2023-11-20', '1', 'P0005201123', 'P0005-2023', '5');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (8, '2023-11-24', '2023-11-24', '-', 'P0006', 2, 'J.K INDUSTRIES', NULL, NULL, 'Air Compressor Motor ', NULL, '47500.00', '-', '-', '-', NULL, '-', '330200', NULL, '-', '-', '-', '-', '-', '47500.00', '-', NULL, '-', NULL, '47500.00', NULL, 'B00001', '2023-11-24', '1', 'P0006241123', 'P0006-2023', '6');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (9, '2024-02-12', '2024-02-12', '-', 'P0007', 10, 'ATOMBERG TECHNOLOGY PVT', NULL, NULL, '26CL ROTOR', NULL, '112.00', '-', '-', '-', NULL, '-', '112', NULL, '-', '-', '-', '-', '-', '112.00', '-', NULL, '-', NULL, '112.00', NULL, '12', '2024-02-12', '1', 'P0007120224', 'P0007-2024', '7');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (10, '2024-03-04', NULL, 'V/23-24/-007', NULL, 0, 'J.K INDUSTRIES', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '200', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Cash', NULL, '330000', NULL, '-', NULL, '-', NULL, '1', NULL, NULL, NULL);
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (11, '2024-03-25', '2024-03-25', '-', 'P008', 0, 'ATOMBERG TECHNOLOGY PVT', NULL, NULL, 'Compressor||1080R2-2PM STATOR STAMPING-GANG', NULL, '9900.00', '-', '-', '-', NULL, '-', '10012', NULL, '-', '-', '-', '-', '-', '7200.00||2700.00', '-', NULL, '-', NULL, '9900.00', NULL, 'IN006', '2024-03-25', '1', NULL, NULL, '8');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (12, '2024-03-25', NULL, 'V/23-24/-009', NULL, 0, 'ATOMBERG TECHNOLOGY PVT', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '3012', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Cash', NULL, '7000', NULL, '-', NULL, '-', NULL, '1', NULL, NULL, NULL);
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (13, '2024-07-01', '2024-07-01', '-', 'P001', 2, 'J.K INDUSTRIES', NULL, NULL, 'Air Compressor Motor ', NULL, '59000.00', '-', '-', '-', NULL, '-', '59000', NULL, '-', '-', '-', '-', '-', '59000.00', '-', NULL, '-', NULL, '59000.00', NULL, '1224', '2024-07-01', '1', 'P001010724', 'P001-2024', '1');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (14, '2024-07-11', '2024-07-03', '-', 'P0002', 16, 'STAR GEARS', NULL, NULL, 'AC', NULL, '11800.00', '-', '-', '-', NULL, '-', '11800', NULL, '-', '-', '-', '-', '-', '11800.00', '-', NULL, '-', NULL, '11800.00', NULL, '121', '2024-07-11', '1', 'P0002030724', 'P0002-2024', '2');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (15, '2024-08-20', '2024-08-20', '-', 'P0003', 10, 'ATOMBERG TECHNOLOGY PVT', NULL, NULL, 'Air Compressor Motor ', NULL, '5900.00', '-', '-', '-', NULL, '-', '5900', NULL, '-', '-', '-', '-', '-', '5900.00', '-', NULL, '-', NULL, '5900.00', NULL, '001', '2024-08-20', '1', 'P0003200824', 'P0003-2024', '3');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (16, '2024-08-20', NULL, 'V/23-24/-011', NULL, 0, 'ATOMBERG TECHNOLOGY PVT', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '2900', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Cash', NULL, '3000', NULL, '-', NULL, '-', NULL, '1', NULL, NULL, NULL);
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (17, '2024-08-24', '2024-08-24', '-', 'P0004', 0, 'd', NULL, NULL, 'AC', NULL, '10000.00', '-', '-', '-', NULL, '-', '10000', NULL, '-', '-', '-', '-', '-', '10000.00', '-', NULL, '-', NULL, '10000.00', NULL, '001', '2024-08-24', '1', 'P0004240824', 'P0004-2024', '4');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (18, '2024-08-24', '2024-08-24', '-', 'P0005', 0, ',,m', NULL, NULL, 'Air Compressor Motor ', NULL, '50000000.00', '-', '-', '-', NULL, '-', '50000000', NULL, '-', '-', '-', '-', '-', '50000000.00', '-', NULL, '-', NULL, '50000000.00', NULL, '89', '2024-08-24', '1', 'P0005240824', 'P0005-2024', '5');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (19, '2024-08-24', '2024-08-24', '-', 'P006', 0, 'RK Industries', NULL, NULL, 'BLACK PAINT', NULL, '19000.00', '-', '-', '-', NULL, '-', '19000', NULL, '-', '-', '-', '-', '-', '19000.00', '-', NULL, '-', NULL, '19000.00', NULL, '0035', '2024-08-24', '1', NULL, NULL, '7');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (20, '2024-08-24', '2024-08-24', '-', 'P0007', 3, 'RK Industries', NULL, NULL, 'BLACK PAINT', NULL, '11210.00', '-', '-', '-', NULL, '-', '30210', NULL, '-', '-', '-', '-', '-', '11210.00', '-', NULL, '-', NULL, '11210.00', NULL, '036', '2024-08-24', '1', 'P0007240824', 'P0007-2024', '8');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (21, '2024-09-04', '2024-09-04', '-', 'P0008', 3, 'RK Industries', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', NULL, '15013.00', '-', '-', '-', NULL, '-', '45223', NULL, '-', '-', '-', '-', '-', '14160.00', '-', NULL, '-', NULL, '15013.00', NULL, 'po1', '2024-09-04', '1', 'P0008040924', 'P0008-2024', '9');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (22, '2024-09-04', '2024-09-04', '-', 'P0009', 18, 'kee Enterprises', NULL, NULL, 'Oversized Tshirt', NULL, '122700.00', '-', '-', '-', NULL, '-', '122700', NULL, '-', '-', '-', '-', '-', '118000.00', '-', NULL, '-', NULL, '122700.00', NULL, 'IN001', '2024-09-04', '1', 'P0009040924', 'P0009-2024', '10');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (23, '2025-02-06', '2025-02-06', '-', 'P0010', 10, 'ATOMBERG TECHNOLOGY PVT', NULL, NULL, 'Air Compressor Motor ', NULL, '59030.00', '-', '-', '-', NULL, '-', '61930', NULL, '-', '-', '-', '-', '-', '59000.00', '-', NULL, '-', NULL, '59030.00', NULL, '1006', '2025-02-06', '1', 'P0010060225', 'P0010-2025', '11');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (24, '2025-02-06', '2025-02-06', '-', 'P011', 0, 'STAR GEARS', NULL, NULL, 'BLACK PAINT', NULL, '5605.00', '-', '-', '-', NULL, '-', '17405', NULL, '-', '-', '-', '-', '-', '5605.00', '-', NULL, '-', NULL, '5605.00', NULL, '1009', '2025-02-06', '1', NULL, NULL, '12');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (25, '2025-02-06', NULL, 'V/23-24/-014', NULL, 0, 'ATOMBERG TECHNOLOGY PVT', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '60430', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Cash', NULL, '1500', NULL, '-', NULL, '-', NULL, '1', NULL, NULL, NULL);
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (26, '2025-02-06', '2025-02-06', '-', 'P0012', 18, 'kee Enterprises', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', NULL, '11800.00', '-', '-', '-', NULL, '-', '134500', NULL, '-', '-', '-', '-', '-', '11800.00', '-', NULL, '-', NULL, '11800.00', NULL, '001', '2025-02-06', '1', 'P0012060225', 'P0012-2025', '13');
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (27, '2025-02-26', NULL, 'V/23-24/-016', NULL, 0, 'RK Industries', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '3223', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Bank dbs', NULL, '42000', NULL, '-', NULL, '-', NULL, '1', NULL, NULL, NULL);
INSERT INTO `po_party_statements_backup` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (28, '2025-02-26', '2025-02-26', '-', 'P0013', 3, 'RK Industries', NULL, NULL, 'Air Compressor Motor ||raw material', NULL, '54500.00', '-', '-', '-', NULL, '-', '57723', NULL, '-', '-', '-', '-', '-', '54500.00||', '-', NULL, '-', NULL, '54500.00', NULL, '1236', '2025-02-26', '1', 'P0013260225', 'P0013-2025', '14');


#
# TABLE STRUCTURE FOR: preference_details
#

DROP TABLE IF EXISTS `preference_details`;

CREATE TABLE `preference_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `sed` varchar(255) DEFAULT NULL,
  `edc` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: preference_settings
#

DROP TABLE IF EXISTS `preference_settings`;

CREATE TABLE `preference_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotationPrefix` varchar(255) NOT NULL,
  `quotation` varchar(255) NOT NULL,
  `expenses` varchar(255) NOT NULL,
  `expensePrefix` varchar(255) NOT NULL,
  `dc` varchar(255) NOT NULL,
  `voucherPrefix` varchar(255) NOT NULL,
  `voucher` varchar(255) NOT NULL,
  `debitPrefix` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `creditPrefix` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `purchasePrefix` varchar(255) NOT NULL,
  `purchase` varchar(255) NOT NULL,
  `invoicePrefix` varchar(255) NOT NULL,
  `invoice` varchar(255) NOT NULL,
  `salesdcPrefix` varchar(255) NOT NULL,
  `materialdcPrefix` varchar(255) NOT NULL,
  `jobdcPrefix` varchar(255) NOT NULL,
  `proforma_invoicePrefix` varchar(255) NOT NULL,
  `proforma_invoice` varchar(255) NOT NULL,
  `inwardPrefix` varchar(255) NOT NULL,
  `inward` varchar(255) NOT NULL,
  `cashbillPrefix` varchar(255) NOT NULL,
  `cashbill_invoice` varchar(255) NOT NULL,
  `creditnote` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) NOT NULL,
  `supplierpurchaseorder` varchar(100) NOT NULL,
  `jobworkdc` varchar(255) DEFAULT NULL,
  `materialdc` varchar(255) DEFAULT NULL,
  `cmp_companyname` varchar(255) NOT NULL,
  `cmp_phoneno` varchar(255) NOT NULL,
  `cmp_mobileno` varchar(255) NOT NULL,
  `cmp_address1` varchar(255) NOT NULL,
  `cmp_address2` varchar(255) NOT NULL,
  `cmp_city` varchar(255) NOT NULL,
  `cmp_pincode` varchar(255) NOT NULL,
  `cmp_stateCode` varchar(255) NOT NULL,
  `cmp_website` varchar(255) NOT NULL,
  `cmp_emailid` varchar(255) NOT NULL,
  `cmp_logo` varchar(255) NOT NULL,
  `cont_companyname` varchar(255) NOT NULL,
  `cont_phoneno` varchar(255) NOT NULL,
  `cont_mobileno` varchar(255) NOT NULL,
  `cont_address1` varchar(255) NOT NULL,
  `cont_address2` varchar(255) NOT NULL,
  `cont_city` varchar(255) NOT NULL,
  `cont_pincode` varchar(255) NOT NULL,
  `cont_stateCode` varchar(255) NOT NULL,
  `cont_website` varchar(255) NOT NULL,
  `cont_emailid` varchar(255) NOT NULL,
  `cont_logo` varchar(255) NOT NULL,
  `discountBy` varchar(255) NOT NULL,
  `invoiceBy` varchar(255) NOT NULL,
  `itemType` varchar(255) NOT NULL,
  `bill_type` varchar(255) DEFAULT NULL,
  `quot_bill_type` varchar(255) DEFAULT NULL,
  `voucher_receivable` varchar(255) DEFAULT NULL,
  `voucher_payable` varchar(255) DEFAULT NULL,
  `last_backup` date NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `inward_add` varchar(255) NOT NULL,
  `cashbill_add` varchar(255) NOT NULL,
  `cashbill_tax_type` varchar(255) NOT NULL,
  `priceType` varchar(255) DEFAULT NULL,
  `priceType1` varchar(255) DEFAULT NULL,
  `sales_dc` int(11) NOT NULL,
  `material_dc` int(11) NOT NULL,
  `jobwork_dc` int(11) NOT NULL,
  `cpo_type` varchar(255) NOT NULL,
  `spo_type` varchar(255) NOT NULL,
  `proforma_type` varchar(255) NOT NULL,
  `attendance` int(11) NOT NULL,
  `status` int(10) NOT NULL,
  `einvoice` int(11) NOT NULL,
  `eway` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `preference_settings` (`id`, `quotationPrefix`, `quotation`, `expenses`, `expensePrefix`, `dc`, `voucherPrefix`, `voucher`, `debitPrefix`, `debit`, `creditPrefix`, `credit`, `purchasePrefix`, `purchase`, `invoicePrefix`, `invoice`, `salesdcPrefix`, `materialdcPrefix`, `jobdcPrefix`, `proforma_invoicePrefix`, `proforma_invoice`, `inwardPrefix`, `inward`, `cashbillPrefix`, `cashbill_invoice`, `creditnote`, `purchaseorder`, `supplierpurchaseorder`, `jobworkdc`, `materialdc`, `cmp_companyname`, `cmp_phoneno`, `cmp_mobileno`, `cmp_address1`, `cmp_address2`, `cmp_city`, `cmp_pincode`, `cmp_stateCode`, `cmp_website`, `cmp_emailid`, `cmp_logo`, `cont_companyname`, `cont_phoneno`, `cont_mobileno`, `cont_address1`, `cont_address2`, `cont_city`, `cont_pincode`, `cont_stateCode`, `cont_website`, `cont_emailid`, `cont_logo`, `discountBy`, `invoiceBy`, `itemType`, `bill_type`, `quot_bill_type`, `voucher_receivable`, `voucher_payable`, `last_backup`, `itemcode`, `inward_add`, `cashbill_add`, `cashbill_tax_type`, `priceType`, `priceType1`, `sales_dc`, `material_dc`, `jobwork_dc`, `cpo_type`, `spo_type`, `proforma_type`, `attendance`, `status`, `einvoice`, `eway`) VALUES (1, 'Q', '', '001', 'E', '', 'V/25-26/-', '', 'D', '001', 'C', '001', 'P', '', 'INV/25-26/-', '', 'SDC/25-26/-', 'MDC/25-26/-', 'PDC/25-26/', 'PI/25-26/', '', 'I', '', 'CB', '001', NULL, '001', '001', '001', '001', 'Myoffice Solutions', '7373333321', '8608701222', ' #91 Dr. Jaganathan Nagar', 'Civil Aerodrome Post, Coimbatore', 'Coimbatore', '641014', '33', 'www.idreamdevelopers.org', 'info@idreamdevelopers.com', '12832299_1579401915712151_5416626780361493206_n.png', 'IDREAMDEVELOPERS', '7373333321', '8608701333', ' #91 Dr. Jaganathan Nagar', 'Civil Aerodrome Post, Coimbatore', 'Coimbatore', '641014', '33', 'www.idreamdevelopers.com', 'info@idreamdevelopers.com', 'idream_logo.PNG', 'amount_wise', 'without_stock', 'with_item', 'Overall Tax', 'Overall Tax', 'Against Invoice', 'Against Purchase', '2025-03-01', '1', 'With Inward', 'With Cashbill', 'Overall Tax', '0', '0', 1, 0, 3, 'Overall Tax', 'Overall Tax', 'Overall Tax', 0, 1, 1, 1);


#
# TABLE STRUCTURE FOR: profile
#

DROP TABLE IF EXISTS `profile`;

CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `companyname` varchar(255) DEFAULT NULL,
  `softwarename` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `stateCode` varchar(255) NOT NULL,
  `emailid` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `gstin` varchar(225) DEFAULT NULL,
  `aadharno` varchar(225) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `bankname` varchar(255) DEFAULT NULL,
  `accountno` varchar(255) DEFAULT NULL,
  `bankbranch` varchar(255) DEFAULT NULL,
  `ifsccode` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `profile` (`id`, `date`, `companyname`, `softwarename`, `mobileno`, `phoneno`, `address1`, `address2`, `city`, `pincode`, `stateCode`, `emailid`, `website`, `tinno`, `cstno`, `gstin`, `aadharno`, `status`, `username`, `password`, `bankname`, `accountno`, `bankbranch`, `ifsccode`, `state`) VALUES (1, NULL, 'MYOFFICE ERP', 'MYOFFICE ERP', '8608701222', '7373333321', '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp', 'Avinashi Road, Hopes College', 'Coimbatore', '560001', 'Karnataka', 'info@idreamdevelopers.com', '', '12345', '54321', '29AABCT1332L000', '', '1', 'admin', 'admin001', '', '', '', '', NULL);


#
# TABLE STRUCTURE FOR: proforma_invoice_details
#

DROP TABLE IF EXISTS `proforma_invoice_details`;

CREATE TABLE `proforma_invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `proforma_invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (1, '2025-04-25', '2025-04-25', '', '2025-04-25', 'PI/23-24/001', NULL, 'Sales Invoice', NULL, 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '5', '7500.00', '0', 'amount_wise', '0', '7500.00', '9', '675.00', '9', '675.00', '18', '', NULL, '7500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '8850.00', 'PI/23-24/001250425', 'PI/23-24/001-2025', 1, 1);


#
# TABLE STRUCTURE FOR: proforma_invoice_details_backup
#

DROP TABLE IF EXISTS `proforma_invoice_details_backup`;

CREATE TABLE `proforma_invoice_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) NOT NULL,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `proforma_invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (1, '2023-08-22', '2023-08-22', '002', '2023-08-22', 'PI/23-24/001', NULL, '', NULL, 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '7204', '', '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '100', '200000.00', '0', 'percent_wise', '0.00', '200000.00', '9', '18000.00', '9', '18000.00', '18', '', NULL, '200000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '236000.00', 'PI/23-24/001220823', 'PI/23-24/001-2023', 1, 1);
INSERT INTO `proforma_invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (2, '2023-08-22', '2023-08-22', '002', '2023-08-22', 'PI/23-24/002', NULL, '', NULL, 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '7204', '', '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '100', '200000.00', '0', 'percent_wise', '0.00', '200000.00', '9', '18000.00', '9', '18000.00', '18', '', NULL, '200000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '236000.00', 'PI/23-24/002220823', 'PI/23-24/002-2023', 1, 1);
INSERT INTO `proforma_invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (3, '2023-08-22', '2023-08-22', '002', '2023-08-22', 'PI/23-24/002', NULL, '', NULL, 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '7204', '', '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '100', '200000.00', '0', 'percent_wise', '0.00', '200000.00', '9', '18000.00', '9', '18000.00', '18', '', NULL, '200000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '236000.00', 'PI/23-24/002220823', 'PI/23-24/002-2023', 1, 1);
INSERT INTO `proforma_invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (4, '2023-08-22', '2023-08-22', '002', '2023-08-22', 'PI/23-24/003', NULL, '', NULL, 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '7204', '', '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '150', '300000.00', '0', 'percent_wise', '0.00', '300000.00', '9', '27000.00', '9', '27000.00', '18', '', NULL, '300000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '354000.00', 'PI/23-24/003220823', 'PI/23-24/003-2023', 1, 1);
INSERT INTO `proforma_invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (5, '2023-11-30', '2023-11-30', '002', '2023-11-30', 'PI/23-24/004', NULL, '', NULL, 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', '', '', 'TN 37 v7993', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '1002', '', 'drilling machine', '', 'KGS', '1500', '10', '15000.00', '0', 'percent_wise', '0.00', '15000.00', '9', '1350.00', '9', '1350.00', '18', '', NULL, '15000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '17700.00', 'PI/23-24/004301123', 'PI/23-24/004-2023', 1, 1);
INSERT INTO `proforma_invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (6, '2024-04-02', '2024-04-02', '', '2024-04-02', 'PI/23-24/001', NULL, '', NULL, 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '1002', '', 'drilling machine', '', 'KGS', '1500', '14', '21000.00', '0', 'percent_wise', '0.00', '21000.00', '9', '1890.00', '9', '1890.00', '18', '', NULL, '21000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '24780.00', 'PI/23-24/001020424', 'PI/23-24/001-2024', 1, 1);
INSERT INTO `proforma_invoice_details_backup` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (7, '2024-04-02', '2024-04-02', '', '2024-04-02', 'PI/23-24/002', NULL, '', NULL, 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '1002', '', 'drilling machine', '', 'KGS', '1500', '15', '22500.00', '0', 'percent_wise', '0.00', '22500.00', '9', '2025.00', '9', '2025.00', '18', '', NULL, '22500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '26550.00', 'PI/23-24/002020424', 'PI/23-24/002-2024', 1, 1);


#
# TABLE STRUCTURE FOR: proforma_invoice_reports
#

DROP TABLE IF EXISTS `proforma_invoice_reports`;

CREATE TABLE `proforma_invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2025-04-25', 'PI/23-24/001', '2025-04-25', NULL, NULL, 1, 'IDREAMDEVELOPERS', NULL, NULL, NULL, '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '2025-04-25', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '5', 'KGS', NULL, NULL, '7500.00', NULL, NULL, '8850.00', NULL, NULL, '1', 'PI/23-24/001-2025', 'PI/23-24/001250425', '1');


#
# TABLE STRUCTURE FOR: proinvoice_party_statement
#

DROP TABLE IF EXISTS `proinvoice_party_statement`;

CREATE TABLE `proinvoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `proinvoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '-', '-', NULL, '2025-04-25', 'PI/23-24/001', 1, 'IDREAMDEVELOPERS', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2025-04-25', '2025-04-25', '8850.00', '-', '-', '', '', '-', '-', NULL, '-13800.01', '-', '-', '-', '-', '8850.00', '-', '8850.00', NULL, NULL, 'PI/23-24/001-2025', 'PI/23-24/001250425', '1');


#
# TABLE STRUCTURE FOR: purchase_collection
#

DROP TABLE IF EXISTS `purchase_collection`;

CREATE TABLE `purchase_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `date_po` date NOT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) NOT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `currentlypaid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchase_details
#

DROP TABLE IF EXISTS `purchase_details`;

CREATE TABLE `purchase_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchasetype` varchar(100) NOT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (2, '2025-04-25', '2025-04-25', '2025-04-25', 'Direct Purchase', 'P', 18, 'kee Enterprises', '43,Ram nagar Street, Devakottai, devakottai, Tamil Nadu', '001', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '1500', '5', '7500.00', '0', 'amount_wise', '0', '7500.00', '9', '675.00', '9', '675.00', '18', '1350.00', '8850.00', '8850.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '8850.00', 'P250425', 'P-2025', 1, '8850.00', 1, 1);


#
# TABLE STRUCTURE FOR: purchase_details_backup
#

DROP TABLE IF EXISTS `purchase_details_backup`;

CREATE TABLE `purchase_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (1, '2023-08-18', '2023-08-18', '2023-08-18', 'P001', 2, 'J.K INDUSTRIES', 'CHERAN NAGAR, Ganapathy, Coimbatore, Tamil Nadu', 'IN_001', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1000', '200', '200000.00', '0', 'percent_wise', '0.00', '200000.00', '', '', '', '', '', '', '200000.00', '200000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '200000.00', 'P001180823', 'P001-2023', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (2, '2023-10-03', '2023-10-03', '2023-10-03', 'P002', 2, 'J.K INDUSTRIES', 'CHERAN NAGAR, Ganapathy, Coimbatore, Tamil Nadu', 'IN_007', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '1500', '10', '15000.00', '0', 'percent_wise', '0.00', '15000.00', '9', '1350.00', '9', '1350.00', '18', '2700.00', '17700.00', '17700.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '17700.00', 'P0002031023', 'P0002-2023', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (3, '2023-11-08', '2023-11-08', '2023-11-08', 'P003', 3, 'RK Industries', 'Avarampalayam, VOC Nagar, Coimbatore, Tamil Nadu', '004', 'interstate', 'interstate', '', '', 'igst', '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '1500', '100', '150000.00', '0', 'percent_wise', '0.00', '150000.00', '9', '13500.00', '9', '13500.00', '18', '27000.00', '177000.00', '177000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '177000.00', 'P0003081123', 'P0003-2023', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (4, '2023-11-20', '2023-11-20', '2023-11-20', 'P004', 2, 'J.K INDUSTRIES', 'CHERAN NAGAR, Ganapathy, Coimbatore, Tamil Nadu', '0045', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '01', NULL, 'Air Compressor Motor ', 'KGS', '5000', '11', '46610.17', '0', 'percent_wise', '55000', '55000.00', '9', '4194.92', '9', '4194.92', '18', '8389.83', '55000.00', '55000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '55000.00', 'P0004201123', 'P0004-2023', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (5, '2023-11-20', '2023-11-20', '2023-11-20', 'P005', 2, 'J.K INDUSTRIES', 'CHERAN NAGAR, Ganapathy, Coimbatore, Tamil Nadu', '0046', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '01', NULL, 'Air Compressor Motor ', 'KGS', '5000', '9', '41284.40', '0', 'percent_wise', '45000', '45000.00', '9', '1857.80', '9', '1857.80', '9', '3715.60', '45000.00', '45000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '45000.00', 'P0005201123', 'P0005-2023', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (6, '2023-11-24', '2023-11-24', '2023-11-24', 'P006', 2, 'J.K INDUSTRIES', 'CHERAN NAGAR, Ganapathy, Coimbatore, Tamil Nadu', 'B00001', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '01', NULL, 'Air Compressor Motor ', 'KGS', '5000', '10', '43577.98', '05', 'percent_wise', '47500', '47500.00', '9', '1961.01', '9', '1961.01', '9', '3922.02', '47500.00', '47500.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '47500.00', 'P0006241123', 'P0006-2023', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (7, '2024-02-12', '2024-02-12', '2024-02-12', 'P007', 10, 'ATOMBERG TECHNOLOGY PVT', 'MUMBAI, MUMBAI, mumbai, Maharashtra', '12', 'interstate', 'interstate', '', '', 'igst', '8503', NULL, '26CL ROTOR', 'NOS', '10', '10', '100.00', '0', 'percent_wise', '0.00', '100.00', '6', '6.00', '6', '6.00', '12', '12.00', '112.00', '112.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '112.00', 'P0007120224', 'P0007-2024', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (8, '2024-03-25', '2024-03-25', '2024-03-25', 'P008', 10, 'ATOMBERG TECHNOLOGY PVT', 'MUMBAI, MUMBAI, mumbai, Maharashtra', 'IN006', 'interstate', 'interstate', '', '', 'igst', '1001||7204', '0||', 'Compressor||1080R2-2PM STATOR STAMPING-GANG', 'KGS||KGS', '900||180', '8||15', '7200.00||2700.00', '0||0', 'percent_wise', '0.00||0.00', '7200.00||2700.00', '9||9', '648.00||243.00', '9||9', '648.00||243.00', '9||9', '720.00||2700.00', '7200.00||2700.00', '9900.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '9900.00', 'P0008250324', 'P0008-2024', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (9, '2024-07-01', '2024-07-01', '2024-07-01', 'P001', 2, 'J.K INDUSTRIES', 'CHERAN NAGAR, Ganapathy, Coimbatore, Tamil Nadu', '1224', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '01', NULL, 'Air Compressor Motor ', 'KGS', '5000', '10', '50000.00', '0', 'percent_wise', '0.00', '50000.00', '9', '4500.00', '9', '4500.00', '18', '9000.00', '59000.00', '59000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '59000.00', 'P001010724', 'P001-2024', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (10, '2024-07-03', '2024-07-03', '2024-07-11', 'P002', 16, 'STAR GEARS', 'CBE, CBE, CBE, Tamil Nadu', '121', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '124', NULL, 'AC', 'NOS', '1000', '010', '10000.00', '0', 'percent_wise', '0.00', '10000.00', '9', '900.00', '9', '900.00', '18', '1800.00', '11800.00', '11800.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '11800.00', 'P0002030724', 'P0002-2024', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (11, '2024-08-20', '2024-08-20', '2024-08-20', 'P003', 10, 'ATOMBERG TECHNOLOGY PVT', 'MUMBAI, MUMBAI, mumbai, Maharashtra', '001', 'interstate', 'interstate', '', '', 'igst', '01', NULL, 'Air Compressor Motor ', 'KGS', '5000', '1', '5000.00', '0', 'percent_wise', '0.00', '5000.00', '9', '450.00', '9', '450.00', '18', '900.00', '5900.00', '5900.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '5900.00', 'P0003200824', 'P0003-2024', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (12, '2024-08-24', '2024-08-24', '2024-08-24', 'P004', 0, 'd', 'd', '001', '', '', NULL, NULL, NULL, '124', NULL, 'AC', 'NOS', '1000', '10', '10000.00', '0', 'percent_wise', '0.00', '10000.00', '9', '', '9', '', '18', '', '10000.00', '10000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '10000.00', 'P0004240824', 'P0004-2024', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (13, '2024-08-24', '2024-08-24', '2024-08-24', 'P005', 0, ',,m', 'f', '89', '', '', NULL, NULL, NULL, '01', NULL, 'Air Compressor Motor ', 'KGS', '5000', '10000', '50000000.00', '0', 'percent_wise', '0.00', '50000000.00', '9', '', '9', '', '18', '', '50000000.00', '50000000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '50000000.00', 'P0005240824', 'P0005-2024', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (14, '2024-08-24', '2024-08-24', '2024-08-24', 'P006', 3, 'RK Industries', 'Avarampalayam, VOC Nagar, Coimbatore, Tamil Nadu', '0035', 'interstate', 'interstate', '', '', 'igst', '002', '0', 'BLACK PAINT', 'lITRE', '950', '20', '19000.00', '0', 'percent_wise', '0.00', '19000.00', '9', '1710.00', '9', '1710.00', '18', '2565.00', '19000.00', '19000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '19000.00', 'P0006240824', 'P0006-2024', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (15, '2024-08-24', '2024-08-24', '2024-08-24', 'P007', 3, 'RK Industries', 'Avarampalayam, VOC Nagar, Coimbatore, Tamil Nadu', '036', 'interstate', 'interstate', '', '', 'igst', '002', NULL, 'BLACK PAINT', 'lITRE', '950', '10', '9500.00', '0', 'percent_wise', '0.00', '9500.00', '9', '855.00', '9', '855.00', '18', '1710.00', '11210.00', '11210.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '11210.00', 'P0007240824', 'P0007-2024', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (16, '2024-09-04', '2024-09-04', '2024-09-04', 'P008', 3, 'RK Industries', 'Avarampalayam, VOC Nagar, Coimbatore, Tamil Nadu', 'po1', 'interstate', 'interstate', '', '', 'igst', '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', 'KGS', '2000', '06', '12000.00', '0', 'percent_wise', '0.00', '12000.00', '9', '1080.00', '9', '1080.00', '18', '2160.00', '14160.00', '15013.00', '230', '5', '11.50', '5', '11.50', '10', '23.00', '253.00', '500', '10', '50.00', '10', '50.00', '20', '100.00', '600.00', '0', '0', '1', '15013.00', 'P0008040924', 'P0008-2024', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (17, '2024-09-04', '2024-09-04', '2024-09-04', 'P009', 18, 'kee Enterprises', '43,Ram nagar Street, Devakottai, devakottai, Tamil Nadu', 'IN001', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '32123212', NULL, 'Oversized Tshirt', 'piece', '100', '1000', '100000.00', '0', 'percent_wise', '0.00', '100000.00', '9', '9000.00', '9', '9000.00', '18', '18000.00', '118000.00', '122640.00', '2000', '8', '160.00', '8', '160.00', '16', '320.00', '2320.00', '2000', '8', '160.00', '8', '160.00', '16', '320.00', '2320.00', '0', '60', '1', '122700.00', 'P0009040924', 'P0009-2024', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (18, '2025-02-06', '2025-02-06', '2025-02-06', 'P010', 10, 'ATOMBERG TECHNOLOGY PVT', 'MUMBAI, MUMBAI, mumbai, Maharashtra', '1006', 'interstate', 'interstate', '', '', 'igst', '01', NULL, 'Air Compressor Motor ', 'KGS', '5000', '10', '50000.00', '0', 'percent_wise', '0.00', '50000.00', '9', '4500.00', '9', '4500.00', '18', '9000.00', '59000.00', '59030.00', '15', '0', '0.00', '0', '0.00', '0', '0.00', '15.00', '15', '0', '0.00', '0', '0.00', '0', '0.00', '15.00', '0', '0', '1', '59030.00', 'P0010060225', 'P0010-2025', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (19, '2025-02-06', '2025-02-06', '2025-02-06', 'P011', 16, 'STAR GEARS', 'CBE, CBE, CBE, Tamil Nadu', '1009', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '002', '0', 'BLACK PAINT', 'lITRE', '950', '5', '4750.00', '0', 'percent_wise', '0.00', '4750.00', '9', '427.50', '9', '427.50', '18', '3420.00', '5605.00', '5605.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '5605.00', 'P0011060225', 'P0011-2025', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (20, '2025-02-06', '2025-02-06', '2025-02-06', 'P012', 18, 'kee Enterprises', '43,Ram nagar Street, Devakottai, devakottai, Tamil Nadu', '001', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '1000', '10', '10000.00', '0', 'percent_wise', '0.00', '10000.00', '9', '900.00', '9', '900.00', '18', '1800.00', '11800.00', '11800.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '11800.00', 'P0012060225', 'P0012-2025', 1, NULL, NULL, 1);
INSERT INTO `purchase_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (21, '2025-02-26', '2025-02-26', '2025-02-26', 'P013', 3, 'RK Industries', 'Avarampalayam, VOC Nagar, Coimbatore, Tamil Nadu', '1236', 'interstate', 'interstate', '', '', 'igst', '01||', NULL, 'Air Compressor Motor ||raw material', 'KGS||', '5000||', '10||10', '50000.00||', '0||0', 'percent_wise', '0.00||', '50000.00||', '9||', '4500.00||', '9||', '4500.00||', '9||', '4500.00||', '54500.00||', '54500.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '54500.00', 'P0013260225', 'P0013-2025', 1, NULL, NULL, 1);


#
# TABLE STRUCTURE FOR: purchase_reports
#

DROP TABLE IF EXISTS `purchase_reports`;

CREATE TABLE `purchase_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (1, '1', '2025-03-08', 'P001', '2025-03-08', NULL, 23, 'winner equipments', 'PALLAPATI, PALLAPATI, SALEM, Tamil Nadu', '510', '2025-03-08', NULL, NULL, '8418', 'VISI COOLER SRC380', '2', '01', '3', '31500.01', NULL, NULL, NULL, NULL, NULL, '31500.01', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2025', 'P001080325');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (2, '2', '2025-04-25', 'P', '2025-04-25', NULL, 18, 'kee Enterprises', '43,Ram nagar Street, Devakottai, devakottai, Tamil Nadu', '001', '2025-04-25', NULL, NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', '1', '5', '8', '8850.00', NULL, NULL, NULL, NULL, NULL, '8850.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P-2025', 'P250425');


#
# TABLE STRUCTURE FOR: purchaseorder_details
#

DROP TABLE IF EXISTS `purchaseorder_details`;

CREATE TABLE `purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` longtext,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` longtext NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` longtext,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

#
# TABLE STRUCTURE FOR: purchaseorder_details_backup
#

DROP TABLE IF EXISTS `purchaseorder_details_backup`;

CREATE TABLE `purchaseorder_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `purchaseorder_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (1, '2023-11-24', '2023-11-24', '2023-11-24', 'Direct PO', 'P', '0055', NULL, 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '1500', '10', NULL, '', '15000.00', '0', 'percent_wise', '0.00', '15000.00', '9', '1350.00', '9', '1350.00', '18', '', NULL, '15000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', '17700.00', 'P241123', 'P-2023', 1, 0);
INSERT INTO `purchaseorder_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (2, '2024-07-03', '2024-07-03', '2024-07-03', 'Direct PO', 'P001', '120', NULL, 15, 'GRD', 'CBE, CBE, CBE, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '124', NULL, 'AC', 'NOS', '1000', '10', NULL, '', '10000.00', '0', 'percent_wise', '0.00', '10000.00', '9', '900.00', '9', '900.00', '18', '', NULL, '10000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', '11800.00', 'P001030724', 'P001-2024', 1, 0);
INSERT INTO `purchaseorder_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (3, '2025-02-23', '2025-02-23', '2025-02-23', 'Direct PO', 'P002', '001', NULL, 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '850300||7204', NULL, '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', 'KGS||KGS', '1500||2000', '10||10', NULL, '', '15000.00||20000.00', '0||0', 'percent_wise', '0.00||0.00', '15000.00||20000.00', '9', '3150.00', '9', '3150.00', '18', '', NULL, '35000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1||1', '41300.00', 'P002230225', 'P002-2025', 1, 0);
INSERT INTO `purchaseorder_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (4, '2025-02-25', '2025-02-25', '2025-02-25', 'Direct PO', 'P003', '001', NULL, 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', '0', 'interstate', 'interstate', NULL, NULL, NULL, '850300||7204', NULL, '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', 'KGS||KGS', '1500||2000', '10||10', NULL, '', '15000.00||20000.00', '0||0', 'percent_wise', '0.00||0.00', '15000.00||20000.00', '9', '', '9', '', '18', '6300.00', NULL, '35000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1||1', '41300.00', 'P003250225', 'P003-2025', 1, 0);
INSERT INTO `purchaseorder_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (5, '2025-02-25', '2025-02-25', '2025-02-25', 'Direct PO', 'P004', '001', NULL, 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '1234556', NULL, '10886', 'NOS', '22', '10', NULL, '', '220.00', '0', 'percent_wise', '0.00', '220.00', '9', '19.80', '9', '19.80', '18', '', NULL, '220.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', '259.60', 'P004250225', 'P004-2025', 1, 0);
INSERT INTO `purchaseorder_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (6, '2025-02-26', '2025-02-26', '2025-02-26', 'Direct PO', 'P005', '0023', NULL, 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', 'KGS', '2000', '100', NULL, '', '200000.00', '0', 'percent_wise', '0.00', '200000.00', '9', '18000.00', '9', '18000.00', '18', '', NULL, '200000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', '236000.00', 'P005260225', 'P005-2025', 1, 0);
INSERT INTO `purchaseorder_details_backup` (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (7, '2025-02-27', '2025-02-27', '2025-02-27', 'Direct PO', 'P006', 'verbal', NULL, 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '1234556', NULL, '10886', 'NOS', '22', '1000', NULL, '', '22000.00', '0', 'percent_wise', '0.00', '22000.00', '9', '1980.00', '9', '1980.00', '18', '', NULL, '22000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', '25960.00', 'P006270225', 'P006-2025', 1, 1);


#
# TABLE STRUCTURE FOR: purchaseorder_reports
#

DROP TABLE IF EXISTS `purchaseorder_reports`;

CREATE TABLE `purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (1, '1', '2023-11-24', 'Direct PO', 'P', '0055', NULL, '2023-11-24', NULL, 1, 'IDREAMDEVELOPERS', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', '0', '2023-11-24', NULL, NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '1500', '10', '4', '', NULL, '15000.00', NULL, NULL, NULL, NULL, NULL, '17700.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P-2023', 'P241123');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (2, '1', '2024-07-03', 'Direct PO', 'P001', '120', NULL, '2024-07-03', NULL, 15, 'GRD', 'CBE, CBE, CBE, Tamil Nadu', '0', '2024-07-03', NULL, NULL, '124', 'AC', 'NOS', '1000', '10', '5', '', NULL, '10000.00', NULL, NULL, NULL, NULL, NULL, '11800.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2024', 'P001030724');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (3, '2', '2025-02-23', 'Direct PO', 'P002', '001', NULL, '2025-02-23', NULL, 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', '0', '2025-02-23', NULL, NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '1500', '10', '0', '', NULL, '35000.00', NULL, NULL, NULL, NULL, NULL, '41300.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P002-2025', 'P002230225');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (4, '2', '2025-02-23', 'Direct PO', 'P002', '001', NULL, '2025-02-23', NULL, 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', '0', '2025-02-23', NULL, NULL, '7204', '1080R2-2PM STATOR STAMPING-GANG', 'KGS', '2000', '10', '0', '', NULL, '35000.00', NULL, NULL, NULL, NULL, NULL, '41300.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P002-2025', 'P002230225');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (5, '3', '2025-02-25', 'Direct PO', 'P003', '001', NULL, '2025-02-25', NULL, 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', '0', '2025-02-25', NULL, NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '1500', '10', '1', '', NULL, '35000.00', NULL, NULL, NULL, NULL, NULL, '41300.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P003-2025', 'P003250225');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (6, '3', '2025-02-25', 'Direct PO', 'P003', '001', NULL, '2025-02-25', NULL, 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', '0', '2025-02-25', NULL, NULL, '7204', '1080R2-2PM STATOR STAMPING-GANG', 'KGS', '2000', '10', '2', '', NULL, '35000.00', NULL, NULL, NULL, NULL, NULL, '41300.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P003-2025', 'P003250225');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (7, '4', '2025-02-25', 'Direct PO', 'P004', '001', NULL, '2025-02-25', NULL, 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', '0', '2025-02-25', NULL, NULL, '1234556', '10886', 'NOS', '22', '10', '0', '', NULL, '220.00', NULL, NULL, NULL, NULL, NULL, '259.60', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P004-2025', 'P004250225');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (8, '5', '2025-02-26', 'Direct PO', 'P005', '0023', NULL, '2025-02-26', NULL, 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', '0', '2025-02-26', NULL, NULL, '7204', '1080R2-2PM STATOR STAMPING-GANG', 'KGS', '2000', '100', '15', '', NULL, '200000.00', NULL, NULL, NULL, NULL, NULL, '236000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P005-2025', 'P005260225');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (9, '6', '2025-02-27', 'Direct PO', 'P006', 'verbal', NULL, '2025-02-27', NULL, 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', '0', '2025-02-27', NULL, NULL, '1234556', '10886', 'NOS', '22', '1000', '1000', '', NULL, '22000.00', NULL, NULL, NULL, NULL, NULL, '25960.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P006-2025', 'P006270225');


#
# TABLE STRUCTURE FOR: quotation_details
#

DROP TABLE IF EXISTS `quotation_details`;

CREATE TABLE `quotation_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `description` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `quotation_details` (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (1, '2025-03-03', '2025-03-03', NULL, NULL, 'Q001', 22, 'thennarasdu', 'teachers colony, vennampatty main road, dharmapuri, Tamil Nadu', NULL, NULL, 'intrastate', NULL, NULL, NULL, '84158210', 'daikin cassette ac', NULL, 'NOS', '70000', '1', '70000.00', '0', '0', '70000.00', '9', '6300.00', '9', '6300.00', '18', '', '70000.00', '70000.00', NULL, NULL, NULL, NULL, '82600.00', NULL, NULL, 1, 1);
INSERT INTO `quotation_details` (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (2, '2025-04-25', '2025-04-25', NULL, NULL, 'Q', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, 'intrastate', NULL, NULL, NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', NULL, 'KGS', '1500', '10', '15000.00', '0', '0', '15000.00', '9', '1350.00', '9', '1350.00', '18', '', '15000.00', '15000.00', NULL, NULL, NULL, NULL, '17700.00', NULL, NULL, 1, 1);


#
# TABLE STRUCTURE FOR: quotation_details_backup
#

DROP TABLE IF EXISTS `quotation_details_backup`;

CREATE TABLE `quotation_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `description` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `quotation_details_backup` (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (1, '2023-08-22', '2023-08-22', NULL, NULL, 'Q001', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, 'intrastate', NULL, NULL, NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', NULL, 'KGS', '1500', '100', '150000.00', '0', '0', '150000.00', '9', '13500.00', '9', '13500.00', '18', '', '150000.00', '150000.00', NULL, NULL, NULL, NULL, '177000.00', NULL, NULL, 1, 1);
INSERT INTO `quotation_details_backup` (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (2, '2023-09-12', '2023-09-12', NULL, NULL, 'Q002', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, 'intrastate', NULL, NULL, NULL, '7204', '1080R2-2PM STATOR STAMPING-GANG', NULL, 'KGS', '100', '2', '200.00', '0', '0', '200.00', '9', '18.00', '9', '18.00', '18', '', '200.00', '200.00', NULL, NULL, NULL, NULL, '236.00', NULL, NULL, 1, 1);
INSERT INTO `quotation_details_backup` (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (3, '2024-04-02', '2024-04-02', NULL, NULL, 'Q001', 11, 'shivamobiles', 'avanshi road annur, annur, coimbatore, Tamil Nadu', NULL, NULL, 'intrastate', NULL, NULL, NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', NULL, 'KGS', '1500', '100', '150000.00', '0', '0', '150000.00', '9', '13500.00', '9', '13500.00', '18', '', '150000.00', '150000.00', NULL, NULL, NULL, NULL, '177000.00', NULL, NULL, 1, 1);
INSERT INTO `quotation_details_backup` (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (4, '2024-06-09', '2024-06-09', NULL, NULL, 'Q002', 12, 'Jayaprakash', 'jaganathan nagar, Coimbatore, coimabtore, Tamil Nadu', NULL, NULL, 'intrastate', NULL, NULL, NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', NULL, 'KGS', '1500', '5', '7500.00', '0', '0.00', '7500.00', '9', '675.00', '9', '675.00', '18', '', '8850.00', '8850.00', NULL, NULL, '0', NULL, '8850.00', NULL, NULL, 1, 1);
INSERT INTO `quotation_details_backup` (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (5, '2024-07-01', '2024-07-01', NULL, NULL, 'Q003', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, 'intrastate', NULL, NULL, NULL, '01', 'Air Compressor Motor ', NULL, 'KGS', '5000', '10', '50000.00', '0', '0.00', '50000.00', '9', '4500.00', '9', '4500.00', '18', '', '59000.00', '59000.00', NULL, NULL, '0', NULL, '59000.00', NULL, NULL, 1, 1);
INSERT INTO `quotation_details_backup` (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (6, '2024-08-23', '2024-08-23', NULL, NULL, 'Q004', 17, 'intra customer demo', 'idreamdevelopers, idreamdevelopers, coimpatore, Tamil Nadu', NULL, NULL, 'intrastate', NULL, NULL, NULL, '9908', 'demo', NULL, 'UNIT', '100', '21', '2100.00', '0', '0', '2100.00', '15', '315.00', '15', '315.00', '30', '', '2100.00', '2100.00', NULL, NULL, NULL, NULL, '2730.00', NULL, NULL, 1, 1);
INSERT INTO `quotation_details_backup` (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (7, '2025-02-23', '2025-02-23', NULL, NULL, 'Q005', 1, 'IDREAMDEVELOPERS', '91, jaganathan nagar,,  civil aerodrome , COIMBATORE, Tamil Nadu', NULL, NULL, 'intrastate', NULL, NULL, NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', NULL, 'KGS', '1500', '10', '15000.00', '0', '0', '15000.00', '9', '1350.00', '9', '1350.00', '18', '', '15000.00', '15000.00', NULL, NULL, NULL, NULL, '17700.00', NULL, NULL, 1, 1);


#
# TABLE STRUCTURE FOR: sales_return
#

DROP TABLE IF EXISTS `sales_return`;

CREATE TABLE `sales_return` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext,
  `itemname` longtext,
  `rate` longtext,
  `qty` longtext,
  `uom` longtext,
  `amount` longtext,
  `discount` longtext,
  `taxableamount` longtext,
  `discountamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sales_return_backup
#

DROP TABLE IF EXISTS `sales_return_backup`;

CREATE TABLE `sales_return_backup` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext,
  `itemname` longtext,
  `rate` longtext,
  `qty` longtext,
  `uom` longtext,
  `amount` longtext,
  `discount` longtext,
  `taxableamount` longtext,
  `discountamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `sales_return_backup` (`id`, `date`, `returndate`, `types`, `time`, `dateofissue`, `customername`, `customerid`, `supplierid`, `gsttype`, `suppliername`, `openingbal`, `outstandingamount`, `returnno`, `description`, `invoiceno`, `purchaseno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `uom`, `amount`, `discount`, `taxableamount`, `discountamount`, `cgst`, `cgstamount`, `sgst`, `sgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `grandtotal`, `status`) VALUES (1, '2024-08-09', '2024-08-09', 'Debit', '12:16:22 PM', '2024-08-09', 'IDREAMDEVELOPERS', '1', '-', 'interstate', '-', '340490', NULL, 'D001', 'sales', 'INV/23-24/-0001', '-', NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', '1500', '5', 'KGS', '7500.00', '0', '7500.00', '0.00', '9', '', '9', '', '18', '1350.00', '8850.00', '8850.00', '0', '', '', '', '', '', '', '', '0', '', '', '', '', '', '', '', '', '8850.00', '1');


#
# TABLE STRUCTURE FOR: statecode
#

DROP TABLE IF EXISTS `statecode`;

CREATE TABLE `statecode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) NOT NULL,
  `stateCode` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (1, 'Jammu & Kashmir', '01', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (2, 'Himachal Pradesh', '02', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (3, 'Punjab', '03', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (4, 'Chandigarh', '04', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (5, 'Uttarakhand', '05', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (6, 'Haryana', '06', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (7, 'Delhi', '07', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (8, 'Rajasthan', '08', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (9, 'Uttar Pradesh', '09', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (10, 'Bihar', '10', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (11, 'Sikkim', '11', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (12, 'Arunachal Pradesh', '12', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (13, 'Nagaland', '13', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (14, 'Manipur', '14', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (15, 'Mizoram', '15', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (16, 'Tripura', '16', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (17, 'Meghalaya', '17', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (18, 'Assam', '18', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (19, 'West Bengal', '19', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (20, 'Jharkhand', '20', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (21, 'odisha', '21', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (22, 'Chattisgarh', '22', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (23, 'Madhya Pradesh', '23', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (24, 'Daman & Diu', '25', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (25, 'Gujarat', '24', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (26, 'Dadra & Nagar Haveli', '26', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (27, 'Maharashtra', '27', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (28, 'Andhra Pradesh', '28', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (29, 'Karnataka', '29', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (30, 'Goa', '30', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (31, 'Lakshadweep', '31', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (32, 'Kerala', '32', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (33, 'Tamil Nadu', '33', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (34, 'Puducherry', '34', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (35, 'Andaman & Nicobar Islands', '35', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (36, 'Telengana', '36', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (37, 'Andrapradesh(New)', '37', 1);


#
# TABLE STRUCTURE FOR: stock
#

DROP TABLE IF EXISTS `stock`;

CREATE TABLE `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `updatestock` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `balance` varchar(255) NOT NULL,
  `oldqty` varchar(255) DEFAULT NULL,
  `currentstock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (1, '2025-02-27', '01', NULL, '9', '9', '9', 'Air Compressor Motor ', '10', '5000', '10', '', '', '9928', NULL, NULL, '', '2025-02-26', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (2, '2024-08-24', '124', NULL, '9', '9', '18', 'AC', '10', '1000', '10', '', '', '2', NULL, NULL, '', '2024-08-24', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (3, '2024-08-23', '9908', '0', '15', '15', '30', 'demo', '1000', '100', '1000', '', '1', '900', NULL, NULL, '', '2024-08-23', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (4, '2025-02-06', '002', NULL, '9', '9', '18', 'BLACK PAINT', '20', '950', '20', '', '1', '50', NULL, NULL, '', '2025-02-06', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (5, '2025-02-06', '002', NULL, '9', '9', '18', 'BLACK PAINT', '20', '950', '20', '', '', '50', NULL, NULL, '', '2025-02-06', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (6, '2025-02-06', '002', NULL, '9', '9', '18', 'BLACK PAINT', '20', '950', '20', '', '', '50', NULL, NULL, '', '2025-02-06', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (7, '2025-04-09', '7204', NULL, '9', '9', '18', '1080R2-2PM STATOR STAMPING-GANG', '06', '2000', '06', '', '', '-122', NULL, NULL, '', '2024-09-04', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (8, '2024-09-04', '32123212', NULL, '9', '9', '18', 'Oversized Tshirt', '1000', '100', '1000', '', '', '500', NULL, NULL, '', '2024-09-04', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (9, '2025-02-06', '002', '0', '9', '9', '18', 'BLACK PAINT', '5', '950', '5', '', '', '5', NULL, NULL, '', '2025-02-06', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (10, '2025-05-14', '850300', NULL, '9', '9', '18', '1080R2-2PM 70MM CLEATED STATOR', '5', '1000', '5', '', '', '-45', NULL, NULL, '', '2025-04-25', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (11, '2025-02-25', '8466', '0', '9', '9', '18', '10885 lock nut', '500', '20', '500', '', '1', '500', NULL, NULL, '', '2025-02-25', 'Inclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (12, '2025-02-25', '8466', '0', '9', '9', '18', '10886', '500', '22', '500', '', '1', '500', NULL, NULL, '', '2025-02-25', 'Inclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (13, '2025-02-26', '', NULL, '', '', '', 'raw material', '10', '', '10', '', '', '10', NULL, NULL, '', '2025-02-26', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (14, '2025-02-27', '1234556', '0', '9', '9', '18', '10886', '1000', '22', '1000', '', '1', '1000', NULL, NULL, '', '2025-02-27', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (15, '2025-03-08', '8418', NULL, '9', '9', '18', 'VISI COOLER SRC380', '01', '26694.92', '01', '', '', '0', NULL, NULL, '', '2025-03-08', 'Exclusive');


#
# TABLE STRUCTURE FOR: stock_reports
#

DROP TABLE IF EXISTS `stock_reports`;

CREATE TABLE `stock_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `updatestock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  `balance` varchar(225) DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (1, '2024-07-01', '01', NULL, 'Air Compressor Motor ', NULL, '10', '', '2024-07-01', '1', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (2, '2024-07-03', '124', NULL, 'AC', NULL, '010', '', '2024-07-03', '2', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (3, '2024-08-20', '01', NULL, 'Air Compressor Motor ', NULL, '1', '', NULL, '3', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (4, '2024-08-23', '9908', '0', 'demo', '1', '1000', 'FromAddStock', '2024-08-23', NULL, NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (5, '2024-08-24', '124', NULL, 'AC', NULL, '10', '', NULL, '4', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (6, '2024-08-24', '002', '0', 'BLACK PAINT', '1', '0', 'FromAddStock', '2024-08-24', NULL, NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (7, '2024-08-24', '01', NULL, 'Air Compressor Motor ', NULL, '10000', '', NULL, '5', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (9, '2024-08-24', '002', '0', 'BLACK PAINT', NULL, '0', '', '2024-08-24', '6', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (11, '2024-08-24', '002', '0', 'BLACK PAINT', NULL, '20', '', '2024-08-24', '7', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (12, '2024-08-24', '002', NULL, 'BLACK PAINT', NULL, '10', '', NULL, '8', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (13, '2024-09-04', '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', NULL, '06', '', '2024-09-04', '9', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (14, '2024-09-04', '32123212', NULL, 'Oversized Tshirt', NULL, '1000', '', '2024-09-04', '10', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (15, '2025-02-06', '01', NULL, 'Air Compressor Motor ', NULL, '10', '', NULL, '11', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (17, '2025-02-06', '002', '0', 'BLACK PAINT', NULL, '5', '', '2025-02-06', '12', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (18, '2025-02-06', '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', NULL, '10', '', '2025-02-06', '13', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (19, '2025-02-25', '8466', '0', '10885 lock nut', '1', '500', 'FromAddStock', '2025-02-25', NULL, NULL, 'Inclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (20, '2025-02-25', '8466', '0', '10886', '1', '500', 'FromAddStock', '2025-02-25', NULL, NULL, 'Inclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (21, '2025-02-26', '01', NULL, 'Air Compressor Motor ', NULL, '10', '', NULL, '14', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (22, '2025-02-26', '', NULL, 'raw material', NULL, '10', '', '2025-02-26', '14', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (23, '2025-02-27', '1234556', '0', '10886', '1', '1000', 'FromAddStock', '2025-02-27', NULL, NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (24, '2025-03-08', '8418', NULL, 'VISI COOLER SRC380', NULL, '0', '', '2025-03-08', '1', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (25, '2025-04-25', '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', NULL, '5', '', NULL, '2', NULL, 'Exclusive');


#
# TABLE STRUCTURE FOR: sup_purchaseorder_details
#

DROP TABLE IF EXISTS `sup_purchaseorder_details`;

CREATE TABLE `sup_purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToAddress` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sup_purchaseorder_details_backup
#

DROP TABLE IF EXISTS `sup_purchaseorder_details_backup`;

CREATE TABLE `sup_purchaseorder_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sup_purchaseorder_reports
#

DROP TABLE IF EXISTS `sup_purchaseorder_reports`;

CREATE TABLE `sup_purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (1, '1', '2023-08-18', 'Direct PO', 'P001', NULL, NULL, '2023-08-18', NULL, 2, 'J.K INDUSTRIES', 'CHERAN NAGAR, Ganapathy, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '1', '20', '20', '', '35400.00', '35400.00', NULL, NULL, NULL, NULL, NULL, '35400.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2023', 'P001180823');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (2, '2', '2023-08-18', 'Direct PO', 'P001', NULL, NULL, '2023-08-18', NULL, 2, 'J.K INDUSTRIES', 'CHERAN NAGAR, Ganapathy, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '1', '20', '20', '', '35400.00', '35400.00', NULL, NULL, NULL, NULL, NULL, '35400.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2023', 'P001180823');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (3, '3', '2023-11-20', 'Direct PO', 'P003', NULL, NULL, '2023-11-20', NULL, 2, 'J.K INDUSTRIES', 'CHERAN NAGAR, Ganapathy, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '01', 'Air Compressor Motor ', 'KGS', '5', '10', '0', '', '50000.00', '50000.00', NULL, NULL, NULL, NULL, NULL, '50000.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P003-2023', 'P003201123');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (4, '4', '2023-11-24', 'Direct PO', 'P004', NULL, NULL, '2023-11-24', NULL, 2, 'J.K INDUSTRIES', 'CHERAN NAGAR, Ganapathy, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '01', 'Air Compressor Motor ', 'KGS', '5', '10', '10', '', '50000.00', '50000.00', NULL, NULL, NULL, NULL, NULL, '50000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P004-2023', 'P004241123');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (5, '5', '2023-11-24', 'Direct PO', 'P005', NULL, NULL, '2023-11-24', NULL, 3, 'RK Industries', 'Avarampalayam, VOC Nagar, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '1', '11', '11', '', '18172.00', '18172.00', NULL, NULL, NULL, NULL, NULL, '18180.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P005-2023', 'P005241123');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (7, '7', '2023-11-25', 'Direct PO', 'P006', NULL, NULL, '2023-11-25', NULL, 3, 'RK Industries', 'Avarampalayam, VOC Nagar, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '01', 'Air Compressor Motor ', 'KGS', '5', '20', '20', '', '118000.00', '118000.00', NULL, NULL, NULL, NULL, NULL, '118000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P006-2023', 'P006251123');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (8, '8', '2023-11-25', 'Direct PO', 'P007', NULL, NULL, '2023-11-25', NULL, 3, 'RK Industries', 'Avarampalayam, VOC Nagar, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '01', 'Air Compressor Motor ', 'KGS', '5', '10', '10', '', '59000.00', '430700.00', NULL, NULL, NULL, NULL, NULL, '430700.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P007-2023', 'P007251123');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (9, '8', '2023-11-25', 'Direct PO', 'P007', NULL, NULL, '2023-11-25', NULL, 3, 'RK Industries', 'Avarampalayam, VOC Nagar, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '0', '210', '210', '', '371700.00', '430700.00', NULL, NULL, NULL, NULL, NULL, '430700.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P007-2023', 'P007251123');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (10, '9', '2023-11-25', 'Direct PO', 'P008', NULL, NULL, '2023-11-25', NULL, 3, 'RK Industries', 'Avarampalayam, VOC Nagar, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '1001', 'Compressor', 'KGS', '1', '10', '10', '', '11800.00', '29500.00', NULL, NULL, NULL, NULL, NULL, '29500.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P008-2023', 'P008251123');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (11, '9', '2023-11-25', 'Direct PO', 'P008', NULL, NULL, '2023-11-25', NULL, 3, 'RK Industries', 'Avarampalayam, VOC Nagar, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '1002', 'drilling machine', 'KGS', '0', '10', '10', '', '17700.00', '29500.00', NULL, NULL, NULL, NULL, NULL, '29500.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P008-2023', 'P008251123');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (12, '10', '2023-11-25', 'Direct PO', 'P009', NULL, NULL, '2023-11-25', NULL, 3, 'RK Industries', 'Avarampalayam, VOC Nagar, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '1001', 'Compressor', 'KGS', '1', '10', '10', '', '11800.00', '29500.00', NULL, NULL, NULL, NULL, NULL, '29500.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P009-2023', 'P009251123');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (13, '10', '2023-11-25', 'Direct PO', 'P009', NULL, NULL, '2023-11-25', NULL, 3, 'RK Industries', 'Avarampalayam, VOC Nagar, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '1002', 'drilling machine', 'KGS', '0', '10', '10', '', '17700.00', '29500.00', NULL, NULL, NULL, NULL, NULL, '29500.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P009-2023', 'P009251123');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (14, '11', '2023-11-30', 'Direct PO', 'P010', NULL, NULL, '2023-11-30', NULL, 3, 'RK Industries', 'Avarampalayam, VOC Nagar, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '1002', 'drilling machine', 'KGS', '1', '10', '10', '', '17700.00', '28320.00', NULL, NULL, NULL, NULL, NULL, '28320.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P010-2023', 'P010301123');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (15, '11', '2023-11-30', 'Direct PO', 'P010', NULL, NULL, '2023-11-30', NULL, 3, 'RK Industries', 'Avarampalayam, VOC Nagar, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '1001', 'Compressor', 'KGS', '5', '09', '09', '', '10620.00', '28320.00', NULL, NULL, NULL, NULL, NULL, '28320.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P010-2023', 'P010301123');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (16, '12', '2024-03-25', 'Direct PO', 'P011', NULL, NULL, '2024-03-25', NULL, 10, 'ATOMBERG TECHNOLOGY PVT', 'MUMBAI, MUMBAI, mumbai, Maharashtra', '0', NULL, NULL, NULL, '1001', 'Compressor', 'KGS', '9', '15', '7', '', '15930.00', '22089.60', NULL, NULL, NULL, NULL, NULL, '22089.60', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P011-2024', 'P011250324');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (17, '12', '2024-03-25', 'Direct PO', 'P011', NULL, NULL, '2024-03-25', NULL, 10, 'ATOMBERG TECHNOLOGY PVT', 'MUMBAI, MUMBAI, mumbai, Maharashtra', '0', NULL, NULL, NULL, '7204', '1080R2-2PM STATOR STAMPING-GANG', 'KGS', '0', '29', '7', '', '6159.60', '22089.60', NULL, NULL, NULL, NULL, NULL, '22089.60', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P011-2024', 'P011250324');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (18, '1', '2024-04-02', 'Direct PO', 'P001', NULL, NULL, '2024-04-02', NULL, 10, 'ATOMBERG TECHNOLOGY PVT', 'MUMBAI, MUMBAI, mumbai, Maharashtra', '0', NULL, NULL, NULL, '02', 'Metal Stamping', 'KGS', '1', '2', '2', '', '2000.00', '2000.00', NULL, NULL, NULL, NULL, NULL, '2000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2024', 'P001020424');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (19, '2', '2025-02-25', 'Direct PO', 'P002', NULL, NULL, '2025-02-25', NULL, 3, 'RK Industries', 'Avarampalayam, VOC Nagar, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '850300', '1080R2-2PM 70MM CLEATED STATOR', 'KGS', '1', '10', '10', '', '17700.00', '18700.00', NULL, NULL, NULL, NULL, NULL, '18700.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P002-2025', 'P002250225');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (20, '2', '2025-02-25', 'Direct PO', 'P002', NULL, NULL, '2025-02-25', NULL, 3, 'RK Industries', 'Avarampalayam, VOC Nagar, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '0', '1080R2-2PM STATOR STAMPING NEW', 'KGS', '5', '10', '10', '', '1000.00', '18700.00', NULL, NULL, NULL, NULL, NULL, '18700.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P002-2025', 'P002250225');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (21, '3', '2025-02-26', 'Direct PO', 'P003', NULL, NULL, '2025-02-26', NULL, 3, 'RK Industries', 'Avarampalayam, VOC Nagar, Coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '', 'raw material', '', '1', '10', '0', '', '10000.00', '10000.00', NULL, NULL, NULL, NULL, NULL, '10000.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P003-2025', 'P003260225');


#
# TABLE STRUCTURE FOR: tbl_person
#

DROP TABLE IF EXISTS `tbl_person`;

CREATE TABLE `tbl_person` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: uom
#

DROP TABLE IF EXISTS `uom`;

CREATE TABLE `uom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (1, '2023-07-28', 'KGS', 1);
INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (2, '2024-01-08', 'NOS', 1);
INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (3, '2024-07-01', 'piece', 1);
INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (5, '2024-08-23', 'UNIT', 1);
INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (6, '2024-08-24', 'lITRE', 1);
INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (7, '2025-05-14', 'ML', 1);


#
# TABLE STRUCTURE FOR: user_menu
#

DROP TABLE IF EXISTS `user_menu`;

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) NOT NULL,
  `main_menu` varchar(255) NOT NULL,
  `sub_menu` varchar(255) NOT NULL,
  `sub_menu_link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

INSERT INTO `user_menu` (`id`, `login_id`, `main_menu`, `sub_menu`, `sub_menu_link`) VALUES (37, 10, 'Settings', 'Tax Type', 'taxtype');
INSERT INTO `user_menu` (`id`, `login_id`, `main_menu`, `sub_menu`, `sub_menu_link`) VALUES (38, 10, 'Settings', 'Add UOM', 'uom');
INSERT INTO `user_menu` (`id`, `login_id`, `main_menu`, `sub_menu`, `sub_menu_link`) VALUES (39, 10, 'Settings', 'Add Item', 'itemmaster');
INSERT INTO `user_menu` (`id`, `login_id`, `main_menu`, `sub_menu`, `sub_menu_link`) VALUES (40, 10, 'Settings', 'Account Headers', 'headers');
INSERT INTO `user_menu` (`id`, `login_id`, `main_menu`, `sub_menu`, `sub_menu_link`) VALUES (41, 10, 'Settings', 'Company Profile', 'profile');
INSERT INTO `user_menu` (`id`, `login_id`, `main_menu`, `sub_menu`, `sub_menu_link`) VALUES (42, 10, 'Settings', 'Backup Settings', 'backup');
INSERT INTO `user_menu` (`id`, `login_id`, `main_menu`, `sub_menu`, `sub_menu_link`) VALUES (43, 10, 'Settings', 'Support', 'support');
INSERT INTO `user_menu` (`id`, `login_id`, `main_menu`, `sub_menu`, `sub_menu_link`) VALUES (44, 10, 'Settings', 'User Manager', 'usermaster');


#
# TABLE STRUCTURE FOR: vat_details
#

DROP TABLE IF EXISTS `vat_details`;

CREATE TABLE `vat_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `sgst` varchar(225) DEFAULT NULL,
  `cgst` varchar(225) DEFAULT NULL,
  `igst` varchar(225) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `vat_details` (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (4, '2024-01-08', 'GST', '12', 'GST @ 12 %', '6', '6', '12', '1');
INSERT INTO `vat_details` (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (5, '2024-02-12', 'gst', '18', 'gst @ 18 %', '9', '9', '18', '1');
INSERT INTO `vat_details` (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (6, '2024-03-27', 'gst', '5', 'gst @ 5 %', '2.5', '2.5', '5', '1');
INSERT INTO `vat_details` (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (11, '2025-03-03', 'GST', '28', 'GST @ 28 %', '14', '14', '28', '1');


#
# TABLE STRUCTURE FOR: vendor_details
#

DROP TABLE IF EXISTS `vendor_details`;

CREATE TABLE `vendor_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `vendorname` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: voucher
#

DROP TABLE IF EXISTS `voucher`;

CREATE TABLE `voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `tdsamount` varchar(100) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `balance_amt` varchar(255) DEFAULT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `voucher` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `tdsamount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (1, '2025-04-25', 'V/23-24/-001', 1, 'IDREAMDEVELOPERS', '2025-04-25', 'payment', '', 'Cash', '0', '', '', '0', '', '8850', 'Cash', NULL, NULL, '8850', '8850', '', '1', 'INV/25-26/-005', NULL, '8850', 0);


#
# TABLE STRUCTURE FOR: voucher_backup
#

DROP TABLE IF EXISTS `voucher_backup`;

CREATE TABLE `voucher_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `purchaseno` varchar(255) NOT NULL,
  `balance_amt` varchar(255) NOT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (1, '2023-08-23', 'V/23-24/-001', 1, 'SMK INDUSTRIES', '2023-08-23', 'payment', 'Product', 'Cash', '0', '', '', '0', '', '1000', 'Cash', NULL, NULL, '1000', '1000', '1', 'INV/23-24/-001', '', '1000', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (2, '2023-08-23', 'V/23-24/-002', 2, 'J.K INDUSTRIES', '2023-08-23', 'receipt', 'Product', 'Cash', '0', '', '', '0', '', '25000', 'Cash', NULL, NULL, '25000', '25000', '1', '', 'P001', '25000', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (3, '2023-08-23', 'V/23-24/-003', 1, 'SMK INDUSTRIES', '2023-08-23', 'payment', 'Product', 'Cheque', 'INDIAN OVERSEAS', '563966', '10000', '0', '', '', 'Cheque INDIAN OVERSEAS 563966', NULL, '24-08-2023', '10000', '10000', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (4, '2023-08-23', 'V/23-24/-004', 2, 'J.K INDUSTRIES', '2023-08-23', 'receipt', 'Product', 'Cheque', 'INDIAN BANK', '563966', '10000', '0', '', '', 'Cheque INDIAN BANK 563966', NULL, '24-08-2023', '10000', '10000', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (5, '2024-02-12', 'V/23-24/-005', 9, 'SELVAGANAPATHI', '2024-02-12', 'payment', '', 'Cash', '0', '', '', '0', '', '130', 'Cash', NULL, NULL, '130', '130', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (6, '2024-03-04', 'V/23-24/-006', 1, 'SMK INDUSTRIES', '2024-03-04', 'payment', 'Sale', 'Cash', '0', '', '', '0', '', '1200000', 'Cash', NULL, NULL, '1200000', '1200000', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (7, '2024-03-04', 'V/23-24/-007', 2, 'J.K INDUSTRIES', '2024-03-04', 'receipt', 'outside sale', 'Cash', '0', '', '', '0', '', '330000', 'Cash', NULL, NULL, '330000', '330000', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (8, '2024-03-19', 'V/23-24/-008', 8, 'JAI SHREE SAI ENGINEERING', '2024-03-19', 'payment', '', 'Cash', '', '', '', '', '', '4600', 'Cash', NULL, NULL, '4600', '4600', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (9, '2024-03-25', 'V/23-24/-009', 10, 'ATOMBERG TECHNOLOGY PVT', '2024-03-25', 'receipt', '', 'Cash', '0', '', '', '0', '', '7000', 'Cash', NULL, NULL, '7000', '7000', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (10, '2024-03-28', 'V/23-24/-010', 1, 'SMK INDUSTRIES', '2024-03-28', 'payment', '', 'Cash', '0', '', '', '0', '', '211061', 'Cash', NULL, NULL, '211061', '211061', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (11, '2024-03-28', 'V/23-24/-011', 12, 'Jayaprakash', '2024-03-28', 'payment', '', 'Cash', '0', '', '', '0', '', '1770', 'Cash', NULL, NULL, '1770', '1770', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (16, '2024-03-28', 'V/23-24/-001', 12, 'Jayaprakash', '2024-03-28', 'payment', '', 'Cash', '0', '', '', '0', '', '12000', 'Cash', NULL, NULL, '12000', '12000', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (17, '2024-03-28', 'V/23-24/-001', 1, 'SMK INDUSTRIES', '2024-03-28', 'payment', '', 'Cash', '0', '', '', '0', '', '10620', 'Cash', NULL, NULL, '10620', '10620', '1', 'INV/23-24/-002', '', '10620', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (18, '2024-03-28', 'V/23-24/-001', 1, 'SMK INDUSTRIES', '2024-03-28', 'payment', '', 'Cash', '0', '', '', '0', '', '11800', 'Cash', NULL, NULL, '11800', '11800', '1', 'INV/23-24/-003', '', '11800', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (19, '2024-03-28', 'V/23-24/-002', 1, 'SMK INDUSTRIES', '2024-03-28', 'payment', '', 'Cash', '0', '', '', '0', '', '8850', 'Cash', NULL, NULL, '8850', '8850', '1', 'INV/23-24/-0001', '', '8850', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (20, '2024-03-28', 'V/23-24/-003', 1, 'SMK INDUSTRIES', '2024-03-28', 'payment', 'old invoice ', 'Cash', '0', '', '', '0', '', '5900', 'Cash', NULL, NULL, '5900', '5900', '1', 'INV/23-24/-10001||INV/23-24/-10002', '', '3540.00||2360.00', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (21, '2024-04-09', 'V/23-24/-004', 1, 'SMK INDUSTRIES', '2024-04-09', 'payment', '', 'Cheque', 'ANDHRA BANK', '123455', '17000', '0', '', '', 'Cheque ANDHRA BANK 123455', NULL, '', '17000', '17000', '1', 'INV/23-24/-10003', '', '17000', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (22, '2024-05-03', 'V/23-24/-005', 1, 'SMK INDUSTRIES', '2024-05-03', 'payment', '', 'Cash', '', '', '', '', '', '90000', 'Cash', NULL, NULL, '90000', '90000', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (23, '2024-05-16', 'V/23-24/-006', 1, 'SMK INDUSTRIES', '2024-05-16', 'payment', '', 'Cash', '0', '', '', '0', '', '500', 'Cash', NULL, NULL, '500', '500', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (24, '2024-07-01', 'V/23-24/-007', 1, 'IDREAMDEVELOPERS', '2024-07-01', 'payment', '', 'Cash', '0', '', '', '0', '', '10000', 'Cash', NULL, NULL, '10000', '10000', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (25, '2024-07-03', 'V/23-24/-008', 15, 'GRD', '2024-07-03', 'payment', '', 'Cash', '0', '', '', '0', '', '10000', 'Cash', NULL, NULL, '10000', '10000', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (26, '2024-08-20', 'V/23-24/-009', 1, 'IDREAMDEVELOPERS', '2024-08-20', 'payment', '', 'Cash', '0', '', '', '0', '', '2000', 'Cash', NULL, NULL, '2000', '2000', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (27, '2024-08-20', 'V/23-24/-010', 1, 'IDREAMDEVELOPERS', '2024-08-20', 'payment', '', 'Cash', '0', '', '', '0', '', '24190', 'Cash', NULL, NULL, '24190', '24190', '1', 'INV/23-24/-10', '', '24190', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (28, '2024-08-20', 'V/23-24/-011', 10, 'ATOMBERG TECHNOLOGY PVT', '2024-08-20', 'receipt', '', 'Cash', '0', '', '', '0', '', '3000', 'Cash', NULL, NULL, '3000', '3000', '1', '', 'P003', '3000', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (29, '2024-08-24', 'V/23-24/-012', 1, 'IDREAMDEVELOPERS', '2024-08-24', 'payment', '', 'Cash', '0', '', '', '0', '', '4', 'Cash', NULL, NULL, '4', '4', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (30, '2025-02-06', 'V/23-24/-013', 1, 'IDREAMDEVELOPERS', '2025-02-06', 'payment', '', 'Cash', '0', '', '', '0', '', '100000', 'Cash', NULL, NULL, '100000', '100000', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (31, '2025-02-06', 'V/23-24/-014', 10, 'ATOMBERG TECHNOLOGY PVT', '2025-02-06', 'receipt', 'purchase', 'Cash', '0', '', '', '0', '', '1500', 'Cash', NULL, NULL, '1500', '1500', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (32, '2025-02-19', 'V/23-24/-015', 12, 'Jayaprakash', '2025-02-19', 'payment', '', 'Cash', '0', '', '', '0', '', '500', 'Cash', NULL, NULL, '500', '500', '1', '', '', '', 0);
INSERT INTO `voucher_backup` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (33, '2025-02-26', 'V/23-24/-016', 3, 'RK Industries', '2025-02-26', 'receipt', 'rk', 'Bank', '0', '', '', 'dbs', '42000', '', 'Bank dbs', '125632', NULL, '42000', '42000', '1', '', '', '', 0);


