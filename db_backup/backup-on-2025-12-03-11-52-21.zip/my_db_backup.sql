#
# TABLE STRUCTURE FOR: add_staff
#

DROP TABLE IF EXISTS `add_staff`;

CREATE TABLE `add_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `staff_name` varchar(255) NOT NULL,
  `mobileno` varchar(255) NOT NULL,
  `amobileno` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `referred` varchar(255) NOT NULL,
  `salary` varchar(255) NOT NULL,
  `salarytype` varchar(255) NOT NULL,
  `perdaysalary` varchar(255) NOT NULL,
  `ot` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: additem
#

DROP TABLE IF EXISTS `additem`;

CREATE TABLE `additem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` text CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `patterncode` varchar(255) NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `pattern_material` varchar(255) NOT NULL,
  `casting_weight` varchar(255) NOT NULL,
  `liquid_weight` varchar(255) NOT NULL,
  `yield` varchar(255) NOT NULL,
  `price` varchar(255) DEFAULT NULL,
  `taxtype` varchar(225) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `priceType` varchar(10) NOT NULL,
  `itemtype` varchar(255) NOT NULL,
  `purchaseNo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (1, '2025-08-11', '1', '002', 'Coal Nozzle', '1001', '001', 'Yield', '250', '100', '250', '15000', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (3, '2025-10-08', '1', 'SP03', 'Collector Casting', '1003', '3-SPG-8557 REV0', 'BS3100 309C30', '31', '', '', '542', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (4, '2025-11-20', '1', 'SBM03', 'LH OUTER BOX', '1004', 'STMSC016', 'WCB', '25.4', '26', '97.69', '167', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (5, '2025-11-20', '1', 'SBM05', 'LH INNER BOX', '1005', 'STMS014', 'ALUMINIUM', '26.1', '30', '87.00', '167', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);


#
# TABLE STRUCTURE FOR: attendance
#

DROP TABLE IF EXISTS `attendance`;

CREATE TABLE `attendance` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `attendancedate` date NOT NULL,
  `staff` varchar(255) NOT NULL,
  `attendances` varchar(255) NOT NULL,
  `intime` varchar(255) NOT NULL,
  `outtime` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `lastupdate` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: backup_details
#

DROP TABLE IF EXISTS `backup_details`;

CREATE TABLE `backup_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` longtext DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=82 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (1, 'backup-on-2025-06-21-09-29-14.zip', '2025-06-21');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (2, 'backup-on-2025-06-23-10-32-40.zip', '2025-06-23');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (3, 'backup-on-2025-06-24-12-15-22.zip', '2025-06-24');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (4, 'backup-on-2025-06-25-15-18-12.zip', '2025-06-25');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (5, 'backup-on-2025-06-28-11-57-40.zip', '2025-06-28');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (6, 'backup-on-2025-07-01-15-17-26.zip', '2025-07-01');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (7, 'backup-on-2025-07-02-11-36-22.zip', '2025-07-02');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (8, 'backup-on-2025-07-03-12-06-54.zip', '2025-07-03');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (9, 'backup-on-2025-07-11-17-20-54.zip', '2025-07-11');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (10, 'backup-on-2025-07-13-10-28-41.zip', '2025-07-13');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (11, 'backup-on-2025-07-14-16-02-07.zip', '2025-07-14');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (12, 'backup-on-2025-07-17-12-20-39.zip', '2025-07-17');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (13, 'backup-on-2025-07-19-12-34-18.zip', '2025-07-19');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (14, 'backup-on-2025-07-20-12-06-32.zip', '2025-07-20');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (15, 'backup-on-2025-07-22-15-22-23.zip', '2025-07-22');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (16, 'backup-on-2025-07-23-12-24-23.zip', '2025-07-23');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (17, 'backup-on-2025-07-24-11-53-24.zip', '2025-07-24');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (18, 'backup-on-2025-07-25-15-20-00.zip', '2025-07-25');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (19, 'backup-on-2025-08-04-10-18-51.zip', '2025-08-04');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (20, 'backup-on-2025-08-11-14-38-18.zip', '2025-08-11');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (21, 'backup-on-2025-08-13-18-55-03.zip', '2025-08-13');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (22, 'backup-on-2025-08-14-11-06-34.zip', '2025-08-14');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (23, 'backup-on-2025-08-18-12-13-01.zip', '2025-08-18');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (24, 'backup-on-2025-08-19-15-31-40.zip', '2025-08-19');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (25, 'backup-on-2025-08-21-10-24-45.zip', '2025-08-21');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (26, 'backup-on-2025-08-23-11-25-14.zip', '2025-08-23');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (27, 'backup-on-2025-08-25-18-08-57.zip', '2025-08-25');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (28, 'backup-on-2025-08-26-10-43-44.zip', '2025-08-26');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (29, 'backup-on-2025-08-28-13-20-40.zip', '2025-08-28');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (30, 'backup-on-2025-09-01-11-18-03.zip', '2025-09-01');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (31, 'backup-on-2025-09-02-11-00-26.zip', '2025-09-02');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (32, 'backup-on-2025-09-03-09-53-12.zip', '2025-09-03');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (33, 'backup-on-2025-09-04-18-16-21.zip', '2025-09-04');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (34, 'backup-on-2025-09-05-10-48-29.zip', '2025-09-05');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (35, 'backup-on-2025-09-06-11-07-45.zip', '2025-09-06');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (36, 'backup-on-2025-09-11-16-39-38.zip', '2025-09-11');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (37, 'backup-on-2025-09-12-10-52-25.zip', '2025-09-12');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (38, 'backup-on-2025-09-13-10-50-06.zip', '2025-09-13');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (39, 'backup-on-2025-09-15-12-01-35.zip', '2025-09-15');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (40, 'backup-on-2025-09-16-18-27-15.zip', '2025-09-16');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (41, 'backup-on-2025-09-17-10-51-38.zip', '2025-09-17');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (42, 'backup-on-2025-09-19-10-33-25.zip', '2025-09-19');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (43, 'backup-on-2025-09-20-09-56-47.zip', '2025-09-20');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (44, 'backup-on-2025-09-22-09-52-36.zip', '2025-09-22');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (45, 'backup-on-2025-09-24-11-36-55.zip', '2025-09-24');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (46, 'backup-on-2025-09-25-10-50-02.zip', '2025-09-25');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (47, 'backup-on-2025-09-26-11-57-14.zip', '2025-09-26');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (48, 'backup-on-2025-09-29-10-00-12.zip', '2025-09-29');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (49, 'backup-on-2025-10-01-19-12-22.zip', '2025-10-01');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (50, 'backup-on-2025-10-03-12-35-48.zip', '2025-10-03');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (51, 'backup-on-2025-10-06-18-05-01.zip', '2025-10-06');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (52, 'backup-on-2025-10-07-10-47-39.zip', '2025-10-07');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (53, 'backup-on-2025-10-08-10-33-07.zip', '2025-10-08');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (54, 'backup-on-2025-10-09-11-25-51.zip', '2025-10-09');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (55, 'backup-on-2025-10-10-17-08-57.zip', '2025-10-10');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (56, 'backup-on-2025-10-11-09-58-47.zip', '2025-10-11');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (57, 'backup-on-2025-10-12-14-29-32.zip', '2025-10-12');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (58, 'backup-on-2025-10-13-10-49-09.zip', '2025-10-13');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (59, 'backup-on-2025-10-15-10-33-03.zip', '2025-10-15');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (60, 'backup-on-2025-10-16-10-41-33.zip', '2025-10-16');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (61, 'backup-on-2025-10-21-14-51-30.zip', '2025-10-21');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (62, 'backup-on-2025-10-22-09-42-14.zip', '2025-10-22');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (63, 'backup-on-2025-10-25-10-55-59.zip', '2025-10-25');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (64, 'backup-on-2025-10-27-09-38-25.zip', '2025-10-27');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (65, 'backup-on-2025-10-29-10-30-36.zip', '2025-10-29');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (66, 'backup-on-2025-10-31-16-39-20.zip', '2025-10-31');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (67, 'backup-on-2025-11-01-11-16-24.zip', '2025-11-01');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (68, 'backup-on-2025-11-03-12-53-05.zip', '2025-11-03');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (69, 'backup-on-2025-11-04-14-43-26.zip', '2025-11-04');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (70, 'backup-on-2025-11-08-09-31-14.zip', '2025-11-08');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (71, 'backup-on-2025-11-11-12-15-41.zip', '2025-11-11');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (72, 'backup-on-2025-11-15-15-40-17.zip', '2025-11-15');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (73, 'backup-on-2025-11-17-16-04-53.zip', '2025-11-17');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (74, 'backup-on-2025-11-18-11-47-48.zip', '2025-11-18');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (75, 'backup-on-2025-11-19-11-03-27.zip', '2025-11-19');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (76, 'backup-on-2025-11-20-10-57-58.zip', '2025-11-20');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (77, 'backup-on-2025-11-21-11-20-15.zip', '2025-11-21');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (78, 'backup-on-2025-11-22-14-51-31.zip', '2025-11-22');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (79, 'backup-on-2025-11-24-11-43-13.zip', '2025-11-24');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (80, 'backup-on-2025-11-25-11-10-03.zip', '2025-11-25');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (81, 'backup-on-2025-12-02-15-51-34.zip', '2025-12-02');


#
# TABLE STRUCTURE FOR: backup_url
#

DROP TABLE IF EXISTS `backup_url`;

CREATE TABLE `backup_url` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: bed_details
#

DROP TABLE IF EXISTS `bed_details`;

CREATE TABLE `bed_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `bed` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: card
#

DROP TABLE IF EXISTS `card`;

CREATE TABLE `card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: cash_bill
#

DROP TABLE IF EXISTS `cash_bill`;

CREATE TABLE `cash_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `dcno` longtext DEFAULT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `dcnos` longtext DEFAULT NULL,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: cashbill_details
#

DROP TABLE IF EXISTS `cashbill_details`;

CREATE TABLE `cashbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `cust_mobno` varchar(255) NOT NULL,
  `address` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `systemDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: cashbill_reports
#

DROP TABLE IF EXISTS `cashbill_reports`;

CREATE TABLE `cashbill_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `systemDate` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `category` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: collection_details
#

DROP TABLE IF EXISTS `collection_details`;

CREATE TABLE `collection_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `collection_details` (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2025-06-20', NULL, '2025-06-20', NULL, 'V/25-26/-001', 'jack', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '800', NULL, NULL, NULL);
INSERT INTO `collection_details` (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '2025-06-20', NULL, '2025-06-20', NULL, 'V/25-26/-002', 'jack', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cheque INDIAN OVERSEAS 484654355454', NULL, NULL, NULL, NULL, '8000', NULL, NULL, NULL);
INSERT INTO `collection_details` (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (3, '2025-06-21', NULL, '2025-06-21', NULL, 'V/25-26/-002', 'SIGMA POWER & ENERGY ENGINEERS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '8800', NULL, NULL, NULL);
INSERT INTO `collection_details` (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (4, '2025-06-24', NULL, '2025-06-24', NULL, 'V/25-26/-004', 'IT Solution', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '500', NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: company_logo
#

DROP TABLE IF EXISTS `company_logo`;

CREATE TABLE `company_logo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `company_logo` (`id`, `date`, `image`, `status`) VALUES (1, '2025-07-14', 'Untitled.png', '1');


#
# TABLE STRUCTURE FOR: customer_details
#

DROP TABLE IF EXISTS `customer_details`;

CREATE TABLE `customer_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `contactperson` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `old_openingBal` varchar(255) DEFAULT NULL,
  `salesamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  `accountpay` varchar(255) NOT NULL,
  `chequeno` varchar(100) NOT NULL,
  `last_modified` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (1, '2025-09-17', 'Intra customer', 'jack', '7806876370', 'jack@gmail.com', 'gandhipuram', 'singanallur', 'maddy', 'Tamil Nadu', 'karaikudi', '', '', NULL, '0.00', NULL, '909970', '300', '909670', NULL, '', NULL, '654616', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33ADXPT3291N2ZJ', '', '', '', '', '', '2025-09-17');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (2, '2025-07-17', 'Intra customer', 'SIGMA POWER & ENERGY ENGINEERS', '7339666782', 'sigmapower@sigmapower.in', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE', 'Phase II, VALAVANTHAN KOTTAI, THUVAKUDI', 'NANDHINI.P', 'Tamil Nadu', 'TRICHY', '', '', NULL, '0.00', NULL, '360527.2', '8800', '623727.2', NULL, '', NULL, '620015', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33ABRFS2547Q1ZD', '', '', '', '', '', '2025-07-17');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (3, '2025-06-21', 'Intra supplier', 'CK PRIME ALLOYS', '', '', 'ANNUR ROAD', 'KARUMATTAMPATTY', '', 'Tamil Nadu', 'COIMBATORE', '', '', NULL, '0.00', NULL, '1858500', '2400', '1856100', NULL, '', NULL, '641659', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2025-06-21');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (4, '2025-06-23', 'Intra customer', 'IT Solution', '09360296512', '', 'Hoysala nagar, Ramamurthy signal', 'Kasthuri nagar', 'Pradeepa D', 'Karnataka', 'Bangalore', '', '', NULL, '0.00', NULL, '2366.7', '500', '1866.7', NULL, '', NULL, '560016', NULL, NULL, NULL, NULL, NULL, '1', '', '', '29', '', '', '', '', '', '', '2025-06-23');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (5, '2025-06-24', 'Intra supplier', 'Gateway', '9500995841', 'lithikutti81@gmail.com', 'Kasthuri nagar, Sri lakshmi apartement', 'Bangalore', 'Lithi', 'Karnataka', 'Bangalore', '', '', NULL, '0.00', NULL, '44370326.66', '500', '22185347.58', '995.50', '', NULL, '560016', NULL, NULL, NULL, NULL, NULL, '1', '', '', '29', '', '', '', '', '', '', '2025-06-24');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (6, '2025-06-25', 'Intra customer', 'Tech AU', '1234567890', 'pradee@gmail.com', 'Hoysala nagar, Ramamurthy signal', 'Avinashi Road, Hopes College', 'Pradeepa D', 'Tamil Nadu', 'Bangalore', '', '', NULL, '0.00', NULL, NULL, NULL, '0.00', NULL, '', NULL, '560016', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2025-06-25');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (7, '2025-07-17', 'Intra customer', 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '7708330192', 'sales@cadalan.com.sg', 'No:54 SRI VIGNESHWAR ILLAM', 'MGR NAGAR, GOLDWINS', 'SELVARAJ', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '0.00', NULL, '7109500', NULL, '14189500', NULL, '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33AAICC6141M1ZK', '', '', '', '', '', '2025-07-17');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (8, '2025-10-08', 'Intra supplier', 'PREMIER ALLOYS', '9894021872', 'premieralloys@yahoo.com', 'No 2, Goldwins,Avinashi Road, ', 'Civil Aerodrome(po)', 'SARAN', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '0.00', NULL, '594187.5', NULL, '296827.5', NULL, '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33AAHFP3172F1ZG', '', '', '', '', '', '2025-10-08');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (9, '2025-11-20', 'Intra customer', 'STAAN BIO MED PVT LTD', '9710240325', 'murugan@staan.in', '190-A, Bharathiar Road', 'Ganapathy', 'MURUGAN', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '0.00', NULL, '913373.1', NULL, '913373.1', NULL, '', NULL, '641006', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33AAICS8026R1ZQ', '', '', '', '', '', '2025-11-20');


#
# TABLE STRUCTURE FOR: customerpo_details
#

DROP TABLE IF EXISTS `customerpo_details`;

CREATE TABLE `customerpo_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `cuspodate` date DEFAULT NULL,
  `invoicetype` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `cuspono` varchar(255) DEFAULT NULL,
  `transport` varchar(255) DEFAULT NULL,
  `customerpodate` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `cstname` varchar(255) DEFAULT NULL,
  `cstamount` varchar(255) DEFAULT NULL,
  `pf` varchar(255) DEFAULT NULL,
  `freight` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `pfadjus` varchar(255) DEFAULT NULL,
  `freightadjus` varchar(255) DEFAULT NULL,
  `roundoff` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: dc_delivery
#

DROP TABLE IF EXISTS `dc_delivery`;

CREATE TABLE `dc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(100) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `grade` varchar(100) NOT NULL,
  `weight` varchar(100) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (4, '2025-06-20', 2, 9, 'Against Inward', 'SDC/25-26/-001', '2025-06-20', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-rotor', '1', '', '', '50', '50', '50', '0001', NULL, 'KGS', '', NULL, '', 'SDC/25-26/-001-25', 'SDC/25-26/-001200625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (5, '2025-06-20', 2, 10, 'Against Inward', 'SDC/25-26/-001', '2025-06-20', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-motor', '2', '', '', '50', '50', '50', '0002', NULL, 'KGS', '', NULL, '', 'SDC/25-26/-001-25', 'SDC/25-26/-001200625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (6, '2025-06-20', 2, 11, 'Against Inward', 'SDC/25-26/-001', '2025-06-20', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-rotor', '1', '', '', '50', '50', '50', '0001', NULL, 'KGS', '', NULL, '', 'SDC/25-26/-001-25', 'SDC/25-26/-001200625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (7, '2025-06-20', 3, NULL, 'Direct DC', 'SDC/25-26/-002', '2025-06-20', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-rotor', '1', '', '', '100', '50', '', '0001', NULL, 'KGS', '', NULL, '', 'SDC/25-26/-002-25', 'SDC/25-26/-002200625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (8, '2025-06-20', 3, NULL, 'Direct DC', 'SDC/25-26/-002', '2025-06-20', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-motor', '2', '', '', '100', '50', '', '0002', NULL, 'KGS', '', NULL, '', 'SDC/25-26/-002-25', 'SDC/25-26/-002200625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (9, '2025-06-20', 4, NULL, 'Direct DC', 'SDC/25-26/-003', '2025-06-20', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-rotor', '1', '', '', '100', '100', '', '0001', NULL, 'KGS', '', NULL, '', 'SDC/25-26/-003-25', 'SDC/25-26/-003200625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (10, '2025-06-20', 4, NULL, 'Direct DC', 'SDC/25-26/-003', '2025-06-20', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-motor', '2', '', '', '100', '100', '', '0002', NULL, 'KGS', '', NULL, '', 'SDC/25-26/-003-25', 'SDC/25-26/-003200625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (11, '2025-06-20', 5, 12, 'Against Inward', 'SDC/25-26/-004', '2025-06-20', 1, 'jack', '', 'gandhipuram, singanallur', 'I002', NULL, NULL, '1080-rotor', '1', '', '', '50', '25', '', '0001', NULL, 'KGS', '', NULL, '', 'SDC/25-26/-004-25', 'SDC/25-26/-004200625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (12, '2025-06-20', 5, 13, 'Against Inward', 'SDC/25-26/-004', '2025-06-20', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-motor', '2', '', '', '50', '25', '', '0002', NULL, 'KGS', '', NULL, '', 'SDC/25-26/-004-25', 'SDC/25-26/-004200625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (13, '2025-06-21', 6, 14, 'Against Inward', 'SDC/25-26/-005', '2025-06-21', 2, 'SIGMA POWER & ENERGY ENGINEERS', '', 'e-5 SIDCO INDUSTRIES ESTATE, THUVAKUDI', 'I003', NULL, NULL, 'EH OUTER BOX', '3', '', '', '50', '50', '', '123456', NULL, 'KGS', '', NULL, '', 'SDC/25-26/-005-25', 'SDC/25-26/-005210625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (14, '2025-06-25', 7, NULL, 'Direct DC', 'SDC/25-26/-006', '2025-06-25', 4, 'IT Solution', '', 'Hoysala nagar, Ramamurthy signal, Kasthuri nagar', NULL, NULL, NULL, 'Stationary things', '4', '', '', '2', '2', 'Urgent Item', '00002', NULL, 'PACK', '', NULL, 'Urgent Item', 'SDC/25-26/-006-25', 'SDC/25-26/-006250625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (21, '2025-07-23', 12, 22, 'Against Inward', 'SDC/25-26/-008', '2025-07-23', 1, 'jack', '', 'gandhipuram, singanallur', 'I006', '', '', '1080 Stator', '8', '1002', '', '50', '49', 'qwerty', '123456', NULL, 'KGS', 'MSS', NULL, '', 'SDC/25-26/-008-25', 'SDC/25-26/-008230725', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (22, '2025-07-23', 12, 23, 'Against Inward', 'SDC/25-26/-008', '2025-07-23', 1, 'jack', '', 'gandhipuram, singanallur', 'I006', '', '', '1/2\" CL 600 Body', '5', '1003', '', '2', '1', 'qwerty', '73259930', NULL, 'KGS', '', NULL, '', 'SDC/25-26/-008-25', 'SDC/25-26/-008230725', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (20, '2025-07-23', 12, 21, 'Against Inward', 'SDC/25-26/-008', '2025-07-23', 1, 'jack', '', 'gandhipuram, singanallur', 'I006', '', '', '1080 Rotor', '7', '1001', '', '50', '49', 'qwerty', '123456', NULL, 'KGS', 'MSS', NULL, '', 'SDC/25-26/-008-25', 'SDC/25-26/-008230725', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (28, '2025-07-23', 13, 23, 'Against Inward', 'SDC/25-26/-009', '2025-07-23', 1, 'jack', '', 'gandhipuram, singanallur', 'I006', '', '', '1/2\" CL 600 Body', '5', '1003', '', '1', '1', 'qwerty', '73259930', NULL, 'KGS', '', NULL, '', 'SDC/25-26/-009-25', 'SDC/25-26/-009230725', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (27, '2025-07-23', 13, 21, 'Against Inward', 'SDC/25-26/-009', '2025-07-23', 1, 'jack', '', 'gandhipuram, singanallur', 'I006', '', '', '1080 Rotor', '7', '1001', '', '10', '10', 'qwerty', '123456', NULL, 'KGS', 'MSS', NULL, '', 'SDC/25-26/-009-25', 'SDC/25-26/-009230725', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (26, '2025-07-23', 13, 22, 'Against Inward', 'SDC/25-26/-009', '2025-07-23', 1, 'jack', '', 'gandhipuram, singanallur', 'I006', '', '', '1080 Stator', '8', '1002', '', '10', '10', 'qwerty', '123456', NULL, 'KGS', 'MSS', NULL, '', 'SDC/25-26/-009-25', 'SDC/25-26/-009230725', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (29, '2025-08-04', 14, NULL, 'Direct DC', 'SDC/25-26/-010', '2025-08-04', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS', NULL, NULL, NULL, 'Coal Nozzle', '6', '200', '', '10', '9', '-', '84803000', '0', 'NOS', 'MSS', NULL, '', 'SDC/25-26/-010-25', 'SDC/25-26/-010040825', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (30, '2025-09-19', 16, NULL, 'Direct DC', 'SDC/25-26/-011', '2025-09-19', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, 'Coal Nozzle', '1', NULL, '-', '15', '15', '-', '123456', '002', 'KGS', '1', '10', NULL, 'SDC/25-26/-011-25', 'SDC/25-26/-011190925', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (31, '2025-09-19', 16, NULL, 'Direct DC', 'SDC/25-26/-011', '2025-09-19', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, 'Coal Nozzle', '1', NULL, '-', '25', '25', '-', '123456', '002', 'KGS', '1', '10', NULL, 'SDC/25-26/-011-25', 'SDC/25-26/-011190925', 1, 1);


#
# TABLE STRUCTURE FOR: dcbill_details
#

DROP TABLE IF EXISTS `dcbill_details`;

CREATE TABLE `dcbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` longtext DEFAULT NULL,
  `customerdcdate` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext DEFAULT NULL,
  `remarks` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `weight` varchar(100) DEFAULT NULL,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (2, '2025-06-20', 'Against Inward', 'SDC/25-26/-001', '2025-06-20', 1, 'jack', '', '07:43:PM', '', '', '', '2000', 'gandhipuram, singanallur', 'I001', NULL, NULL, '1080-rotor||1080-motor||1080-rotor', '1||2||1', '', '||||', '50||50||50', '50||50||50', '0001||0002||0001', NULL, 'KGS||KGS||KGS', '', NULL, 'SDC/25-26/-001-25', 'SDC/25-26/-001200625', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (3, '2025-06-20', 'Direct DC', 'SDC/25-26/-002', '2025-06-20', 1, 'jack', '', '07:44:PM', '', '', '', '2000', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-rotor||1080-motor', '1||2', '', '||', '100||100', '||', '0001||0002', NULL, 'KGS||KGS', '', NULL, 'SDC/25-26/-002-25', 'SDC/25-26/-002200625', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (4, '2025-06-20', 'Direct DC', 'SDC/25-26/-003', '2025-06-20', 1, 'jack', '', '08:01:PM', '', '', '', '2000', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-rotor||1080-motor', '1||2', '', '||', '100||100', '||', '0001||0002', NULL, 'KGS||KGS', '', NULL, 'SDC/25-26/-003-25', 'SDC/25-26/-003200625', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (5, '2025-06-20', 'Against Inward', 'SDC/25-26/-004', '2025-06-20', 1, 'jack', '', '08:11:PM', '', '', '', '2000', 'gandhipuram, singanallur', 'I002', NULL, NULL, '1080-rotor||1080-motor', '1||2', '', '||', '50||50', '||', '0001||0002', NULL, 'KGS||KGS', '', NULL, 'SDC/25-26/-004-25', 'SDC/25-26/-004200625', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (6, '2025-06-21', 'Against Inward', 'SDC/25-26/-005', '2025-06-21', 2, 'SIGMA POWER & ENERGY ENGINEERS', '', '09:50:AM', '', '', '', '', 'e-5 SIDCO INDUSTRIES ESTATE, THUVAKUDI', 'I003', NULL, NULL, 'EH OUTER BOX', '3', '', '', '50', '', '123456', NULL, 'KGS', '', NULL, 'SDC/25-26/-005-25', 'SDC/25-26/-005210625', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (7, '2025-06-25', 'Direct DC', 'SDC/25-26/-006', '2025-06-25', 4, 'IT Solution', '', '10:36:PM', '', '', 'Urgent Item', '', 'Hoysala nagar, Ramamurthy signal, Kasthuri nagar', NULL, NULL, NULL, 'Stationary things', '4', '', '', '2', 'Urgent Item', '00002', '15015', 'PACK', '', NULL, 'SDC/25-26/-006-25', 'SDC/25-26/-006250625', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (8, '2025-07-23', 'Direct DC', 'SDC/25-26/-007', '2025-07-23', 1, 'jack', '001', '01:02:PM', '', '', '', '', 'gandhipuram, singanallur', '', NULL, NULL, '1080 Rotor||1080 Stator', '7||8', '1001||1002', '||', '10||10', 'qwerty||qwerty', '123456||123456', '001||002', 'KGS||KGS', 'MSS||MSS', NULL, 'SDC/25-26/-007-25', 'SDC/25-26/-007230725', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (9, '2025-07-23', 'Direct DC', 'SDC/25-26/-007', '2025-07-23', 1, 'jack', '001', '01:02:PM', '', '', '', '', 'gandhipuram, singanallur', '', NULL, NULL, '1080 Rotor||1080 Stator', '7||8', '1001||1002', '||', '10||10', 'qwerty||qwerty', '123456||123456', '001||002', 'KGS||KGS', 'MSS||MSS', NULL, 'SDC/25-26/-007-25', 'SDC/25-26/-007230725', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (10, '2025-07-23', 'Direct DC', 'SDC/25-26/-007', '2025-07-23', 1, 'jack', '001', '01:02:PM', '', '', '', '', 'gandhipuram, singanallur', '', NULL, NULL, '1080 Rotor||1080 Stator', '7||8', '1001||1002', '||', '10||10', 'qwerty||qwerty', '123456||123456', '001||002', 'KGS||KGS', 'MSS||MSS', NULL, 'SDC/25-26/-007-25', 'SDC/25-26/-007230725', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (11, '2025-07-23', 'Direct DC', 'SDC/25-26/-007', '2025-07-23', 1, 'jack', '001', '03:25:PM', '', '', '', '10000', 'gandhipuram, singanallur', '', '', '', '1080 Rotor||1080 Stator||1080 Stator', '7||8||8', '1001||1002||', '||||', '10||10||10', 'qwerty||qwerty||qqq', '123456||123456||123456', '001||002||002', 'KGS||KGS||KGS', 'MSS||MSS||MSS', NULL, 'SDC/25-26/-007-25', 'SDC/25-26/-007230725', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (12, '2025-07-23', 'Against Inward', 'SDC/25-26/-008', '2025-07-23', 1, 'jack', '', '04:23:PM', '', '', '', '250000', 'gandhipuram, singanallur', 'I006', '', '', '1080 Rotor||1080 Stator||1/2', '7||8||5', '1001||1002||1003', '||||', '50||50||2', 'qwerty||qwerty||qwerty', '123456||123456||73259930', '', 'KGS||KGS||KGS', 'MSS||MSS||', NULL, 'SDC/25-26/-008-25', 'SDC/25-26/-008230725', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (13, '2025-07-23', 'Against Inward', 'SDC/25-26/-009', '2025-07-23', 1, 'jack', '', '04:42:PM', '', '', '', '', 'gandhipuram, singanallur', 'I006', '', '', '1080 Stator||1080 Rotor||1/2\" CL 600 Body', '8||7||5', '1002||1001||1003', '||||', '10||10||1', 'qwerty||qwerty||qwerty', '123456||123456||73259930', '', 'KGS||KGS||KGS', 'MSS||MSS||', NULL, 'SDC/25-26/-009-25', 'SDC/25-26/-009230725', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (14, '2025-08-04', 'Direct DC', 'SDC/25-26/-010', '2025-08-04', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '', '11:51:AM', '', '', '', '10000', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS', '', NULL, NULL, 'Coal Nozzle', '6', '200', '', '10', '-', '84803000', '0', 'NOS', 'MSS', NULL, 'SDC/25-26/-010-25', 'SDC/25-26/-010040825', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (15, '2025-09-19', 'Direct DC', 'SDC/25-26/-011', '2025-09-19', 1, 'jack', '', '10:39:AM', '', '', NULL, '100000', 'gandhipuram, singanallur', '', NULL, NULL, 'Coal Nozzle||Coal Nozzle', '1||1', '', '-||-', '15||25', '-||-', '123456||123456', '002||002', 'KGS||KGS', '1||1', '10||10', 'SDC/25-26/-011-25', 'SDC/25-26/-011190925', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (16, '2025-09-19', 'Direct DC', 'SDC/25-26/-011', '2025-09-19', 1, 'jack', '', '10:39:AM', '', '', NULL, '100000', 'gandhipuram, singanallur', '', NULL, NULL, 'Coal Nozzle||Coal Nozzle', '1||1', '', '-||-', '15||25', '-||-', '123456||123456', '002||002', 'KGS||KGS', '1||1', '10||10', 'SDC/25-26/-011-25', 'SDC/25-26/-011190925', 1, 1, '');


#
# TABLE STRUCTURE FOR: dcbill_details_backup
#

DROP TABLE IF EXISTS `dcbill_details_backup`;

CREATE TABLE `dcbill_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` longtext DEFAULT NULL,
  `customerdcdate` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext DEFAULT NULL,
  `remarks` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: dpt_report
#

DROP TABLE IF EXISTS `dpt_report`;

CREATE TABLE `dpt_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `dpt_report_no` varchar(100) NOT NULL,
  `dpt_date` varchar(100) NOT NULL,
  `customername` varchar(100) DEFAULT NULL,
  `customerid` varchar(100) DEFAULT NULL,
  `report_no` varchar(100) DEFAULT NULL,
  `stage_of_test` varchar(100) DEFAULT NULL,
  `grade` varchar(100) DEFAULT NULL,
  `type_of_penetrant` varchar(100) DEFAULT NULL,
  `casting_temperature` varchar(100) DEFAULT NULL,
  `type_of_developer` varchar(100) DEFAULT NULL,
  `surface_condition` varchar(100) DEFAULT NULL,
  `testing_date` varchar(100) DEFAULT NULL,
  `acceptance_standard` varchar(100) DEFAULT NULL,
  `dwell_time` varchar(100) DEFAULT NULL,
  `procedure_ref` varchar(100) DEFAULT NULL,
  `fluosrecent` varchar(100) DEFAULT NULL,
  `area_method_of_test` varchar(100) DEFAULT NULL,
  `penetrant_apply_method` varchar(10) DEFAULT NULL,
  `precleaning_method` varchar(100) DEFAULT NULL,
  `post_of_test_cleaning` varchar(100) DEFAULT NULL,
  `light_indensity` varchar(100) DEFAULT NULL,
  `background` varchar(100) DEFAULT NULL,
  `result` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `drawing_no` text DEFAULT NULL,
  `heat_no` text DEFAULT NULL,
  `dp_no` text DEFAULT NULL,
  `qty` text DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `dpt_report` (`id`, `date`, `dpt_report_no`, `dpt_date`, `customername`, `customerid`, `report_no`, `stage_of_test`, `grade`, `type_of_penetrant`, `casting_temperature`, `type_of_developer`, `surface_condition`, `testing_date`, `acceptance_standard`, `dwell_time`, `procedure_ref`, `fluosrecent`, `area_method_of_test`, `penetrant_apply_method`, `precleaning_method`, `post_of_test_cleaning`, `light_indensity`, `background`, `result`, `description`, `drawing_no`, `heat_no`, `dp_no`, `qty`, `status`, `created_at`) VALUES (1, '2025-10-22', 'DPT001', '22-10-2025', 'jack', '1', 'DPT', 'DPT', '3', 'DPT', 'DPT', '22-10-2025', 'DPT', '22-10-2025', 'DPT', 'DPT', 'DPT', 'Flourecent', 'DPT', 'DPT', 'DPT', 'DPT', 'DPT', 'DPT', 'DPT', 'Coal Nozzle,Coal Nozzle,Coal Nozzle,Coal Nozzle', '001,001,001,001', 'DPT,DPT,DPT,DPT', 'DPT,DPT,DPT,DPT', 'DPT,DPT,DPT,DPT', 1, '2025-10-22 20:38:46');
INSERT INTO `dpt_report` (`id`, `date`, `dpt_report_no`, `dpt_date`, `customername`, `customerid`, `report_no`, `stage_of_test`, `grade`, `type_of_penetrant`, `casting_temperature`, `type_of_developer`, `surface_condition`, `testing_date`, `acceptance_standard`, `dwell_time`, `procedure_ref`, `fluosrecent`, `area_method_of_test`, `penetrant_apply_method`, `precleaning_method`, `post_of_test_cleaning`, `light_indensity`, `background`, `result`, `description`, `drawing_no`, `heat_no`, `dp_no`, `qty`, `status`, `created_at`) VALUES (2, '2025-11-03', 'DPT002', '20-10-2025', 'SIGMA POWER & ENERGY ENGINEERS', '2', 'LPI/0039/25-26', 'AFTER HEAT TREATMENT', '4', 'MAGNAFLUX SKL-SP1 -', '28\'C TO 40\'C', '20-10-2025', 'ROUGH CASTING', '26-10-2025', 'ASME B16.34 APPENDIX II', ' 10 TO 15 MINTS', 'ASME SEC V - ART 6 & 24', '', '100%', 'BRUSH', 'SOLVENT', 'SOLVENT REMOVING', '1110 LUX', 'WHITE', 'DPI TEST CARRIED OUT AT ALL ACCESSIBLE AREA AND FOUND ACCEPTABLE', 'Collector Casting', '3-SPG-8557 REV0', '2356', 'D25-437', '1', 1, '2025-10-27 13:50:08');
INSERT INTO `dpt_report` (`id`, `date`, `dpt_report_no`, `dpt_date`, `customername`, `customerid`, `report_no`, `stage_of_test`, `grade`, `type_of_penetrant`, `casting_temperature`, `type_of_developer`, `surface_condition`, `testing_date`, `acceptance_standard`, `dwell_time`, `procedure_ref`, `fluosrecent`, `area_method_of_test`, `penetrant_apply_method`, `precleaning_method`, `post_of_test_cleaning`, `light_indensity`, `background`, `result`, `description`, `drawing_no`, `heat_no`, `dp_no`, `qty`, `status`, `created_at`) VALUES (3, '2025-11-04', 'DPT003', '04-11-2025', 'SIGMA POWER & ENERGY ENGINEERS', '2', '1', '1', '4', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', 'Coal Nozzle', '001', '150', '50', '10', 1, '2025-11-04 15:00:57');


#
# TABLE STRUCTURE FOR: einvoicetoken
#

DROP TABLE IF EXISTS `einvoicetoken`;

CREATE TABLE `einvoicetoken` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tokenexpiry` varchar(255) NOT NULL,
  `authtoken` varchar(255) NOT NULL,
  `sek` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS `expenses`;

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `expenses` (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (1, '2025-06-23', '001', 'Pradeepa', '2025-06-23', 'Advance salary', 'Cash', '0', '', '', '0', '', '30000', NULL, 'Cash', '30000', '1', 'Salary ', '');
INSERT INTO `expenses` (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (3, '2025-06-23', '002', 'RM Company', '2025-06-23', 'tea', 'Cheque', 'AXIS', '1224335', '3', '0', '', '', NULL, 'Cheque AXIS 1224335', '3', '1', 'Salary ', '');
INSERT INTO `expenses` (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (4, '2025-06-23', '003', 'RM Company', '2025-06-23', 'tea', 'Cash', 'AXIS', '1224335', '3', '0', '', '30000', NULL, 'Cash', '30000', '1', 'Salary ', '');


#
# TABLE STRUCTURE FOR: expenses_backup
#

DROP TABLE IF EXISTS `expenses_backup`;

CREATE TABLE `expenses_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: grade
#

DROP TABLE IF EXISTS `grade`;

CREATE TABLE `grade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `heat_treatment` varchar(255) DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `hsnno` varchar(100) NOT NULL,
  `element` text DEFAULT NULL,
  `min_value` text DEFAULT NULL,
  `max_value` text DEFAULT NULL,
  `mechanicalelement` text DEFAULT NULL,
  `mechanicalminvalue` text DEFAULT NULL,
  `mechanicalmaxvalue` text DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `grade` (`id`, `date`, `heat_treatment`, `grade`, `hsnno`, `element`, `min_value`, `max_value`, `mechanicalelement`, `mechanicalminvalue`, `mechanicalmaxvalue`, `remarks`, `status`) VALUES (4, '2025-10-08', '', 'BS310 0 309C30', '73259930', 'C,Si,Mn,S,P,Cr,Ni,Mo,,,,,,,', '-,-,-,-,-,22.000,10.000,-,,,,,,,', '-,-,-,-,-,22.000,10.000,-,,,,,,,', 'Yield Strength,Tensile Strength,% Elongation,% Reduction of Area,Hardness,Bend Test,Impact Test in Joules', '-,-,-,-,-,-,-', '-,-,-,-,-,-,-', '', 1);
INSERT INTO `grade` (`id`, `date`, `heat_treatment`, `grade`, `hsnno`, `element`, `min_value`, `max_value`, `mechanicalelement`, `mechanicalminvalue`, `mechanicalmaxvalue`, `remarks`, `status`) VALUES (7, '2025-11-21', 'NORMALAZING : Heated  to  920°C soak for  3 Hrs and  then  air cooled.', 'WCB', '73259999', 'C,Si,Mn,S,P,Cr,Ni,Mo,Cu,V,,,,,', ',,,,,,,,,,,,,,', '0.300,0.600,1.000,0.035,0.035,0.500,0.500,0.200,0.300,0.030,,,,,', 'Yield Strength,Tensile Strength,% Elongation,% Reduction of Area,Hardness,Bend Test,Impact Test in Joules', '250,485,22,35,-,-,-', '-,-,-,-,235,-,-', '<p><span style=\"font-size: 12px;\">﻿Separate test bar poured and the same bar tested for chemical and mechanical properties</span></p><p><span style=\"font-size: 12px;\">&nbsp;Tensile Testing conducted on round specimen at room temperature</span><br></p><p><span style=\"font-size: 12px;\">&nbsp;Visual inspection carried out at as per MSS SP-55, found satisfied</span></p>', 1);


#
# TABLE STRUCTURE FOR: headers
#

DROP TABLE IF EXISTS `headers`;

CREATE TABLE `headers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `headers` (`id`, `date`, `status`, `name`) VALUES (1, '2025-06-23', 1, 'Salary ');


#
# TABLE STRUCTURE FOR: hsnmaster
#

DROP TABLE IF EXISTS `hsnmaster`;

CREATE TABLE `hsnmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `party` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `hsnmaster` (`id`, `date`, `hsnno`, `party`, `status`) VALUES (2, '2025-08-11', '145311090', NULL, 1);


#
# TABLE STRUCTURE FOR: inspection_report
#

DROP TABLE IF EXISTS `inspection_report`;

CREATE TABLE `inspection_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `insno` varchar(100) NOT NULL,
  `inspection_date` varchar(100) NOT NULL,
  `customername` varchar(100) NOT NULL,
  `customerid` varchar(100) NOT NULL,
  `itemname` varchar(100) NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `dimension_in` varchar(100) NOT NULL,
  `sno` longtext NOT NULL,
  `view` longtext NOT NULL,
  `length` longtext NOT NULL,
  `inspection1` longtext NOT NULL,
  `inspection2` longtext NOT NULL,
  `inspection3` longtext NOT NULL,
  `inspection4` longtext NOT NULL,
  `remark` longtext NOT NULL,
  `ndt` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `result` varchar(255) NOT NULL,
  `ndt_remarks` text NOT NULL,
  `overall_remarks` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `inspection_report` (`id`, `date`, `insno`, `inspection_date`, `customername`, `customerid`, `itemname`, `drawingno`, `product_code`, `grade`, `dimension_in`, `sno`, `view`, `length`, `inspection1`, `inspection2`, `inspection3`, `inspection4`, `remark`, `ndt`, `qty`, `result`, `ndt_remarks`, `overall_remarks`, `status`, `created_at`) VALUES (1, '2025-11-03', 'INS001', '04-09-2025', 'SIGMA POWER & ENERGY ENGINEERS', '2', 'Collector Casting', '3-SPG-8557 REV0', 'SP03', '4', '', '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46', 'Length,Length,Width,Length,Height,Inner Width,Degree,Depth,Inner Width,Width,Height,Height,Height,Inner Width,Inner Width,Width,Width,DIM,DIM,DIM,DIM,DIM,DIM,Inner Width,Width,DIM,DIM,DIM,Height,DIM,DIM,DIM,Height,Height,Inner Width,Inner Width,Width,Height,Height,Height,Height,Height,Width,Width,Width,Width', '353,98,331,364,22.5,30,45°,48,126.5,51.5,271,24,11,97,119.5,331,62,1.5°,1.5°,5°,2.5°,5°,1.5°,54.5,98,1.5°,1.5°,1°,32,5°,5°,1.5°,20,35,97,119.5,331,25,42,220,45,32,57,50,70,20', '350,98.5,332,362,22.5,30,45°,48,127,52,272,24,11,97,120.5,332,62,1.5°,1.5°,5°,2.5°,5°,1.5°,54.5,98,1.5°,1.5°,1°,32,5°,5°,1.5°,20,35,97,119.5,332,26,43,225,45,45,45,48,40,20', '350,89.5,21213,12,12,123,123,123,123,121,23,123,12,12,12,213,456,1.5°,1.5°,1.5°,1.5°,1.5°,1.5°,45,7,1.5°,1.5°,1.5°,45,1.5°,1.5°,1.5°,20,74,45,456,456,43521,12,123,123,021,789,546,45,456', ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,', ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,', 'ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ookk,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok', 'DP ,MP,RT,UT,VISUAL (As Per Mss SP-55),DIM.INSPECTION,DESPATCH QTY,OTHER REQUIRMENT', ',,,,20,2,20,', ',,,,20,2,20,', ',,,,,,,', '<p><span style=\"font-size: 12px;\">﻿</span><br></p>', 1, '2025-11-03 13:11:34');
INSERT INTO `inspection_report` (`id`, `date`, `insno`, `inspection_date`, `customername`, `customerid`, `itemname`, `drawingno`, `product_code`, `grade`, `dimension_in`, `sno`, `view`, `length`, `inspection1`, `inspection2`, `inspection3`, `inspection4`, `remark`, `ndt`, `qty`, `result`, `ndt_remarks`, `overall_remarks`, `status`, `created_at`) VALUES (2, '2025-11-04', 'INS002', '04-11-2025', 'SIGMA POWER & ENERGY ENGINEERS', '2', 'Coal Nozzle', '001', '002', '4', '150', '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46', 'Length,Length,Width,Length,Height,Inner Width,Degree,Depth,Inner Width,Width,Height,Height,Height,Inner Width,Inner Width,Width,Width,DIM,DIM,DIM,DIM,DIM,DIM,Inner Width,Width,DIM,DIM,DIM,Height,DIM,DIM,DIM,Height,Height,Inner Width,Inner Width,Width,Height,Height,Height,Height,Height,Width,Width,Width,Width', '353,98,331,364,22.5,30,45°,48,126.5,51.5,271,24,11,97,119.5,331,62,1.5°,1.5°,5°,2.5°,5°,1.5°,54.5,98,1.5°,1.5°,1°,32,5°,5°,1.5°,20,35,97,119.5,331,25,42,220,45,32,57,50,70,20', ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,', ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,', ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,', ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,', ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,', 'DP ,MP,RT,UT,VISUAL (As Per Mss SP-55),DIM.INSPECTION,DESPATCH QTY,OTHER REQUIRMENT', ',,,,,,,', ',,,,,,,', ',,,,,,,', '<p><span style=\"font-size: 12px;\">﻿</span><br></p>', 1, '2025-11-04 14:54:34');
INSERT INTO `inspection_report` (`id`, `date`, `insno`, `inspection_date`, `customername`, `customerid`, `itemname`, `drawingno`, `product_code`, `grade`, `dimension_in`, `sno`, `view`, `length`, `inspection1`, `inspection2`, `inspection3`, `inspection4`, `remark`, `ndt`, `qty`, `result`, `ndt_remarks`, `overall_remarks`, `status`, `created_at`) VALUES (3, '2025-11-04', 'INS003', '04-11-2025', 'SIGMA POWER & ENERGY ENGINEERS', '2', 'Coal Nozzle', '001', '002', '4', '150', '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46', 'Length,Length,Width,Length,Height,Inner Width,Degree,Depth,Inner Width,Width,Height,Height,Height,Inner Width,Inner Width,Width,Width,DIM,DIM,DIM,DIM,DIM,DIM,Inner Width,Width,DIM,DIM,DIM,Height,DIM,DIM,DIM,Height,Height,Inner Width,Inner Width,Width,Height,Height,Height,Height,Height,Width,Width,Width,Width', '353,98,331,364,22.5,30,45°,48,126.5,51.5,271,24,11,97,119.5,331,62,1.5°,1.5°,5°,2.5°,5°,1.5°,54.5,98,1.5°,1.5°,1°,32,5°,5°,1.5°,20,35,97,119.5,331,25,42,220,45,32,57,50,70,20', ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,', ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,', ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,', ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,', ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,', 'DP ,MP,RT,UT,VISUAL (As Per Mss SP-55),DIM.INSPECTION,DESPATCH QTY,OTHER REQUIRMENT', ',,,,,,,', ',,,,,,,', ',,,,,,,', '<p><span style=\"font-size: 12px;\">﻿</span><br></p>', 1, '2025-11-04 14:58:30');


#
# TABLE STRUCTURE FOR: invoice_details
#

DROP TABLE IF EXISTS `invoice_details`;

CREATE TABLE `invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `pino` varchar(255) DEFAULT NULL,
  `purchaseordernos` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) NOT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerdcnos` varchar(100) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `removalDate` date NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToId` varchar(255) DEFAULT NULL,
  `shipToAddress` longtext DEFAULT NULL,
  `deliveryAddress1` longtext DEFAULT NULL,
  `deliveryAddress2` longtext DEFAULT NULL,
  `mobileNo` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `dcnos` longtext DEFAULT NULL,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext DEFAULT NULL,
  `workorderid` varchar(20) NOT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `weight` varchar(100) NOT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `totalqty` varchar(255) DEFAULT NULL,
  `acno` varchar(255) NOT NULL,
  `acdate` varchar(255) NOT NULL,
  `irn` varchar(255) NOT NULL,
  `signedinvoice` longtext NOT NULL,
  `signedqrcode` longtext NOT NULL,
  `status_ein` longtext NOT NULL,
  `ewayno` varchar(255) NOT NULL,
  `ewaydate` varchar(255) NOT NULL,
  `ewbvalidtill` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `status_cd` varchar(255) NOT NULL,
  `status_desc` varchar(255) NOT NULL,
  `einvoice_status` int(11) NOT NULL,
  `eway_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `purchaseorder`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `workorderid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (1, '2025-11-25', '2025-11-25', '', '1970-01-01', 'INV/25-26/-001', '', 'WO/25-26/-001', NULL, 'WO/25-26/-001||WO/25-26/-001', 'PO-2526-0628||PO-2526-0628', 'Tax Invoice', 'Against PO', '', 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', NULL, NULL, '', '2025-11-25', '12:14 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '', '4||3', '73259999||73259999', 'SBM05||SBM03', 'LH INNER BOX||LH OUTER BOX', '||', '', 'heatno : R1001-10 , R1002-10 , R1003-10||heatno : R1011-10 , R1012-10 , R1013-10', 'KGS||KGS', '7||7', '167||167', '30||30', '26.1||25.4', '130761.00||127254.00', '0||0', 'amount_wise', '', '130761.00||127254.00', '9', '23221.35', '9', '23221.35', '18', '', '', '258015.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '304457.70', '304457.70', 1, 'INV/25-26/-001251125', 'INV/25-26/-001-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `purchaseorder`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `workorderid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (2, '2025-11-25', '2025-11-25', '', '1970-01-01', 'INV/25-26/-001', '', 'WO/25-26/-001', NULL, 'WO/25-26/-001||WO/25-26/-001', 'PO-2526-0628||PO-2526-0628', 'Tax Invoice', 'Against PO', '', 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', NULL, NULL, '', '2025-11-25', '12:14 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '', '4||3', '73259999||73259999', 'SBM05||SBM03', 'LH INNER BOX||LH OUTER BOX', '||', '', 'heatno : R1001-10 , R1002-10 , R1003-10||heatno : R1011-10 , R1012-10 , R1013-10', 'KGS||KGS', '7||7', '167||167', '30||30', '26.1||25.4', '130761.00||127254.00', '0||0', 'amount_wise', '', '130761.00||127254.00', '9', '23221.35', '9', '23221.35', '18', '', '', '258015.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '304457.70', '304457.70', 1, 'INV/25-26/-001251125', 'INV/25-26/-001-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);


#
# TABLE STRUCTURE FOR: invoice_details_backup
#

DROP TABLE IF EXISTS `invoice_details_backup`;

CREATE TABLE `invoice_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `pino` varchar(255) DEFAULT NULL,
  `purchaseordernos` varchar(255) DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerdcnos` varchar(100) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `removalDate` date NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToId` varchar(255) DEFAULT NULL,
  `shipToAddress` longtext DEFAULT NULL,
  `deliveryAddress1` longtext DEFAULT NULL,
  `deliveryAddress2` longtext DEFAULT NULL,
  `mobileNo` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `dcnos` longtext DEFAULT NULL,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `heatno` varchar(100) NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `itemcode` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `weight` varchar(100) NOT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `totalqty` varchar(255) DEFAULT NULL,
  `acno` varchar(255) NOT NULL,
  `acdate` varchar(255) NOT NULL,
  `irn` varchar(255) NOT NULL,
  `signedinvoice` longtext NOT NULL,
  `signedqrcode` longtext NOT NULL,
  `status_ein` longtext NOT NULL,
  `ewayno` varchar(255) NOT NULL,
  `ewaydate` varchar(255) NOT NULL,
  `ewbvalidtill` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `status_cd` varchar(255) NOT NULL,
  `status_desc` varchar(255) NOT NULL,
  `einvoice_status` int(11) NOT NULL,
  `eway_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: invoice_party_statement
#

DROP TABLE IF EXISTS `invoice_party_statement`;

CREATE TABLE `invoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `weight` varchar(100) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '-', '-', NULL, '2025-11-25', 'INV/25-26/-001', 9, 'STAAN BIO MED PVT LTD', '', '', '', 'LH INNER BOX||LH OUTER BOX', 'heatno : R1001-10 , R1002-10 , R1003-10||heatno : R1011-10 , R1012-10 , R1013-10', '', '', '', NULL, NULL, '', '', '1', '2025-11-25', '2025-11-25', '304457.70', '-', '-', '', '', '-', '-', NULL, '913373.1', '-', '-', '-', '-', '304457.70', '-', '304457.70', NULL, NULL, 'INV/25-26/-001-2025', 'INV/25-26/-001251125', '2');


#
# TABLE STRUCTURE FOR: invoice_party_statement_backup
#

DROP TABLE IF EXISTS `invoice_party_statement_backup`;

CREATE TABLE `invoice_party_statement_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `weight` varchar(100) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: invoice_reports
#

DROP TABLE IF EXISTS `invoice_reports`;

CREATE TABLE `invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseordernos` varchar(100) NOT NULL,
  `purchaseorder` varchar(100) NOT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `heatno` varchar(100) DEFAULT NULL,
  `itemid` varchar(100) NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `uom` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `weight` varchar(100) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  `workorderid` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (1, '2025-11-25', 'INV/25-26/-001', 'WO/25-26/-001||WO/25-26/-001', 'PO-2526-0628||PO-2526-0628', '2025-11-25', NULL, NULL, 9, 'STAAN BIO MED PVT LTD', NULL, NULL, NULL, '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '73259999', NULL, '', 'SBM05', NULL, 'LH INNER BOX', 'heatno : R1001-10 , R1002-10 , R1003-10', '1', '', '7', '30', '26.1', '', NULL, '258015.00', NULL, NULL, '304457.70', NULL, NULL, '1', 'INV/25-26/-001-2025', 'INV/25-26/-001251125', '2', '4');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (2, '2025-11-25', 'INV/25-26/-001', 'WO/25-26/-001||WO/25-26/-001', 'PO-2526-0628||PO-2526-0628', '2025-11-25', NULL, NULL, 9, 'STAAN BIO MED PVT LTD', NULL, NULL, NULL, '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '73259999', NULL, '', 'SBM03', NULL, 'LH OUTER BOX', 'heatno : R1011-10 , R1012-10 , R1013-10', '6', '', '7', '30', '25.4', '', NULL, '258015.00', NULL, NULL, '304457.70', NULL, NULL, '1', 'INV/25-26/-001-2025', 'INV/25-26/-001251125', '2', '3');


#
# TABLE STRUCTURE FOR: inward_delivery
#

DROP TABLE IF EXISTS `inward_delivery`;

CREATE TABLE `inward_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insertid` int(11) NOT NULL,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(50) NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `lastupdatedqty` int(11) NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(50) NOT NULL,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `inward_status` int(11) DEFAULT NULL,
  `lastupdated` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (9, 4, '2025-06-20', 'I001', '2025-06-20', 'jack', 'gandhipuram, singanallur', '001', '2025-06-20', '1', '', '1080-rotor', '', '100', '50', 100, '', '0001', NULL, 'KGS', '', 'I001-25', 'I001200625', 1, 1, '2025-06-20 19:42:54');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (10, 4, '2025-06-20', 'I001', '2025-06-20', 'jack', 'gandhipuram, singanallur', '001', '2025-06-20', '2', '', '1080-motor', '', '100', '50', 100, '', '0002', NULL, 'KGS', '', 'I001-25', 'I001200625', 1, 1, '2025-06-20 19:42:54');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (11, 4, '2025-06-20', 'I001', '2025-06-20', 'jack', 'gandhipuram, singanallur', '001', '2025-06-20', '1', '', '1080-rotor', '', '100', '50', 100, '', '0001', NULL, 'KGS', '', 'I001-25', 'I001200625', 1, 1, '2025-06-20 19:42:54');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (12, 5, '2025-06-20', 'I002', '2025-06-20', 'jack', 'gandhipuram, singanallur', '002', '2025-06-20', '1', '', '1080-rotor', '', '100', '50', 100, '', '0001', NULL, 'KGS', '', 'I002-25', 'I002200625', 1, 1, '2025-06-20 20:11:08');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (13, 5, '2025-06-20', 'I002', '2025-06-20', 'jack', 'gandhipuram, singanallur', '002', '2025-06-20', '2', '', '1080-motor', '', '100', '50', 100, '', '0002', NULL, 'KGS', '', 'I002-25', 'I002200625', 1, 1, '2025-06-20 20:11:08');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (14, 6, '2025-06-20', 'I003', '2025-06-20', 'SIGMA POWER & ENERGY ENGINEERS', 'e-5 SIDCO INDUSTRIES ESTATE, THUVAKUDI', '001', '2025-06-20', '3', '', 'EH OUTER BOX', '', '100', '50', 100, '', '123456', NULL, 'KGS', '', 'I003-25', 'I003200625', 1, 1, '2025-06-21 09:48:40');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (15, 7, '2025-06-25', 'I004', '2025-06-25', 'IT Solution', 'Hoysala nagar, Ramamurthy signal, Kasthuri nagar', 'Hosur', '2025-06-25', '4', '', 'Stationary things', '', '2', '2', 2, 'Urgent needed', '00002', NULL, 'PACK', '', 'I004-25', 'I004250625', 1, 1, '2025-06-25 21:36:23');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (19, 8, '2025-07-22', 'I005', '2025-07-22', 'jack', 'gandhipuram, singanallur', '001', '2025-07-22', '8', '1001', '1080 Stator', '', '100', '100', 100, 'qwerty', '123456', '002', 'KGS', '', 'I005-25', 'I005220725', 1, 1, '2025-07-22 19:24:30');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (17, 8, '2025-07-22', 'I005', '2025-07-22', 'jack', 'gandhipuram, singanallur', '001', '2025-07-22', '8', '', '1080 Stator', '', '100', '100', 100, 'qwerty', '123456', '1002', 'KGS', '', 'I005-25', 'I005220725', 1, 1, '2025-07-22 19:24:30');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (16, 8, '2025-07-22', 'I005', '2025-07-22', 'jack', 'gandhipuram, singanallur', '001', '2025-07-22', '7', '', '1080 Rotor', '', '100', '100', 100, 'qwerty', '123456', '1001', 'KGS', '', 'I005-25', 'I005220725', 1, 1, '2025-07-22 19:24:30');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (20, 8, '2025-07-22', 'I005', '2025-07-22', 'jack', 'gandhipuram, singanallur', '001', '2025-07-22', '5', '', '1/2\" CL 600 Body', '', '5', '5', 5, 'Machining', '73259930', 'CA16', 'KGS', '', 'I005-25', 'I005220725', 1, 1, '2025-07-22 19:24:30');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (22, 9, '2025-07-23', 'I006', '2025-07-23', 'jack', 'gandhipuram, singanallur', '002', '2025-07-23', '8', '1002', '1080 Stator', '', '100', '40', 100, 'qwerty', '123456', '002', 'KGS', 'MSS', 'I006-25', 'I006230725', 1, 1, '2025-07-23 15:39:02');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (21, 9, '2025-07-23', 'I006', '2025-07-23', 'jack', 'gandhipuram, singanallur', '002', '2025-07-23', '7', '1001', '1080 Rotor', '', '100', '40', 100, 'qwerty', '123456', '001', 'KGS', 'MSS', 'I006-25', 'I006230725', 1, 1, '2025-07-23 15:39:02');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (23, 9, '2025-07-23', 'I006', '2025-07-23', 'jack', 'gandhipuram, singanallur', '002', '2025-07-23', '5', '1003', '1/2\" CL 600 Body', '', '5', '2', 5, 'qwerty', '73259930', 'CA16', 'KGS', '', 'I006-25', 'I006230725', 1, 1, '2025-07-23 15:39:02');


#
# TABLE STRUCTURE FOR: inward_details
#

DROP TABLE IF EXISTS `inward_details`;

CREATE TABLE `inward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(50) NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(50) NOT NULL,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (4, '2025-06-20', 'I001', '2025-06-20', 'jack', 'gandhipuram, singanallur', '001', '2025-06-20', '1||2||1', '', '1080-rotor||1080-motor||1080-rotor', '', '100||100||100', '', '0001||0002||0001', NULL, 'KGS||KGS||KGS', '', 'I001-25', 'I001200625', 1, 0, '9,10,11');
INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (5, '2025-06-20', 'I002', '2025-06-20', 'jack', 'gandhipuram, singanallur', '002', '2025-06-20', '1||2', '', '1080-rotor||1080-motor', '', '100||100', '', '0001||0002', NULL, 'KGS||KGS', '', 'I002-25', 'I002200625', 1, 0, '12,13');
INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (6, '2025-06-20', 'I003', '2025-06-20', 'SIGMA POWER & ENERGY ENGINEERS', 'e-5 SIDCO INDUSTRIES ESTATE, THUVAKUDI', '001', '2025-06-20', '3', '', 'EH OUTER BOX', '', '100', '', '123456', NULL, 'KGS', '', 'I003-25', 'I003200625', 1, 0, '14');
INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (7, '2025-06-25', 'I004', '2025-06-25', 'IT Solution', 'Hoysala nagar, Ramamurthy signal, Kasthuri nagar', 'Hosur', '2025-06-25', '4', '', 'Stationary things', '', '2', 'Urgent needed', '00002', NULL, 'PACK', '', 'I004-25', 'I004250625', 1, 1, '15');
INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (8, '2025-07-22', 'I005', '2025-07-22', 'jack', 'gandhipuram, singanallur', '001', '2025-07-22', '7||8||8||5', '001||002||003||004', '1080 Rotor||1080 Stator||1080 Stator||1/2\" CL 600 Body', '', '100||100||100||5', 'qwerty||qwerty||qwerty||Machining', '123456||123456||123456||73259930', '1001||1002||002||CA16', 'KGS||KGS||KGS||KGS', 'MSS||MSS||MSS', 'I005-25', 'I005220725', 1, 1, '16,17,19,20');
INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (9, '2025-07-23', 'I006', '2025-07-23', 'jack', 'gandhipuram, singanallur', '002', '2025-07-23', '7||8||5', '1001||1002||1003', '1080 Rotor||1080 Stator||1/2\" CL 600 Body', '', '100||100||5', 'qwerty||qwerty||qwerty', '123456||123456||73259930', '001||002||CA16', 'KGS||KGS||KGS', 'MSS||MSS', 'I006-25', 'I006230725', 1, 0, '21,22,23');


#
# TABLE STRUCTURE FOR: inward_details_backup
#

DROP TABLE IF EXISTS `inward_details_backup`;

CREATE TABLE `inward_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(100) NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: job_data
#

DROP TABLE IF EXISTS `job_data`;

CREATE TABLE `job_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: job_details
#

DROP TABLE IF EXISTS `job_details`;

CREATE TABLE `job_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `joborderdate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext DEFAULT NULL,
  `category` longtext DEFAULT NULL,
  `jobdescription` longtext DEFAULT NULL,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: jobinward_data
#

DROP TABLE IF EXISTS `jobinward_data`;

CREATE TABLE `jobinward_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `joborderqty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobinward_details
#

DROP TABLE IF EXISTS `jobinward_details`;

CREATE TABLE `jobinward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `jobinwarddate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `category` longtext DEFAULT NULL,
  `jobdescription` longtext DEFAULT NULL,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobworkdc_delivery
#

DROP TABLE IF EXISTS `jobworkdc_delivery`;

CREATE TABLE `jobworkdc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `jobworkdc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (1, '2025-06-25', 1, NULL, 'Direct DC', 'PDC/25-26/001', '2025-06-25', 0, 'Tech AU', '', 'Avinashi Road, Hopes College', NULL, NULL, NULL, 'Stationary things', '', '2', '2', 'Urgent', '00002', '15015', 'PACK', 'PDC/25-26/001-25', 'PDC/25-26/001250625', 1, 1);


#
# TABLE STRUCTURE FOR: jobworkdc_delivery_backup
#

DROP TABLE IF EXISTS `jobworkdc_delivery_backup`;

CREATE TABLE `jobworkdc_delivery_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: jobworkdc_details
#

DROP TABLE IF EXISTS `jobworkdc_details`;

CREATE TABLE `jobworkdc_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` longtext DEFAULT NULL,
  `customerdcdate` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext DEFAULT NULL,
  `remarks` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `jobworkdc_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (1, '2025-06-25', 'Direct DC', 'PDC/25-26/001', '2025-06-25', 0, 'Tech AU', '', '12:50:PM', 'Online Purchase', '', '', '', 'Avinashi Road, Hopes College', NULL, NULL, NULL, 'Stationary things', '', '2', 'Urgent', '00002', '15015', 'PACK', 'PDC/25-26/001-25', 'PDC/25-26/001250625', 1, 1, '');


#
# TABLE STRUCTURE FOR: jobworkdc_details_backup
#

DROP TABLE IF EXISTS `jobworkdc_details_backup`;

CREATE TABLE `jobworkdc_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` longtext DEFAULT NULL,
  `customerdcdate` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext DEFAULT NULL,
  `remarks` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: login_details
#

DROP TABLE IF EXISTS `login_details`;

CREATE TABLE `login_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userType` char(1) NOT NULL,
  `date` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `sub_menu_link` text DEFAULT NULL,
  `selectedMainMenu` text NOT NULL,
  `selectedSubMenu` text NOT NULL,
  `add_party` int(11) DEFAULT NULL,
  `add_expenses` int(11) DEFAULT NULL,
  `add_quotation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (1, 'A', '2017-01-26', 'admin', '', 'test@gmail.com', '876049652', '0000-00-00', 'admin', 'admin001', '1', '', '', '', NULL, NULL, NULL);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (5, 'U', '2018-05-02', 'purchase', 'Purchase Team', '', '', '1970-01-01', 'purchase', '123456', '1', 'purchase,inward,inward/view,inward/pending,stockmaster,daily_stockreports,customer/view', 'Purchase,Inward,Inward,Inward,Stock,Stock,Reports', 'Purchase Receipt,Add Inward,Inward Reports,Inward Pending,Add Stock,Daily Stock Reports,Party Reports', 1, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (6, 'U', '2018-05-02', 'Accounts', 'Accounts Team', '', '', '1970-01-01', 'Accounts', '123456', '1', 'invoice_statement/view,tax/view,cashbill/listing,purchase_statement/view,purchasetax/view,voucher,voucher/reports,stockmaster,daily_stockreports,itemwise_report,expenses/reports,quotation/view', 'Sales Invoice,Sales Invoice,Cash Bill,Purchase,Purchase,Voucher,Voucher,Stock,Stock,Stock,Reports,Reports', 'Invoice Party Statement,Invoice Tax Reports,Cash Bill Reports,Purchase Party Statement,Purchase Tax Reports,Add Voucher,Voucher Reports,Add Stock,Daily Stock Reports,Itemwise Reports,Expenses Reports,Quotation Reports', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (7, 'U', '2018-08-10', 'ramesh', 'developer', '', '', '1970-01-01', 'ramesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/reports,purchase_statement/view,purchasetax/view,stockmaster,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Stock,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Add Stock,Add Item', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (8, 'U', '2018-08-10', 'tester1', 'testing', '', '', '1970-01-01', 'tester1', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/view,purchase_statement/view,purchasetax/view,taxtype,uom,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Settings,Settings,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Tax Type,Add UOM,Add Item', 1, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (9, 'U', '2021-06-28', 'parmesh', 'developer', 'pshm956@gmail.com', '8344031191', '2021-06-28', 'parmesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,proforma_invoice/view', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Proforma Invoice Reports', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (10, 'U', '2023-09-12', 'jp', 'quotation', 'jp@idreamdevelopers.com', '7810028222', '2023-09-12', 'jp', '123456', '1', 'taxtype,uom,itemmaster,headers,profile,backup,support,usermaster', 'Settings,Settings,Settings,Settings,Settings,Settings,Settings,Settings', 'Tax Type,Add UOM,Add Item,Account Headers,Company Profile,Backup Settings,Support,User Manager', 1, 1, 1);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (12, 'U', '2025-06-20', 'Pradeepa ', 'Technical support', 'pradee@gmail.com', '9500995841', '2025-06-03', 'Pradeepa ', 'adminoo1', '1', '', '', '', 0, 0, 0);


#
# TABLE STRUCTURE FOR: materialdc_delivery
#

DROP TABLE IF EXISTS `materialdc_delivery`;

CREATE TABLE `materialdc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: materialdc_details
#

DROP TABLE IF EXISTS `materialdc_details`;

CREATE TABLE `materialdc_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` longtext DEFAULT NULL,
  `customerdcdate` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext DEFAULT NULL,
  `remarks` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: materialdc_details_backup
#

DROP TABLE IF EXISTS `materialdc_details_backup`;

CREATE TABLE `materialdc_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` longtext DEFAULT NULL,
  `customerdcdate` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext DEFAULT NULL,
  `remarks` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: mpt_report
#

DROP TABLE IF EXISTS `mpt_report`;

CREATE TABLE `mpt_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `mpt_report_no` varchar(100) NOT NULL,
  `mpt_date` varchar(100) NOT NULL,
  `customername` varchar(100) NOT NULL,
  `customerid` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `equipment_make` varchar(100) NOT NULL,
  `magnetic_powder_color` varchar(100) NOT NULL,
  `equipment_type` varchar(100) NOT NULL,
  `prod_spacing` varchar(100) NOT NULL,
  `procedure_ref` varchar(100) NOT NULL,
  `current_amps` varchar(100) NOT NULL,
  `stage_of_test` varchar(100) NOT NULL,
  `magnetisation` varchar(100) NOT NULL,
  `process` varchar(100) NOT NULL,
  `surface_condition` varchar(100) NOT NULL,
  `inspection_date` varchar(100) NOT NULL,
  `acceptance_standard` varchar(100) NOT NULL,
  `current` varchar(100) NOT NULL,
  `medium` varchar(100) NOT NULL,
  `light_indensity` varchar(100) NOT NULL,
  `fluosrecent` varchar(100) NOT NULL,
  `area_of_test` varchar(100) NOT NULL,
  `casting_temp` varchar(100) NOT NULL,
  `demagnetization` varchar(100) NOT NULL,
  `observation` varchar(100) NOT NULL,
  `po_no_dt` longtext NOT NULL,
  `description` longtext NOT NULL,
  `drawing_no` longtext NOT NULL,
  `heat_no` longtext NOT NULL,
  `mpi_no` longtext NOT NULL,
  `desp_qty` longtext NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_by` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `mpt_report` (`id`, `date`, `mpt_report_no`, `mpt_date`, `customername`, `customerid`, `grade`, `equipment_make`, `magnetic_powder_color`, `equipment_type`, `prod_spacing`, `procedure_ref`, `current_amps`, `stage_of_test`, `magnetisation`, `process`, `surface_condition`, `inspection_date`, `acceptance_standard`, `current`, `medium`, `light_indensity`, `fluosrecent`, `area_of_test`, `casting_temp`, `demagnetization`, `observation`, `po_no_dt`, `description`, `drawing_no`, `heat_no`, `mpi_no`, `desp_qty`, `status`, `created_by`) VALUES (1, '2025-10-22', 'MPT001', '22-10-2025', 'jack', '1', '3', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm', '22-10-2025', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm', 'Flourecent', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm,mtcForm,mtcForm,mtcForm', 'Coal Nozzle,Coal Nozzle,Coal Nozzle,Coal Nozzle', '001,001,001,001', 'mtcForm,mtcForm,mtcForm,mtcForm', 'mtcForm,mtcForm,mtcForm,mtcForm', 'mtcForm,mtcForm,mtcForm,mtcForm', 1, '2025-10-22 19:09:39');
INSERT INTO `mpt_report` (`id`, `date`, `mpt_report_no`, `mpt_date`, `customername`, `customerid`, `grade`, `equipment_make`, `magnetic_powder_color`, `equipment_type`, `prod_spacing`, `procedure_ref`, `current_amps`, `stage_of_test`, `magnetisation`, `process`, `surface_condition`, `inspection_date`, `acceptance_standard`, `current`, `medium`, `light_indensity`, `fluosrecent`, `area_of_test`, `casting_temp`, `demagnetization`, `observation`, `po_no_dt`, `description`, `drawing_no`, `heat_no`, `mpi_no`, `desp_qty`, `status`, `created_by`) VALUES (2, '2025-10-25', 'MPT002', '25-10-2025', 'SIGMA POWER & ENERGY ENGINEERS', '2', '4', 'DEV ENGG', 'FLUORECSENT', 'PROD', '4\" TO 6\" ', 'ASME SEC V Art-7 & 25/ASTM E709-2021 ', '400-700 AMPS', 'AFTER HEAT TREATMENT', 'CIRCULAR', 'WET', 'As Cast', '23-10-2025', 'SME B16.34 APPENDIX II-', 'HWDE', 'MAGNAFLUX MG2410 BATCH NO:22D49,EXP Dt: APR 2027', '1200 Microwatts/Sq.cm', 'Fluosrecent', 'All External and Internal Accessible Area', '32°c ', ' NOT DONE ', 'NO RECORDABLE INDICATIONS OBSERVED,FOUND ACCEPTED', 'P002/8/10/2025', 'Collector Casting', '3-SPG-8557 REV0', '2356', 'M25-1868', '1', 1, '2025-10-25 12:57:58');


#
# TABLE STRUCTURE FOR: mtc_report
#

DROP TABLE IF EXISTS `mtc_report`;

CREATE TABLE `mtc_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `tcno` varchar(100) NOT NULL,
  `tcdate` varchar(100) NOT NULL,
  `heatno` varchar(100) NOT NULL,
  `customername` varchar(100) NOT NULL,
  `customerid` varchar(100) NOT NULL,
  `purchaseorderno` varchar(100) NOT NULL,
  `purchaseorder` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `heat_treatment` text NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `drawing_no` varchar(100) NOT NULL,
  `partno` varchar(100) NOT NULL,
  `poured_qty` varchar(100) NOT NULL,
  `chemical_element` text NOT NULL,
  `chemical_minvalue` text NOT NULL,
  `chemical_maxvalue` text NOT NULL,
  `chemical_actualvalue` text NOT NULL,
  `mechanical_element` longtext NOT NULL,
  `mechanical_minvalue` text NOT NULL,
  `mechanical_maxvalue` text NOT NULL,
  `mechanical_actualvalue` text NOT NULL,
  `remarks` longtext NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `mtc_report` (`id`, `date`, `tcno`, `tcdate`, `heatno`, `customername`, `customerid`, `purchaseorderno`, `purchaseorder`, `grade`, `heat_treatment`, `product_code`, `itemname`, `drawing_no`, `partno`, `poured_qty`, `chemical_element`, `chemical_minvalue`, `chemical_maxvalue`, `chemical_actualvalue`, `mechanical_element`, `mechanical_minvalue`, `mechanical_maxvalue`, `mechanical_actualvalue`, `remarks`, `status`) VALUES (1, '2025-11-24', 'MTC001', '07-10-2025', 'R1012', 'STAAN BIO MED PVT LTD', '9', 'PO-2526-0628', 'WO/25-26/-001', '7', 'NORMALAZING : Heated  to  920°C soak for  3 Hrs and  then  air cooled.', 'SBM03', 'LH OUTER BOX', 'STMSC016', '', '10', 'C,Si,Mn,S,P,Cr,Ni,Mo,Cu,V,,,,,', ',,,,,,,,,,,,,,', '0.300,0.600,1.000,0.035,0.035,0.500,0.500,0.200,0.300,0.030,,,,,', '0.250,0.580,0.951,0.021,0.016,0.458,0.460,0.158,0.245,0.002,,,,,', 'Yield Strength,Tensile Strength,% Elongation,% Reduction of Area,Hardness,Bend Test,Impact Test in Joules', '250,485,22,35,-,-,-', '-,-,-,-,235,-,-', '351,531,27,48,200,,', '<p><span style=\"font-size: 12px;\">﻿Separate test bar poured and the same bar tested for chemical and mechanical properties</span></p><p><span style=\"font-size: 12px;\">&nbsp;Tensile Testing conducted on round specimen at room temperature</span><br></p><p><span style=\"font-size: 12px;\">&nbsp;Visual inspection carried out at as per MSS SP-55, found satisfied</span></p>', 1);
INSERT INTO `mtc_report` (`id`, `date`, `tcno`, `tcdate`, `heatno`, `customername`, `customerid`, `purchaseorderno`, `purchaseorder`, `grade`, `heat_treatment`, `product_code`, `itemname`, `drawing_no`, `partno`, `poured_qty`, `chemical_element`, `chemical_minvalue`, `chemical_maxvalue`, `chemical_actualvalue`, `mechanical_element`, `mechanical_minvalue`, `mechanical_maxvalue`, `mechanical_actualvalue`, `remarks`, `status`) VALUES (3, '2025-11-24', 'MTC002', '07-10-2025', 'R1011', 'STAAN BIO MED PVT LTD', '9', 'PO-2526-0628', 'WO/25-26/-001', '7', 'NORMALAZING : Heated  to  920°C soak for  3 Hrs and  then  air cooled.', 'SBM03', 'LH OUTER BOX', 'STMSC016', '', '10', 'C,Si,Mn,S,P,Cr,Ni,Mo,Cu,V,,,,,', ',,,,,,,,,,,,,,', '0.300,0.600,1.000,0.035,0.035,0.500,0.500,0.200,0.300,0.030,,,,,', '0.250,0.250,0.951,0.021,0.019,0.354,0.265,0.162,0.200,0.001,,,,,', 'Yield Strength,Tensile Strength,% Elongation,% Reduction of Area,Hardness,Bend Test,Impact Test in Joules', '250,485,22,35,-,-,-', '-,-,-,-,235,-,-', '351,548,37,45,218,,', '<p><span style=\"font-size: 12px;\">﻿Separate test bar poured and the same bar tested for chemical and mechanical properties</span></p><p><span style=\"font-size: 12px;\">&nbsp;Tensile Testing conducted on round specimen at room temperature</span><br></p><p><span style=\"font-size: 12px;\">&nbsp;Visual inspection carried out at as per MSS SP-55, found satisfied</span></p>', 1);
INSERT INTO `mtc_report` (`id`, `date`, `tcno`, `tcdate`, `heatno`, `customername`, `customerid`, `purchaseorderno`, `purchaseorder`, `grade`, `heat_treatment`, `product_code`, `itemname`, `drawing_no`, `partno`, `poured_qty`, `chemical_element`, `chemical_minvalue`, `chemical_maxvalue`, `chemical_actualvalue`, `mechanical_element`, `mechanical_minvalue`, `mechanical_maxvalue`, `mechanical_actualvalue`, `remarks`, `status`) VALUES (4, '2025-11-24', 'MTC003', '07-10-2025', 'R1001', 'STAAN BIO MED PVT LTD', '9', 'PO-2526-0628', 'WO/25-26/-001', '7', 'NORMALAZING : Heated  to  920°C soak for  3 Hrs and  then  air cooled.', 'SBM05', 'LH INNER BOX', 'STMS014', '', '10', 'C,Si,Mn,S,P,Cr,Ni,Mo,Cu,V,,,,,', ',,,,,,,,,,,,,,', '0.300,0.600,1.000,0.035,0.035,0.500,0.500,0.200,0.300,0.030,,,,,', '0.250,0.250,0.958,0.030,0.025,0.458,0.459,0.153,0.258,0.002,,,,,', 'Yield Strength,Tensile Strength,% Elongation,% Reduction of Area,Hardness,Bend Test,Impact Test in Joules', '250,485,22,35,-,-,-', '-,-,-,-,235,-,-', '380,590,35,45,200,,', '<p><span style=\"font-size: 12px;\">﻿Separate test bar poured and the same bar tested for chemical and mechanical properties</span></p><p><span style=\"font-size: 12px;\">&nbsp;Tensile Testing conducted on round specimen at room temperature</span><br></p><p><span style=\"font-size: 12px;\">&nbsp;Visual inspection carried out at as per MSS SP-55, found satisfied</span></p>', 1);


#
# TABLE STRUCTURE FOR: po_party_statements
#

DROP TABLE IF EXISTS `po_party_statements`;

CREATE TABLE `po_party_statements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (1, '2025-10-06', '2025-10-06', '-', 'P001', 8, 'PREMIER ALLOYS', NULL, NULL, 'LH INNER BOX||LH INNER BOX||LH INNER BOX||LH OUTER BOX', NULL, '143210.70', '-', '-', '-', '-', '-', '157457.7', NULL, '-', '-', '-', '-', '-', '47736.90||47736.90||47736.90||', '-', NULL, '-', NULL, '143210.70', NULL, 'PA/0121/25-26', '2025-10-06', '1', 'P001241125', 'P001-2025', '1');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (2, '2025-10-13', '2025-10-13', '-', 'P0002', 8, 'PREMIER ALLOYS', NULL, NULL, 'LH OUTER BOX||LH OUTER BOX||LH OUTER BOX', NULL, '139369.80', '-', '-', '-', '-', '-', '296827.5', NULL, '-', '-', '-', '-', '-', '46456.60||46456.60||46456.60', '-', NULL, '-', NULL, '139369.80', NULL, 'PA/0130/25-26', '2025-10-13', '1', 'P0002241125', 'P0002-2025', '2');


#
# TABLE STRUCTURE FOR: po_party_statements_backup
#

DROP TABLE IF EXISTS `po_party_statements_backup`;

CREATE TABLE `po_party_statements_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: preference_details
#

DROP TABLE IF EXISTS `preference_details`;

CREATE TABLE `preference_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `sed` varchar(255) DEFAULT NULL,
  `edc` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: preference_settings
#

DROP TABLE IF EXISTS `preference_settings`;

CREATE TABLE `preference_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotationPrefix` varchar(255) NOT NULL,
  `quotation` varchar(255) NOT NULL,
  `expenses` varchar(255) NOT NULL,
  `expensePrefix` varchar(255) NOT NULL,
  `dc` varchar(255) NOT NULL,
  `voucherPrefix` varchar(255) NOT NULL,
  `voucher` varchar(255) NOT NULL,
  `debitPrefix` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `creditPrefix` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `purchasePrefix` varchar(255) NOT NULL,
  `purchase` varchar(255) NOT NULL,
  `invoicePrefix` varchar(255) NOT NULL,
  `invoice` varchar(255) NOT NULL,
  `salesdcPrefix` varchar(255) NOT NULL,
  `materialdcPrefix` varchar(255) NOT NULL,
  `jobdcPrefix` varchar(255) NOT NULL,
  `proforma_invoicePrefix` varchar(255) NOT NULL,
  `proforma_invoice` varchar(255) NOT NULL,
  `inwardPrefix` varchar(255) NOT NULL,
  `inward` varchar(255) NOT NULL,
  `cashbillPrefix` varchar(255) NOT NULL,
  `cashbill_invoice` varchar(255) NOT NULL,
  `mtcPrefix` varchar(100) NOT NULL,
  `tcno` varchar(100) NOT NULL,
  `insPrefix` varchar(100) NOT NULL,
  `insno` varchar(100) NOT NULL,
  `utPrefix` varchar(100) NOT NULL,
  `utno` varchar(100) NOT NULL,
  `mptPrefix` varchar(100) NOT NULL,
  `mptno` varchar(100) NOT NULL,
  `dptPrefix` varchar(100) NOT NULL,
  `dptno` varchar(100) NOT NULL,
  `creditnote` varchar(255) DEFAULT NULL,
  `po_prefix` varchar(50) NOT NULL,
  `purchaseorder` varchar(255) NOT NULL,
  `spo_prefix` varchar(50) NOT NULL,
  `supplierpurchaseorder` varchar(100) NOT NULL,
  `jobworkdc` varchar(255) DEFAULT NULL,
  `materialdc` varchar(255) DEFAULT NULL,
  `cmp_companyname` varchar(255) NOT NULL,
  `cmp_phoneno` varchar(255) NOT NULL,
  `cmp_mobileno` varchar(255) NOT NULL,
  `cmp_address1` varchar(255) NOT NULL,
  `cmp_address2` varchar(255) NOT NULL,
  `cmp_city` varchar(255) NOT NULL,
  `cmp_pincode` varchar(255) NOT NULL,
  `cmp_stateCode` varchar(255) NOT NULL,
  `cmp_website` varchar(255) NOT NULL,
  `cmp_emailid` varchar(255) NOT NULL,
  `cmp_logo` varchar(255) NOT NULL,
  `cont_companyname` varchar(255) NOT NULL,
  `cont_phoneno` varchar(255) NOT NULL,
  `cont_mobileno` varchar(255) NOT NULL,
  `cont_address1` varchar(255) NOT NULL,
  `cont_address2` varchar(255) NOT NULL,
  `cont_city` varchar(255) NOT NULL,
  `cont_pincode` varchar(255) NOT NULL,
  `cont_stateCode` varchar(255) NOT NULL,
  `cont_website` varchar(255) NOT NULL,
  `cont_emailid` varchar(255) NOT NULL,
  `cont_logo` varchar(255) NOT NULL,
  `discountBy` varchar(255) NOT NULL,
  `invoiceBy` varchar(255) NOT NULL,
  `itemType` varchar(255) NOT NULL,
  `bill_type` varchar(255) DEFAULT NULL,
  `quot_bill_type` varchar(255) DEFAULT NULL,
  `voucher_receivable` varchar(255) DEFAULT NULL,
  `voucher_payable` varchar(255) DEFAULT NULL,
  `last_backup` date NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `inward_add` varchar(255) NOT NULL,
  `cashbill_add` varchar(255) NOT NULL,
  `cashbill_tax_type` varchar(255) NOT NULL,
  `priceType` varchar(255) DEFAULT NULL,
  `priceType1` varchar(255) DEFAULT NULL,
  `sales_dc` int(11) NOT NULL,
  `material_dc` int(11) NOT NULL,
  `jobwork_dc` int(11) NOT NULL,
  `cpo_type` varchar(255) NOT NULL,
  `spo_type` varchar(255) NOT NULL,
  `proforma_type` varchar(255) NOT NULL,
  `attendance` int(11) NOT NULL,
  `status` int(10) NOT NULL,
  `einvoice` int(11) NOT NULL,
  `eway` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `preference_settings` (`id`, `quotationPrefix`, `quotation`, `expenses`, `expensePrefix`, `dc`, `voucherPrefix`, `voucher`, `debitPrefix`, `debit`, `creditPrefix`, `credit`, `purchasePrefix`, `purchase`, `invoicePrefix`, `invoice`, `salesdcPrefix`, `materialdcPrefix`, `jobdcPrefix`, `proforma_invoicePrefix`, `proforma_invoice`, `inwardPrefix`, `inward`, `cashbillPrefix`, `cashbill_invoice`, `mtcPrefix`, `tcno`, `insPrefix`, `insno`, `utPrefix`, `utno`, `mptPrefix`, `mptno`, `dptPrefix`, `dptno`, `creditnote`, `po_prefix`, `purchaseorder`, `spo_prefix`, `supplierpurchaseorder`, `jobworkdc`, `materialdc`, `cmp_companyname`, `cmp_phoneno`, `cmp_mobileno`, `cmp_address1`, `cmp_address2`, `cmp_city`, `cmp_pincode`, `cmp_stateCode`, `cmp_website`, `cmp_emailid`, `cmp_logo`, `cont_companyname`, `cont_phoneno`, `cont_mobileno`, `cont_address1`, `cont_address2`, `cont_city`, `cont_pincode`, `cont_stateCode`, `cont_website`, `cont_emailid`, `cont_logo`, `discountBy`, `invoiceBy`, `itemType`, `bill_type`, `quot_bill_type`, `voucher_receivable`, `voucher_payable`, `last_backup`, `itemcode`, `inward_add`, `cashbill_add`, `cashbill_tax_type`, `priceType`, `priceType1`, `sales_dc`, `material_dc`, `jobwork_dc`, `cpo_type`, `spo_type`, `proforma_type`, `attendance`, `status`, `einvoice`, `eway`) VALUES (1, 'Q', '', '', 'E', '', 'V/25-26/-', '', 'D', '001', 'C', '', 'P', '', 'INV/25-26/-', '', 'SDC/25-26/-', 'MDC/25-26/-', 'PDC/25-26/', 'PI/25-26/', '', 'I', '', 'CB', '001', 'MTC', '', 'INS', '', '', '', 'MPT', '', 'DPT', '', NULL, 'WO/25-26/-', '', 'SPO/25-26/-', '', '', '001', 'Myoffice Solutions', '7373333321', '8608701222', ' #91 Dr. Jaganathan Nagar', 'Civil Aerodrome Post, Coimbatore', 'Coimbatore', '641014', '33', 'www.idreamdevelopers.org', 'info@idreamdevelopers.com', '12832299_1579401915712151_5416626780361493206_n.png', 'IDREAMDEVELOPERS', '7373333321', '8608701333', ' #91 Dr. Jaganathan Nagar', 'Civil Aerodrome Post, Coimbatore', 'Coimbatore', '641014', '33', 'www.idreamdevelopers.com', 'info@idreamdevelopers.com', 'idream_logo.PNG', 'amount_wise', 'without_stock', 'with_item', 'Overall Tax', 'Overall Tax', 'Without Invoice', 'Without Purchase', '2025-03-01', '1', 'With Inward', 'Without Cashbill', 'Overall Tax', '1', '0', 1, 0, 3, 'Overall Tax', 'Overall Tax', 'Overall Tax', 0, 1, 0, 0);


#
# TABLE STRUCTURE FOR: profile
#

DROP TABLE IF EXISTS `profile`;

CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `companyname` varchar(255) DEFAULT NULL,
  `softwarename` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `stateCode` varchar(255) NOT NULL,
  `emailid` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `gstin` varchar(225) DEFAULT NULL,
  `aadharno` varchar(225) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `bankname` varchar(255) DEFAULT NULL,
  `accountno` varchar(255) DEFAULT NULL,
  `bankbranch` varchar(255) DEFAULT NULL,
  `ifsccode` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `profile` (`id`, `date`, `companyname`, `softwarename`, `mobileno`, `phoneno`, `address1`, `address2`, `city`, `pincode`, `stateCode`, `emailid`, `website`, `tinno`, `cstno`, `gstin`, `aadharno`, `status`, `username`, `password`, `bankname`, `accountno`, `bankbranch`, `ifsccode`, `state`) VALUES (1, NULL, 'CK PRIME ALLOYS', 'MYOFFICE ERP', '9790153461', '9159531600', 'SF.NO:845B, Door No:1J(4) Annur road, Rayarpalayam', ' Karumathampatti', 'Coimbatore', '641659', 'Karnataka', 'ckprimealloys@gmail.com', 'www.ckprimealloys.com', '12345', '54321', '33CGRPR4623R1ZI', '', '1', 'admin', 'admin001', '', '', '', '', NULL);


#
# TABLE STRUCTURE FOR: proforma_invoice_details
#

DROP TABLE IF EXISTS `proforma_invoice_details`;

CREATE TABLE `proforma_invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `dcnos` longtext DEFAULT NULL,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: proforma_invoice_details_backup
#

DROP TABLE IF EXISTS `proforma_invoice_details_backup`;

CREATE TABLE `proforma_invoice_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `dcnos` longtext DEFAULT NULL,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) NOT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: proforma_invoice_reports
#

DROP TABLE IF EXISTS `proforma_invoice_reports`;

CREATE TABLE `proforma_invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: proinvoice_party_statement
#

DROP TABLE IF EXISTS `proinvoice_party_statement`;

CREATE TABLE `proinvoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: purchase_collection
#

DROP TABLE IF EXISTS `purchase_collection`;

CREATE TABLE `purchase_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `date_po` date NOT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) NOT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `currentlypaid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `purchase_collection` (`id`, `date`, `date_po`, `purchasedate`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `suppliername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bamount`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `purchaseno`, `currentlypaid`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `payment`, `paid`, `invoiceamt`, `invoiceno`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (1, '2025-06-21', '0000-00-00', NULL, NULL, '2025-06-21', NULL, 'V/25-26/-003', 'CK PRIME ALLOYS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, '2400', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `purchase_collection` (`id`, `date`, `date_po`, `purchasedate`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `suppliername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bamount`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `purchaseno`, `currentlypaid`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `payment`, `paid`, `invoiceamt`, `invoiceno`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (2, '2025-06-24', '0000-00-00', NULL, NULL, '2025-06-24', NULL, 'V/25-26/-005', 'Gateway', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, '500', NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: purchase_details
#

DROP TABLE IF EXISTS `purchase_details`;

CREATE TABLE `purchase_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchasetype` varchar(100) NOT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `purchaseorderno` varchar(200) NOT NULL,
  `purchaseorder` varchar(200) NOT NULL,
  `poRecordId` varchar(100) NOT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `heatno` text DEFAULT NULL,
  `itemid` text DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `weight` varchar(20) NOT NULL,
  `grade` varchar(50) NOT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (1, '2025-11-24', '2025-10-06', '2025-10-06', 'purchase Order', 'P001', 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0121/25-26', 'SPO/25-26/-001||SPO/25-26/-001||SPO/25-26/-001||SPO/25-26/-001', 'PO-2526-0628||PO-2526-0628||PO-2526-0628||PO-2526-0628', '1||1||1||2', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '73259999||73259999||73259999||73259999', 'SBM05||SBM05||SBM05||SBM03', 'R1001||R1002||R1003||', '5||5||5||4', 'LH INNER BOX||LH INNER BOX||LH INNER BOX||LH OUTER BOX', 'KGS||KGS||KGS||KGS', '26.1||26.1||26.1||25', '', '155||155||155||155', '10||10||10||', '40455.00||40455.00||40455.00||', '0||0||0||0', 'amount_wise', '0.00||0.00||0.00||', '40455.00||40455.00||40455.00||', '9||9||9||9', '3640.95||3640.95||3640.95||', '9||9||9||9', '3640.95||3640.95||3640.95||', '18||18||18||18', '7281.90||7281.90||7281.90||', '47736.90||47736.90||47736.90||', '143210.70', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1', '143210.70', 'P001241125', 'P001-2025', 1, '143210.70', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (2, '2025-11-24', '2025-10-13', '2025-10-13', 'purchase Order', 'P002', 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0130/25-26', 'SPO/25-26/-001||SPO/25-26/-001||SPO/25-26/-001', 'PO-2526-0628||PO-2526-0628||PO-2526-0628', '2||2||2', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '73259999||73259999||73259999', 'SBM03||SBM03||SBM03', 'R1011||R1012||R1013', '4||4||4', 'LH OUTER BOX||LH OUTER BOX||LH OUTER BOX', 'KGS||KGS||KGS', '25.4||25.4||25.4', '', '155||155||155', '10||10||10', '39370.00||39370.00||39370.00', '0||0||0', 'amount_wise', '0.00||0.00||0.00', '39370.00||39370.00||39370.00', '9||9||9', '3543.30||3543.30||3543.30', '9||9||9', '3543.30||3543.30||3543.30', '18||18||18', '7086.60||7086.60||7086.60', '46456.60||46456.60||46456.60', '139369.80', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1', '139369.80', 'P0002241125', 'P0002-2025', 1, '139369.80', 1, 1);


#
# TABLE STRUCTURE FOR: purchase_details_backup
#

DROP TABLE IF EXISTS `purchase_details_backup`;

CREATE TABLE `purchase_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: purchase_reports
#

DROP TABLE IF EXISTS `purchase_reports`;

CREATE TABLE `purchase_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseorderno` varchar(100) NOT NULL,
  `purchaseorder` varchar(100) NOT NULL,
  `poRecordId` varchar(50) NOT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `heatno` varchar(255) DEFAULT NULL,
  `weight` varchar(20) NOT NULL,
  `grade` varchar(50) NOT NULL,
  `itemid` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `create_mtc_status` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (1, '1', '2025-11-24', 'P001', '2025-10-06', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0121/25-26', 'SPO/25-26/-001', 'PO-2526-0628', '1', '2025-10-06', NULL, 'SBM05', 'R1001', '26.1', '', '5', '73259999', 'LH INNER BOX', '1', '10', '4', '143210.70', NULL, NULL, NULL, NULL, NULL, '143210.70', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2025', 'P001241125', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (2, '1', '2025-11-24', 'P001', '2025-10-06', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0121/25-26', 'SPO/25-26/-001', 'PO-2526-0628', '1', '2025-10-06', NULL, 'SBM05', 'R1002', '26.1', '', '5', '73259999', 'LH INNER BOX', '5', '10', '7', '143210.70', NULL, NULL, NULL, NULL, NULL, '143210.70', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2025', 'P001241125', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (3, '1', '2025-11-24', 'P001', '2025-10-06', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0121/25-26', 'SPO/25-26/-001', 'PO-2526-0628', '1', '2025-10-06', NULL, 'SBM05', 'R1003', '26.1', '', '5', '73259999', 'LH INNER BOX', '5', '10', '7', '143210.70', NULL, NULL, NULL, NULL, NULL, '143210.70', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2025', 'P001241125', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (5, '2', '2025-11-24', 'P0002', '2025-10-13', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0130/25-26', 'SPO/25-26/-001', 'PO-2526-0628', '2', '2025-10-13', NULL, 'SBM03', 'R1011', '25.4', '', '4', '73259999', 'LH OUTER BOX', '1', '10', '4', '139369.80', NULL, NULL, NULL, NULL, NULL, '139369.80', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0002-2025', 'P0002241125', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (6, '2', '2025-11-24', 'P0002', '2025-10-13', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0130/25-26', 'SPO/25-26/-001', 'PO-2526-0628', '2', '2025-10-13', NULL, 'SBM03', 'R1012', '25.4', '', '4', '73259999', 'LH OUTER BOX', '5', '10', '6', '139369.80', NULL, NULL, NULL, NULL, NULL, '139369.80', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0002-2025', 'P0002241125', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (7, '2', '2025-11-24', 'P0002', '2025-10-13', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0130/25-26', 'SPO/25-26/-001', 'PO-2526-0628', '2', '2025-10-13', NULL, 'SBM03', 'R1013', '25.4', '', '4', '73259999', 'LH OUTER BOX', '5', '10', '4', '139369.80', NULL, NULL, NULL, NULL, NULL, '139369.80', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0002-2025', 'P0002241125', 1);


#
# TABLE STRUCTURE FOR: purchaseorder_details
#

DROP TABLE IF EXISTS `purchaseorder_details`;

CREATE TABLE `purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `deliverydate` varchar(100) NOT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` longtext DEFAULT NULL,
  `heatno` text DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `uom` longtext DEFAULT NULL,
  `weight` varchar(100) NOT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `balanceqty` longtext DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` longtext NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` longtext DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `oa_status` int(11) NOT NULL,
  `oa_deliverydate` varchar(255) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `invoice_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (1, '2025-11-24', '2025-08-05', '2025-08-05', '31-10-2025', 'Direct PO', 'WO/25-26/-001', 'PO-2526-0628', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '73259999||73259999', 'SBM03||SBM05', NULL, 'LH OUTER BOX||LH INNER BOX', '||', 'STMSC016||STMS014', '7||7', 'KGS||KGS', '25.4||26.1', '167||167', '30||30', '30||30', '', '127254.00||130761.00', '0||0', 'amount_wise', '0||', '127254.00||130761.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1', NULL, 'WO/25-26/-001241125', 'WO/25-26/-001-2025', 1, 2, '13-10-2025||07-10-2025', 1, 0);


#
# TABLE STRUCTURE FOR: purchaseorder_details_backup
#

DROP TABLE IF EXISTS `purchaseorder_details_backup`;

CREATE TABLE `purchaseorder_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: purchaseorder_reports
#

DROP TABLE IF EXISTS `purchaseorder_reports`;

CREATE TABLE `purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `heatno` text DEFAULT NULL,
  `itemid` text DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `weight` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `workorderbalance` varchar(100) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `oa_status` int(11) NOT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (4, '1', '2025-11-24', '', 'WO/25-26/-001', 'PO-2526-0628', NULL, '2025-08-05', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', NULL, '2025-08-05', NULL, 'SBM05', NULL, NULL, '73259999', 'LH INNER BOX', '', 'KGS', '26.1', '7', 'STMS014', '167', '30', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', 0, NULL, NULL, NULL, NULL, NULL, 'WO/25-26/-001-2025', 'WO/25-26/-001241125');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (3, '1', '2025-11-24', '', 'WO/25-26/-001', 'PO-2526-0628', NULL, '2025-08-05', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', NULL, '2025-08-05', NULL, 'SBM03', NULL, NULL, '73259999', 'LH OUTER BOX', '', 'KGS', '25.4', '7', 'STMSC016', '167', '30', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', 0, NULL, NULL, NULL, NULL, NULL, 'WO/25-26/-001-2025', 'WO/25-26/-001241125');


#
# TABLE STRUCTURE FOR: quotation_details
#

DROP TABLE IF EXISTS `quotation_details`;

CREATE TABLE `quotation_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `quotation_details` (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (1, '2025-06-23', '2025-06-23', NULL, NULL, 'Q001', 4, 'IT Solution', 'Hoysala nagar, Ramamurthy signal, Kasthuri nagar, Bangalore, Karnataka', NULL, NULL, 'intrastate', NULL, NULL, NULL, '00002', 'Stationary things', NULL, 'PACK', '170', '12', '2040.00', '0', '0', '2040.00', '7.5', '153.00', '7.5', '153.00', '15', '', '2040.00', '2040.00', NULL, NULL, NULL, NULL, '2346.00', NULL, NULL, 1, 1);


#
# TABLE STRUCTURE FOR: quotation_details_backup
#

DROP TABLE IF EXISTS `quotation_details_backup`;

CREATE TABLE `quotation_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: sales_return
#

DROP TABLE IF EXISTS `sales_return`;

CREATE TABLE `sales_return` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `discountamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `sales_return` (`id`, `date`, `returndate`, `types`, `time`, `dateofissue`, `customername`, `customerid`, `supplierid`, `gsttype`, `suppliername`, `openingbal`, `outstandingamount`, `returnno`, `description`, `invoiceno`, `purchaseno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `uom`, `amount`, `discount`, `taxableamount`, `discountamount`, `cgst`, `cgstamount`, `sgst`, `sgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `grandtotal`, `status`) VALUES (1, '2025-06-24', '2025-06-24', 'Credit', '11:14:26 PM', '2025-06-24', '-', '-', '5', 'intrastate', 'Gateway', '1864', NULL, 'C001', 'Package damage', '-', 'P003', NULL, '00002', 'Stationary things', '170', '5', 'PACK', '850.00', '0', '850.00', '0.00', '7.5', '63.75', '7.5', '63.75', '15', '', '977.50', '995.50', '6', '0', '0.00', '0', '0.00', '0', '0.00', '6.00', '12', '0', '0.00', '0', '0.00', '0', '0.00', '12.00', '0', '995.50', '1');


#
# TABLE STRUCTURE FOR: sales_return_backup
#

DROP TABLE IF EXISTS `sales_return_backup`;

CREATE TABLE `sales_return_backup` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `discountamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: statecode
#

DROP TABLE IF EXISTS `statecode`;

CREATE TABLE `statecode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) NOT NULL,
  `stateCode` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (1, 'Jammu & Kashmir', '01', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (2, 'Himachal Pradesh', '02', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (3, 'Punjab', '03', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (4, 'Chandigarh', '04', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (5, 'Uttarakhand', '05', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (6, 'Haryana', '06', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (7, 'Delhi', '07', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (8, 'Rajasthan', '08', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (9, 'Uttar Pradesh', '09', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (10, 'Bihar', '10', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (11, 'Sikkim', '11', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (12, 'Arunachal Pradesh', '12', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (13, 'Nagaland', '13', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (14, 'Manipur', '14', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (15, 'Mizoram', '15', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (16, 'Tripura', '16', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (17, 'Meghalaya', '17', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (18, 'Assam', '18', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (19, 'West Bengal', '19', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (20, 'Jharkhand', '20', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (21, 'odisha', '21', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (22, 'Chattisgarh', '22', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (23, 'Madhya Pradesh', '23', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (24, 'Daman & Diu', '25', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (25, 'Gujarat', '24', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (26, 'Dadra & Nagar Haveli', '26', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (27, 'Maharashtra', '27', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (28, 'Andhra Pradesh', '28', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (29, 'Karnataka', '29', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (30, 'Goa', '30', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (31, 'Lakshadweep', '31', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (32, 'Kerala', '32', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (33, 'Tamil Nadu', '33', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (34, 'Puducherry', '34', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (35, 'Andaman & Nicobar Islands', '35', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (36, 'Telengana', '36', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (37, 'Andrapradesh(New)', '37', 1);


#
# TABLE STRUCTURE FOR: stock
#

DROP TABLE IF EXISTS `stock`;

CREATE TABLE `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `heatno` varchar(255) DEFAULT NULL,
  `itemid` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `updatestock` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `balance` varchar(255) NOT NULL,
  `oldqty` varchar(255) DEFAULT NULL,
  `currentstock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (12, '2025-11-25', '73259999', '', '5', 'SBM03', '9', '9', '18', 'LH OUTER BOX', '', '', '', '', '', '-50', NULL, NULL, '', '2025-10-06', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (13, '2025-11-25', '73259999', 'R1000', '|', 'SBM05', '9', '9', '18', 'LH INNER BOX', '10', '155', '10', '', '', '-50', NULL, NULL, '', '2025-10-01', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (14, '2025-11-25', '73259999', 'R1001', '5', 'SBM05', '9', '9', '18', 'LH INNER BOX', '10', '155', '10', '', '', '-50', NULL, NULL, '', '2025-10-06', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (15, '2025-11-25', '73259999', 'R1002', '|', 'SBM05', '9', '9', '18', 'LH INNER BOX', '10', '155', '10', '', '', '-50', NULL, NULL, '', '2025-10-06', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (16, '2025-11-25', '73259999', 'R1005', '4', 'SBM03', '9', '9', '18', 'LH OUTER BOX', '10', '155', '10', '', '', '-50', NULL, NULL, '', '2025-10-13', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (17, '2025-11-25', '73259999', 'R1006', '|', 'SBM03', '9', '9', '18', 'LH OUTER BOX', '10', '155', '10', '', '', '-50', NULL, NULL, '', '2025-10-13', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (18, '2025-11-25', '73259999', 'R1007', '|', 'SBM03', '9', '9', '18', 'LH OUTER BOX', '10', '155', '10', '', '', '-50', NULL, NULL, '', '2025-10-13', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (19, '2025-11-25', '73259999', 'R1003', '|', 'SBM05', '9', '9', '18', 'LH INNER BOX', '10', '155', '10', '', '', '-50', NULL, NULL, '', '2025-10-06', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (20, '2025-11-25', '73259999', 'R1011', '4', 'SBM03', '9', '9', '18', 'LH OUTER BOX', '10', '155', '10', '', '', '-50', NULL, NULL, '', '2025-10-13', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (21, '2025-11-25', '73259999', 'R1012', '|', 'SBM03', '9', '9', '18', 'LH OUTER BOX', '10', '155', '10', '', '', '-50', NULL, NULL, '', '2025-10-13', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (22, '2025-11-25', '73259999', 'R1013', '|', 'SBM03', '9', '9', '18', 'LH OUTER BOX', '10', '155', '10', '', '', '-50', NULL, NULL, '', '2025-10-13', 'Exclusive');


#
# TABLE STRUCTURE FOR: stock_reports
#

DROP TABLE IF EXISTS `stock_reports`;

CREATE TABLE `stock_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `heatno` varchar(255) DEFAULT NULL,
  `itemid` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `updatestock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  `balance` varchar(225) DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (1, '2025-09-11', '123456', '001', '1', '002', 'Coal Nozzle', NULL, '5', '', '2025-09-11', '6', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (2, '2025-09-11', '123456', '002', '|', '002', 'Coal Nozzle', NULL, '5', '', '2025-09-11', '6', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (3, '2025-10-09', '73259930', 'POO3', '', 'SP03', 'Collector Casting', NULL, '4', '', '2025-07-30', '7', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (5, '2025-10-29', '73259930', 'P1007-4,R0005-5,R0023-6,R0024-5', '3', 'SP03', 'Collector Casting', NULL, '20', '', '2025-10-29', '8', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (18, '2025-11-19', '73259930', '003', '1', 'SP03', 'Collector Casting', NULL, '3', '', '2025-11-17', '9', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (17, '2025-11-19', '73259930', '003', '|', 'SP03', 'Collector Casting', NULL, '3', '', '2025-11-17', '9', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (16, '2025-11-19', '73259930', '002', '|', '002', 'Coal Nozzle', NULL, '2', '', '2025-11-17', '9', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (15, '2025-11-19', '73259930', '002', '1', '002', 'Coal Nozzle', NULL, '3', '', '2025-11-17', '9', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (10, '2025-11-18', '73259930', 'R1000', '3', 'SP03', 'Collector Casting', NULL, '10', '', '2025-10-03', '10', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (11, '2025-11-18', '73259930', 'R1001', '|', 'SP03', 'Collector Casting', NULL, '10', '', '2025-10-03', '10', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (12, '2025-11-18', '73259930', 'R1002', '|', 'SP03', 'Collector Casting', NULL, '10', '', '2025-10-03', '10', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (13, '2025-11-18', '73259930', 'R1003', '3', 'SP03', 'Collector Casting', NULL, '10', '', '2025-10-03', '10', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (14, '2025-11-18', '73259930', 'R1004', '|', 'SP03', 'Collector Casting', NULL, '10', '', '2025-10-03', '10', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (19, '2025-11-24', '73259999', '', '4', 'SBM03', 'LH OUTER BOX', NULL, '', '', '2025-10-01', '11', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (20, '2025-11-24', '73259999', 'R1000', '|', 'SBM05', 'LH INNER BOX', NULL, '10', '', '2025-10-01', '11', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (21, '2025-11-24', '73259999', 'R1001', '|', 'SBM05', 'LH INNER BOX', NULL, '10', '', '2025-10-01', '11', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (22, '2025-11-24', '73259999', 'R1002', '5', 'SBM05', 'LH INNER BOX', NULL, '10', '', '2025-10-01', '11', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (23, '2025-11-24', '73259999', 'R1005', '4', 'SBM03', 'LH OUTER BOX', NULL, '10', '', '2025-10-13', '12', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (24, '2025-11-24', '73259999', 'R1006', '|', 'SBM03', 'LH OUTER BOX', NULL, '10', '', '2025-10-13', '12', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (25, '2025-11-24', '73259999', 'R1007', '|', 'SBM03', 'LH OUTER BOX', NULL, '10', '', '2025-10-13', '12', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (26, '2025-11-24', '73259999', 'R1001', '5', 'SBM05', 'LH INNER BOX', NULL, '10', '', NULL, '1', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (27, '2025-11-24', '73259999', 'R1002', '|', 'SBM05', 'LH INNER BOX', NULL, '10', '', NULL, '1', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (28, '2025-11-24', '73259999', 'R1003', '|', 'SBM05', 'LH INNER BOX', NULL, '10', '', '2025-10-06', '1', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (29, '2025-11-24', '73259999', '', '5', 'SBM03', 'LH OUTER BOX', NULL, '', '', NULL, '1', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (30, '2025-11-24', '73259999', 'R1011', '4', 'SBM03', 'LH OUTER BOX', NULL, '10', '', '2025-10-13', '2', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (31, '2025-11-24', '73259999', 'R1012', '|', 'SBM03', 'LH OUTER BOX', NULL, '10', '', '2025-10-13', '2', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (32, '2025-11-24', '73259999', 'R1013', '|', 'SBM03', 'LH OUTER BOX', NULL, '10', '', '2025-10-13', '2', NULL, 'Exclusive');


#
# TABLE STRUCTURE FOR: sup_purchaseorder_details
#

DROP TABLE IF EXISTS `sup_purchaseorder_details`;

CREATE TABLE `sup_purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `deliverydate` varchar(100) NOT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `supplierid` varchar(100) NOT NULL,
  `suppliername` varchar(100) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToAddress` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(100) NOT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `grade` varchar(100) NOT NULL,
  `workorderno` varchar(100) NOT NULL,
  `workorderid` varchar(100) NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `uom` longtext DEFAULT NULL,
  `weight` varchar(100) DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (1, '2025-11-24', '2025-08-06', NULL, '24-11-2025', 'workorder', 'SPO/25-26/-001', 'PO-2526-0628', NULL, '8', 'PREMIER ALLOYS', 9, 'STAAN BIO MED PVT LTD', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '73259999||73259999', 'SBM05||SBM03', 'LH INNER BOX||LH OUTER BOX', '||', '7||7', 'WO/25-26/-001', '4||3', 'STMS014||STMSC016', 'KGS||KGS', '26.1||25.4', '155||155', '30||30', '30||30', '', '121365.00||118110.00', NULL, 'amount_wise', '||', '121365.00||118110.00', '', '0.00', '0', '0.00', '0||0', '0||0', NULL, '239475.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1||1', '239475.00', 'SPO/25-26/-001241125', 'SPO/25-26/-001-2025', 1, 1);


#
# TABLE STRUCTURE FOR: sup_purchaseorder_details_backup
#

DROP TABLE IF EXISTS `sup_purchaseorder_details_backup`;

CREATE TABLE `sup_purchaseorder_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: sup_purchaseorder_reports
#

DROP TABLE IF EXISTS `sup_purchaseorder_reports`;

CREATE TABLE `sup_purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `supplierid` varchar(100) NOT NULL,
  `suppliername` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `deliverydate` varchar(100) NOT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(100) NOT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `weight` varchar(100) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `workorderid` varchar(100) NOT NULL,
  `workorderno` varchar(100) NOT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (1, '1', '2025-11-24', 'workorder', 'SPO/25-26/-001', 'PO-2526-0628', NULL, '2025-08-06', NULL, 9, 'STAAN BIO MED PVT LTD', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0', NULL, '24-11-2025', NULL, NULL, '73259999', 'SBM05', 'LH INNER BOX', '', 'KGS', '26.1', '155', '30', '7', 'STMS014', '4', 'WO/25-26/-001', '0', '', NULL, '239475.00', NULL, NULL, NULL, NULL, NULL, '239475.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'SPO/25-26/-001-2025', 'SPO/25-26/-001241125');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (2, '1', '2025-11-24', 'workorder', 'SPO/25-26/-001', 'PO-2526-0628', NULL, '2025-08-06', NULL, 9, 'STAAN BIO MED PVT LTD', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0', NULL, '24-11-2025', NULL, NULL, '73259999', 'SBM03', 'LH OUTER BOX', '', 'KGS', '25.4', '155', '30', '7', 'STMSC016', '3', 'WO/25-26/-001', '0', '', NULL, '239475.00', NULL, NULL, NULL, NULL, NULL, '239475.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'SPO/25-26/-001-2025', 'SPO/25-26/-001241125');


#
# TABLE STRUCTURE FOR: tbl_person
#

DROP TABLE IF EXISTS `tbl_person`;

CREATE TABLE `tbl_person` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: uom
#

DROP TABLE IF EXISTS `uom`;

CREATE TABLE `uom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (1, '2025-06-20', 'KGS', 1);
INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (2, '2025-06-21', 'NOS', 1);
INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (3, '2025-06-23', 'PACK', 1);


#
# TABLE STRUCTURE FOR: user_menu
#

DROP TABLE IF EXISTS `user_menu`;

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) NOT NULL,
  `main_menu` varchar(255) NOT NULL,
  `sub_menu` varchar(255) NOT NULL,
  `sub_menu_link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: ut_report
#

DROP TABLE IF EXISTS `ut_report`;

CREATE TABLE `ut_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `ut_report_no` varchar(100) NOT NULL,
  `ut_date` varchar(100) NOT NULL,
  `customername` varchar(100) NOT NULL,
  `customerid` varchar(100) NOT NULL,
  `stage_of_test` varchar(100) NOT NULL,
  `test_date` varchar(100) NOT NULL,
  `surface_condition` varchar(100) NOT NULL,
  `calibration_block` varchar(100) NOT NULL,
  `equipment` varchar(100) NOT NULL,
  `couplant` varchar(100) NOT NULL,
  `probe` varchar(100) NOT NULL,
  `range_of_crt` varchar(100) NOT NULL,
  `frequency` varchar(100) NOT NULL,
  `gain` varchar(100) NOT NULL,
  `area_coverage` varchar(100) NOT NULL,
  `procedure_ref` varchar(100) NOT NULL,
  `acceptance_standard` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `drawing` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `heat_no` varchar(100) NOT NULL,
  `ut_no` varchar(100) NOT NULL,
  `result` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `ut_report` (`id`, `date`, `ut_report_no`, `ut_date`, `customername`, `customerid`, `stage_of_test`, `test_date`, `surface_condition`, `calibration_block`, `equipment`, `couplant`, `probe`, `range_of_crt`, `frequency`, `gain`, `area_coverage`, `procedure_ref`, `acceptance_standard`, `description`, `itemid`, `drawing`, `grade`, `heat_no`, `ut_no`, `result`, `status`, `created_at`) VALUES (1, '2025-10-21', 'UT001', '21-10-2025', 'jack', '1', 'FINA', '21-10-2025', 'MODSONIC EINSTEIN - II DFT COUPLANT', 'V1 BLOCK', 'ROUGH CASTING', 'OIL+GREASE', 'DUALCRYSTAL PROBE', '0 TO 600', 'DIA 24MM & 4 MHZ', '80 dB', '100%', 'ASME SEC V ART 5 & 23/ CP014', 'ASME B16.34 APP-4', 'Coal Nozzle', '1', '001', '3', 'D3693', 'UT24-73', 'OK FOUND ACCEPTABL', 1, '2025-10-21 12:53:29');
INSERT INTO `ut_report` (`id`, `date`, `ut_report_no`, `ut_date`, `customername`, `customerid`, `stage_of_test`, `test_date`, `surface_condition`, `calibration_block`, `equipment`, `couplant`, `probe`, `range_of_crt`, `frequency`, `gain`, `area_coverage`, `procedure_ref`, `acceptance_standard`, `description`, `itemid`, `drawing`, `grade`, `heat_no`, `ut_no`, `result`, `status`, `created_at`) VALUES (2, '2025-10-25', '00002', '16-10-2025', 'SIGMA POWER & ENERGY ENGINEERS', '2', 'Final', '16-10-2025', 'MODSONIC EINSTEIN - II DFT COUPLANT', 'V1 Block', 'Rough Casting', 'OIL + GREASE', 'DualCrystal Probe', '0 to 600', 'DIA 24MM & 4 MHZ', '80db', '100%', 'ASME SEC V ART 5 & 23/ CP014', 'ASME B16.34 APP-4', 'Collector Casting', '', '3-SPG-8557 REV0', '4', 'D3963', 'UT24-73', 'OK FOUND ACCEPTABLE', 1, '2025-10-25 12:49:12');
INSERT INTO `ut_report` (`id`, `date`, `ut_report_no`, `ut_date`, `customername`, `customerid`, `stage_of_test`, `test_date`, `surface_condition`, `calibration_block`, `equipment`, `couplant`, `probe`, `range_of_crt`, `frequency`, `gain`, `area_coverage`, `procedure_ref`, `acceptance_standard`, `description`, `itemid`, `drawing`, `grade`, `heat_no`, `ut_no`, `result`, `status`, `created_at`) VALUES (3, '2025-11-03', '00003', '12-09-2025', 'SIGMA POWER & ENERGY ENGINEERS', '2', 'Final', '10-09-2025', 'MODSONIC EINSTEIN - II DFT COUPLANT', 'V1 Block', 'Rough Casting', 'OIL + GREASE', 'DualCrystal Probe', '0 to 600', 'DIA 24MM & 4 MHZ', '80db', '100%', 'ASME SEC V ART 5 & 23/ CP014', 'ASME B16.34 APP-4', 'Collector Casting', '', '3-SPG-8557 REV0', '4', 'P0007', 'UT20-23', 'OK FOUND ACCEPTABLE', 1, '2025-11-03 13:15:43');


#
# TABLE STRUCTURE FOR: vat_details
#

DROP TABLE IF EXISTS `vat_details`;

CREATE TABLE `vat_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `sgst` varchar(225) DEFAULT NULL,
  `cgst` varchar(225) DEFAULT NULL,
  `igst` varchar(225) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `vat_details` (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (1, '2025-06-20', 'gst', '18', 'gst @ 18 %', '9', '9', '18', '1');
INSERT INTO `vat_details` (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (2, '2025-06-21', 'GSt', '12', 'GSt @ 12 %', '6', '6', '12', '1');
INSERT INTO `vat_details` (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (3, '2025-06-23', 'GST', '15', 'GST @ 15 %', '7.5', '7.5', '15', '1');


#
# TABLE STRUCTURE FOR: vendor_details
#

DROP TABLE IF EXISTS `vendor_details`;

CREATE TABLE `vendor_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `vendorname` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: voucher
#

DROP TABLE IF EXISTS `voucher`;

CREATE TABLE `voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `tdsamount` varchar(100) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `balance_amt` varchar(255) DEFAULT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `voucher` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `tdsamount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (1, '2025-06-20', 'V/25-26/-001', 1, 'jack', '2025-06-20', 'payment', '', 'Cash', '', '', '', '', '', '1100', 'Cash', NULL, NULL, '1100', '1100', '', '1', NULL, NULL, '', 0);
INSERT INTO `voucher` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `tdsamount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (3, '2025-06-21', 'V/25-26/-002', 2, 'SIGMA POWER', '2025-06-21', 'payment', '', 'Cash', '0', '', '', '0', '', '8800', 'Cash', NULL, NULL, '8800', '8800', '', '1', NULL, NULL, '', 0);
INSERT INTO `voucher` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `tdsamount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (4, '2025-06-21', 'V/25-26/-003', 3, 'CK PRIME ALLOYS', '2025-06-21', 'receipt', '', 'Cash', '0', '', '', '0', '', '2400', 'Cash', NULL, NULL, '2400', '2400', '', '1', NULL, NULL, '', 0);
INSERT INTO `voucher` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `tdsamount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (5, '2025-06-24', 'V/25-26/-004', 4, 'IT Solution', '2025-06-24', 'payment', 'Online Purchase', 'Cash', '0', '', '', '0', '', '500', 'Cash', NULL, NULL, '500', '500', '', '1', NULL, NULL, '', 0);
INSERT INTO `voucher` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `tdsamount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (6, '2025-06-24', 'V/25-26/-005', 5, 'Gateway', '2025-06-24', 'receipt', 'Online Purchase', 'Cash', '0', '', '', '0', '', '500', 'Cash', NULL, NULL, '500', '500', '', '1', NULL, NULL, '', 0);


#
# TABLE STRUCTURE FOR: voucher_backup
#

DROP TABLE IF EXISTS `voucher_backup`;

CREATE TABLE `voucher_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `purchaseno` varchar(255) NOT NULL,
  `balance_amt` varchar(255) NOT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

