#
# TABLE STRUCTURE FOR: additem
#

DROP TABLE IF EXISTS additem;

CREATE TABLE `additem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `taxtype` varchar(225) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `priceType` varchar(10) NOT NULL,
  `itemtype` varchar(255) NOT NULL,
  `purchaseNo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES ('1', '2022-01-11', '1', '123456789', '0', 'Aluminium c12A Y body', '35000', '1', '14', '14', '28', '1', 'Exclusive', '', NULL);
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES ('2', '2022-02-03', '2', '0', '0', 'GST FEES ', '1000', '2', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES ('3', '2022-03-12', '1', '0123456', '0', 'metal body', '1500', '2', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES ('4', '2022-06-22', '3', '0', '0', '168 dia gasket', '150', '2', '', '', '', '1', 'Exclusive', '', NULL);
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES ('5', '2022-06-22', '3', '0', '0', '168 dia gasket', '150', '2', '', '', '', '1', 'Exclusive', '', NULL);
INSERT INTO additem (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES ('6', '2022-06-24', '1', '123', '0', 'metal ', '150', '2', '9', '9', '18', '1', 'Exclusive', '', NULL);


#
# TABLE STRUCTURE FOR: backup_details
#

DROP TABLE IF EXISTS backup_details;

CREATE TABLE `backup_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` longtext,
  `date_created` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=latin1;

INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('1', 'backup-on-2022-01-01-13-26-17.zip', '2022-01-01');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('2', 'backup-on-2022-01-04-07-33-55.zip', '2022-01-04');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('3', 'backup-on-2022-01-06-12-20-25.zip', '2022-01-06');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('4', 'backup-on-2022-01-10-16-31-34.zip', '2022-01-10');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('5', 'backup-on-2022-01-11-10-47-57.zip', '2022-01-11');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('6', 'backup-on-2022-01-12-01-40-14.zip', '2022-01-12');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('7', 'backup-on-2022-01-13-20-37-27.zip', '2022-01-13');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('8', 'backup-on-2022-01-18-11-50-43.zip', '2022-01-18');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('9', 'backup-on-2022-01-19-15-31-26.zip', '2022-01-19');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('10', 'backup-on-2022-01-20-11-28-55.zip', '2022-01-20');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('11', 'backup-on-2022-01-25-17-35-39.zip', '2022-01-25');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('12', 'backup-on-2022-01-27-21-29-13.zip', '2022-01-27');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('13', 'backup-on-2022-01-31-11-41-51.zip', '2022-01-31');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('14', 'backup-on-2022-02-01-13-13-43.zip', '2022-02-01');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('15', 'backup-on-2022-02-03-16-18-50.zip', '2022-02-03');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('16', 'backup-on-2022-02-18-21-35-50.zip', '2022-02-18');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('17', 'backup-on-2022-02-24-16-44-36.zip', '2022-02-24');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('18', 'backup-on-2022-02-25-12-07-38.zip', '2022-02-25');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('19', 'backup-on-2022-02-26-11-09-26.zip', '2022-02-26');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('20', 'backup-on-2022-02-28-16-05-44.zip', '2022-02-28');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('21', 'backup-on-2022-03-01-10-59-52.zip', '2022-03-01');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('22', 'backup-on-2022-03-02-14-11-34.zip', '2022-03-02');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('23', 'backup-on-2022-03-07-11-58-13.zip', '2022-03-07');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('24', 'backup-on-2022-03-08-14-21-04.zip', '2022-03-08');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('25', 'backup-on-2022-03-10-10-09-28.zip', '2022-03-10');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('26', 'backup-on-2022-03-11-10-14-35.zip', '2022-03-11');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('27', 'backup-on-2022-03-12-10-05-21.zip', '2022-03-12');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('28', 'backup-on-2022-03-14-16-39-57.zip', '2022-03-14');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('29', 'backup-on-2022-03-15-14-51-46.zip', '2022-03-15');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('30', 'backup-on-2022-03-16-12-45-02.zip', '2022-03-16');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('31', 'backup-on-2022-03-17-11-48-43.zip', '2022-03-17');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('32', 'backup-on-2022-03-18-09-19-30.zip', '2022-03-18');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('33', 'backup-on-2022-03-21-10-43-23.zip', '2022-03-21');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('34', 'backup-on-2022-03-23-17-08-02.zip', '2022-03-23');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('35', 'backup-on-2022-03-24-12-47-41.zip', '2022-03-24');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('36', 'backup-on-2022-03-25-10-20-05.zip', '2022-03-25');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('37', 'backup-on-2022-03-30-11-18-24.zip', '2022-03-30');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('38', 'backup-on-2022-03-31-09-22-38.zip', '2022-03-31');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('39', 'backup-on-2022-04-01-10-42-01.zip', '2022-04-01');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('40', 'backup-on-2022-04-02-21-18-56.zip', '2022-04-02');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('41', 'backup-on-2022-04-04-14-55-41.zip', '2022-04-04');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('42', 'backup-on-2022-04-06-10-26-28.zip', '2022-04-06');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('43', 'backup-on-2022-04-12-16-20-38.zip', '2022-04-12');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('44', 'backup-on-2022-04-14-08-52-56.zip', '2022-04-14');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('45', 'backup-on-2022-04-17-11-13-30.zip', '2022-04-17');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('46', 'backup-on-2022-04-21-15-51-17.zip', '2022-04-21');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('47', 'backup-on-2022-04-28-10-09-14.zip', '2022-04-28');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('48', 'backup-on-2022-04-29-13-39-25.zip', '2022-04-29');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('49', 'backup-on-2022-04-30-10-08-43.zip', '2022-04-30');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('50', 'backup-on-2022-05-02-16-51-58.zip', '2022-05-02');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('51', 'backup-on-2022-05-04-12-45-23.zip', '2022-05-04');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('52', 'backup-on-2022-05-05-17-03-41.zip', '2022-05-05');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('53', 'backup-on-2022-05-14-10-43-33.zip', '2022-05-14');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('54', 'backup-on-2022-05-19-16-20-22.zip', '2022-05-19');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('55', 'backup-on-2022-05-22-14-52-56.zip', '2022-05-22');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('56', 'backup-on-2022-05-31-17-23-20.zip', '2022-05-31');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('57', 'backup-on-2022-06-01-18-50-49.zip', '2022-06-01');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('58', 'backup-on-2022-06-02-14-43-14.zip', '2022-06-02');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('59', 'backup-on-2022-06-03-10-56-36.zip', '2022-06-03');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('60', 'backup-on-2022-06-04-12-12-44.zip', '2022-06-04');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('61', 'backup-on-2022-06-07-11-45-26.zip', '2022-06-07');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('62', 'backup-on-2022-06-08-20-47-45.zip', '2022-06-08');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('63', 'backup-on-2022-06-10-16-05-27.zip', '2022-06-10');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('64', 'backup-on-2022-06-11-10-28-32.zip', '2022-06-11');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('65', 'backup-on-2022-06-12-12-58-45.zip', '2022-06-12');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('66', 'backup-on-2022-06-14-15-58-06.zip', '2022-06-14');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('67', 'backup-on-2022-06-15-13-35-56.zip', '2022-06-15');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('68', 'backup-on-2022-06-20-14-37-10.zip', '2022-06-20');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('69', 'backup-on-2022-06-21-10-37-34.zip', '2022-06-21');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('70', 'backup-on-2022-06-22-12-43-19.zip', '2022-06-22');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('71', 'backup-on-2022-06-23-10-20-55.zip', '2022-06-23');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('72', 'backup-on-2022-06-23-10-20-55.zip', '2022-06-23');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('73', 'backup-on-2022-06-24-10-28-12.zip', '2022-06-24');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('74', 'backup-on-2022-06-25-10-06-09.zip', '2022-06-25');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('75', 'backup-on-2022-06-29-11-22-40.zip', '2022-06-29');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('76', 'backup-on-2022-07-01-17-03-55.zip', '2022-07-01');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('77', 'backup-on-2022-07-02-12-35-02.zip', '2022-07-02');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('78', 'backup-on-2022-07-04-16-42-43.zip', '2022-07-04');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('79', 'backup-on-2022-07-07-19-08-26.zip', '2022-07-07');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('80', 'backup-on-2022-07-08-21-31-59.zip', '2022-07-08');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('81', 'backup-on-2022-07-09-11-52-08.zip', '2022-07-09');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('82', 'backup-on-2022-07-11-10-31-26.zip', '2022-07-11');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('83', 'backup-on-2022-07-12-22-15-51.zip', '2022-07-12');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('84', 'backup-on-2022-07-13-07-35-40.zip', '2022-07-13');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('85', 'backup-on-2022-07-15-16-13-55.zip', '2022-07-15');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('86', 'backup-on-2022-07-16-18-22-28.zip', '2022-07-16');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('87', 'backup-on-2022-07-18-17-59-34.zip', '2022-07-18');
INSERT INTO backup_details (`id`, `file_name`, `date_created`) VALUES ('88', 'backup-on-2022-07-20-16-19-48.zip', '2022-07-20');


#
# TABLE STRUCTURE FOR: bed_details
#

DROP TABLE IF EXISTS bed_details;

CREATE TABLE `bed_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `bed` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: card
#

DROP TABLE IF EXISTS card;

CREATE TABLE `card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO card (`id`, `name`, `date`, `status`) VALUES ('1', 'Credit Card', '0000-00-00', '1');
INSERT INTO card (`id`, `name`, `date`, `status`) VALUES ('2', 'Debit Card', '0000-00-00', '1');


#
# TABLE STRUCTURE FOR: cash_bill
#

DROP TABLE IF EXISTS cash_bill;

CREATE TABLE `cash_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cashbill_details
#

DROP TABLE IF EXISTS cashbill_details;

CREATE TABLE `cashbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `cust_mobno` varchar(255) NOT NULL,
  `address` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `systemDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cashbill_reports
#

DROP TABLE IF EXISTS cashbill_reports;

CREATE TABLE `cashbill_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `systemDate` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS category;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `category` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: collection_details
#

DROP TABLE IF EXISTS collection_details;

CREATE TABLE `collection_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('1', '2022-02-03', NULL, '2022-02-03', NULL, 'R1', 'SRI VINAYAKA TRADERS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '1000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('2', '2022-03-24', NULL, '2022-03-24', NULL, 'R2', 'Paramesh Steels and Alloys', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '50000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('3', '2022-03-24', NULL, '2022-03-24', NULL, 'R3', 'Paramesh Steels and Alloys', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '80000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('4', '2022-03-24', NULL, '2022-03-24', NULL, 'R4', 'Paramesh Steels and Alloys', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '50000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('5', '2022-03-24', NULL, '2022-03-24', NULL, 'R5', 'Paramesh Steels and Alloys', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '6170', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('6', '2022-03-24', NULL, '2022-03-24', NULL, 'R6', 'Paramesh Steels and Alloys', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '60000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('7', '2022-03-25', NULL, '2022-03-25', NULL, 'R7', 'Prakash Castings', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '144800', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('8', '2022-03-25', NULL, '2022-03-25', NULL, 'R7', 'Prakash Castings', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '1770', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('9', '2022-03-25', NULL, '2022-03-25', NULL, 'R8', 'Prakash Castings', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '89600', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('10', '2022-03-25', NULL, '2022-03-25', NULL, 'R9', 'Prakash Castings', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '44800', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('11', '2022-03-25', NULL, '2022-03-25', NULL, 'R10', 'Prakash Castings', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '100000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('12', '2022-03-30', NULL, '2022-03-30', NULL, 'R11', 'SMk', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '1000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('13', '2022-03-30', NULL, '2022-03-30', NULL, 'R12', 'Prakash Castings', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '2000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('14', '2022-03-30', NULL, '2022-03-30', NULL, 'R13', 'SMk', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '5000', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('15', '2022-06-15', NULL, '2022-06-15', NULL, 'R14', 'SMk', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cheque KOTAK MAHINDRA 1222', NULL, NULL, NULL, NULL, '92877', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('16', '2022-06-21', NULL, '2022-06-21', NULL, 'R15', 'SMk', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '268800', NULL, NULL, NULL);
INSERT INTO collection_details (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('17', '2022-06-21', NULL, '2022-06-21', NULL, 'R16', 'SMk', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '89600', NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: company_logo
#

DROP TABLE IF EXISTS company_logo;

CREATE TABLE `company_logo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO company_logo (`id`, `date`, `image`, `status`) VALUES ('1', '2022-02-28', 'myoffice_1.png', '1');


#
# TABLE STRUCTURE FOR: customer_details
#

DROP TABLE IF EXISTS customer_details;

CREATE TABLE `customer_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `contactperson` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `old_openingBal` varchar(255) DEFAULT NULL,
  `salesamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  `chequeno` varchar(100) NOT NULL,
  `last_modified` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`, `last_modified`) VALUES ('1', '2022-01-11', 'Intra customer', 'SMk', '9902525007', 'idream@gmail.com', '442/ CH-20/A1 Ramaswamy circle', 'CMC SIGNAL', 'vincent', 'Tamil Nadu', 'coimbatore', '', '', NULL, '0.00', NULL, '-3894053', '89600', '5148360', '89600', '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33GFHTFD56G', '', '', '', '', '2022-01-11');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`, `last_modified`) VALUES ('2', '2022-02-01', 'Intra customer', 'SRI VINAYAKA TRADERS', '', '', 'ARASUR', 'COIMBATORE', '', 'Tamil Nadu', 'COIMBATORE', '', '', NULL, '0.00', NULL, '9900', '1000', '8900', NULL, '', NULL, '641062', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '2022-02-01');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`, `last_modified`) VALUES ('3', '2022-03-24', 'Intra customer', 'Paramesh Steels and Alloys', '0123456789', 'paramesh@hotmail.com', '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp', 'Avinashi Road, Hopes College', 'Paramesh', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '100000', NULL, '136170', '50000', '0', NULL, '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33ABCHT325P1Z1', '', '', '', '', '2022-03-24');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`, `last_modified`) VALUES ('4', '2022-03-25', 'Intra customer', 'Prakash Castings', '9876543210', 'Prakash@zohomail.com', '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp', 'Avinashi Road, Hopes College', 'Prakash', 'Tamil Nadu', 'COIMBATORE', '', '', NULL, '100000', NULL, '136170', '2000', '-2000', NULL, '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33prakash3152', '', '', '', '', '2022-03-25');
INSERT INTO customer_details (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `chequeno`, `last_modified`) VALUES ('5', '2022-06-21', 'Intra supplier', 'smk', '', '', 'Jaganathan Street', 'Hopes', '', 'Tamil Nadu', 'Punjai Puliampatti', '', '', NULL, '0.00', NULL, '441280', NULL, '127680', NULL, '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '2022-06-21');


#
# TABLE STRUCTURE FOR: customerpo_details
#

DROP TABLE IF EXISTS customerpo_details;

CREATE TABLE `customerpo_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `cuspodate` date DEFAULT NULL,
  `invoicetype` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `cuspono` varchar(255) DEFAULT NULL,
  `transport` varchar(255) DEFAULT NULL,
  `customerpodate` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `cstname` varchar(255) DEFAULT NULL,
  `cstamount` varchar(255) DEFAULT NULL,
  `pf` varchar(255) DEFAULT NULL,
  `freight` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `pfadjus` varchar(255) DEFAULT NULL,
  `freightadjus` varchar(255) DEFAULT NULL,
  `roundoff` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: dc_delivery
#

DROP TABLE IF EXISTS dc_delivery;

CREATE TABLE `dc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES ('1', '2022-03-02', '1', '1', 'Against Inward', 'SDC', '2022-03-02', '2', 'SRI VINAYAKA TRADERS', '', 'ARASUR, COIMBATORE', 'I', '123', '2022-03-02', 'Aluminium c12A Y body', '', '5', '5', 'milling', '123456789', NULL, 'KGS', 'SDC-22', 'SDC020322', '1', '1');
INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES ('2', '2022-03-02', '3', '1', 'Against Inward', 'SDC', '2022-03-02', '2', 'SRI VINAYAKA TRADERS', '', 'ARASUR, COIMBATORE', 'I', '123', '2022-03-02', 'Aluminium c12A Y body', '', '5', '5', 'milling', '123456789', NULL, 'KGS', 'SDC-22', 'SDC020322', '1', '1');
INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES ('3', '2022-03-02', '2', '1', 'Against Inward', 'SDC', '2022-03-02', '2', 'SRI VINAYAKA TRADERS', '', 'ARASUR, COIMBATORE', 'I', '123', '2022-03-02', 'Aluminium c12A Y body', '', '5', '5', 'milling', '123456789', NULL, 'KGS', 'SDC-22', 'SDC020322', '1', '1');
INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES ('4', '2022-03-02', '4', '1', 'Against Inward', 'SDC', '2022-03-02', '2', 'SRI VINAYAKA TRADERS', '', 'ARASUR, COIMBATORE', 'I', '123', '2022-03-02', 'Aluminium c12A Y body', '', '5', '5', 'milling', '123456789', NULL, 'KGS', 'SDC-22', 'SDC020322', '1', '1');
INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES ('15', '2022-03-11', '15', '2', 'Against Inward', 'SDC1', '2022-03-11', '1', 'SMk', '', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL', 'I1', '001', '2022-03-08', 'GST FEES ', '', '1', '1', '', '0', NULL, 'NOS', 'SDC1-22', 'SDC1110322', '1', '1');
INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES ('16', '2022-04-02', '16', NULL, 'Direct DC', 'SDC', '2022-04-02', '4', 'Prakash Castings', '', '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp, Avinashi Road, Hopes College', NULL, NULL, NULL, 'Aluminium c12A Y body', '', '10', '10', 'df', '123456789', NULL, 'KGS', 'SDC-22', 'SDC020422', '1', '1');
INSERT INTO dc_delivery (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES ('18', '2022-06-21', '17', '8', 'Against Inward', 'SDC1', '2022-06-21', '1', 'SMk', '', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL', NULL, 'dc0021', '2022-06-21', 'Aluminium c12A Y body', '', '11', '6', 'finish', '123456789', NULL, 'KGS', 'SDC1-22', 'SDC1210622', '1', '1');


#
# TABLE STRUCTURE FOR: dcbill_details
#

DROP TABLE IF EXISTS dcbill_details;

CREATE TABLE `dcbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES ('1', '2022-03-02', 'Against Inward', 'SDC', '2022-03-02', '2', 'SRI VINAYAKA TRADERS', '', '02:29:PM', '', '', '', NULL, 'ARASUR, COIMBATORE', 'I', '123', '2022-03-02', 'Aluminium c12A Y body', '', '5', 'milling', '123456789', NULL, 'KGS', 'SDC-22', 'SDC020322', '1', '1', '');
INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES ('2', '2022-03-02', 'Against Inward', 'SDC', '2022-03-02', '2', 'SRI VINAYAKA TRADERS', '', '02:29:PM', '', '', '', NULL, 'ARASUR, COIMBATORE', 'I', '123', '2022-03-02', 'Aluminium c12A Y body', '', '5', 'milling', '123456789', NULL, 'KGS', 'SDC-22', 'SDC020322', '1', '1', '');
INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES ('3', '2022-03-02', 'Against Inward', 'SDC', '2022-03-02', '2', 'SRI VINAYAKA TRADERS', '', '02:29:PM', '', '', '', NULL, 'ARASUR, COIMBATORE', 'I', '123', '2022-03-02', 'Aluminium c12A Y body', '', '5', 'milling', '123456789', NULL, 'KGS', 'SDC-22', 'SDC020322', '1', '1', '');
INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES ('4', '2022-03-02', 'Against Inward', 'SDC', '2022-03-02', '2', 'SRI VINAYAKA TRADERS', '', '02:29:PM', '', '', '', NULL, 'ARASUR, COIMBATORE', 'I', '123', '2022-03-02', 'Aluminium c12A Y body', '', '5', 'milling', '123456789', NULL, 'KGS', 'SDC-22', 'SDC020322', '1', '1', '');
INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES ('15', '2022-03-11', 'Against Inward', 'SDC1', '2022-03-11', '1', 'SMk', '', '06:20:PM', '', '', '', NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL', 'I1', '001', '2022-03-08', 'GST FEES ', '', '1', '', '0', NULL, 'NOS', 'SDC1-22', 'SDC1110322', '1', '1', '');
INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES ('16', '2022-04-02', 'Direct DC', 'SDC', '2022-04-02', '4', 'Prakash Castings', '', '09:19:PM', '', '', '', '10', '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp, Avinashi Road, Hopes College', NULL, NULL, NULL, 'Aluminium c12A Y body', '', '10', 'df', '123456789', NULL, 'KGS', 'SDC-22', 'SDC020422', '1', '1', '');
INSERT INTO dcbill_details (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES ('17', '2022-06-21', 'Against Inward', 'SDC1', '2022-06-21', '1', 'SMk', '', '10:40:AM', '', '', '', NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL', 'I7', 'dc0021', '2022-06-21', 'Aluminium c12A Y body', '', '11', 'finish', '123456789', NULL, 'KGS', 'SDC1-22', 'SDC1210622', '1', '1', '');


#
# TABLE STRUCTURE FOR: dcbill_details_backup
#

DROP TABLE IF EXISTS dcbill_details_backup;

CREATE TABLE `dcbill_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS expenses;

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO expenses (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES ('1', '2022-06-22', '', 'KUMAR', '2022-06-22', 'SALARY ADV', 'Cash', '0', '', '', '0', '', '1000', 'Credit Card', 'Cash', '1000', '1', 'SALLARY ', '');


#
# TABLE STRUCTURE FOR: expenses_backup
#

DROP TABLE IF EXISTS expenses_backup;

CREATE TABLE `expenses_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: headers
#

DROP TABLE IF EXISTS headers;

CREATE TABLE `headers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES ('2', '2022-06-22', '1', 'SALLARY ');
INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES ('3', '2022-06-22', '1', 'OFFICE EXP');
INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES ('4', '2022-06-22', '1', 'TEA EXP');
INSERT INTO headers (`id`, `date`, `status`, `name`) VALUES ('5', '2022-06-22', '1', 'PETROL EXP');


#
# TABLE STRUCTURE FOR: hsnmaster
#

DROP TABLE IF EXISTS hsnmaster;

CREATE TABLE `hsnmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `party` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: invoice_details
#

DROP TABLE IF EXISTS invoice_details;

CREATE TABLE `invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `pono` varchar(255) DEFAULT NULL,
  `pino` varchar(255) DEFAULT NULL,
  `purchaseordernos` varchar(255) DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `removalDate` date NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToId` varchar(255) DEFAULT NULL,
  `shipToAddress` longtext,
  `deliveryAddress1` longtext,
  `deliveryAddress2` longtext,
  `mobileNo` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemcode` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `totalqty` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('1', '2022-01-10', '2022-01-10', '001', '2022-01-11', 'INV', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, 'TN66A0001', '2022-01-10', '11:00 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '2', '70000.00', '0', 'percent_wise', '0.00', '70000.00', '14', '9800.00', '14', '9800.00', '28', '', NULL, '70000.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '0', '89600.00', '89600.00', '1', 'INV100122', 'INV-2022', '1', '0', '2.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('3', '2022-03-18', '2022-03-18', '22', '1969-12-31', 'INV1', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-03-18', '10:41 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '', NULL, NULL, '0', '', '100', '1', '100.00', '0', 'percent_wise', '0.00', '100.00', '', '', '', '', '', '', NULL, '100.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '100.00', '0', '0', 'INV1180322', 'INV1-2022', '1', '1', '1.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('4', '2022-03-18', '2022-03-18', '22', '1969-12-31', 'INV2', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-03-18', '10:41 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '', NULL, '', '0', '', '100', '1', '100.00', '0', 'percent_wise', '0.00', '100.00', '', '', '', '', '', '', NULL, '100.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '100.00', '0', '0', 'INV1180322', 'INV1-2022', '1', '1', '1.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('5', '2022-03-18', '2022-03-18', '', '1969-12-31', 'INV3', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-03-18', '10:59 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '', NULL, 'casing', '', '', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '135.00', '9', '135.00', '', '', NULL, '1500.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '1770.00', '0', '0', 'INV3180322', 'INV3-2022', '1', '1', '1.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('6', '2022-03-18', '2022-03-18', '', '1969-12-31', 'INV4', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-03-18', '11:06 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '', NULL, 'casing', '', '', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '', '', '', '', '', '', '1500.00', '1500.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', NULL, '1', '1500.00', '0', '0', 'INV4180322', 'INV4-2022', '1', '1', '0');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('7', '2022-03-18', '2022-03-18', '', '1969-12-31', 'INV5', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-03-18', '11:06 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '1', '35000.00', '0', 'percent_wise', '0.00', '35000.00', '14', '4900.00', '14', '4900.00', '28', '9800.00', '44800.00', '44800.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', NULL, '1', '44800.00', '0', '0', 'INV4180322', 'INV4-2022', '1', '1', '0');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('8', '2022-03-18', '2022-03-18', '', '1969-12-31', 'INV6', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-03-18', '11:08 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '1', '35000.00', '0', 'percent_wise', '0.00', '35000.00', '14', '4900.00', '14', '4900.00', '28', '', NULL, '35000.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '44800.00', '0', '0', 'INV6180322', 'INV6-2022', '1', '1', '1.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('9', '2022-03-18', '2022-03-18', '', '1969-12-31', 'INV7', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-03-18', '11:18 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '1', '35000.00', '0', 'percent_wise', '0.00', '35000.00', '14', '4900.00', '14', '4900.00', '28', '9800.00', '44800.00', '44800.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', NULL, '1', '44800.00', '44800.00', '1', 'INV7180322', 'INV7-2022', '1', '1', '0');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('10', '2022-03-18', '2022-03-18', '', '1969-12-31', 'INV8', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-03-18', '11:34 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '1', '35000.00', '0', 'percent_wise', '0.00', '35000.00', '14', '4900.00', '14', '4900.00', '28', '9800.00', '44800.00', '44800.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', NULL, '1', '44800.00', '0', '0', 'INV8180322', 'INV8-2022', '1', '1', '0');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('11', '2022-03-18', '2022-03-18', '', '1969-12-31', 'INV9', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-03-18', '11:42 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '1', '35000.00', '0', 'percent_wise', '0.00', '35000.00', '14', '4900.00', '14', '4900.00', '28', '9800.00', '44800.00', '44800.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', NULL, '1', '44800.00', '44800.00', '1', 'INV9180322', 'INV9-2022', '1', '1', '0');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('12', '2022-03-18', '2022-03-18', '', '1969-12-31', 'INV10', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-03-18', '11:51 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '1', '35000.00', '0', 'percent_wise', '0.00', '35000.00', '14', '4900.00', '14', '4900.00', '28', '9800.00', '44800.00', '44800.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', NULL, '1', '44800.00', '44800.00', '1', 'INV10180322', 'INV10-2022', '1', '1', '0');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('13', '2022-03-18', '2022-03-18', '', '1969-12-31', 'INV11', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-03-18', '11:53 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '1', '35000.00', '0', 'percent_wise', '0.00', '35000.00', '14', '4900.00', '14', '4900.00', '28', '9800.00', '44800.00', '44800.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', NULL, '1', '44800.00', '44800.00', '1', 'INV11180322', 'INV11-2022', '1', '1', '0');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('14', '2022-03-18', '2022-03-18', '', '1969-12-31', 'INV12', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-03-18', '01:11 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '', NULL, 'casing', '', '', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '', '', '', '', '', '', NULL, '1500.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '1500.00', '1500.00', '1', 'INV12180322', 'INV12-2022', '1', '1', '1.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('15', '2022-03-18', '2022-03-18', '', '1969-12-31', 'INV13', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-03-18', '01:16 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456', NULL, 'casing', '', 'kgs', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '135.00', '9', '135.00', '', '', NULL, '1500.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '1770.00', '1770.00', '1', 'INV13180322', 'INV13-2022', '1', '1', '1.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('16', '2022-03-18', '2022-03-18', '', '1969-12-31', 'INV14', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-03-18', '01:17 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '012389||0126514||012345', NULL, 'aluminium||casing||aluminium', '||||', 'kgs||kgs||kgs', '1500||2000||2000', '1||1||1', '1500.00||2000.00||2000.00', '0||0||0', 'percent_wise', '0.00||0.00||0.00', '1500.00||2000.00||2000.00', '14', '770.00', '14', '770.00', '28', '', '0', '5500.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1||1||1', '7040.00', '1770.00', '1', NULL, NULL, '1', '1', '1.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('17', '2022-03-23', '2022-03-23', '', '1969-12-31', 'INV15', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '2', 'SRI VINAYAKA TRADERS', 'ARASUR, COIMBATORE, COIMBATORE, Tamil Nadu', NULL, NULL, '', '2022-03-23', '05:10 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '0123456', NULL, 'metal body', '', 'KGS', '1500', '15', '22500.00', '0', 'percent_wise', '0.00', '22500.00', '9', '2070.00', '9', '2070.00', '18', '', NULL, '22500.00', '500', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', 'NaN', 'NaN', '1', 'INV15230322', 'INV15-2022', '1', '1', '15.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('18', '2022-03-24', '2022-03-24', '', '1969-12-31', 'INV16', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '3', 'Paramesh Steels and Alloys', '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp, Avinashi Road, Hopes College, Coimbatore, Tamil Nadu', NULL, NULL, '', '2022-03-24', '06:33 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '1', '35000.00', '0', 'percent_wise', '0.00', '35000.00', '14', '4900.00', '14', '4900.00', '28', '', NULL, '35000.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '44800.00', '44800.00', '1', 'INV16240322', 'INV16-2022', '1', '1', '1.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('19', '2022-03-24', '2022-03-24', '', '1969-12-31', 'INV17', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '3', 'Paramesh Steels and Alloys', '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp, Avinashi Road, Hopes College, Coimbatore, Tamil Nadu', NULL, NULL, '', '2022-03-24', '06:34 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '0123456', NULL, 'metal body', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '135.00', '9', '135.00', '18', '', NULL, '1500.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '1770.00', '1770.00', '1', 'INV17240322', 'INV17-2022', '1', '1', '1.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('20', '2022-03-24', '2022-03-24', '', '1969-12-31', 'INV18', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '3', 'Paramesh Steels and Alloys', '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp, Avinashi Road, Hopes College, Coimbatore, Tamil Nadu', NULL, NULL, '', '2022-03-24', '06:34 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '2', '70000.00', '0', 'percent_wise', '0.00', '70000.00', '14', '9800.00', '14', '9800.00', '28', '', NULL, '70000.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '89600.00', '89600.00', '1', 'INV18240322', 'INV18-2022', '1', '1', '2.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('22', '2022-03-24', '2022-03-24', '', '1969-12-31', 'INV20', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '4', 'Prakash Castings', '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp, Avinashi Road, Hopes College, COIMBATORE, Tamil Nadu', NULL, NULL, '', '2022-03-24', '10:24 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '0123456', NULL, 'metal body', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '135.00', '9', '135.00', '18', '', NULL, '1500.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '1770.00', '0', '0', 'INV20240322', 'INV20-2022', '1', '1', '1.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('23', '2022-03-24', '2022-03-24', '', '1969-12-31', 'INV21', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '4', 'Prakash Castings', '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp, Avinashi Road, Hopes College, COIMBATORE, Tamil Nadu', NULL, NULL, '', '2022-03-24', '10:25 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '2', '70000.00', '0', 'percent_wise', '0.00', '70000.00', '14', '9800.00', '14', '9800.00', '28', '', NULL, '70000.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '89600.00', '0', '0', 'INV21240322', 'INV21-2022', '1', '1', '2.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('24', '2022-03-24', '2022-03-24', '', '1969-12-31', 'INV22', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '4', 'Prakash Castings', '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp, Avinashi Road, Hopes College, COIMBATORE, Tamil Nadu', NULL, NULL, '', '2022-03-24', '10:28 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '1', '35000.00', '0', 'percent_wise', '0.00', '35000.00', '14', '4900.00', '14', '4900.00', '28', '', NULL, '35000.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '44800.00', '0', '0', 'INV22240322', 'INV22-2022', '1', '1', '1.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('25', '2022-03-30', '2022-03-30', '', '1969-12-31', 'INV23', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '2', 'SRI VINAYAKA TRADERS', 'ARASUR, COIMBATORE, COIMBATORE, Tamil Nadu', NULL, NULL, '', '2022-03-30', '09:26 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '', NULL, 'motor', '', 'nos', '5000', '2', '10000.00', '01', 'percent_wise', '100.00', '9900.00', '', '', '', '', '', '', NULL, '9900.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '9900.00', '9900.00', '1', 'INV23300322', 'INV23-2022', '1', '1', '2.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('26', '2022-03-31', '2022-03-31', '', '1969-12-31', 'INV24', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-03-31', '11:55 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '1', '35000.00', '0', 'percent_wise', '0.00', '35000.00', '14', '4900.00', '14', '4900.00', '28', '9800.00', '44800.00', '44800.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', NULL, '1', '44800.00', '44800.00', '1', 'INV24310322', 'INV24-2022', '1', '1', '0');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('29', '2022-06-07', '2022-06-04', '', '1969-12-31', 'INV2', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '', NULL, NULL, '', '2022-06-04', '12:14 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789||123456789||123456789||123456789||123456789||123456789||123456789||123456789||123456789||123456789||123456789', NULL, 'Aluminium c12A Y body||Aluminium c12A Y body||Aluminium c12A Y body||Aluminium c12A Y body||Aluminium c12A Y body||Aluminium c12A Y body||Aluminium c12A Y body||Aluminium c12A Y body||Aluminium c12A Y body||Aluminium c12A Y body||Aluminium c12A Y body', '||||||||||||||||||||', 'KGS||KGS||KGS||KGS||KGS||KGS||KGS||KGS||KGS||KGS||KGS', '35000||35000||35000||35000||35000||35000||35000||35000||35000||35000||35000', '1||2||3||4||5||6||7||8||9||10||11', '35000.00||70000.00||105000.00||140000.00||175000.00||210000.00||245000.00||280000.00||315000.00||350000.00||385000.00', '0||0||0||0||0||0||0||0||0||0||0', 'percent_wise', '0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00', '35000.00||70000.00||105000.00||140000.00||175000.00||210000.00||245000.00||280000.00||315000.00||350000.00||385000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2956800.00', '', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1||1||1||1||1||1||1||1||1||1||1', '2956800.00', '2956800.00', '1', NULL, NULL, '1', '1', '0');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('30', '2022-06-21', '2022-06-10', '', '1969-12-31', 'INV3', NULL, NULL, NULL, NULL, 'Labour Bill', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-06-10', '04:06 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '1', '35000.00', '0', 'percent_wise', '0.00', '35000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '44800.00', '', '0', '0', '0', '0', '0', '0', '0', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '44800.00', '0', '0', NULL, NULL, '1', '1', '0');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('31', '2022-06-21', '2022-06-21', '', '1969-12-31', 'INV4', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-06-21', '10:43 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '10', '350000.00', '0', 'percent_wise', '0.00', '350000.00', '14', '49000.00', '14', '49000.00', '28', '', NULL, '350000.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '448000.00', '448000.00', '1', 'INV4210622', 'INV4-2022', '1', '1', '10.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('32', '2022-06-21', '2022-06-21', '', '1969-12-31', 'INV5', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-06-21', '10:43 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '10', '350000.00', '0', 'percent_wise', '0.00', '350000.00', '14', '49000.00', '14', '49000.00', '28', '', NULL, '350000.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '448000.00', '448000.00', '1', 'INV4210622', 'INV4-2022', '1', '1', '10.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('33', '2022-06-21', '2022-04-01', '', '1969-12-31', 'INV6', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-06-21', '10:46 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '5', '175000.00', '0', 'percent_wise', '0.00', '175000.00', '14', '24500.00', '14', '24500.00', '28', '', NULL, '175000.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '224000.00', '0', '0', 'INV6210622', 'INV6-2022', '1', '1', '5.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('34', '2022-06-21', '2022-06-21', '', '1969-12-31', 'INV7', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-06-21', '10:55 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '2', '70000.00', '10', 'percent_wise', '7000.00', '63000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '63000.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '80640.00', '42560.00', '1', NULL, NULL, '1', '1', '1.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('35', '2022-06-21', '2022-04-01', '', '1969-12-31', 'INV8', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-06-21', '11:02 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '1', '35000.00', '0', 'percent_wise', '0.00', '35000.00', '14', '4900.00', '14', '4900.00', '28', '', NULL, '35000.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '44800.00', '0', '0', 'INV8210622', 'INV8-2022', '1', '1', '1.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('36', '2022-06-22', '2022-06-22', '', '1969-12-31', 'INV9', 'SDC1', NULL, NULL, NULL, 'Tax Invoice', 'Against DC', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-06-22', '01:11 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', 'SDC1||SDC1', '17', '15||18', '0||123456789', '||', 'GST FEES ||Aluminium c12A Y body', '||', 'NOS||KGS', '1000||35000', '0||5', '0.00||175000.00', '0||0', 'percent_wise', '||', '0.00||175000.00', '14', '24500.00', '14', '24500.00', '28', '', '0.00||175000.00', '175000.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1||1', '224000.00', '224000.00', '1', 'INV9220622', 'INV9-2022', '1', '1', '0');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('37', '2022-06-22', '2022-06-22', '', '1969-12-31', 'INV10', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-06-22', '03:46 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '5', '175000.00', '0', 'percent_wise', '0.00', '175000.00', '14', '24500.00', '14', '24500.00', '28', '', NULL, '175000.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '224000.00', '224000.00', '1', 'INV10220622', 'INV10-2022', '1', '1', '5.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('38', '2022-06-22', '2022-06-22', '', '1969-12-31', 'INV11', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-06-22', '03:49 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '5', '175000.00', '0', 'percent_wise', '0.00', '175000.00', '14', '24500.00', '14', '24500.00', '28', '', NULL, '175000.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '224000.00', '224000.00', '1', 'INV10220622', 'INV10-2022', '1', '1', '5.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('39', '2022-06-22', '2022-06-22', '', '1969-12-31', 'INV12', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-06-22', '03:51 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', 'KGS', '35000', '2', '70000.00', '0', 'percent_wise', '0.00', '70000.00', '14', '9800.00', '14', '9800.00', '28', '', NULL, '70000.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '89600.00', '89600.00', '1', 'INV11220622', 'INV11-2022', '1', '1', '2.00');
INSERT INTO invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES ('40', '2022-07-16', '2022-07-16', '', '1969-12-31', 'INV/22-23/-00013', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, '', '2022-07-16', '06:23 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789||123', NULL, 'Aluminium c12A Y body||metal ', '||', 'KGS||KGS', '35000||150', '1||1', '35000.00||150.00', '0||0', 'percent_wise', '0.00||0.00', '35000.00||150.00', '9', '3163.50', '9', '3163.50', '18', '', NULL, '35150.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1||1', '41477.00', '41477.00', '1', 'INV/22-23/-00013160722', 'INV/22-23/-00013-2022', '1', '1', '2.00');


#
# TABLE STRUCTURE FOR: invoice_details_backup
#

DROP TABLE IF EXISTS invoice_details_backup;

CREATE TABLE `invoice_details_backup` (
  `id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `pono` varchar(255) DEFAULT NULL,
  `purchaseordernos` varchar(255) DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `removalDate` date NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToId` varchar(255) DEFAULT NULL,
  `shipToAddress` longtext,
  `deliveryAddress1` longtext,
  `deliveryAddress2` longtext,
  `mobileNo` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: invoice_party_statement
#

DROP TABLE IF EXISTS invoice_party_statement;

CREATE TABLE `invoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;

INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('1', '-', '-', NULL, '2022-01-10', 'INV', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-01-10', '2022-01-10', '89600.00', '-', '-', '', '', '-', '-', NULL, '89600', '-', '-', '-', '-', '89600.00', '-', '89600.00', NULL, NULL, 'INV-2022', 'INV100122', '1');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('6', '-', '-', NULL, '2022-03-18', 'INV1', '1', 'SMk', '', '', '', '', '0', '', '', NULL, NULL, '', '', '1', '2022-03-18', '2022-03-18', '100.00', '-', '-', '', '', '-', '-', NULL, '2570', '-', '-', '-', '-', '100.00', '-', '100.00', NULL, NULL, 'INV1-2022', 'INV1180322', '4');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('7', '-', '-', NULL, '2022-03-18', 'INV3', '1', 'SMk', '', '', '', 'casing', '', '', '', NULL, NULL, '', '', '1', '2022-03-18', '2022-03-18', '1770.00', '-', '-', '', '', '-', '-', NULL, '4340', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV3-2022', 'INV3180322', '5');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('8', '-', '-', NULL, '2022-03-18', 'INV4', '1', 'SMk', '', '', '', 'casing', '', '', '', NULL, NULL, '', '', '1', '2022-03-18', '2022-03-18', '1500.00', '-', '-', '', '', '-', '-', NULL, '5840', '-', '-', '-', '-', '1500.00', '-', '1500.00', NULL, NULL, 'INV4-2022', 'INV4180322', '6');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('9', '-', '-', NULL, '2022-03-18', 'INV4', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-03-18', '2022-03-18', '44800.00', '-', '-', '', '', '-', '-', NULL, '50640', '-', '-', '-', '-', '44800.00', '-', '44800.00', NULL, NULL, 'INV4-2022', 'INV4180322', '7');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('10', '-', '-', NULL, '2022-03-18', 'INV6', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-03-18', '2022-03-18', '44800.00', '-', '-', '', '', '-', '-', NULL, '95440', '-', '-', '-', '-', '44800.00', '-', '44800.00', NULL, NULL, 'INV6-2022', 'INV6180322', '8');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('11', '-', '-', NULL, '2022-03-18', 'INV7', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-03-18', '2022-03-18', '44800.00', '-', '-', '', '', '-', '-', NULL, '140240', '-', '-', '-', '-', '44800.00', '-', '44800.00', NULL, NULL, 'INV7-2022', 'INV7180322', '9');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('12', '-', '-', NULL, '2022-03-18', 'INV8', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-03-18', '2022-03-18', '44800.00', '-', '-', '', '', '-', '-', NULL, '185040', '-', '-', '-', '-', '44800.00', '-', '44800.00', NULL, NULL, 'INV8-2022', 'INV8180322', '10');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('13', '-', '-', NULL, '2022-03-18', 'INV9', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-03-18', '2022-03-18', '44800.00', '-', '-', '', '', '-', '-', NULL, '229840', '-', '-', '-', '-', '44800.00', '-', '44800.00', NULL, NULL, 'INV9-2022', 'INV9180322', '11');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('14', '-', '-', NULL, '2022-03-18', 'INV10', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-03-18', '2022-03-18', '44800.00', '-', '-', '', '', '-', '-', NULL, '274640', '-', '-', '-', '-', '44800.00', '-', '44800.00', NULL, NULL, 'INV10-2022', 'INV10180322', '12');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('15', '-', '-', NULL, '2022-03-18', 'INV11', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-03-18', '2022-03-18', '44800.00', '-', '-', '', '', '-', '-', NULL, '319440', '-', '-', '-', '-', '44800.00', '-', '44800.00', NULL, NULL, 'INV11-2022', 'INV11180322', '13');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('16', '-', '-', NULL, '2022-03-18', 'INV12', '1', 'SMk', '', '', '', 'casing', '', '', '', NULL, NULL, '', '', '1', '2022-03-18', '2022-03-18', '1500.00', '-', '-', '', '', '-', '-', NULL, '320940', '-', '-', '-', '-', '1500.00', '-', '1500.00', NULL, NULL, 'INV12-2022', 'INV12180322', '14');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('17', '-', '-', NULL, '2022-03-18', 'INV13', '1', 'SMk', '', '', '', 'casing', '', '', '', NULL, NULL, '', '', '1', '2022-03-18', '2022-03-18', '1770.00', '-', '-', '', '', '-', '-', NULL, '322710', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV13-2022', 'INV13180322', '15');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('20', '-', '-', NULL, '2022-03-18', 'INV14', '1', 'SMk', '', '', '', 'aluminium||casing||aluminium', '||||', '', '', NULL, NULL, '', '', '1', '2022-03-18', '2022-03-18', '7040.00', '-', '-', '', '', '-', '-', NULL, '329750', '-', '-', '-', '-', '7040.00', '-', '7040.00', NULL, NULL, NULL, NULL, '16');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('21', '-', '-', NULL, '2022-03-23', 'INV15', '2', 'SRI VINAYAKA TRADERS', '', '', '', 'metal body', '', '', '', NULL, NULL, '', '', '1', '2022-03-23', '2022-03-23', 'NaN', '-', '-', '', '', '-', '-', NULL, '-1000', '-', '-', '-', '-', 'NaN', '-', 'NaN', NULL, NULL, 'INV15-2022', 'INV15230322', '17');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('22', '-', '-', NULL, '2022-03-24', 'INV16', '3', 'Paramesh Steels and Alloys', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-03-24', '2022-03-24', '44800.00', '-', '-', '', '', '-', '-', NULL, '144800', '-', '-', '-', '-', '44800.00', '-', '44800.00', NULL, NULL, 'INV16-2022', 'INV16240322', '18');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('23', '-', '-', NULL, '2022-03-24', 'INV17', '3', 'Paramesh Steels and Alloys', '', '', '', 'metal body', '', '', '', NULL, NULL, '', '', '1', '2022-03-24', '2022-03-24', '1770.00', '-', '-', '', '', '-', '-', NULL, '146570', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV17-2022', 'INV17240322', '19');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('24', '-', '-', NULL, '2022-03-24', 'INV18', '3', 'Paramesh Steels and Alloys', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-03-24', '2022-03-24', '89600.00', '-', '-', '', '', '-', '-', NULL, '236170', '-', '-', '-', '-', '89600.00', '-', '89600.00', NULL, NULL, 'INV18-2022', 'INV18240322', '20');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('32', '-', '-', NULL, '2022-03-24', 'INV20', '4', 'Prakash Castings', '', '', '', 'metal body', '', '', '', NULL, NULL, '', '', '1', '2022-03-24', '2022-03-24', '1770.00', '-', '-', '', '', '-', '-', NULL, '146570', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV20-2022', 'INV20240322', '22');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('33', '-', '-', NULL, '2022-03-24', 'INV21', '4', 'Prakash Castings', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-03-24', '2022-03-24', '89600.00', '-', '-', '', '', '-', '-', NULL, '236170', '-', '-', '-', '-', '89600.00', '-', '89600.00', NULL, NULL, 'INV21-2022', 'INV21240322', '23');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('34', '-', '-', NULL, '2022-03-24', 'INV22', '4', 'Prakash Castings', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-03-24', '2022-03-24', '44800.00', '-', '-', '', '', '-', '-', NULL, '236170', '-', '-', '-', '-', '44800.00', '-', '44800.00', NULL, NULL, 'INV22-2022', 'INV22240322', '24');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('42', '-', '-', NULL, '2022-03-30', 'INV23', '2', 'SRI VINAYAKA TRADERS', '', '', '', 'motor', '', '', '', NULL, NULL, '', '', '1', '2022-03-30', '2022-03-30', '9900.00', '-', '-', '', '', '-', '-', NULL, '8900', '-', '-', '-', '-', '9900.00', '-', '9900.00', NULL, NULL, 'INV23-2022', 'INV23300322', '25');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('43', '-', '-', NULL, '2022-03-31', 'INV24', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-03-31', '2022-03-31', '44800.00', '-', '-', '', '', '-', '-', NULL, '368550', '-', '-', '-', '-', '44800.00', '-', '44800.00', NULL, NULL, 'INV24-2022', 'INV24310322', '26');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('48', '-', '-', NULL, '2022-06-04', 'INV2', '1', 'SMk', '', '', '', 'Aluminium c12A Y body||Aluminium c12A Y body||Aluminium c12A Y body||Aluminium c12A Y body||Aluminium c12A Y body||Aluminium c12A Y body||Aluminium c12A Y body||Aluminium c12A Y body||Aluminium c12A Y body||Aluminium c12A Y body||Aluminium c12A Y body', '||||||||||||||||||||', '', '', NULL, NULL, '', '', '1', '2022-06-04', '2022-06-04', '2956800.00', '-', '-', '', '', '-', '-', NULL, '3506320', '-', '-', '-', '-', '2956800.00', '-', '2956800.00', NULL, NULL, NULL, NULL, '29');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('51', 'R14', '', NULL, '2022-06-15', '-', '0', 'SMk', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2022-06-15', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '3458243', NULL, NULL, NULL, 'Cheque KOTAK MAHINDRA 1222', NULL, '92877', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('52', '-', '-', NULL, '2022-06-10', 'INV3', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-06-10', '2022-06-10', '44800.00', '-', '-', '', '', '-', '-', NULL, '3458243', '-', '-', '-', '-', '44800.00', '-', '44800.00', NULL, NULL, NULL, NULL, '30');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('53', '-', '-', NULL, '2022-06-21', 'INV4', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-06-21', '2022-06-21', '448000.00', '-', '-', '', '', '-', '-', NULL, '3906243', '-', '-', '-', '-', '448000.00', '-', '448000.00', NULL, NULL, 'INV4-2022', 'INV4210622', '31');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('54', '-', '-', NULL, '2022-06-21', 'INV4', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-06-21', '2022-06-21', '448000.00', '-', '-', '', '', '-', '-', NULL, '4354243', '-', '-', '-', '-', '448000.00', '-', '448000.00', NULL, NULL, 'INV4-2022', 'INV4210622', '32');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('55', '-', '-', NULL, '2022-04-01', 'INV6', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-04-01', '2022-04-01', '224000.00', '-', '-', '', '', '-', '-', NULL, '4533443', '-', '-', '-', '-', '224000.00', '-', '224000.00', NULL, NULL, 'INV6-2022', 'INV6210622', '33');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('57', '-', '-', NULL, '2022-06-21', 'INV7', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-06-21', '2022-06-21', '80640.00', '-', '-', '', '', '-', '-', NULL, '4703683', '-', '-', '-', '-', '80640.00', '-', '80640.00', NULL, NULL, NULL, NULL, '34');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('58', '-', '-', NULL, '2022-04-01', 'INV8', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-04-01', '2022-04-01', '44800.00', '-', '-', '', '', '-', '-', NULL, '4703683', '-', '-', '-', '-', '44800.00', '-', '44800.00', NULL, NULL, 'INV8-2022', 'INV8210622', '35');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('59', 'R15', '', NULL, '2022-06-21', '-', '0', 'SMk', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2022-06-21', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '4434883', NULL, NULL, NULL, 'Cash', NULL, '268800', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('60', 'R16', '', NULL, '2022-06-21', '-', '0', 'SMk', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2022-06-21', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '4345283', NULL, NULL, NULL, 'Cash', NULL, '89600', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('61', '-', '-', NULL, '2022-06-22', 'INV9', '1', 'SMk', '', '', '', 'GST FEES ||Aluminium c12A Y body', '||', '', '', NULL, NULL, '', '', '1', '2022-06-22', '2022-06-22', '224000.00', '-', '-', '', '', '-', '-', NULL, '4569283', '-', '-', '-', '-', '224000.00', '-', '224000.00', NULL, NULL, 'INV9-2022', 'INV9220622', '36');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('62', '-', '-', NULL, '2022-06-22', 'INV10', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-06-22', '2022-06-22', '224000.00', '-', '-', '', '', '-', '-', NULL, '4793283', '-', '-', '-', '-', '224000.00', '-', '224000.00', NULL, NULL, 'INV10-2022', 'INV10220622', '37');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('63', '-', '-', NULL, '2022-06-22', 'INV10', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-06-22', '2022-06-22', '224000.00', '-', '-', '', '', '-', '-', NULL, '5017283', '-', '-', '-', '-', '224000.00', '-', '224000.00', NULL, NULL, 'INV10-2022', 'INV10220622', '38');
INSERT INTO invoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('64', '-', '-', NULL, '2022-06-22', 'INV11', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-06-22', '2022-06-22', '89600.00', '-', '-', '', '', '-', '-', NULL, '5106883', '-', '-', '-', '-', '89600.00', '-', '89600.00', NULL, NULL, 'INV11-2022', 'INV11220622', '39');


#
# TABLE STRUCTURE FOR: invoice_party_statement_backup
#

DROP TABLE IF EXISTS invoice_party_statement_backup;

CREATE TABLE `invoice_party_statement_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: invoice_reports
#

DROP TABLE IF EXISTS invoice_reports;

CREATE TABLE `invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=latin1;

INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('1', '2022-01-10', 'INV', '2022-01-10', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN66A0001', NULL, '2022-01-11', '001', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '2', NULL, NULL, '70000.00', NULL, NULL, '89600.00', NULL, NULL, '1', 'INV-2022', 'INV100122', '1');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('3', '2022-03-18', 'INV3', '2022-03-18', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '', NULL, NULL, 'casing', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV3-2022', 'INV3180322', '5');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('4', '2022-03-18', 'INV4', '2022-03-18', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '', NULL, NULL, 'casing', '', '1', '1', '1', NULL, '1500.00', NULL, NULL, '1500.00', NULL, NULL, '1', 'INV4-2022', 'INV4180322', '6');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('5', '2022-03-18', 'INV4', '2022-03-18', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '1', '4', NULL, '44800.00', NULL, NULL, '44800.00', NULL, NULL, '1', 'INV4-2022', 'INV4180322', '7');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('6', '2022-03-18', 'INV6', '2022-03-18', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '1', NULL, NULL, '35000.00', NULL, NULL, '44800.00', NULL, NULL, '1', 'INV6-2022', 'INV6180322', '8');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('7', '2022-03-18', 'INV7', '2022-03-18', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '1', '4', NULL, '44800.00', NULL, NULL, '44800.00', NULL, NULL, '1', 'INV7-2022', 'INV7180322', '9');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('8', '2022-03-18', 'INV8', '2022-03-18', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '1', '4', NULL, '44800.00', NULL, NULL, '44800.00', NULL, NULL, '1', 'INV8-2022', 'INV8180322', '10');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('9', '2022-03-18', 'INV9', '2022-03-18', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '1', '4', NULL, '44800.00', NULL, NULL, '44800.00', NULL, NULL, '1', 'INV9-2022', 'INV9180322', '11');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('10', '2022-03-18', 'INV10', '2022-03-18', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '1', '4', NULL, '44800.00', NULL, NULL, '44800.00', NULL, NULL, '1', 'INV10-2022', 'INV10180322', '12');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('11', '2022-03-18', 'INV11', '2022-03-18', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '1', '4', NULL, '44800.00', NULL, NULL, '44800.00', NULL, NULL, '1', 'INV11-2022', 'INV11180322', '13');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('12', '2022-03-18', 'INV12', '2022-03-18', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '', NULL, NULL, 'casing', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1500.00', NULL, NULL, '1', 'INV12-2022', 'INV12180322', '14');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('13', '2022-03-18', 'INV13', '2022-03-18', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456', NULL, NULL, 'casing', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV13-2022', 'INV13180322', '15');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('16', '2022-03-18', 'INV14', '2022-03-18', NULL, NULL, '0', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '012389', NULL, NULL, 'aluminium', '', '1500', '1', NULL, NULL, '5500.00', NULL, NULL, '7040.00', NULL, NULL, '1', NULL, NULL, '16');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('17', '2022-03-18', 'INV14', '2022-03-18', NULL, NULL, '0', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '0126514', NULL, NULL, 'casing', '', '2000', '1', NULL, NULL, '5500.00', NULL, NULL, '7040.00', NULL, NULL, '1', NULL, NULL, '16');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('18', '2022-03-18', 'INV14', '2022-03-18', NULL, NULL, '0', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '012345', NULL, NULL, 'aluminium', '', '2000', '1', NULL, NULL, '5500.00', NULL, NULL, '7040.00', NULL, NULL, '1', NULL, NULL, '16');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('19', '2022-03-23', 'INV15', '2022-03-23', NULL, NULL, '2', 'SRI VINAYAKA TRADERS', NULL, NULL, NULL, 'ARASUR, COIMBATORE, COIMBATORE, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '0123456', NULL, NULL, 'metal body', '', '1', '15', NULL, NULL, '22500.00', NULL, NULL, 'NaN', NULL, NULL, '1', 'INV15-2022', 'INV15230322', '17');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('20', '2022-03-24', 'INV16', '2022-03-24', NULL, NULL, '3', 'Paramesh Steels and Alloys', NULL, NULL, NULL, '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp, Avinashi Road, Hopes College, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '1', NULL, NULL, '35000.00', NULL, NULL, '44800.00', NULL, NULL, '1', 'INV16-2022', 'INV16240322', '18');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('21', '2022-03-24', 'INV17', '2022-03-24', NULL, NULL, '3', 'Paramesh Steels and Alloys', NULL, NULL, NULL, '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp, Avinashi Road, Hopes College, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '0123456', NULL, NULL, 'metal body', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV17-2022', 'INV17240322', '19');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('22', '2022-03-24', 'INV18', '2022-03-24', NULL, NULL, '3', 'Paramesh Steels and Alloys', NULL, NULL, NULL, '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp, Avinashi Road, Hopes College, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '2', NULL, NULL, '70000.00', NULL, NULL, '89600.00', NULL, NULL, '1', 'INV18-2022', 'INV18240322', '20');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('24', '2022-03-24', 'INV20', '2022-03-24', NULL, NULL, '4', 'Prakash Castings', NULL, NULL, NULL, '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp, Avinashi Road, Hopes College, COIMBATORE, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '0123456', NULL, NULL, 'metal body', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV20-2022', 'INV20240322', '22');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('25', '2022-03-24', 'INV21', '2022-03-24', NULL, NULL, '4', 'Prakash Castings', NULL, NULL, NULL, '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp, Avinashi Road, Hopes College, COIMBATORE, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '2', NULL, NULL, '70000.00', NULL, NULL, '89600.00', NULL, NULL, '1', 'INV21-2022', 'INV21240322', '23');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('26', '2022-03-24', 'INV22', '2022-03-24', NULL, NULL, '4', 'Prakash Castings', NULL, NULL, NULL, '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp, Avinashi Road, Hopes College, COIMBATORE, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '1', NULL, NULL, '35000.00', NULL, NULL, '44800.00', NULL, NULL, '1', 'INV22-2022', 'INV22240322', '24');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('27', '2022-03-30', 'INV23', '2022-03-30', NULL, NULL, '2', 'SRI VINAYAKA TRADERS', NULL, NULL, NULL, 'ARASUR, COIMBATORE, COIMBATORE, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '', NULL, NULL, 'motor', '', '5', '2', NULL, NULL, '9900.00', NULL, NULL, '9900.00', NULL, NULL, '1', 'INV23-2022', 'INV23300322', '25');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('28', '2022-03-31', 'INV24', '2022-03-31', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '1', '4', NULL, '44800.00', NULL, NULL, '44800.00', NULL, NULL, '1', 'INV24-2022', 'INV24310322', '26');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('53', '2022-06-07', 'INV2', '2022-06-04', NULL, NULL, '0', 'SMk', NULL, NULL, NULL, '', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '35000', '1', NULL, NULL, '2956800.00', NULL, NULL, '2956800.00', NULL, NULL, '1', NULL, NULL, '29');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('54', '2022-06-07', 'INV2', '2022-06-04', NULL, NULL, '0', 'SMk', NULL, NULL, NULL, '', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '35000', '2', NULL, NULL, '2956800.00', NULL, NULL, '2956800.00', NULL, NULL, '1', NULL, NULL, '29');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('55', '2022-06-07', 'INV2', '2022-06-04', NULL, NULL, '0', 'SMk', NULL, NULL, NULL, '', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '35000', '3', NULL, NULL, '2956800.00', NULL, NULL, '2956800.00', NULL, NULL, '1', NULL, NULL, '29');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('56', '2022-06-07', 'INV2', '2022-06-04', NULL, NULL, '0', 'SMk', NULL, NULL, NULL, '', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '35000', '4', NULL, NULL, '2956800.00', NULL, NULL, '2956800.00', NULL, NULL, '1', NULL, NULL, '29');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('57', '2022-06-07', 'INV2', '2022-06-04', NULL, NULL, '0', 'SMk', NULL, NULL, NULL, '', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '35000', '5', NULL, NULL, '2956800.00', NULL, NULL, '2956800.00', NULL, NULL, '1', NULL, NULL, '29');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('58', '2022-06-07', 'INV2', '2022-06-04', NULL, NULL, '0', 'SMk', NULL, NULL, NULL, '', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '35000', '6', NULL, NULL, '2956800.00', NULL, NULL, '2956800.00', NULL, NULL, '1', NULL, NULL, '29');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('59', '2022-06-07', 'INV2', '2022-06-04', NULL, NULL, '0', 'SMk', NULL, NULL, NULL, '', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '35000', '7', NULL, NULL, '2956800.00', NULL, NULL, '2956800.00', NULL, NULL, '1', NULL, NULL, '29');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('60', '2022-06-07', 'INV2', '2022-06-04', NULL, NULL, '0', 'SMk', NULL, NULL, NULL, '', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '35000', '8', NULL, NULL, '2956800.00', NULL, NULL, '2956800.00', NULL, NULL, '1', NULL, NULL, '29');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('61', '2022-06-07', 'INV2', '2022-06-04', NULL, NULL, '0', 'SMk', NULL, NULL, NULL, '', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '35000', '9', NULL, NULL, '2956800.00', NULL, NULL, '2956800.00', NULL, NULL, '1', NULL, NULL, '29');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('62', '2022-06-07', 'INV2', '2022-06-04', NULL, NULL, '0', 'SMk', NULL, NULL, NULL, '', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '35000', '10', NULL, NULL, '2956800.00', NULL, NULL, '2956800.00', NULL, NULL, '1', NULL, NULL, '29');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('63', '2022-06-07', 'INV2', '2022-06-04', NULL, NULL, '0', 'SMk', NULL, NULL, NULL, '', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '35000', '11', NULL, NULL, '2956800.00', NULL, NULL, '2956800.00', NULL, NULL, '1', NULL, NULL, '29');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('66', '2022-06-21', 'INV3', '2022-06-10', NULL, NULL, '0', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '35000', '1', NULL, NULL, '44800.00', NULL, NULL, '44800.00', NULL, NULL, '1', NULL, NULL, '30');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('67', '2022-06-21', 'INV4', '2022-06-21', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '10', NULL, NULL, '350000.00', NULL, NULL, '448000.00', NULL, NULL, '1', 'INV4-2022', 'INV4210622', '31');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('68', '2022-06-21', 'INV4', '2022-06-21', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '10', NULL, NULL, '350000.00', NULL, NULL, '448000.00', NULL, NULL, '1', 'INV4-2022', 'INV4210622', '32');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('69', '2022-06-21', 'INV6', '2022-04-01', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '5', NULL, NULL, '175000.00', NULL, NULL, '224000.00', NULL, NULL, '1', 'INV6-2022', 'INV6210622', '33');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('71', '2022-06-21', 'INV7', '2022-06-21', NULL, NULL, '0', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '35000', '2', NULL, NULL, '63000.00', NULL, NULL, '80640.00', NULL, NULL, '1', NULL, NULL, '34');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('72', '2022-06-21', 'INV8', '2022-04-01', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '1', NULL, NULL, '35000.00', NULL, NULL, '44800.00', NULL, NULL, '1', 'INV8-2022', 'INV8210622', '35');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('73', '2022-06-22', 'INV9', '2022-06-22', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '0', '', NULL, 'GST FEES ', '', '1', '0', '0', NULL, '175000.00', NULL, NULL, '224000.00', NULL, NULL, '1', 'INV9-2022', 'INV9220622', '36');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('74', '2022-06-22', 'INV9', '2022-06-22', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', '', NULL, 'Aluminium c12A Y body', '', '0', '5', '.', NULL, '175000.00', NULL, NULL, '224000.00', NULL, NULL, '1', 'INV9-2022', 'INV9220622', '36');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('75', '2022-06-22', 'INV10', '2022-06-22', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '5', NULL, NULL, '175000.00', NULL, NULL, '224000.00', NULL, NULL, '1', 'INV10-2022', 'INV10220622', '37');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('76', '2022-06-22', 'INV10', '2022-06-22', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '5', NULL, NULL, '175000.00', NULL, NULL, '224000.00', NULL, NULL, '1', 'INV10-2022', 'INV10220622', '38');
INSERT INTO invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('77', '2022-06-22', 'INV11', '2022-06-22', NULL, NULL, '1', 'SMk', NULL, NULL, NULL, '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '123456789', NULL, NULL, 'Aluminium c12A Y body', '', '3', '2', NULL, NULL, '70000.00', NULL, NULL, '89600.00', NULL, NULL, '1', 'INV11-2022', 'INV11220622', '39');


#
# TABLE STRUCTURE FOR: inward_delivery
#

DROP TABLE IF EXISTS inward_delivery;

CREATE TABLE `inward_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insertid` int(11) NOT NULL,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `inward_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES ('1', '1', '2022-03-02', 'I', '2022-03-02', 'SRI VINAYAKA TRADERS', 'ARASUR, COIMBATORE', '123', '2022-03-02', 'Aluminium c12A Y body', '', '10', '5', 'milling', '123456789', NULL, 'KGS', 'I-22', 'I020322', '1', '1');
INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES ('2', '2', '2022-03-08', 'I1', '2022-03-08', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL', '001', '2022-03-08', 'GST FEES ', '', '1', '0', '', '0', NULL, 'NOS', 'I1-22', 'I1080322', '1', '0');
INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES ('3', '3', '2022-03-09', 'I2', '2022-03-09', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL', '002', '2022-03-09', 'Aluminium c12A Y body', '', '1', '1', '', '123456789', NULL, 'KGS', 'I2-22', 'I2090322', '1', '1');
INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES ('4', '4', '2022-03-09', 'I3', '2022-03-09', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL', '003', '2022-03-09', 'Aluminium c12A Y body', '', '1', '1', '', '123456789', NULL, 'KGS', 'I3-22', 'I3090322', '1', '1');
INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES ('5', '5', '2022-03-14', 'I4', '2022-03-14', 'SRI VINAYAKA TRADERS', 'ARASUR, COIMBATORE', '10102', '2022-03-14', 'Aluminium c12A Y body', '', '12', '12', 'multi procc', '123456789', NULL, 'KGS', 'I4-22', 'I4140322', '1', '1');
INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES ('6', '6', '2022-06-15', 'I5', '2022-06-15', 'Paramesh Steels and Alloys', '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp, Avinashi Road, Hopes College', '123233', '2022-06-15', 'Aluminium c12A Y body', '', '500', '500', '', '123456789', NULL, 'KGS', 'I5-22', 'I5150622', '1', '1');
INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES ('7', '7', '2022-06-15', 'I6', '2022-06-15', 'SRI VINAYAKA TRADERS', 'ARASUR, COIMBATORE', '12121212', '2022-06-15', 'Aluminium c12A Y body', '', '100', '100', '', '123456789', NULL, 'KGS', 'I6-22', 'I6150622', '1', '1');
INSERT INTO inward_delivery (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`) VALUES ('8', '8', '2022-06-21', 'I7', '2022-06-21', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL', 'dc0021', '2022-06-21', 'Aluminium c12A Y body', '', '15', '4', '', '123456789', NULL, 'KGS', 'I7-22', 'I7210622', '1', '1');


#
# TABLE STRUCTURE FOR: inward_details
#

DROP TABLE IF EXISTS inward_details;

CREATE TABLE `inward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES ('1', '2022-03-02', 'I', '2022-03-02', 'SRI VINAYAKA TRADERS', 'ARASUR, COIMBATORE', '123', '2022-03-02', 'Aluminium c12A Y body', '', '10', 'milling', '123456789', NULL, 'KGS', 'I-22', 'I020322', '1', '0', '1');
INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES ('2', '2022-03-08', 'I1', '2022-03-08', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL', '001', '2022-03-08', 'GST FEES ', '', '1', '', '', NULL, 'NOS', 'I1-22', 'I1080322', '1', '0', '2');
INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES ('3', '2022-03-09', 'I2', '2022-03-09', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL', '002', '2022-03-09', 'Aluminium c12A Y body', '', '1', '', '123456789', NULL, 'KGS', 'I2-22', 'I2090322', '1', '1', '3');
INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES ('4', '2022-03-09', 'I3', '2022-03-09', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL', '003', '2022-03-09', 'Aluminium c12A Y body', '', '1', '', '123456789', NULL, 'KGS', 'I3-22', 'I3090322', '1', '1', '4');
INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES ('5', '2022-03-14', 'I4', '2022-03-14', 'SRI VINAYAKA TRADERS', 'ARASUR, COIMBATORE', '10102', '2022-03-14', 'Aluminium c12A Y body', '', '12', 'multi procc', '123456789', NULL, 'KGS', 'I4-22', 'I4140322', '1', '1', '5');
INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES ('6', '2022-06-15', 'I5', '2022-06-15', 'Paramesh Steels and Alloys', '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp, Avinashi Road, Hopes College', '123233', '2022-06-15', 'Aluminium c12A Y body', '', '500', '', '123456789', NULL, 'KGS', 'I5-22', 'I5150622', '1', '1', '6');
INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES ('7', '2022-06-15', 'I6', '2022-06-15', 'SRI VINAYAKA TRADERS', 'ARASUR, COIMBATORE', '12121212', '2022-06-15', 'Aluminium c12A Y body', '', '100', '', '123456789', NULL, 'KGS', 'I6-22', 'I6150622', '1', '1', '7');
INSERT INTO inward_details (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES ('8', '2022-06-21', 'I7', '2022-06-21', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL', 'dc0021', '2022-06-21', 'Aluminium c12A Y body', '', '15', '', '123456789', NULL, 'KGS', 'I7-22', 'I7210622', '1', '0', '8');


#
# TABLE STRUCTURE FOR: inward_details_backup
#

DROP TABLE IF EXISTS inward_details_backup;

CREATE TABLE `inward_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: job_data
#

DROP TABLE IF EXISTS job_data;

CREATE TABLE `job_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: job_details
#

DROP TABLE IF EXISTS job_details;

CREATE TABLE `job_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `joborderdate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext,
  `category` longtext,
  `jobdescription` longtext,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobinward_data
#

DROP TABLE IF EXISTS jobinward_data;

CREATE TABLE `jobinward_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `joborderqty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobinward_details
#

DROP TABLE IF EXISTS jobinward_details;

CREATE TABLE `jobinward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `jobinwarddate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext,
  `joborderno` varchar(225) DEFAULT NULL,
  `category` longtext,
  `jobdescription` longtext,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobworkdc_delivery
#

DROP TABLE IF EXISTS jobworkdc_delivery;

CREATE TABLE `jobworkdc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobworkdc_delivery_backup
#

DROP TABLE IF EXISTS jobworkdc_delivery_backup;

CREATE TABLE `jobworkdc_delivery_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobworkdc_details
#

DROP TABLE IF EXISTS jobworkdc_details;

CREATE TABLE `jobworkdc_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobworkdc_details_backup
#

DROP TABLE IF EXISTS jobworkdc_details_backup;

CREATE TABLE `jobworkdc_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: login_details
#

DROP TABLE IF EXISTS login_details;

CREATE TABLE `login_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userType` char(1) NOT NULL,
  `date` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `sub_menu_link` text,
  `selectedMainMenu` text NOT NULL,
  `selectedSubMenu` text NOT NULL,
  `add_party` int(11) DEFAULT NULL,
  `add_expenses` int(11) DEFAULT NULL,
  `add_quotation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES ('1', 'A', '2017-01-26', 'admin', '', 'test@gmail.com', '876049652', '0000-00-00', 'admin', 'admin001', '1', '', '', '', NULL, NULL, NULL);
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES ('5', 'U', '2018-05-02', 'purchase', 'Purchase Team', '', '', '1970-01-01', 'purchase', '123456', '1', 'purchase,inward,inward/view,inward/pending,stockmaster,daily_stockreports,customer/view', 'Purchase,Inward,Inward,Inward,Stock,Stock,Reports', 'Purchase Receipt,Add Inward,Inward Reports,Inward Pending,Add Stock,Daily Stock Reports,Party Reports', '1', '0', '0');
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES ('6', 'U', '2018-05-02', 'Accounts', 'Accounts Team', '', '', '1970-01-01', 'Accounts', '123456', '1', 'invoice_statement/view,tax/view,cashbill/listing,purchase_statement/view,purchasetax/view,voucher,voucher/reports,stockmaster,daily_stockreports,itemwise_report,expenses/reports,quotation/view', 'Sales Invoice,Sales Invoice,Cash Bill,Purchase,Purchase,Voucher,Voucher,Stock,Stock,Stock,Reports,Reports', 'Invoice Party Statement,Invoice Tax Reports,Cash Bill Reports,Purchase Party Statement,Purchase Tax Reports,Add Voucher,Voucher Reports,Add Stock,Daily Stock Reports,Itemwise Reports,Expenses Reports,Quotation Reports', '0', '0', '0');
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES ('7', 'U', '2018-08-10', 'ramesh', 'developer', '', '', '1970-01-01', 'ramesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/reports,purchase_statement/view,purchasetax/view,stockmaster,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Stock,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Add Stock,Add Item', '0', '0', '0');
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES ('8', 'U', '2018-08-10', 'tester1', 'testing', '', '', '1970-01-01', 'tester1', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/view,purchase_statement/view,purchasetax/view,taxtype,uom,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Settings,Settings,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Tax Type,Add UOM,Add Item', '1', '0', '0');
INSERT INTO login_details (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES ('9', 'U', '2021-06-28', 'parmesh', 'developer', 'pshm956@gmail.com', '8344031191', '2021-06-28', 'parmesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,proforma_invoice/view', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Proforma Invoice Reports', '0', '0', '0');


#
# TABLE STRUCTURE FOR: materialdc_delivery
#

DROP TABLE IF EXISTS materialdc_delivery;

CREATE TABLE `materialdc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: materialdc_details
#

DROP TABLE IF EXISTS materialdc_details;

CREATE TABLE `materialdc_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: materialdc_details_backup
#

DROP TABLE IF EXISTS materialdc_details_backup;

CREATE TABLE `materialdc_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: po_party_statements
#

DROP TABLE IF EXISTS po_party_statements;

CREATE TABLE `po_party_statements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO po_party_statements (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES ('4', '2022-06-21', '2022-06-21', '-', 'P', '0', 'smk', NULL, NULL, 'Aluminium c12A Y body', NULL, '127680.00', '-', '-', '-', NULL, '-', '127680', NULL, '-', '-', '-', '-', '-', '127680.00', '-', NULL, '-', NULL, '127680.00', NULL, '001', '2022-06-21', '1', NULL, NULL, '1');


#
# TABLE STRUCTURE FOR: po_party_statements_backup
#

DROP TABLE IF EXISTS po_party_statements_backup;

CREATE TABLE `po_party_statements_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: preference_details
#

DROP TABLE IF EXISTS preference_details;

CREATE TABLE `preference_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `sed` varchar(255) DEFAULT NULL,
  `edc` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: preference_settings
#

DROP TABLE IF EXISTS preference_settings;

CREATE TABLE `preference_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotationPrefix` varchar(255) NOT NULL,
  `quotation` varchar(255) NOT NULL,
  `expenses` varchar(255) NOT NULL,
  `expensePrefix` varchar(255) NOT NULL,
  `dc` varchar(255) NOT NULL,
  `voucherPrefix` varchar(255) NOT NULL,
  `voucher` varchar(255) NOT NULL,
  `debitPrefix` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `creditPrefix` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `purchasePrefix` varchar(255) NOT NULL,
  `purchase` varchar(255) NOT NULL,
  `invoicePrefix` varchar(255) NOT NULL,
  `invoice` varchar(255) NOT NULL,
  `salesdcPrefix` varchar(255) NOT NULL,
  `materialdcPrefix` varchar(255) NOT NULL,
  `jobdcPrefix` varchar(255) NOT NULL,
  `proforma_invoicePrefix` varchar(255) NOT NULL,
  `proforma_invoice` varchar(255) NOT NULL,
  `inwardPrefix` varchar(255) NOT NULL,
  `inward` varchar(255) NOT NULL,
  `cashbillPrefix` varchar(255) NOT NULL,
  `cashbill_invoice` varchar(255) NOT NULL,
  `creditnote` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) NOT NULL,
  `jobworkdc` varchar(255) DEFAULT NULL,
  `materialdc` varchar(255) DEFAULT NULL,
  `cmp_companyname` varchar(255) NOT NULL,
  `cmp_phoneno` varchar(255) NOT NULL,
  `cmp_mobileno` varchar(255) NOT NULL,
  `cmp_address1` varchar(255) NOT NULL,
  `cmp_address2` varchar(255) NOT NULL,
  `cmp_city` varchar(255) NOT NULL,
  `cmp_pincode` varchar(255) NOT NULL,
  `cmp_stateCode` varchar(255) NOT NULL,
  `cmp_website` varchar(255) NOT NULL,
  `cmp_emailid` varchar(255) NOT NULL,
  `cmp_logo` varchar(255) NOT NULL,
  `cont_companyname` varchar(255) NOT NULL,
  `cont_phoneno` varchar(255) NOT NULL,
  `cont_mobileno` varchar(255) NOT NULL,
  `cont_address1` varchar(255) NOT NULL,
  `cont_address2` varchar(255) NOT NULL,
  `cont_city` varchar(255) NOT NULL,
  `cont_pincode` varchar(255) NOT NULL,
  `cont_stateCode` varchar(255) NOT NULL,
  `cont_website` varchar(255) NOT NULL,
  `cont_emailid` varchar(255) NOT NULL,
  `cont_logo` varchar(255) NOT NULL,
  `discountBy` varchar(255) NOT NULL,
  `invoiceBy` varchar(255) NOT NULL,
  `itemType` varchar(255) NOT NULL,
  `bill_type` varchar(255) DEFAULT NULL,
  `quot_bill_type` varchar(255) DEFAULT NULL,
  `voucher_receivable` varchar(255) DEFAULT NULL,
  `voucher_payable` varchar(255) DEFAULT NULL,
  `last_backup` date NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `inward_add` varchar(255) NOT NULL,
  `cashbill_add` varchar(255) NOT NULL,
  `priceType` varchar(255) DEFAULT NULL,
  `priceType1` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO preference_settings (`id`, `quotationPrefix`, `quotation`, `expenses`, `expensePrefix`, `dc`, `voucherPrefix`, `voucher`, `debitPrefix`, `debit`, `creditPrefix`, `credit`, `purchasePrefix`, `purchase`, `invoicePrefix`, `invoice`, `salesdcPrefix`, `materialdcPrefix`, `jobdcPrefix`, `proforma_invoicePrefix`, `proforma_invoice`, `inwardPrefix`, `inward`, `cashbillPrefix`, `cashbill_invoice`, `creditnote`, `purchaseorder`, `jobworkdc`, `materialdc`, `cmp_companyname`, `cmp_phoneno`, `cmp_mobileno`, `cmp_address1`, `cmp_address2`, `cmp_city`, `cmp_pincode`, `cmp_stateCode`, `cmp_website`, `cmp_emailid`, `cmp_logo`, `cont_companyname`, `cont_phoneno`, `cont_mobileno`, `cont_address1`, `cont_address2`, `cont_city`, `cont_pincode`, `cont_stateCode`, `cont_website`, `cont_emailid`, `cont_logo`, `discountBy`, `invoiceBy`, `itemType`, `bill_type`, `quot_bill_type`, `voucher_receivable`, `voucher_payable`, `last_backup`, `itemcode`, `inward_add`, `cashbill_add`, `priceType`, `priceType1`) VALUES ('1', 'Q/22-23/-', '001', '001', 'E/22-23/-', '001', 'R/22-23/-', '001', 'D/22-23/-', '001', 'C/22-23/-', '001', 'PI/22-23/-', '001', 'INV/22-23/-', '', 'SDC/22-23/-', 'MDC/22-23/-', 'PDC/22-23/', 'PI/22-23/', '001', 'INW/22-23/-', '001', 'CB/22-23/-', '001', NULL, '', '001', '001', 'Myoffice Solutions', '7373333321', '8608701222', ' #91 Dr. Jaganathan Nagar', 'Civil Aerodrome Post, Coimbatore', 'Coimbatore', '641014', '33', 'www.idreamdevelopers.org', 'info@idreamdevelopers.com', '12832299_1579401915712151_5416626780361493206_n.png', 'IDREAMDEVELOPERS', '7373333321', '8608701333', ' #91 Dr. Jaganathan Nagar', 'Civil Aerodrome Post, Coimbatore', 'Coimbatore', '641014', '33', 'www.idreamdevelopers.com', 'info@idreamdevelopers.com', 'idream_logo.PNG', 'percent_wise', 'without_stock', 'with_item', 'Overall Tax', 'Overall Tax', 'Without Invoice', 'Without Purchase', '2020-05-04', NULL, 'With Inward', 'With Cashbill', NULL, NULL);


#
# TABLE STRUCTURE FOR: profile
#

DROP TABLE IF EXISTS profile;

CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `companyname` varchar(255) DEFAULT NULL,
  `softwarename` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `stateCode` varchar(255) NOT NULL,
  `emailid` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `gstin` varchar(225) DEFAULT NULL,
  `aadharno` varchar(225) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `bankname` varchar(255) DEFAULT NULL,
  `accountno` varchar(255) DEFAULT NULL,
  `bankbranch` varchar(255) DEFAULT NULL,
  `ifsccode` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO profile (`id`, `date`, `companyname`, `softwarename`, `mobileno`, `phoneno`, `address1`, `address2`, `city`, `pincode`, `stateCode`, `emailid`, `website`, `tinno`, `cstno`, `gstin`, `aadharno`, `status`, `username`, `password`, `bankname`, `accountno`, `bankbranch`, `ifsccode`, `state`) VALUES ('1', NULL, 'MYOFFICE ERP', 'MYOFFICE ERP', '8608701222', '7373333321', '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp', 'Avinashi Road, Hopes College', 'Coimbatore', '641014', 'Tamil Nadu', 'myoffice.ind.in@gmail.com', '', '12345', '54321', '33AAEEDR5643EF2', '', '1', 'admin', 'admin001', '', '', '', '', NULL);


#
# TABLE STRUCTURE FOR: proforma_invoice_details
#

DROP TABLE IF EXISTS proforma_invoice_details;

CREATE TABLE `proforma_invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO proforma_invoice_details (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES ('1', '2022-06-21', '2022-06-21', '', '2022-06-21', 'PI/21-22/001', NULL, 'Sales Invoice', '0', '1', 'SMk', NULL, '', '', '', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '123456789', 'Aluminium c12A Y body', '', 'KGS', '35000', '2', '70000.00', '0', 'percent_wise', '0.00', '70000.00', '14', '9800.00', '14', '9800.00', '28', '19600.00', '89600.00', '89600.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '89600.00', NULL, NULL, '1', '1');


#
# TABLE STRUCTURE FOR: proforma_invoice_details_backup
#

DROP TABLE IF EXISTS proforma_invoice_details_backup;

CREATE TABLE `proforma_invoice_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: proforma_invoice_reports
#

DROP TABLE IF EXISTS proforma_invoice_reports;

CREATE TABLE `proforma_invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO proforma_invoice_reports (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('2', '2022-06-21', 'PI/21-22/001', '2022-06-21', NULL, NULL, '0', 'SMk', NULL, NULL, NULL, NULL, 'intrastate', 'intrastate', '', '', NULL, '2022-06-21', '', NULL, '123456789', NULL, 'Aluminium c12A Y body', '', '35000', '2', NULL, '89600.00', NULL, '89600.00', NULL, NULL, '89600.00', NULL, NULL, '1', NULL, NULL, '1');


#
# TABLE STRUCTURE FOR: proinvoice_party_statement
#

DROP TABLE IF EXISTS proinvoice_party_statement;

CREATE TABLE `proinvoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO proinvoice_party_statement (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES ('2', '-', '-', NULL, '2022-06-21', 'PI/21-22/001', '1', 'SMk', '', '', '', 'Aluminium c12A Y body', '', '', '', NULL, NULL, '', '', '1', '2022-06-21', '2022-06-21', '89600.00', '-', '-', '', '', '-', '-', NULL, '4623043', '-', '-', '-', '-', '89600.00', '-', '89600.00', NULL, NULL, NULL, NULL, '1');


#
# TABLE STRUCTURE FOR: purchase_collection
#

DROP TABLE IF EXISTS purchase_collection;

CREATE TABLE `purchase_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `date_po` date NOT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) NOT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `currentlypaid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchase_details
#

DROP TABLE IF EXISTS purchase_details;

CREATE TABLE `purchase_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO purchase_details (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES ('1', '2022-06-21', '2022-06-21', '2022-06-21', 'P', '5', 'smk', 'Jaganathan Street, Hopes, Punjai Puliampatti, Tamil Nadu', '001', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '123456789', '', 'Aluminium c12A Y body', 'KGS', '35000', '3', '105000.00', '5', 'percent_wise', '5250.00', '99750.00', '14', '13965.00', '14', '13965.00', '28', 'NaN', '127680.00', '127680.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '127680.00', 'P210622', 'P-2022', '1', '89600.00', '1', '1');


#
# TABLE STRUCTURE FOR: purchase_details_backup
#

DROP TABLE IF EXISTS purchase_details_backup;

CREATE TABLE `purchase_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchase_reports
#

DROP TABLE IF EXISTS purchase_reports;

CREATE TABLE `purchase_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO purchase_reports (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES ('4', '1', '2022-06-21', 'P', '2022-06-21', NULL, '0', 'smk', 'Jaganathan Street, Hopes, Punjai Puliampatti, Tamil Nadu', '001', '2022-06-21', NULL, '', '123456789', 'Aluminium c12A Y body', '3', '3', '1', '127680.00', NULL, NULL, NULL, NULL, NULL, '127680.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: purchaseorder_details
#

DROP TABLE IF EXISTS purchaseorder_details;

CREATE TABLE `purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` longtext,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` longtext NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` longtext,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

#
# TABLE STRUCTURE FOR: purchaseorder_details_backup
#

DROP TABLE IF EXISTS purchaseorder_details_backup;

CREATE TABLE `purchaseorder_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchaseorder_reports
#

DROP TABLE IF EXISTS purchaseorder_reports;

CREATE TABLE `purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: quotation_details
#

DROP TABLE IF EXISTS quotation_details;

CREATE TABLE `quotation_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `description` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO quotation_details (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES ('1', '2022-03-12', '2022-03-12', NULL, NULL, 'Q', '1', 'SMk', '442/ CH-20/A1 Ramaswamy circle, CMC SIGNAL, coimbatore, Tamil Nadu', NULL, NULL, NULL, NULL, NULL, NULL, '0123456', 'metal body', NULL, 'KGS', '1500', '1', '1500.00', '0', '0.00', '1500.00', NULL, NULL, NULL, NULL, NULL, NULL, '1500.00', '1500.00', NULL, NULL, '0', NULL, '1500.00', NULL, NULL, '1', '1');


#
# TABLE STRUCTURE FOR: quotation_details_backup
#

DROP TABLE IF EXISTS quotation_details_backup;

CREATE TABLE `quotation_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `description` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sales_return
#

DROP TABLE IF EXISTS sales_return;

CREATE TABLE `sales_return` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext,
  `itemname` longtext,
  `rate` longtext,
  `qty` longtext,
  `uom` longtext,
  `amount` longtext,
  `discount` longtext,
  `taxableamount` longtext,
  `discountamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO sales_return (`id`, `date`, `returndate`, `types`, `time`, `dateofissue`, `customername`, `customerid`, `supplierid`, `gsttype`, `suppliername`, `openingbal`, `outstandingamount`, `returnno`, `description`, `invoiceno`, `purchaseno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `uom`, `amount`, `discount`, `taxableamount`, `discountamount`, `cgst`, `cgstamount`, `sgst`, `sgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `grandtotal`, `status`) VALUES ('2', '2022-01-11', '2022-01-11', 'Debit', '11:04:14 AM', '2022-01-11', 'SMk', '1', '-', 'intrastate', '-', '89600', NULL, 'D1', 'damage', 'INV', '-', NULL, '123456789', 'Aluminium c12A Y body', '35000', '2', 'KGS', '70000.00', '0', '70000.00', '0.00', '14', '9800.00', '14', '9800.00', '28', '', '89600.00', '89600.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '89600.00', '1');


#
# TABLE STRUCTURE FOR: sales_return_backup
#

DROP TABLE IF EXISTS sales_return_backup;

CREATE TABLE `sales_return_backup` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext,
  `itemname` longtext,
  `rate` longtext,
  `qty` longtext,
  `uom` longtext,
  `amount` longtext,
  `discount` longtext,
  `taxableamount` longtext,
  `discountamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: stateCode
#

DROP TABLE IF EXISTS stateCode;

CREATE TABLE `stateCode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) NOT NULL,
  `stateCode` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('1', 'Jammu & Kashmir', '01', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('2', 'Himachal Pradesh', '02', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('3', 'Punjab', '03', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('4', 'Chandigarh', '04', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('5', 'Uttarakhand', '05', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('6', 'Haryana', '06', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('7', 'Delhi', '07', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('8', 'Rajasthan', '08', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('9', 'Uttar Pradesh', '09', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('10', 'Bihar', '10', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('11', 'Sikkim', '11', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('12', 'Arunachal Pradesh', '12', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('13', 'Nagaland', '13', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('14', 'Manipur', '14', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('15', 'Mizoram', '15', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('16', 'Tripura', '16', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('17', 'Meghalaya', '17', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('18', 'Assam', '18', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('19', 'West Bengal', '19', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('20', 'Jharkhand', '20', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('21', 'odisha', '21', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('22', 'Chattisgarh', '22', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('23', 'Madhya Pradesh', '23', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('24', 'Daman & Diu', '25', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('25', 'Gujarat', '24', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('26', 'Dadra & Nagar Haveli', '26', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('27', 'Maharashtra', '27', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('28', 'Andhra Pradesh', '28', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('29', 'Karnataka', '29', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('30', 'Goa', '30', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('31', 'Lakshadweep', '31', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('32', 'Kerala', '32', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('33', 'Tamil Nadu', '33', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('34', 'Puducherry', '34', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('35', 'Andaman & Nicobar Islands', '35', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('36', 'Telengana', '36', '1');
INSERT INTO stateCode (`id`, `state`, `stateCode`, `status`) VALUES ('37', 'Andrapradesh(New)', '37', '1');


#
# TABLE STRUCTURE FOR: stock
#

DROP TABLE IF EXISTS stock;

CREATE TABLE `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `updatestock` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `balance` varchar(255) NOT NULL,
  `oldqty` varchar(255) DEFAULT NULL,
  `currentstock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES ('1', '2022-07-16', '123456789', '0', '14', '14', '28', 'Aluminium c12A Y body', '2', '35000', '2', '', '', '-15', NULL, NULL, '', '2022-06-21', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES ('2', '2022-07-16', '123456789', '<div style=', '14', '14', '28', 'Aluminium c12A Y body', '2', '35000', '3', '', '', '-15', NULL, NULL, '', '2022-06-21', 'Exclusive');
INSERT INTO stock (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES ('3', '2022-07-16', '123456789', '', '14', '14', '28', 'Aluminium c12A Y body', '3', '35000', '3', '', '', '-15', NULL, NULL, '', '2022-06-21', '');


#
# TABLE STRUCTURE FOR: stock_reports
#

DROP TABLE IF EXISTS stock_reports;

CREATE TABLE `stock_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `updatestock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  `balance` varchar(225) DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO stock_reports (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES ('4', '2022-06-21', '123456789', '', 'Aluminium c12A Y body', NULL, '3', '', '2022-06-21', '1', NULL, '');


#
# TABLE STRUCTURE FOR: sup_purchaseorder_details
#

DROP TABLE IF EXISTS sup_purchaseorder_details;

CREATE TABLE `sup_purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sup_purchaseorder_details_backup
#

DROP TABLE IF EXISTS sup_purchaseorder_details_backup;

CREATE TABLE `sup_purchaseorder_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sup_purchaseorder_reports
#

DROP TABLE IF EXISTS sup_purchaseorder_reports;

CREATE TABLE `sup_purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_person
#

DROP TABLE IF EXISTS tbl_person;

CREATE TABLE `tbl_person` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: uom
#

DROP TABLE IF EXISTS uom;

CREATE TABLE `uom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES ('1', '2022-01-11', 'KGS', '1');
INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES ('2', '2022-02-03', 'NOS', '1');
INSERT INTO uom (`id`, `date`, `uom`, `status`) VALUES ('3', '2022-06-22', 'per hr', '1');


#
# TABLE STRUCTURE FOR: user_menu
#

DROP TABLE IF EXISTS user_menu;

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) NOT NULL,
  `main_menu` varchar(255) NOT NULL,
  `sub_menu` varchar(255) NOT NULL,
  `sub_menu_link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: vat_details
#

DROP TABLE IF EXISTS vat_details;

CREATE TABLE `vat_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `sgst` varchar(225) DEFAULT NULL,
  `cgst` varchar(225) DEFAULT NULL,
  `igst` varchar(225) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO vat_details (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES ('2', '2022-02-03', 'GST', '18', 'GST @ 18 %', '9', '9', '18', '1');


#
# TABLE STRUCTURE FOR: vendor_details
#

DROP TABLE IF EXISTS vendor_details;

CREATE TABLE `vendor_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `vendorname` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: voucher
#

DROP TABLE IF EXISTS voucher;

CREATE TABLE `voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `balance_amt` varchar(255) DEFAULT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES ('1', '2022-06-21', 'R1', '2', 'SRI VINAYAKA TRADERS', '2022-02-03', 'payment', '', 'Cash', '', '', '', '', '', '1000', 'Cash', NULL, NULL, '1000', '1000', '1', NULL, NULL, '', '0');
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES ('2', '2022-03-24', 'R2', '3', 'Paramesh Steels and Alloys', '2022-03-24', 'payment', 'PAID', 'Cash', '0', '', '', '0', '', '50000', 'Cash', NULL, NULL, '50000', '50000', '1', NULL, NULL, '', '0');
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES ('3', '2022-03-24', 'R3', '3', 'Paramesh Steels and Alloys', '2022-03-24', 'payment', 'PAID', 'Cash', '0', '', '', '0', '', '80000', 'Cash', NULL, NULL, '80000', '80000', '1', NULL, NULL, '', '0');
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES ('4', '2022-03-24', 'R4', '3', 'Paramesh Steels and Alloys', '2022-03-24', 'payment', 'PAID', 'Cash', '0', '', '', '0', '', '50000', 'Cash', NULL, NULL, '50000', '50000', '1', NULL, NULL, '', '0');
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES ('5', '2022-03-24', 'R5', '3', 'Paramesh Steels and Alloys', '2022-03-24', 'payment', 'PAID', 'Cash', '0', '', '', '0', '', '6170', 'Cash', NULL, NULL, '6170', '6170', '1', NULL, NULL, '', '0');
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES ('6', '2022-03-24', 'R6', '3', 'Paramesh Steels and Alloys', '2022-03-24', 'payment', 'PAID', 'Cash', '', '', '', '', '', '50000', 'Cash', NULL, NULL, '50000', '50000', '1', NULL, NULL, '', '0');
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES ('8', '2022-03-25', 'R7', '4', 'Prakash Castings', '2022-03-25', 'payment', '', 'Cash', '0', '', '', '0', '', '1770', 'Cash', NULL, NULL, '1770', '1770', '1', 'INV20', NULL, '1770', '0');
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES ('9', '2022-03-25', 'R8', '4', 'Prakash Castings', '2022-03-25', 'payment', '', 'Cash', '0', '', '', '0', '', '89600', 'Cash', NULL, NULL, '89600', '89600', '1', 'INV21', NULL, '89600', '0');
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES ('10', '2022-03-25', 'R9', '4', 'Prakash Castings', '2022-03-25', 'payment', '', 'Cash', '0', '', '', '0', '', '44800', 'Cash', NULL, NULL, '44800', '44800', '1', 'INV22', NULL, '44800', '0');
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES ('11', '2022-03-25', 'R10', '4', 'Prakash Castings', '2022-03-25', 'payment', '', 'Cash', '0', '', '', '0', '', '100000', 'Cash', NULL, NULL, '100000', '100000', '1', NULL, NULL, '', '0');
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES ('12', '2022-03-30', 'R11', '1', 'SMk', '2022-03-30', 'payment', '', 'Cash', '0', '', '', '0', '', '1000', 'Cash', NULL, NULL, '1000', '1000', '1', 'INV1', NULL, '100.00', '0');
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES ('13', '2022-03-30', 'R12', '4', 'Prakash Castings', '2022-03-30', 'payment', '', 'Cash', '0', '', '', '0', '', '2000', 'Cash', NULL, NULL, '2000', '2000', '1', NULL, NULL, '', '0');
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES ('14', '2022-03-30', 'R13', '1', 'SMk', '2022-03-30', 'payment', '', 'Cash', '0', '', '', '0', '', '5000', 'Cash', NULL, NULL, '5000', '5000', '1', 'INV2', NULL, '100.00', '0');
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES ('15', '2022-06-15', 'R14', '1', 'SMk', '2022-06-15', 'payment', '', 'Cheque', 'KOTAK MAHINDRA', '1222', '92877', '0', '', '', 'Cheque KOTAK MAHINDRA 1222', NULL, '15-06-2022', '92877', '92877', '1', 'INV3||INV4||INV5', NULL, '1770.00||1500.00||44800.00', '0');
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES ('16', '2022-06-21', 'R15', '1', 'SMk', '2022-06-21', 'payment', 'PAID', 'Cash', '0', '', '', '0', '', '268800', 'Cash', NULL, NULL, '268800', '268800', '1', 'INV6', NULL, '44800.00', '0');
INSERT INTO voucher (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES ('17', '2022-06-21', 'R16', '1', 'SMk', '2022-06-21', 'payment', 'Bill Amount', 'Cash', '0', '', '', '0', '', '89600', 'Cash', NULL, NULL, '89600', '89600', '1', 'INV8', NULL, '44800.00', '0');


#
# TABLE STRUCTURE FOR: voucher_backup
#

DROP TABLE IF EXISTS voucher_backup;

CREATE TABLE `voucher_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

