#
# TABLE STRUCTURE FOR: add_staff
#

DROP TABLE IF EXISTS `add_staff`;

CREATE TABLE `add_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `staff_name` varchar(255) NOT NULL,
  `mobileno` varchar(255) NOT NULL,
  `amobileno` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `referred` varchar(255) NOT NULL,
  `salary` varchar(255) NOT NULL,
  `salarytype` varchar(255) NOT NULL,
  `perdaysalary` varchar(255) NOT NULL,
  `ot` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `add_staff` (`id`, `staff_id`, `date`, `time`, `staff_name`, `mobileno`, `amobileno`, `dob`, `age`, `email`, `address1`, `address2`, `city`, `state`, `pincode`, `referred`, `salary`, `salarytype`, `perdaysalary`, `ot`, `status`) VALUES (1, 'S001', '2023-04-05', '05:53:05', 'vincent', '8608701222', '8608701222', '2023-03-01', '0', '', 'coimbatore', 'PATTANAM POST, ONDIPUDUR (VIA)', 'coimbatore', 'tamilnaduu', '641014', '', '10000', 'Daily', '500', '', '1');
INSERT INTO `add_staff` (`id`, `staff_id`, `date`, `time`, `staff_name`, `mobileno`, `amobileno`, `dob`, `age`, `email`, `address1`, `address2`, `city`, `state`, `pincode`, `referred`, `salary`, `salarytype`, `perdaysalary`, `ot`, `status`) VALUES (2, 'S002', '2023-04-07', '01:07:41', 'Adam', '9597787912', '9597787913', '2024-10-07', '1', 'Mani@gmail.com', 'Nehru street ', 'Pellamedu', 'coimbatore ', 'Tamilnadu', '641004', 'JP', '15000', 'Monthly', '500', '000', '1');
INSERT INTO `add_staff` (`id`, `staff_id`, `date`, `time`, `staff_name`, `mobileno`, `amobileno`, `dob`, `age`, `email`, `address1`, `address2`, `city`, `state`, `pincode`, `referred`, `salary`, `salarytype`, `perdaysalary`, `ot`, `status`) VALUES (3, 'S003', '2023-04-07', '01:11:46', 'joanna', '7485964758', '9685744758', '2024-05-07', '1', 'Jo@gmil.com', '4th cross', 'mettupalayam', 'coimbatore', 'Tamil Nadu', '641014', 'Dhanabal', '20000', 'Weekly', '650', '000', '1');
INSERT INTO `add_staff` (`id`, `staff_id`, `date`, `time`, `staff_name`, `mobileno`, `amobileno`, `dob`, `age`, `email`, `address1`, `address2`, `city`, `state`, `pincode`, `referred`, `salary`, `salarytype`, `perdaysalary`, `ot`, `status`) VALUES (4, 'S004', '2023-04-17', '05:06:52', 'admin', '8978989878', '9517532589', '2003-10-14', '19', 'Admin@gmail.com', 'periyar street', 'peelamedu', 'coimbatore', 'Tamilnadu', '641005', 'JP', '30000', 'Monthly', '1000', '0', '1');
INSERT INTO `add_staff` (`id`, `staff_id`, `date`, `time`, `staff_name`, `mobileno`, `amobileno`, `dob`, `age`, `email`, `address1`, `address2`, `city`, `state`, `pincode`, `referred`, `salary`, `salarytype`, `perdaysalary`, `ot`, `status`) VALUES (5, 'S005', '2023-04-17', '05:10:04', 'dheeraj', '6936996639', '6936996631', '2002-10-17', '20', '', 'KPR street', 'pallikaranai', 'chennai', 'tamilnadu', '600228', 'Dhanabal', '18000', 'Monthly', '600', '0', '1');


#
# TABLE STRUCTURE FOR: additem
#

DROP TABLE IF EXISTS `additem`;

CREATE TABLE `additem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` text CHARACTER SET utf8,
  `price` varchar(255) DEFAULT NULL,
  `taxtype` varchar(225) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `priceType` varchar(10) NOT NULL,
  `itemtype` varchar(255) NOT NULL,
  `purchaseNo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (1, '2023-04-05', '1', '1564', 'AL-01', 'ALUMINIUM CASTING', '10000', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (2, '2023-04-05', '2', '5456', 'PLC-02', 'PLC Panel', '245', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (3, '2023-04-05', '2', '1651', 'CP-03', 'Control Panel', '345', '2', '6', '6', '12', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (4, '2023-04-05', '2', '7654', 'ST-04', 'Stabilizer', '550', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (5, '2023-04-05', '1', '6844', 'DC-05', 'DC Motor', '155', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (6, '2023-04-05', '2', '65464', 'STA-06', 'Stator', '750', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);


#
# TABLE STRUCTURE FOR: attendance
#

DROP TABLE IF EXISTS `attendance`;

CREATE TABLE `attendance` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `attendancedate` date NOT NULL,
  `staff` varchar(255) NOT NULL,
  `attendances` varchar(255) NOT NULL,
  `intime` varchar(255) NOT NULL,
  `outtime` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `lastupdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `attendance` (`id`, `date`, `time`, `attendancedate`, `staff`, `attendances`, `intime`, `outtime`, `status`, `lastupdate`) VALUES (1, '2023-04-05', '17:53:47', '2023-04-05', '1', 'Present', '10:00 AM', '8:00 PM', '1', '2023-04-07 13:13:31');
INSERT INTO `attendance` (`id`, `date`, `time`, `attendancedate`, `staff`, `attendances`, `intime`, `outtime`, `status`, `lastupdate`) VALUES (2, '2023-04-07', '13:13:22', '2023-04-04', '1', 'Present', '10:00 AM', '8:00 PM', '1', '2023-04-07 13:13:22');
INSERT INTO `attendance` (`id`, `date`, `time`, `attendancedate`, `staff`, `attendances`, `intime`, `outtime`, `status`, `lastupdate`) VALUES (3, '2023-04-07', '13:13:22', '2023-04-04', '2', 'Present', '10:00 AM', '8:00 PM', '1', '2023-04-07 13:13:22');
INSERT INTO `attendance` (`id`, `date`, `time`, `attendancedate`, `staff`, `attendances`, `intime`, `outtime`, `status`, `lastupdate`) VALUES (4, '2023-04-07', '13:13:22', '2023-04-04', '3', 'Present', '10:00 AM', '8:00 PM', '1', '2023-04-07 13:13:22');
INSERT INTO `attendance` (`id`, `date`, `time`, `attendancedate`, `staff`, `attendances`, `intime`, `outtime`, `status`, `lastupdate`) VALUES (5, '2023-04-07', '13:13:31', '2023-04-05', '2', 'Present', '10:00 AM', '8:00 PM', '1', '2023-04-07 13:13:31');
INSERT INTO `attendance` (`id`, `date`, `time`, `attendancedate`, `staff`, `attendances`, `intime`, `outtime`, `status`, `lastupdate`) VALUES (6, '2023-04-07', '13:13:31', '2023-04-05', '3', 'Present', '10:00 AM', '8:00 PM', '1', '2023-04-07 13:13:31');
INSERT INTO `attendance` (`id`, `date`, `time`, `attendancedate`, `staff`, `attendances`, `intime`, `outtime`, `status`, `lastupdate`) VALUES (7, '2023-04-17', '18:07:38', '1970-01-01', '1', 'Present', '', '', '1', '2023-04-17 18:07:56');
INSERT INTO `attendance` (`id`, `date`, `time`, `attendancedate`, `staff`, `attendances`, `intime`, `outtime`, `status`, `lastupdate`) VALUES (8, '2023-04-17', '18:07:38', '1970-01-01', '2', 'Holiday', '', '', '1', '2023-04-17 18:07:56');
INSERT INTO `attendance` (`id`, `date`, `time`, `attendancedate`, `staff`, `attendances`, `intime`, `outtime`, `status`, `lastupdate`) VALUES (9, '2023-04-17', '18:07:38', '1970-01-01', '3', 'Half Day', '10:00 AM', '8:00 PM', '1', '2023-04-17 18:07:56');
INSERT INTO `attendance` (`id`, `date`, `time`, `attendancedate`, `staff`, `attendances`, `intime`, `outtime`, `status`, `lastupdate`) VALUES (10, '2023-04-17', '18:07:38', '1970-01-01', '4', 'Leave', '', '', '1', '2023-04-17 18:07:56');
INSERT INTO `attendance` (`id`, `date`, `time`, `attendancedate`, `staff`, `attendances`, `intime`, `outtime`, `status`, `lastupdate`) VALUES (11, '2023-04-17', '18:07:38', '1970-01-01', '5', 'Present', '10:00 AM', '8:00 PM', '1', '2023-04-17 18:07:56');


#
# TABLE STRUCTURE FOR: backup_details
#

DROP TABLE IF EXISTS `backup_details`;

CREATE TABLE `backup_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` longtext,
  `date_created` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (1, 'backup-on-2023-04-05-17-28-58.zip', '2023-04-05');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (2, 'backup-on-2023-04-06-10-21-44.zip', '2023-04-06');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (3, 'backup-on-2023-04-07-10-16-55.zip', '2023-04-07');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (4, 'backup-on-2023-04-08-10-46-10.zip', '2023-04-08');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (5, 'backup-on-2023-04-10-10-50-15.zip', '2023-04-10');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (6, 'backup-on-2023-04-11-10-12-38.zip', '2023-04-11');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (7, 'backup-on-2023-04-13-10-24-07.zip', '2023-04-13');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (8, 'backup-on-2023-04-15-10-22-38.zip', '2023-04-15');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (9, 'backup-on-2023-04-17-11-16-28.zip', '2023-04-17');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (10, 'backup-on-2023-04-18-14-57-31.zip', '2023-04-18');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (11, 'backup-on-2023-04-19-19-39-35.zip', '2023-04-19');


#
# TABLE STRUCTURE FOR: backup_url
#

DROP TABLE IF EXISTS `backup_url`;

CREATE TABLE `backup_url` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: bed_details
#

DROP TABLE IF EXISTS `bed_details`;

CREATE TABLE `bed_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `bed` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: card
#

DROP TABLE IF EXISTS `card`;

CREATE TABLE `card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cash_bill
#

DROP TABLE IF EXISTS `cash_bill`;

CREATE TABLE `cash_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cashbill_details
#

DROP TABLE IF EXISTS `cashbill_details`;

CREATE TABLE `cashbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `cust_mobno` varchar(255) NOT NULL,
  `address` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `systemDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cashbill_reports
#

DROP TABLE IF EXISTS `cashbill_reports`;

CREATE TABLE `cashbill_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `systemDate` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `category` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: collection_details
#

DROP TABLE IF EXISTS `collection_details`;

CREATE TABLE `collection_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `collection_details` (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2023-04-06', NULL, '2023-04-06', NULL, 'V/22-23/-001', 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '35000', NULL, NULL, NULL);
INSERT INTO `collection_details` (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '2023-04-17', NULL, '2023-04-17', NULL, 'V/22-23/-003', 'Annu Industries (P) Ltd', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '36460.3', NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: company_logo
#

DROP TABLE IF EXISTS `company_logo`;

CREATE TABLE `company_logo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `company_logo` (`id`, `date`, `image`, `status`) VALUES (1, '2022-08-17', '12832299_1579401915712151_5416626780361493206_n.png', '1');


#
# TABLE STRUCTURE FOR: customer_details
#

DROP TABLE IF EXISTS `customer_details`;

CREATE TABLE `customer_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `contactperson` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `old_openingBal` varchar(255) DEFAULT NULL,
  `salesamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  `accountpay` varchar(255) NOT NULL,
  `chequeno` varchar(100) NOT NULL,
  `last_modified` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (1, '2023-04-06', 'Intra customer', 'Tex-Tech Industries (India) Private Limited', '9597787912', 'idreamdigitalmarketing@gmail.com', 'V. N. Industrial Estate, 27-D', ' Bharathi Colony Rd, Peelamedu,', 'Ela', 'Tamil Nadu', 'coimbatore', '', '', NULL, '1550', NULL, '251440.3', '35000', '222415.3', NULL, '', NULL, '641004', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33AACCT1951A1ZY', '', '', '', '', '', '2023-04-06');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (2, '2023-04-06', 'Intra supplier', 'SRI CHENDUR PUMP INDUSTRIES', '9896854796', 'Ela@gmail.com', '29, Nava India Rd, near Yamaha Service Centre,', 'KR Puram, Post,', 'JP', 'Tamil Nadu', 'coimbatore', '', '', NULL, '1050', NULL, '883301.5', '200000', '684351.5', NULL, '', NULL, '641006', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '27AAACV2809D1ZM', '', '', '', '', '', '2023-04-06');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (3, '2023-04-06', 'Inter customer', 'Annu Industries (P) Ltd', '9874563210', '', ' Ground Floor, C-582, Saraswati Vihar Rd, ', ' Block C, Saraswati Vihar, Pitam Pura', 'Dhanabal', 'Delhi', 'New Delhi', '', '', NULL, '1150', NULL, '475819', '36460.3', '569718.7', NULL, '', NULL, '110034', NULL, NULL, NULL, NULL, NULL, '1', '', '', '07', '06AAECA8479N1Z0', '', '', '', '', '', '2023-04-06');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (4, '2023-04-06', 'Inter supplier', 'Hydrotech Engineering Works', '7889787978', 'jith@gmail.com', 'DSIDC Complex', 'B-13, Sultanpuri, ', 'Ajith', 'Delhi', 'New Delhi', '', '', NULL, '2550', NULL, '45208', NULL, '47758', NULL, '', NULL, ' 110086', NULL, NULL, NULL, NULL, NULL, '1', '', '', '07', '07BFZPA7885L1ZF', '', '', '', '', '', '2023-04-06');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (5, '2023-04-19', 'Subcontract', 'IDREAM DEVELOPERS', '', '', '3/226D, NADUPALAYAM ROAD', 'PATTANAM POST,ONDIPUDUR (VIA)', '', 'Tamil Nadu', 'COIMBATORE', '', '', NULL, '0.00', NULL, NULL, NULL, '0.00', NULL, '', NULL, '641016', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2023-04-19');


#
# TABLE STRUCTURE FOR: customerpo_details
#

DROP TABLE IF EXISTS `customerpo_details`;

CREATE TABLE `customerpo_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `cuspodate` date DEFAULT NULL,
  `invoicetype` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `cuspono` varchar(255) DEFAULT NULL,
  `transport` varchar(255) DEFAULT NULL,
  `customerpodate` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `cstname` varchar(255) DEFAULT NULL,
  `cstamount` varchar(255) DEFAULT NULL,
  `pf` varchar(255) DEFAULT NULL,
  `freight` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `pfadjus` varchar(255) DEFAULT NULL,
  `freightadjus` varchar(255) DEFAULT NULL,
  `roundoff` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: dc_delivery
#

DROP TABLE IF EXISTS `dc_delivery`;

CREATE TABLE `dc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (1, '2023-04-06', 1, 7, 'Against Inward', 'SDC/23-24/-001', '2023-04-06', 1, 'Tex-Tech Industries (India) Private Limited', 'tN23cl6787', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,', 'I', '161651', '2023-04-06', 'ALUMINIUM CASTING', '1', '', '5', '0', '', '1564', NULL, 'KGS', 'SDC/23-24/-001-23', 'SDC/23-24/-001060423', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (2, '2023-04-06', 1, 8, 'Against Inward', 'SDC/23-24/-001', '2023-04-06', 1, 'Tex-Tech Industries (India) Private Limited', 'tN23cl6787', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,', 'I', '161651', '2023-04-06', 'Stabilizer', '4', '', '5', '0', '', '7654', NULL, 'NOS', 'SDC/23-24/-001-23', 'SDC/23-24/-001060423', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (3, '2023-04-06', 1, 9, 'Against Inward', 'SDC/23-24/-001', '2023-04-06', 1, 'Tex-Tech Industries (India) Private Limited', 'tN23cl6787', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,', 'I', '161651', '2023-04-06', 'Stator', '6', '', '5', '0', '', '65464', NULL, 'NOS', 'SDC/23-24/-001-23', 'SDC/23-24/-001060423', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (4, '2023-04-06', 1, 10, 'Against Inward', 'SDC/23-24/-001', '2023-04-06', 1, 'Tex-Tech Industries (India) Private Limited', 'tN23cl6787', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,', 'I', '161651', '2023-04-06', 'PLC Panel', '2', '', '5', '0', '', '5456', NULL, 'NOS', 'SDC/23-24/-001-23', 'SDC/23-24/-001060423', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (5, '2023-04-06', 1, 11, 'Against Inward', 'SDC/23-24/-001', '2023-04-06', 1, 'Tex-Tech Industries (India) Private Limited', 'tN23cl6787', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,', 'I', '161651', '2023-04-06', 'Control Panel', '3', '', '5', '0', '', '1651', NULL, 'NOS', 'SDC/23-24/-001-23', 'SDC/23-24/-001060423', 0, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (6, '2023-04-06', 1, 12, 'Against Inward', 'SDC/23-24/-001', '2023-04-06', 1, 'Tex-Tech Industries (India) Private Limited', 'tN23cl6787', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,', 'I', '161651', '2023-04-06', 'DC Motor', '5', '', '5', '0', '', '6844', NULL, 'KGS', 'SDC/23-24/-001-23', 'SDC/23-24/-001060423', 0, 1);


#
# TABLE STRUCTURE FOR: dcbill_details
#

DROP TABLE IF EXISTS `dcbill_details`;

CREATE TABLE `dcbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `itemid` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (1, '2023-04-06', 'Against Inward', 'SDC/23-24/-001', '2023-04-06', 1, 'Tex-Tech Industries (India) Private Limited', 'tN23cl6787', '07:14:PM', 'Business', '1 month', '', NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,', 'I', '161651||161651||161651||161651||161651||161651', '2023-04-06||2023-04-06||2023-04-06||2023-04-06||2023-04-06||2023-04-06', 'ALUMINIUM CASTING||Stabilizer||Stator||PLC Panel||Control Panel||DC Motor', '1||4||6||2||3||5', '||||||||||', '5||5||5||5||5||5', '||||||||||', '1564||7654||65464||5456||1651||6844', NULL, 'KGS||NOS||NOS||NOS||NOS||KGS', 'SDC/23-24/-001-23', 'SDC/23-24/-001060423', 1, 1, '');


#
# TABLE STRUCTURE FOR: dcbill_details_backup
#

DROP TABLE IF EXISTS `dcbill_details_backup`;

CREATE TABLE `dcbill_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `itemid` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS `expenses`;

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: expenses_backup
#

DROP TABLE IF EXISTS `expenses_backup`;

CREATE TABLE `expenses_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: headers
#

DROP TABLE IF EXISTS `headers`;

CREATE TABLE `headers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `headers` (`id`, `date`, `status`, `name`) VALUES (1, '2023-04-05', 1, 'Vincent');
INSERT INTO `headers` (`id`, `date`, `status`, `name`) VALUES (2, '2023-04-17', 1, 'Dhanabal');


#
# TABLE STRUCTURE FOR: hsnmaster
#

DROP TABLE IF EXISTS `hsnmaster`;

CREATE TABLE `hsnmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `party` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: invoice_details
#

DROP TABLE IF EXISTS `invoice_details`;

CREATE TABLE `invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `pono` varchar(255) DEFAULT NULL,
  `pino` varchar(255) DEFAULT NULL,
  `purchaseordernos` varchar(255) DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerdcnos'` varchar(100) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `removalDate` date NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToId` varchar(255) DEFAULT NULL,
  `shipToAddress` longtext,
  `deliveryAddress1` longtext,
  `deliveryAddress2` longtext,
  `mobileNo` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemcode` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `totalqty` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES (1, '2023-04-06', '2023-04-06', '16111', '2023-04-06', 'INV/23-24/-001', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 3, 'Annu Industries (P) Ltd', ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', NULL, NULL, 'TN35CL9890', '2023-04-06', '06:45 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '1564||65464||7654||5456||1651', NULL, 'ALUMINIUM CASTING||Stator||Stabilizer||PLC Panel||Control Panel', '||||||||', 'KGS||NOS||NOS||NOS||NOS', '10000||750||550||245||345', '05||05||05||05||05', '50000.00||3750.00||2750.00||1225.00||1725.00', '0||0||0||0||0', 'percent_wise', '0.00||0.00||0.00||0.00||0.00', '50000.00||3750.00||2750.00||1225.00||1725.00', '9||9||9||9||6', '4500.00||337.50||247.50||110.25||103.50', '9||9||9||9||6', '4500.00||337.50||247.50||110.25||103.50', '18||18||18||18||12', '9000.00||675.00||495.00||220.50||207.00', '59000.00||4425.00||3245.00||1445.50||1932.00', '70047.50', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', NULL, '1||1||1||1||1', '70047.50', '70047.50', 1, 'INV/23-24/-001060423', 'INV/23-24/-001-2023', 1, 1, NULL);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES (2, '2023-04-06', '2023-04-06', '1651', '2023-04-06', 'INV/23-24/-002', 'SDC/23-24/-001', NULL, NULL, NULL, 'Tax Invoice', 'Against DC', '', 1, 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', NULL, NULL, 'TN35CL9890', '2023-04-06', '07:15 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', 'SDC/23-24/-001||SDC/23-24/-001||SDC/23-24/-001||SDC/23-24/-001||SDC/23-24/-001||SDC/23-24/-001', '1', '1||2||3||4||5||6', '1564||7654||65464||5456||1651||6844', '||||||||||', 'ALUMINIUM CASTING||Stabilizer||Stator||PLC Panel||Control Panel||DC Motor', '||||||||||', 'KGS||NOS||NOS||NOS||NOS||KGS', '10000||550||750||245||345||155', '05||05||05||05||05||05', '50000.00||2750.00||3750.00||1225.00||1725.00||775.00', '0||0||0||0||0||0', 'percent_wise', '||||||||||', '50000.00||2750.00||3750.00||1225.00||1725.00||775.00', NULL, NULL, NULL, NULL, NULL, NULL, '50000.00||2750.00||3750.00||1225.00||1725.00||775.00', '60225.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1||1||1||1||1', '71065.50', '71065.50', 1, 'INV/23-24/-002060423', 'INV/23-24/-002-2023', 1, 1, NULL);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES (3, '2023-04-07', '2023-04-07', '757523', '2023-04-07', 'INV/23-24/-003', NULL, 'P1', NULL, 'P1||P1||P1', 'Tax Invoice', 'Against PO', '', 3, 'Annu Industries (P) Ltd', ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', NULL, NULL, 'TN35CL9890', '2023-04-07', '05:12 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, '3||4||5', '65464||7654||1564', 'STA-06||ST-04||AL-01', 'Stator||Stabilizer||ALUMINIUM CASTING', '||||', 'NOS||NOS||KGS', '750||550||10000', '03||03||03', '2250.00||1650.00||30000.00', '0||0||0', 'percent_wise', NULL, '2250.00||1650.00||30000.00', '9', '', '9', '', '18', '6102.00', NULL, '33900.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1||1', '40002.00', '40002.00', 1, 'INV/23-24/-003070423', 'INV/23-24/-003-2023', 1, 1, NULL);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES (4, '2023-04-08', '2023-04-08', '1691', '2023-04-08', 'INV/23-24/-004', NULL, 'P2', NULL, 'P2||P2||P2||P2||P2||P2', 'Tax Invoice', 'Against PO', '', 1, 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', NULL, NULL, 'TN35CL9890', '2023-04-08', '03:45 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, '6||7||8||9||10||11', '1651||5456||7654||65464||6844||1564', 'CP-03||PLC-02||ST-04||STA-06||DC-05||AL-01', 'Control Panel||PLC Panel||Stabilizer||Stator||DC Motor||ALUMINIUM CASTING', '||||||||||', 'NOS||NOS||NOS||NOS||KGS||KGS', '345||245||550||750||155||10000', '03||03||03||03||03||03', '1035.00||735.00||1650.00||2250.00||465.00||30000.00', '0||0||0||0||0||0', 'percent_wise', NULL, '1035.00||735.00||1650.00||2250.00||465.00||30000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '36135.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1||1||1||1||1', '42639.30', '42639.30', 1, 'INV/23-24/-004080423', 'INV/23-24/-004-2023', 1, 1, NULL);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES (5, '2023-04-17', '2023-04-17', '', '1969-12-31', 'INV/23-24/-005', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', NULL, NULL, '', '2023-04-17', '11:21 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, '0', NULL, '65464', NULL, 'Stator', '', 'NOS', '750', '5', '3750.00', '0', 'percent_wise', '0.00', '3750.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3750.00', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', NULL, '1', '4425.00', '4425.00', 1, 'INV/23-24/-005170423', 'INV/23-24/-005-2023', 1, 1, '5.00');
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES (6, '2023-04-17', '2023-04-17', '6511', '2023-04-17', 'INV/23-24/-006', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', NULL, NULL, 'TN35CL9890', '2023-04-17', '03:03 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '5456||65464||7654||1651||6844||1564', NULL, 'PLC Panel||Stator||Stabilizer||Control Panel||DC Motor||ALUMINIUM CASTING', '||||||||||', 'NOS||NOS||NOS||NOS||KGS||KGS', '245||750||550||345||155||10000', '05||05||05||05||05||05', '1225.00||3750.00||2750.00||1725.00||775.00||50000.00', '0||0||0||0||0||0', 'percent_wise', '0.00||0.00||0.00||0.00||0.00||0.00', '1225.00||3750.00||2750.00||1725.00||775.00||50000.00', '9', '5420.25', '9', '5420.25', '18', '', NULL, '60225.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1||1||1||1||1', '71065.50', '71065.50', 1, 'INV/23-24/-006170423', 'INV/23-24/-006-2023', 1, 1, '30.00');
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES (7, '2023-04-17', '2023-04-17', '76453', '2023-04-17', 'INV/23-24/-007', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 3, 'Annu Industries (P) Ltd', ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', NULL, NULL, 'TN35CL9890', '2023-04-17', '03:09 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '1651||65464||7654||6844||1564||5456', NULL, 'Control Panel||Stator||Stabilizer||DC Motor||ALUMINIUM CASTING||PLC Panel', '||||||||||', 'NOS||NOS||NOS||KGS||KGS||NOS', '345||750||550||155||10000||245', '5||5||5||5||5||5', '1725.00||3750.00||2750.00||775.00||50000.00||1225.00', '0||0||0||0||0||0', 'percent_wise', '0.00||0.00||0.00||0.00||0.00||0.00', '1725.00||3750.00||2750.00||775.00||50000.00||1225.00', '9', '', '9', '', '18', '10840.50', NULL, '60225.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1||1||1||1||1', '71065.50', '71065.50', 1, 'INV/23-24/-007170423', 'INV/23-24/-007-2023', 1, 1, '30.00');
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`) VALUES (8, '2023-04-17', '2023-04-17', '2164', '2023-04-17', 'INV/23-24/-008', NULL, 'P3', NULL, 'P3||P3||P3||P3||P3||P3', 'Tax Invoice', 'Against PO', '', 3, 'Annu Industries (P) Ltd', ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', NULL, NULL, 'TN35CL9890', '2023-04-17', '04:53 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, '12||13||14||15||16||17', '1564||7654||5456||1651||6844||65464', 'AL-01||ST-04||PLC-02||CP-03||DC-05||STA-06', 'ALUMINIUM CASTING||Stabilizer||PLC Panel||Control Panel||DC Motor||Stator', '||||||||||', 'KGS||NOS||NOS||NOS||KGS||NOS', '10000||550||245||345||155||750', '10||10||10||10||10||10', '100000.00||5500.00||2450.00||3450.00||1550.00||7500.00', '0||0||0||0||0||0', 'percent_wise', NULL, '100000.00||5500.00||2450.00||3450.00||1550.00||7500.00', '9', '', '9', '', '18', '21681.00', NULL, '120450.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1||1||1||1||1', '142131.00', '142131.00', 1, 'INV/23-24/-008170423', 'INV/23-24/-008-2023', 1, 1, NULL);


#
# TABLE STRUCTURE FOR: invoice_details_backup
#

DROP TABLE IF EXISTS `invoice_details_backup`;

CREATE TABLE `invoice_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `customerdcnos` varchar(100) DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `pino` varchar(100) NOT NULL,
  `purchaseordernos` varchar(255) DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `removalDate` date NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToId` varchar(255) DEFAULT NULL,
  `shipToAddress` longtext,
  `deliveryAddress1` longtext,
  `deliveryAddress2` longtext,
  `mobileNo` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `totalqty` varchar(255) NOT NULL,
  `poNumber` varchar(100) NOT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: invoice_party_statement
#

DROP TABLE IF EXISTS `invoice_party_statement`;

CREATE TABLE `invoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '-', '-', NULL, '2023-04-06', 'INV/23-24/-001', 3, 'Annu Industries (P) Ltd', '', '', '', 'ALUMINIUM CASTING||Stator||Stabilizer||PLC Panel||Control Panel', '||||||||', '', '', NULL, NULL, '', '', '1', '2023-04-06', '2023-04-06', '70047.50', '-', '-', '', '', '-', '-', NULL, '71197.5', '-', '-', '-', '-', '70047.50', '-', '70047.50', NULL, NULL, 'INV/23-24/-001-2023', 'INV/23-24/-001060423', '1');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '-', '-', NULL, '2023-04-06', 'INV/23-24/-002', 1, 'Tex-Tech Industries (India) Private Limited', '', '', '', 'ALUMINIUM CASTING||Stabilizer||Stator||PLC Panel||Control Panel||DC Motor', '||||||||||', '', '', NULL, NULL, '', '', '1', '2023-04-06', '2023-04-06', '71065.50', '-', '-', '', '', '-', '-', NULL, '72615.5', '-', '-', '-', '-', '71065.50', '-', '71065.50', NULL, NULL, 'INV/23-24/-002-2023', 'INV/23-24/-002060423', '2');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (3, 'V/22-23/-001', '', NULL, '2023-04-06', '-', 0, 'Tex-Tech Industries (India) Private Limited', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2023-04-06', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '37615.5', NULL, NULL, NULL, 'Cash', NULL, '35000', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (4, '-', '-', NULL, '2023-04-07', 'INV/23-24/-003', 3, 'Annu Industries (P) Ltd', '', '', '', 'Stator||Stabilizer||ALUMINIUM CASTING', '||||', '', '', NULL, NULL, '', '', '1', '2023-04-07', '2023-04-07', '40002.00', '-', '-', '', '', '-', '-', NULL, '111199.5', '-', '-', '-', '-', '40002.00', '-', '40002.00', NULL, NULL, 'INV/23-24/-003-2023', 'INV/23-24/-003070423', '3');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (5, '-', '-', NULL, '2023-04-08', 'INV/23-24/-004', 1, 'Tex-Tech Industries (India) Private Limited', '', '', '', 'Control Panel||PLC Panel||Stabilizer||Stator||DC Motor||ALUMINIUM CASTING', '||||||||||', '', '', NULL, NULL, '', '', '1', '2023-04-08', '2023-04-08', '42639.30', '-', '-', '', '', '-', '-', NULL, '80254.8', '-', '-', '-', '-', '42639.30', '-', '42639.30', NULL, NULL, 'INV/23-24/-004-2023', 'INV/23-24/-004080423', '4');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (7, '-', '-', NULL, '2023-04-17', 'INV/23-24/-005', 1, 'Tex-Tech Industries (India) Private Limited', '', '', '', 'Stator', '', '', '', NULL, NULL, '', '', '1', '2023-04-17', '2023-04-17', '4425.00', '-', '-', '', '', '-', '-', NULL, '84679.8', '-', '-', '-', '-', '4425.00', '-', '4425.00', NULL, NULL, NULL, NULL, '5');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (8, '-', '-', NULL, '2023-04-17', 'INV/23-24/-006', 1, 'Tex-Tech Industries (India) Private Limited', '', '', '', 'PLC Panel||Stator||Stabilizer||Control Panel||DC Motor||ALUMINIUM CASTING', '||||||||||', '', '', NULL, NULL, '', '', '1', '2023-04-17', '2023-04-17', '71065.50', '-', '-', '', '', '-', '-', NULL, '155745.3', '-', '-', '-', '-', '71065.50', '-', '71065.50', NULL, NULL, 'INV/23-24/-006-2023', 'INV/23-24/-006170423', '6');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (9, '-', '-', NULL, '2023-04-17', 'INV/23-24/-007', 3, 'Annu Industries (P) Ltd', '', '', '', 'Control Panel||Stator||Stabilizer||DC Motor||ALUMINIUM CASTING||PLC Panel', '||||||||||', '', '', NULL, NULL, '', '', '1', '2023-04-17', '2023-04-17', '71065.50', '-', '-', '', '', '-', '-', NULL, '182265', '-', '-', '-', '-', '71065.50', '-', '71065.50', NULL, NULL, 'INV/23-24/-007-2023', 'INV/23-24/-007170423', '7');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (10, 'V/22-23/-003', '', NULL, '2023-04-17', '-', 0, 'Annu Industries (P) Ltd', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2023-04-17', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '145804.7', NULL, NULL, NULL, 'Cash', NULL, '36460.3', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (11, '-', '-', NULL, '2023-04-17', 'INV/23-24/-008', 3, 'Annu Industries (P) Ltd', '', '', '', 'ALUMINIUM CASTING||Stabilizer||PLC Panel||Control Panel||DC Motor||Stator', '||||||||||', '', '', NULL, NULL, '', '', '1', '2023-04-17', '2023-04-17', '142131.00', '-', '-', '', '', '-', '-', NULL, '569718.7', '-', '-', '-', '-', '142131.00', '-', '142131.00', NULL, NULL, 'INV/23-24/-008-2023', 'INV/23-24/-008170423', '8');


#
# TABLE STRUCTURE FOR: invoice_party_statement_backup
#

DROP TABLE IF EXISTS `invoice_party_statement_backup`;

CREATE TABLE `invoice_party_statement_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: invoice_reports
#

DROP TABLE IF EXISTS `invoice_reports`;

CREATE TABLE `invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2023-04-06', 'INV/23-24/-001', '2023-04-06', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-06', '16111', NULL, '1564', NULL, NULL, 'ALUMINIUM CASTING', '', '1', '05', '5', NULL, '70047.50', NULL, NULL, '70047.50', NULL, NULL, '1', 'INV/23-24/-001-2023', 'INV/23-24/-001060423', '1');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '2023-04-06', 'INV/23-24/-001', '2023-04-06', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-06', '16111', NULL, '65464', NULL, NULL, 'Stator', '', '0', '05', '9', NULL, '70047.50', NULL, NULL, '70047.50', NULL, NULL, '1', 'INV/23-24/-001-2023', 'INV/23-24/-001060423', '1');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (3, '2023-04-06', 'INV/23-24/-001', '2023-04-06', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-06', '16111', NULL, '7654', NULL, NULL, 'Stabilizer', '', '0', '05', '0', NULL, '70047.50', NULL, NULL, '70047.50', NULL, NULL, '1', 'INV/23-24/-001-2023', 'INV/23-24/-001060423', '1');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (4, '2023-04-06', 'INV/23-24/-001', '2023-04-06', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-06', '16111', NULL, '5456', NULL, NULL, 'PLC Panel', '', '0', '05', '0', NULL, '70047.50', NULL, NULL, '70047.50', NULL, NULL, '1', 'INV/23-24/-001-2023', 'INV/23-24/-001060423', '1');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (5, '2023-04-06', 'INV/23-24/-001', '2023-04-06', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-06', '16111', NULL, '1651', NULL, NULL, 'Control Panel', '', '0', '05', '0', NULL, '70047.50', NULL, NULL, '70047.50', NULL, NULL, '1', 'INV/23-24/-001-2023', 'INV/23-24/-001060423', '1');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (6, '2023-04-06', 'INV/23-24/-002', '2023-04-06', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN35CL9890', NULL, '2023-04-06', '1651', NULL, '1564', '', NULL, 'ALUMINIUM CASTING', '', '1', '05', '5', NULL, '60225.00', NULL, NULL, '71065.50', NULL, NULL, '1', 'INV/23-24/-002-2023', 'INV/23-24/-002060423', '2');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (7, '2023-04-06', 'INV/23-24/-002', '2023-04-06', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN35CL9890', NULL, '2023-04-06', '1651', NULL, '7654', '', NULL, 'Stabilizer', '', '0', '05', '0', NULL, '60225.00', NULL, NULL, '71065.50', NULL, NULL, '1', 'INV/23-24/-002-2023', 'INV/23-24/-002060423', '2');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (8, '2023-04-06', 'INV/23-24/-002', '2023-04-06', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN35CL9890', NULL, '2023-04-06', '1651', NULL, '65464', '', NULL, 'Stator', '', '0', '05', '0', NULL, '60225.00', NULL, NULL, '71065.50', NULL, NULL, '1', 'INV/23-24/-002-2023', 'INV/23-24/-002060423', '2');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (9, '2023-04-06', 'INV/23-24/-002', '2023-04-06', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN35CL9890', NULL, '2023-04-06', '1651', NULL, '5456', '', NULL, 'PLC Panel', '', '0', '05', '0', NULL, '60225.00', NULL, NULL, '71065.50', NULL, NULL, '1', 'INV/23-24/-002-2023', 'INV/23-24/-002060423', '2');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (10, '2023-04-06', 'INV/23-24/-002', '2023-04-06', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN35CL9890', NULL, '2023-04-06', '1651', NULL, '1651', '', NULL, 'Control Panel', '', '0', '05', '0', NULL, '60225.00', NULL, NULL, '71065.50', NULL, NULL, '1', 'INV/23-24/-002-2023', 'INV/23-24/-002060423', '2');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (11, '2023-04-06', 'INV/23-24/-002', '2023-04-06', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN35CL9890', NULL, '2023-04-06', '1651', NULL, '6844', '', NULL, 'DC Motor', '', '|', '05', '.', NULL, '60225.00', NULL, NULL, '71065.50', NULL, NULL, '1', 'INV/23-24/-002-2023', 'INV/23-24/-002060423', '2');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (12, '2023-04-07', 'INV/23-24/-003', '2023-04-07', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-07', '757523', NULL, '65464', 'STA-06', NULL, 'Stator', '', '7', '03', NULL, NULL, '33900.00', NULL, NULL, '40002.00', NULL, NULL, '1', 'INV/23-24/-003-2023', 'INV/23-24/-003070423', '3');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (13, '2023-04-07', 'INV/23-24/-003', '2023-04-07', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-07', '757523', NULL, '7654', 'ST-04', NULL, 'Stabilizer', '', '5', '03', NULL, NULL, '33900.00', NULL, NULL, '40002.00', NULL, NULL, '1', 'INV/23-24/-003-2023', 'INV/23-24/-003070423', '3');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (14, '2023-04-07', 'INV/23-24/-003', '2023-04-07', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-07', '757523', NULL, '1564', 'AL-01', NULL, 'ALUMINIUM CASTING', '', '0', '03', NULL, NULL, '33900.00', NULL, NULL, '40002.00', NULL, NULL, '1', 'INV/23-24/-003-2023', 'INV/23-24/-003070423', '3');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (15, '2023-04-08', 'INV/23-24/-004', '2023-04-08', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN35CL9890', NULL, '2023-04-08', '1691', NULL, '1651', 'CP-03', NULL, 'Control Panel', '', '3', '03', NULL, NULL, '36135.00', NULL, NULL, '42639.30', NULL, NULL, '1', 'INV/23-24/-004-2023', 'INV/23-24/-004080423', '4');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (16, '2023-04-08', 'INV/23-24/-004', '2023-04-08', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN35CL9890', NULL, '2023-04-08', '1691', NULL, '5456', 'PLC-02', NULL, 'PLC Panel', '', '4', '03', NULL, NULL, '36135.00', NULL, NULL, '42639.30', NULL, NULL, '1', 'INV/23-24/-004-2023', 'INV/23-24/-004080423', '4');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (17, '2023-04-08', 'INV/23-24/-004', '2023-04-08', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN35CL9890', NULL, '2023-04-08', '1691', NULL, '7654', 'ST-04', NULL, 'Stabilizer', '', '5', '03', NULL, NULL, '36135.00', NULL, NULL, '42639.30', NULL, NULL, '1', 'INV/23-24/-004-2023', 'INV/23-24/-004080423', '4');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (18, '2023-04-08', 'INV/23-24/-004', '2023-04-08', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN35CL9890', NULL, '2023-04-08', '1691', NULL, '65464', 'STA-06', NULL, 'Stator', '', '|', '03', NULL, NULL, '36135.00', NULL, NULL, '42639.30', NULL, NULL, '1', 'INV/23-24/-004-2023', 'INV/23-24/-004080423', '4');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (19, '2023-04-08', 'INV/23-24/-004', '2023-04-08', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN35CL9890', NULL, '2023-04-08', '1691', NULL, '6844', 'DC-05', NULL, 'DC Motor', '', '|', '03', NULL, NULL, '36135.00', NULL, NULL, '42639.30', NULL, NULL, '1', 'INV/23-24/-004-2023', 'INV/23-24/-004080423', '4');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (20, '2023-04-08', 'INV/23-24/-004', '2023-04-08', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN35CL9890', NULL, '2023-04-08', '1691', NULL, '1564', 'AL-01', NULL, 'ALUMINIUM CASTING', '', '2', '03', NULL, NULL, '36135.00', NULL, NULL, '42639.30', NULL, NULL, '1', 'INV/23-24/-004-2023', 'INV/23-24/-004080423', '4');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (22, '2023-04-17', 'INV/23-24/-005', '2023-04-17', NULL, NULL, 0, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1969-12-31', '', NULL, '65464', NULL, NULL, 'Stator', '', '750', '5', NULL, NULL, '3750.00', NULL, NULL, '4425.00', NULL, NULL, '1', NULL, NULL, '5');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (23, '2023-04-17', 'INV/23-24/-006', '2023-04-17', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN35CL9890', NULL, '2023-04-17', '6511', NULL, '5456', NULL, NULL, 'PLC Panel', '', '2', '05', NULL, NULL, '60225.00', NULL, NULL, '71065.50', NULL, NULL, '1', 'INV/23-24/-006-2023', 'INV/23-24/-006170423', '6');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (24, '2023-04-17', 'INV/23-24/-006', '2023-04-17', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN35CL9890', NULL, '2023-04-17', '6511', NULL, '65464', NULL, NULL, 'Stator', '', '4', '05', NULL, NULL, '60225.00', NULL, NULL, '71065.50', NULL, NULL, '1', 'INV/23-24/-006-2023', 'INV/23-24/-006170423', '6');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (25, '2023-04-17', 'INV/23-24/-006', '2023-04-17', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN35CL9890', NULL, '2023-04-17', '6511', NULL, '7654', NULL, NULL, 'Stabilizer', '', '5', '05', NULL, NULL, '60225.00', NULL, NULL, '71065.50', NULL, NULL, '1', 'INV/23-24/-006-2023', 'INV/23-24/-006170423', '6');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (26, '2023-04-17', 'INV/23-24/-006', '2023-04-17', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN35CL9890', NULL, '2023-04-17', '6511', NULL, '1651', NULL, NULL, 'Control Panel', '', '|', '05', NULL, NULL, '60225.00', NULL, NULL, '71065.50', NULL, NULL, '1', 'INV/23-24/-006-2023', 'INV/23-24/-006170423', '6');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (27, '2023-04-17', 'INV/23-24/-006', '2023-04-17', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN35CL9890', NULL, '2023-04-17', '6511', NULL, '6844', NULL, NULL, 'DC Motor', '', '|', '05', NULL, NULL, '60225.00', NULL, NULL, '71065.50', NULL, NULL, '1', 'INV/23-24/-006-2023', 'INV/23-24/-006170423', '6');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (28, '2023-04-17', 'INV/23-24/-006', '2023-04-17', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, 'TN35CL9890', NULL, '2023-04-17', '6511', NULL, '1564', NULL, NULL, 'ALUMINIUM CASTING', '', '7', '05', NULL, NULL, '60225.00', NULL, NULL, '71065.50', NULL, NULL, '1', 'INV/23-24/-006-2023', 'INV/23-24/-006170423', '6');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (29, '2023-04-17', 'INV/23-24/-007', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-17', '76453', NULL, '1651', NULL, NULL, 'Control Panel', '', '3', '5', NULL, NULL, '60225.00', NULL, NULL, '71065.50', NULL, NULL, '1', 'INV/23-24/-007-2023', 'INV/23-24/-007170423', '7');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (30, '2023-04-17', 'INV/23-24/-007', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-17', '76453', NULL, '65464', NULL, NULL, 'Stator', '', '4', '5', NULL, NULL, '60225.00', NULL, NULL, '71065.50', NULL, NULL, '1', 'INV/23-24/-007-2023', 'INV/23-24/-007170423', '7');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (31, '2023-04-17', 'INV/23-24/-007', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-17', '76453', NULL, '7654', NULL, NULL, 'Stabilizer', '', '5', '5', NULL, NULL, '60225.00', NULL, NULL, '71065.50', NULL, NULL, '1', 'INV/23-24/-007-2023', 'INV/23-24/-007170423', '7');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (32, '2023-04-17', 'INV/23-24/-007', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-17', '76453', NULL, '6844', NULL, NULL, 'DC Motor', '', '|', '5', NULL, NULL, '60225.00', NULL, NULL, '71065.50', NULL, NULL, '1', 'INV/23-24/-007-2023', 'INV/23-24/-007170423', '7');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (33, '2023-04-17', 'INV/23-24/-007', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-17', '76453', NULL, '1564', NULL, NULL, 'ALUMINIUM CASTING', '', '|', '5', NULL, NULL, '60225.00', NULL, NULL, '71065.50', NULL, NULL, '1', 'INV/23-24/-007-2023', 'INV/23-24/-007170423', '7');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (34, '2023-04-17', 'INV/23-24/-007', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-17', '76453', NULL, '5456', NULL, NULL, 'PLC Panel', '', '7', '5', NULL, NULL, '60225.00', NULL, NULL, '71065.50', NULL, NULL, '1', 'INV/23-24/-007-2023', 'INV/23-24/-007170423', '7');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (35, '2023-04-17', 'INV/23-24/-008', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-17', '2164', NULL, '1564', 'AL-01', NULL, 'ALUMINIUM CASTING', '', '1', '10', NULL, NULL, '120450.00', NULL, NULL, '142131.00', NULL, NULL, '1', 'INV/23-24/-008-2023', 'INV/23-24/-008170423', '8');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (36, '2023-04-17', 'INV/23-24/-008', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-17', '2164', NULL, '7654', 'ST-04', NULL, 'Stabilizer', '', '0', '10', NULL, NULL, '120450.00', NULL, NULL, '142131.00', NULL, NULL, '1', 'INV/23-24/-008-2023', 'INV/23-24/-008170423', '8');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (37, '2023-04-17', 'INV/23-24/-008', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-17', '2164', NULL, '5456', 'PLC-02', NULL, 'PLC Panel', '', '0', '10', NULL, NULL, '120450.00', NULL, NULL, '142131.00', NULL, NULL, '1', 'INV/23-24/-008-2023', 'INV/23-24/-008170423', '8');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (38, '2023-04-17', 'INV/23-24/-008', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-17', '2164', NULL, '1651', 'CP-03', NULL, 'Control Panel', '', '0', '10', NULL, NULL, '120450.00', NULL, NULL, '142131.00', NULL, NULL, '1', 'INV/23-24/-008-2023', 'INV/23-24/-008170423', '8');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (39, '2023-04-17', 'INV/23-24/-008', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-17', '2164', NULL, '6844', 'DC-05', NULL, 'DC Motor', '', '0', '10', NULL, NULL, '120450.00', NULL, NULL, '142131.00', NULL, NULL, '1', 'INV/23-24/-008-2023', 'INV/23-24/-008170423', '8');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (40, '2023-04-17', 'INV/23-24/-008', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'interstate', 'interstate', NULL, 'TN35CL9890', NULL, '2023-04-17', '2164', NULL, '65464', 'STA-06', NULL, 'Stator', '', '|', '10', NULL, NULL, '120450.00', NULL, NULL, '142131.00', NULL, NULL, '1', 'INV/23-24/-008-2023', 'INV/23-24/-008170423', '8');


#
# TABLE STRUCTURE FOR: inward_delivery
#

DROP TABLE IF EXISTS `inward_delivery`;

CREATE TABLE `inward_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insertid` int(11) NOT NULL,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `inward_status` int(11) DEFAULT NULL,
  `lastupdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (7, 2, '2023-04-06', 'I', '2023-04-06', 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,', '161651', '2023-04-06', '1', 'ALUMINIUM CASTING', '', '5', '0', '', '1564', NULL, 'KGS', 'I-23', 'I060423', 1, 0, '2023-04-06 08:42:14');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (8, 2, '2023-04-06', 'I', '2023-04-06', 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,', '161651', '2023-04-06', '4', 'Stabilizer', '', '5', '0', '', '7654', NULL, 'NOS', 'I-23', 'I060423', 1, 0, '2023-04-06 08:42:14');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (9, 2, '2023-04-06', 'I', '2023-04-06', 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,', '161651', '2023-04-06', '6', 'Stator', '', '5', '0', '', '65464', NULL, 'NOS', 'I-23', 'I060423', 1, 0, '2023-04-06 08:42:14');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (10, 2, '2023-04-06', 'I', '2023-04-06', 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,', '161651', '2023-04-06', '2', 'PLC Panel', '', '5', '0', '', '5456', NULL, 'NOS', 'I-23', 'I060423', 1, 0, '2023-04-06 08:42:14');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (11, 2, '2023-04-06', 'I', '2023-04-06', 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,', '161651', '2023-04-06', '3', 'Control Panel', '', '5', '0', '', '1651', NULL, 'NOS', 'I-23', 'I060423', 1, 0, '2023-04-06 08:42:14');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (12, 2, '2023-04-06', 'I', '2023-04-06', 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,', '161651', '2023-04-06', '5', 'DC Motor', '', '5', '0', '', '6844', NULL, 'KGS', 'I-23', 'I060423', 1, 0, '2023-04-06 08:42:14');


#
# TABLE STRUCTURE FOR: inward_details
#

DROP TABLE IF EXISTS `inward_details`;

CREATE TABLE `inward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (2, '2023-04-06', 'I', '2023-04-06', 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,', '161651', '2023-04-06', '1||4||6||2||3||5', 'ALUMINIUM CASTING||Stabilizer||Stator||PLC Panel||Control Panel||DC Motor', '', '5||5||5||5||5||5', '', '1564||7654||65464||5456||1651||6844', NULL, 'KGS||NOS||NOS||NOS||NOS||KGS', 'I-23', 'I060423', 1, 0, '7,8,9,10,11,12');


#
# TABLE STRUCTURE FOR: inward_details_backup
#

DROP TABLE IF EXISTS `inward_details_backup`;

CREATE TABLE `inward_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: job_data
#

DROP TABLE IF EXISTS `job_data`;

CREATE TABLE `job_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: job_details
#

DROP TABLE IF EXISTS `job_details`;

CREATE TABLE `job_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `joborderdate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext,
  `category` longtext,
  `jobdescription` longtext,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobinward_data
#

DROP TABLE IF EXISTS `jobinward_data`;

CREATE TABLE `jobinward_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `joborderqty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobinward_details
#

DROP TABLE IF EXISTS `jobinward_details`;

CREATE TABLE `jobinward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `jobinwarddate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext,
  `joborderno` varchar(225) DEFAULT NULL,
  `category` longtext,
  `jobdescription` longtext,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobworkdc_delivery
#

DROP TABLE IF EXISTS `jobworkdc_delivery`;

CREATE TABLE `jobworkdc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobworkdc_delivery_backup
#

DROP TABLE IF EXISTS `jobworkdc_delivery_backup`;

CREATE TABLE `jobworkdc_delivery_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobworkdc_details
#

DROP TABLE IF EXISTS `jobworkdc_details`;

CREATE TABLE `jobworkdc_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobworkdc_details_backup
#

DROP TABLE IF EXISTS `jobworkdc_details_backup`;

CREATE TABLE `jobworkdc_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: login_details
#

DROP TABLE IF EXISTS `login_details`;

CREATE TABLE `login_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userType` char(1) NOT NULL,
  `date` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `sub_menu_link` text,
  `selectedMainMenu` text NOT NULL,
  `selectedSubMenu` text NOT NULL,
  `add_party` int(11) DEFAULT NULL,
  `add_expenses` int(11) DEFAULT NULL,
  `add_quotation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (1, 'A', '2017-01-26', 'admin', '', 'test@gmail.com', '876049652', '0000-00-00', 'admin', 'admin001', '1', '', '', '', NULL, NULL, NULL);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (5, 'U', '2018-05-02', 'purchase', 'Purchase Team', '', '', '1970-01-01', 'purchase', '123456', '1', 'purchase,inward,inward/view,inward/pending,stockmaster,daily_stockreports,customer/view', 'Purchase,Inward,Inward,Inward,Stock,Stock,Reports', 'Purchase Receipt,Add Inward,Inward Reports,Inward Pending,Add Stock,Daily Stock Reports,Party Reports', 1, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (6, 'U', '2018-05-02', 'Accounts', 'Accounts Team', '', '', '1970-01-01', 'Accounts', '123456', '1', 'invoice_statement/view,tax/view,cashbill/listing,purchase_statement/view,purchasetax/view,voucher,voucher/reports,stockmaster,daily_stockreports,itemwise_report,expenses/reports,quotation/view', 'Sales Invoice,Sales Invoice,Cash Bill,Purchase,Purchase,Voucher,Voucher,Stock,Stock,Stock,Reports,Reports', 'Invoice Party Statement,Invoice Tax Reports,Cash Bill Reports,Purchase Party Statement,Purchase Tax Reports,Add Voucher,Voucher Reports,Add Stock,Daily Stock Reports,Itemwise Reports,Expenses Reports,Quotation Reports', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (7, 'U', '2018-08-10', 'ramesh', 'developer', '', '', '1970-01-01', 'ramesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/reports,purchase_statement/view,purchasetax/view,stockmaster,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Stock,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Add Stock,Add Item', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (8, 'U', '2018-08-10', 'tester1', 'testing', '', '', '1970-01-01', 'tester1', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/view,purchase_statement/view,purchasetax/view,taxtype,uom,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Settings,Settings,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Tax Type,Add UOM,Add Item', 1, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (9, 'U', '2021-06-28', 'parmesh', 'developer', 'pshm956@gmail.com', '8344031191', '2021-06-28', 'parmesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,proforma_invoice/view', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Proforma Invoice Reports', 0, 0, 0);


#
# TABLE STRUCTURE FOR: materialdc_delivery
#

DROP TABLE IF EXISTS `materialdc_delivery`;

CREATE TABLE `materialdc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: materialdc_details
#

DROP TABLE IF EXISTS `materialdc_details`;

CREATE TABLE `materialdc_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: materialdc_details_backup
#

DROP TABLE IF EXISTS `materialdc_details_backup`;

CREATE TABLE `materialdc_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: po_party_statements
#

DROP TABLE IF EXISTS `po_party_statements`;

CREATE TABLE `po_party_statements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (1, '2023-04-06', '2023-04-06', '-', 'P001', 2, 'SRI CHENDUR PUMP INDUSTRIES', NULL, NULL, 'ALUMINIUM CASTING', NULL, '177000.00', '-', '-', '-', NULL, '-', '178050', NULL, '-', '-', '-', '-', '-', '177000.00', '-', NULL, '-', NULL, '177000.00', NULL, '56169', '2023-04-06', '1', 'P001060423', 'P001-2023', '1');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (2, '2023-04-06', '2023-04-06', '-', '0002', 2, 'SRI CHENDUR PUMP INDUSTRIES', NULL, NULL, 'PLC Panel||Stabilizer||Stator||Control Panel', NULL, '33142.50', '-', '-', '-', NULL, '-', '211192.5', NULL, '-', '-', '-', '-', '-', '4336.50||9735.00||13275.00||5796.00', '-', NULL, '-', NULL, '33142.50', NULL, '14651', '2023-04-06', '1', '0002060423', '0002-2023', '2');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (3, '2023-04-06', '2023-04-06', '-', '0003', 2, 'SRI CHENDUR PUMP INDUSTRIES', NULL, NULL, 'DC Motor', NULL, '1829.00', '-', '-', '-', NULL, '-', '213021.5', NULL, '-', '-', '-', '-', '-', '1829.00', '-', NULL, '-', NULL, '1829.00', NULL, '5362', '2023-04-06', '1', '0003060423', '0003-2023', '3');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (4, '2023-04-07', NULL, 'V/22-23/-002', NULL, 0, 'SRI CHENDUR PUMP INDUSTRIES', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '13021.5', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Cash', NULL, '200000', NULL, '-', NULL, '-', NULL, '1', NULL, NULL, NULL);
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (5, '2023-04-07', '2023-04-07', '-', '0004', 2, 'SRI CHENDUR PUMP INDUSTRIES', NULL, NULL, 'Stator', NULL, '22125.00', '-', '-', '-', NULL, '-', '35146.5', NULL, '-', '-', '-', '-', '-', '22125.00', '-', NULL, '-', NULL, '22125.00', NULL, '9684', '2023-04-07', '1', '0004070423', '0004-2023', '4');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (6, '2023-04-07', '2023-04-07', '-', '0005', 4, 'Hydrotech Engineering Works', NULL, NULL, 'Stabilizer', NULL, '19470.00', '-', '-', '-', NULL, '-', '22020', NULL, '-', '-', '-', '-', '-', '19470.00', '-', NULL, '-', NULL, '19470.00', NULL, '5563', '2023-04-07', '1', '0005070423', '0005-2023', '5');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (7, '2023-04-07', '2023-04-07', '-', '0006', 2, 'SRI CHENDUR PUMP INDUSTRIES', NULL, NULL, 'ALUMINIUM CASTING', NULL, '354000.00', '-', '-', '-', NULL, '-', '389146.5', NULL, '-', '-', '-', '-', '-', '354000.00', '-', NULL, '-', NULL, '354000.00', NULL, '5452', '2023-04-07', '1', '0006070423', '0006-2023', '6');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (8, '2023-04-07', '2023-04-07', '-', '0007', 4, 'Hydrotech Engineering Works', NULL, NULL, 'DC Motor', NULL, '5487.00', '-', '-', '-', NULL, '-', '27507', NULL, '-', '-', '-', '-', '-', '5487.00', '-', NULL, '-', NULL, '5487.00', NULL, '38563', '2023-04-07', '1', '0007070423', '0007-2023', '7');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (9, '2023-04-07', '2023-04-07', '-', '0008', 4, 'Hydrotech Engineering Works', NULL, NULL, 'PLC Panel', NULL, '8673.00', '-', '-', '-', NULL, '-', '36180', NULL, '-', '-', '-', '-', '-', '8673.00', '-', NULL, '-', NULL, '8673.00', NULL, '3453', '2023-04-07', '1', '0008070423', '0008-2023', '8');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (10, '2023-04-07', '2023-04-07', '-', '0009', 2, 'SRI CHENDUR PUMP INDUSTRIES', NULL, NULL, 'Control Panel', NULL, '11592.00', '-', '-', '-', NULL, '-', '400738.5', NULL, '-', '-', '-', '-', '-', '11592.00', '-', NULL, '-', NULL, '11592.00', NULL, '23453', '2023-04-07', '1', '0009070423', '0009-2023', '9');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (11, '2023-04-17', '2023-04-17', '-', '0010', 4, 'Hydrotech Engineering Works', NULL, NULL, 'PLC Panel', NULL, '5782.00', '-', '-', '-', NULL, '-', '41962', NULL, '-', '-', '-', '-', '-', '5782.00', '-', NULL, '-', NULL, '5782.00', NULL, '1651', '2023-04-17', '1', '0010170423', '0010-2023', '10');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (12, '2023-04-17', '2023-04-17', '-', '0011', 2, 'SRI CHENDUR PUMP INDUSTRIES', NULL, NULL, 'ALUMINIUM CASTING', NULL, '236000.00', '-', '-', '-', NULL, '-', '636738.5', NULL, '-', '-', '-', '-', '-', '236000.00', '-', NULL, '-', NULL, '236000.00', NULL, '3216', '2023-04-17', '1', '0011170423', '0011-2023', '11');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (13, '2023-04-17', '2023-04-17', '-', '0012', 2, 'SRI CHENDUR PUMP INDUSTRIES', NULL, NULL, 'Stabilizer', NULL, '12980.00', '-', '-', '-', NULL, '-', '649718.5', NULL, '-', '-', '-', '-', '-', '12980.00', '-', NULL, '-', NULL, '12980.00', NULL, '23145', '2023-04-17', '1', '0012170423', '0012-2023', '12');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (14, '2023-04-17', '2023-04-17', '-', '0013', 2, 'SRI CHENDUR PUMP INDUSTRIES', NULL, NULL, 'Stator', NULL, '17700.00', '-', '-', '-', NULL, '-', '667418.5', NULL, '-', '-', '-', '-', '-', '17700.00', '-', NULL, '-', NULL, '17700.00', NULL, '161561', '2023-04-17', '1', '0013170423', '0013-2023', '13');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (15, '2023-04-17', '2023-04-17', '-', '0014', 2, 'SRI CHENDUR PUMP INDUSTRIES', NULL, NULL, 'DC Motor', NULL, '3658.00', '-', '-', '-', NULL, '-', '671076.5', NULL, '-', '-', '-', '-', '-', '3658.00', '-', NULL, '-', NULL, '3658.00', NULL, '61945', '2023-04-17', '1', '0014170423', '0014-2023', '14');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (16, '2023-04-17', '2023-04-17', '-', '0015', 2, 'SRI CHENDUR PUMP INDUSTRIES', NULL, NULL, 'Stator', NULL, '13275.00', '-', '-', '-', NULL, '-', '684351.5', NULL, '-', '-', '-', '-', '-', '13275.00', '-', NULL, '-', NULL, '13275.00', NULL, '6514', '2023-04-17', '1', '0015170423', '0015-2023', '15');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (17, '2023-04-17', '2023-04-17', '-', '0016', 4, 'Hydrotech Engineering Works', NULL, NULL, 'Control Panel', NULL, '5796.00', '-', '-', '-', NULL, '-', '47758', NULL, '-', '-', '-', '-', '-', '5796.00', '-', NULL, '-', NULL, '5796.00', NULL, '1361', '2023-04-17', '1', '0016170423', '0016-2023', '16');


#
# TABLE STRUCTURE FOR: po_party_statements_backup
#

DROP TABLE IF EXISTS `po_party_statements_backup`;

CREATE TABLE `po_party_statements_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: preference_details
#

DROP TABLE IF EXISTS `preference_details`;

CREATE TABLE `preference_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `sed` varchar(255) DEFAULT NULL,
  `edc` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: preference_settings
#

DROP TABLE IF EXISTS `preference_settings`;

CREATE TABLE `preference_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotationPrefix` varchar(255) NOT NULL,
  `quotation` varchar(255) NOT NULL,
  `expenses` varchar(255) NOT NULL,
  `expensePrefix` varchar(255) NOT NULL,
  `dc` varchar(255) NOT NULL,
  `voucherPrefix` varchar(255) NOT NULL,
  `voucher` varchar(255) NOT NULL,
  `debitPrefix` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `creditPrefix` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `purchasePrefix` varchar(255) NOT NULL,
  `purchase` varchar(255) NOT NULL,
  `invoicePrefix` varchar(255) NOT NULL,
  `invoice` varchar(255) NOT NULL,
  `salesdcPrefix` varchar(255) NOT NULL,
  `materialdcPrefix` varchar(255) NOT NULL,
  `jobdcPrefix` varchar(255) NOT NULL,
  `proforma_invoicePrefix` varchar(255) NOT NULL,
  `proforma_invoice` varchar(255) NOT NULL,
  `inwardPrefix` varchar(255) NOT NULL,
  `inward` varchar(255) NOT NULL,
  `cashbillPrefix` varchar(255) NOT NULL,
  `cashbill_invoice` varchar(255) NOT NULL,
  `creditnote` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) NOT NULL,
  `supplierpurchaseorder` varchar(100) NOT NULL,
  `jobworkdc` varchar(255) DEFAULT NULL,
  `materialdc` varchar(255) DEFAULT NULL,
  `cmp_companyname` varchar(255) NOT NULL,
  `cmp_phoneno` varchar(255) NOT NULL,
  `cmp_mobileno` varchar(255) NOT NULL,
  `cmp_address1` varchar(255) NOT NULL,
  `cmp_address2` varchar(255) NOT NULL,
  `cmp_city` varchar(255) NOT NULL,
  `cmp_pincode` varchar(255) NOT NULL,
  `cmp_stateCode` varchar(255) NOT NULL,
  `cmp_website` varchar(255) NOT NULL,
  `cmp_emailid` varchar(255) NOT NULL,
  `cmp_logo` varchar(255) NOT NULL,
  `cont_companyname` varchar(255) NOT NULL,
  `cont_phoneno` varchar(255) NOT NULL,
  `cont_mobileno` varchar(255) NOT NULL,
  `cont_address1` varchar(255) NOT NULL,
  `cont_address2` varchar(255) NOT NULL,
  `cont_city` varchar(255) NOT NULL,
  `cont_pincode` varchar(255) NOT NULL,
  `cont_stateCode` varchar(255) NOT NULL,
  `cont_website` varchar(255) NOT NULL,
  `cont_emailid` varchar(255) NOT NULL,
  `cont_logo` varchar(255) NOT NULL,
  `discountBy` varchar(255) NOT NULL,
  `invoiceBy` varchar(255) NOT NULL,
  `itemType` varchar(255) NOT NULL,
  `bill_type` varchar(255) DEFAULT NULL,
  `quot_bill_type` varchar(255) DEFAULT NULL,
  `voucher_receivable` varchar(255) DEFAULT NULL,
  `voucher_payable` varchar(255) DEFAULT NULL,
  `last_backup` date NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `inward_add` varchar(255) NOT NULL,
  `cashbill_add` varchar(255) NOT NULL,
  `priceType` varchar(255) DEFAULT NULL,
  `priceType1` varchar(255) DEFAULT NULL,
  `sales_dc` int(11) NOT NULL,
  `material_dc` int(11) NOT NULL,
  `jobwork_dc` int(11) NOT NULL,
  `status` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `preference_settings` (`id`, `quotationPrefix`, `quotation`, `expenses`, `expensePrefix`, `dc`, `voucherPrefix`, `voucher`, `debitPrefix`, `debit`, `creditPrefix`, `credit`, `purchasePrefix`, `purchase`, `invoicePrefix`, `invoice`, `salesdcPrefix`, `materialdcPrefix`, `jobdcPrefix`, `proforma_invoicePrefix`, `proforma_invoice`, `inwardPrefix`, `inward`, `cashbillPrefix`, `cashbill_invoice`, `creditnote`, `purchaseorder`, `supplierpurchaseorder`, `jobworkdc`, `materialdc`, `cmp_companyname`, `cmp_phoneno`, `cmp_mobileno`, `cmp_address1`, `cmp_address2`, `cmp_city`, `cmp_pincode`, `cmp_stateCode`, `cmp_website`, `cmp_emailid`, `cmp_logo`, `cont_companyname`, `cont_phoneno`, `cont_mobileno`, `cont_address1`, `cont_address2`, `cont_city`, `cont_pincode`, `cont_stateCode`, `cont_website`, `cont_emailid`, `cont_logo`, `discountBy`, `invoiceBy`, `itemType`, `bill_type`, `quot_bill_type`, `voucher_receivable`, `voucher_payable`, `last_backup`, `itemcode`, `inward_add`, `cashbill_add`, `priceType`, `priceType1`, `sales_dc`, `material_dc`, `jobwork_dc`, `status`) VALUES (1, 'Q', '001', '001', 'E', '', 'V/22-23/-', '', 'D', '001', 'C', '001', 'P', '', 'INV/23-24/-', '', 'SDC/23-24/-', 'MDC/23-24/-', 'PDC/22-23/', 'PI/23-24/', '', 'I', '', 'CB', '001', NULL, '', '001', '001', '001', 'Myoffice Solutions', '7373333321', '8608701222', ' #91 Dr. Jaganathan Nagar', 'Civil Aerodrome Post, Coimbatore', 'Coimbatore', '641014', '33', 'www.idreamdevelopers.org', 'info@idreamdevelopers.com', '12832299_1579401915712151_5416626780361493206_n.png', 'IDREAMDEVELOPERS', '7373333321', '8608701333', ' #91 Dr. Jaganathan Nagar', 'Civil Aerodrome Post, Coimbatore', 'Coimbatore', '641014', '33', 'www.idreamdevelopers.com', 'info@idreamdevelopers.com', 'idream_logo.PNG', 'percent_wise', 'without_stock', 'with_item', 'Overall Tax', 'Overall Tax', 'Without Invoice', 'Without Purchase', '2020-05-04', '1', 'With Inward', 'Without Cashbill', '1', '0', 1, 0, 3, 1);


#
# TABLE STRUCTURE FOR: profile
#

DROP TABLE IF EXISTS `profile`;

CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `companyname` varchar(255) DEFAULT NULL,
  `softwarename` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `stateCode` varchar(255) NOT NULL,
  `emailid` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `gstin` varchar(225) DEFAULT NULL,
  `aadharno` varchar(225) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `bankname` varchar(255) DEFAULT NULL,
  `accountno` varchar(255) DEFAULT NULL,
  `bankbranch` varchar(255) DEFAULT NULL,
  `ifsccode` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `profile` (`id`, `date`, `companyname`, `softwarename`, `mobileno`, `phoneno`, `address1`, `address2`, `city`, `pincode`, `stateCode`, `emailid`, `website`, `tinno`, `cstno`, `gstin`, `aadharno`, `status`, `username`, `password`, `bankname`, `accountno`, `bankbranch`, `ifsccode`, `state`) VALUES (1, NULL, 'MYOFFICE ERP', 'MYOFFICE ERP', '8608701222', '7373333321', '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp', 'Avinashi Road, Hopes College', 'Coimbatore', '641014', 'Tamil Nadu', 'myoffice.ind.in@gmail.com', '', '12345', '54321', '33AAEEDR5643EF2', '', '1', 'admin', 'admin001', '', '', '', '', NULL);


#
# TABLE STRUCTURE FOR: proforma_invoice_details
#

DROP TABLE IF EXISTS `proforma_invoice_details`;

CREATE TABLE `proforma_invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `proforma_invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (1, '2023-04-17', '2023-04-17', '1611', '2023-04-17', 'PI/23-24/001', NULL, 'Sales Invoice', NULL, 3, 'Annu Industries (P) Ltd', ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', '', 'Vehicle', 'TN35CL9890', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '5456||1651||7654||65464||1564||6844', 'PLC Panel||Control Panel||Stabilizer||Stator||ALUMINIUM CASTING||DC Motor', '||||||||||', 'NOS||NOS||NOS||NOS||KGS||KGS', '245||345||550||750||10000||155', '10||10||10||10||10||10', '2450.00||3450.00||5500.00||7500.00||100000.00||1550.00', '0||0||0||0||0||0', 'percent_wise', '0.00||0.00||0.00||0.00||0.00||0.00', '2450.00||3450.00||5500.00||7500.00||100000.00||1550.00', '9||6||9||9||9||9', '220.50||207.00||495.00||675.00||9000.00||139.50', '9||6||9||9||9||9', '220.50||207.00||495.00||675.00||9000.00||139.50', '18||12||18||18||18||18', '441.00||414.00||990.00||1350.00||18000.00||279.00', '2891.00||3864.00||6490.00||8850.00||118000.00||1829.00', '141924.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1||1||1', '141924.00', 'PI/23-24/001170423', 'PI/23-24/001-2023', 1, 1);
INSERT INTO `proforma_invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (2, '2023-04-17', '2023-04-17', '6514', '2023-04-18', 'PI/23-24/002', NULL, 'Sales Invoice', NULL, 1, 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', '', 'Vehicle', 'TN35CL9890', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '1564||7654||65464', 'ALUMINIUM CASTING||Stabilizer||Stator', '||||', 'KGS||NOS||NOS', '10000||550||750', '05||05||05', '50000.00||2750.00||3750.00', '0||0||0', 'percent_wise', '0.00||0.00||0.00', '50000.00||2750.00||3750.00', '9||9||9', '4500.00||247.50||337.50', '9||9||9', '4500.00||247.50||337.50', '18||18||18', '9000.00||495.00||675.00', '59000.00||3245.00||4425.00', '66670.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1', '66670.00', 'PI/23-24/002170423', 'PI/23-24/002-2023', 1, 1);
INSERT INTO `proforma_invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (3, '2023-04-17', '2023-04-17', '6516514', '2023-04-20', 'PI/23-24/003', NULL, 'Sales Invoice', NULL, 3, 'Annu Industries (P) Ltd', ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', '', 'Vehicle', 'TN35CL9890', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '6844||5456||1651', 'DC Motor||PLC Panel||Control Panel', '||||', 'KGS||NOS||NOS', '155||245||345', '05||05||05', '775.00||1225.00||1725.00', '0||0||0', 'percent_wise', '0.00||0.00||0.00', '775.00||1225.00||1725.00', '9||9||6', '69.75||110.25||103.50', '9||9||6', '69.75||110.25||103.50', '18||18||12', '139.50||220.50||207.00', '914.50||1445.50||1932.00', '4292.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1', '4292.00', 'PI/23-24/003170423', 'PI/23-24/003-2023', 1, 1);
INSERT INTO `proforma_invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (4, '2023-04-17', '2023-04-17', '19194', '2023-04-17', 'PI/23-24/004', NULL, 'Sales Invoice', NULL, 3, 'Annu Industries (P) Ltd', NULL, '', 'Vehicle', 'TN35CL9890', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '1564||5456||7654||6844', 'ALUMINIUM CASTING||PLC Panel||Stabilizer||DC Motor', '||||||', 'KGS||NOS||NOS||KGS', '10000||245||550||155', '10||10||10||10', '100000.00||2450.00||5500.00||1550.00', '0||0||0||0', 'percent_wise', '0.00||0.00||0.00||0.00', '100000.00||2450.00||5500.00||1550.00', '9||9||9||9', '9000.00||220.50||495.00||139.50', '9||9||9||9', '9000.00||220.50||495.00||139.50', '18||18||18||18', '18000.00||441.00||990.00||279.00', '118000.00||2891.00||6490.00||1829.00', '129210.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1', '129210.00', NULL, NULL, 1, 1);
INSERT INTO `proforma_invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (5, '2023-04-17', '2023-04-17', '16545', '2023-04-21', 'PI/23-24/005', NULL, 'Sales Invoice', NULL, 3, 'Annu Industries (P) Ltd', ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', '', 'Vehicle', 'TN35CL9890', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '65464||1651', 'Stator||Control Panel', '||', 'NOS||NOS', '750||345', '05||05', '3750.00||1725.00', '0||0', 'percent_wise', '0.00||0.00', '3750.00||1725.00', '9||6', '337.50||103.50', '9||6', '337.50||103.50', '18||12', '675.00||207.00', '4425.00||1932.00', '6357.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '6357.00', 'PI/23-24/005170423', 'PI/23-24/005-2023', 1, 1);


#
# TABLE STRUCTURE FOR: proforma_invoice_details_backup
#

DROP TABLE IF EXISTS `proforma_invoice_details_backup`;

CREATE TABLE `proforma_invoice_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: proforma_invoice_reports
#

DROP TABLE IF EXISTS `proforma_invoice_reports`;

CREATE TABLE `proforma_invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2023-04-17', 'PI/23-24/001', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'intrastate', 'intrastate', '', 'TN35CL9890', NULL, '2023-04-17', '1611', NULL, '5456', NULL, 'PLC Panel', '', '2', '10', 'NOS', '2', NULL, '141924.00', NULL, NULL, '141924.00', NULL, NULL, '1', 'PI/23-24/001-2023', 'PI/23-24/001170423', '1');
INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '2023-04-17', 'PI/23-24/001', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'intrastate', 'intrastate', '', 'TN35CL9890', NULL, '2023-04-17', '1611', NULL, '1651', NULL, 'Control Panel', '', '4', '10', 'NOS', '8', NULL, '141924.00', NULL, NULL, '141924.00', NULL, NULL, '1', 'PI/23-24/001-2023', 'PI/23-24/001170423', '1');
INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (3, '2023-04-17', 'PI/23-24/001', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'intrastate', 'intrastate', '', 'TN35CL9890', NULL, '2023-04-17', '1611', NULL, '7654', NULL, 'Stabilizer', '', '5', '10', 'NOS', '9', NULL, '141924.00', NULL, NULL, '141924.00', NULL, NULL, '1', 'PI/23-24/001-2023', 'PI/23-24/001170423', '1');
INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (4, '2023-04-17', 'PI/23-24/001', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'intrastate', 'intrastate', '', 'TN35CL9890', NULL, '2023-04-17', '1611', NULL, '65464', NULL, 'Stator', '', '|', '10', 'NOS', '1', NULL, '141924.00', NULL, NULL, '141924.00', NULL, NULL, '1', 'PI/23-24/001-2023', 'PI/23-24/001170423', '1');
INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (5, '2023-04-17', 'PI/23-24/001', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'intrastate', 'intrastate', '', 'TN35CL9890', NULL, '2023-04-17', '1611', NULL, '1564', NULL, 'ALUMINIUM CASTING', '', '|', '10', 'KGS', '.', NULL, '141924.00', NULL, NULL, '141924.00', NULL, NULL, '1', 'PI/23-24/001-2023', 'PI/23-24/001170423', '1');
INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (6, '2023-04-17', 'PI/23-24/001', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'intrastate', 'intrastate', '', 'TN35CL9890', NULL, '2023-04-17', '1611', NULL, '6844', NULL, 'DC Motor', '', '3', '10', 'KGS', '0', NULL, '141924.00', NULL, NULL, '141924.00', NULL, NULL, '1', 'PI/23-24/001-2023', 'PI/23-24/001170423', '1');
INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (7, '2023-04-17', 'PI/23-24/002', '2023-04-17', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', '', 'TN35CL9890', NULL, '2023-04-18', '6514', NULL, '1564', NULL, 'ALUMINIUM CASTING', '', '1', '05', 'KGS', '5', NULL, '66670.00', NULL, NULL, '66670.00', NULL, NULL, '1', 'PI/23-24/002-2023', 'PI/23-24/002170423', '2');
INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (8, '2023-04-17', 'PI/23-24/002', '2023-04-17', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', '', 'TN35CL9890', NULL, '2023-04-18', '6514', NULL, '7654', NULL, 'Stabilizer', '', '0', '05', 'NOS', '9', NULL, '66670.00', NULL, NULL, '66670.00', NULL, NULL, '1', 'PI/23-24/002-2023', 'PI/23-24/002170423', '2');
INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (9, '2023-04-17', 'PI/23-24/002', '2023-04-17', NULL, NULL, 1, 'Tex-Tech Industries (India) Private Limited', NULL, NULL, NULL, 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', 'intrastate', 'intrastate', '', 'TN35CL9890', NULL, '2023-04-18', '6514', NULL, '65464', NULL, 'Stator', '', '0', '05', 'NOS', '0', NULL, '66670.00', NULL, NULL, '66670.00', NULL, NULL, '1', 'PI/23-24/002-2023', 'PI/23-24/002170423', '2');
INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (10, '2023-04-17', 'PI/23-24/003', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'intrastate', 'intrastate', '', 'TN35CL9890', NULL, '2023-04-20', '6516514', NULL, '6844', NULL, 'DC Motor', '', '1', '05', 'KGS', '9', NULL, '4292.00', NULL, NULL, '4292.00', NULL, NULL, '1', 'PI/23-24/003-2023', 'PI/23-24/003170423', '3');
INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (11, '2023-04-17', 'PI/23-24/003', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'intrastate', 'intrastate', '', 'TN35CL9890', NULL, '2023-04-20', '6516514', NULL, '5456', NULL, 'PLC Panel', '', '5', '05', 'NOS', '1', NULL, '4292.00', NULL, NULL, '4292.00', NULL, NULL, '1', 'PI/23-24/003-2023', 'PI/23-24/003170423', '3');
INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (12, '2023-04-17', 'PI/23-24/003', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'intrastate', 'intrastate', '', 'TN35CL9890', NULL, '2023-04-20', '6516514', NULL, '1651', NULL, 'Control Panel', '', '5', '05', 'NOS', '4', NULL, '4292.00', NULL, NULL, '4292.00', NULL, NULL, '1', 'PI/23-24/003-2023', 'PI/23-24/003170423', '3');
INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (17, '2023-04-17', 'PI/23-24/004', '2023-04-17', NULL, NULL, 0, 'Annu Industries (P) Ltd', NULL, NULL, NULL, NULL, 'intrastate', 'intrastate', '', 'TN35CL9890', NULL, '2023-04-17', '19194', NULL, '1564', NULL, 'ALUMINIUM CASTING', '', '10000', '10', NULL, '118000.00', NULL, '129210.00', NULL, NULL, '129210.00', NULL, NULL, '1', NULL, NULL, '4');
INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (18, '2023-04-17', 'PI/23-24/004', '2023-04-17', NULL, NULL, 0, 'Annu Industries (P) Ltd', NULL, NULL, NULL, NULL, 'intrastate', 'intrastate', '', 'TN35CL9890', NULL, '2023-04-17', '19194', NULL, '5456', NULL, 'PLC Panel', '', '245', '10', NULL, '2891.00', NULL, '129210.00', NULL, NULL, '129210.00', NULL, NULL, '1', NULL, NULL, '4');
INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (19, '2023-04-17', 'PI/23-24/004', '2023-04-17', NULL, NULL, 0, 'Annu Industries (P) Ltd', NULL, NULL, NULL, NULL, 'intrastate', 'intrastate', '', 'TN35CL9890', NULL, '2023-04-17', '19194', NULL, '7654', NULL, 'Stabilizer', '', '550', '10', NULL, '6490.00', NULL, '129210.00', NULL, NULL, '129210.00', NULL, NULL, '1', NULL, NULL, '4');
INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (20, '2023-04-17', 'PI/23-24/004', '2023-04-17', NULL, NULL, 0, 'Annu Industries (P) Ltd', NULL, NULL, NULL, NULL, 'intrastate', 'intrastate', '', 'TN35CL9890', NULL, '2023-04-17', '19194', NULL, '6844', NULL, 'DC Motor', '', '155', '10', NULL, '1829.00', NULL, '129210.00', NULL, NULL, '129210.00', NULL, NULL, '1', NULL, NULL, '4');
INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (21, '2023-04-17', 'PI/23-24/005', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'intrastate', 'intrastate', '', 'TN35CL9890', NULL, '2023-04-21', '16545', NULL, '65464', NULL, 'Stator', '', '7', '05', 'NOS', '4', NULL, '6357.00', NULL, NULL, '6357.00', NULL, NULL, '1', 'PI/23-24/005-2023', 'PI/23-24/005170423', '5');
INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (22, '2023-04-17', 'PI/23-24/005', '2023-04-17', NULL, NULL, 3, 'Annu Industries (P) Ltd', NULL, NULL, NULL, ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', 'intrastate', 'intrastate', '', 'TN35CL9890', NULL, '2023-04-21', '16545', NULL, '1651', NULL, 'Control Panel', '', '5', '05', 'NOS', '4', NULL, '6357.00', NULL, NULL, '6357.00', NULL, NULL, '1', 'PI/23-24/005-2023', 'PI/23-24/005170423', '5');


#
# TABLE STRUCTURE FOR: proinvoice_party_statement
#

DROP TABLE IF EXISTS `proinvoice_party_statement`;

CREATE TABLE `proinvoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `proinvoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '-', '-', NULL, '2023-04-17', 'PI/23-24/001', 3, 'Annu Industries (P) Ltd', '', '', '', 'PLC Panel||Control Panel||Stabilizer||Stator||ALUMINIUM CASTING||DC Motor', '||||||||||', '', '', NULL, NULL, '', '', '1', '2023-04-17', '2023-04-17', '141924.00', '-', '-', '', '', '-', '-', NULL, '287728.7', '-', '-', '-', '-', '141924.00', '-', '141924.00', NULL, NULL, 'PI/23-24/001-2023', 'PI/23-24/001170423', '1');
INSERT INTO `proinvoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '-', '-', NULL, '2023-04-17', 'PI/23-24/002', 1, 'Tex-Tech Industries (India) Private Limited', '', '', '', 'ALUMINIUM CASTING||Stabilizer||Stator', '||||', '', '', NULL, NULL, '', '', '1', '2023-04-17', '2023-04-17', '66670.00', '-', '-', '', '', '-', '-', NULL, '222415.3', '-', '-', '-', '-', '66670.00', '-', '66670.00', NULL, NULL, 'PI/23-24/002-2023', 'PI/23-24/002170423', '2');
INSERT INTO `proinvoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (3, '-', '-', NULL, '2023-04-17', 'PI/23-24/003', 3, 'Annu Industries (P) Ltd', '', '', '', 'DC Motor||PLC Panel||Control Panel', '||||', '', '', NULL, NULL, '', '', '1', '2023-04-17', '2023-04-17', '4292.00', '-', '-', '', '', '-', '-', NULL, '292020.7', '-', '-', '-', '-', '4292.00', '-', '4292.00', NULL, NULL, 'PI/23-24/003-2023', 'PI/23-24/003170423', '3');
INSERT INTO `proinvoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (5, '-', '-', NULL, '2023-04-17', 'PI/23-24/004', 3, 'Annu Industries (P) Ltd', '', '', '', 'ALUMINIUM CASTING||PLC Panel||Stabilizer||DC Motor', '||||||', '', '', NULL, NULL, '', '', '1', '2023-04-17', '2023-04-17', '129210.00', '-', '-', '', '', '-', '-', NULL, '421230.7', '-', '-', '-', '-', '129210.00', '-', '129210.00', NULL, NULL, NULL, NULL, '4');
INSERT INTO `proinvoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (6, '-', '-', NULL, '2023-04-17', 'PI/23-24/005', 3, 'Annu Industries (P) Ltd', '', '', '', 'Stator||Control Panel', '||', '', '', NULL, NULL, '', '', '1', '2023-04-17', '2023-04-17', '6357.00', '-', '-', '', '', '-', '-', NULL, '427587.7', '-', '-', '-', '-', '6357.00', '-', '6357.00', NULL, NULL, 'PI/23-24/005-2023', 'PI/23-24/005170423', '5');


#
# TABLE STRUCTURE FOR: purchase_collection
#

DROP TABLE IF EXISTS `purchase_collection`;

CREATE TABLE `purchase_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `date_po` date NOT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) NOT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `currentlypaid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `purchase_collection` (`id`, `date`, `date_po`, `purchasedate`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `suppliername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bamount`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `purchaseno`, `currentlypaid`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `payment`, `paid`, `invoiceamt`, `invoiceno`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (1, '2023-04-07', '0000-00-00', NULL, NULL, '2023-04-07', NULL, 'V/22-23/-002', 'SRI CHENDUR PUMP INDUSTRIES', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, '200000', NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: purchase_details
#

DROP TABLE IF EXISTS `purchase_details`;

CREATE TABLE `purchase_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (1, '2023-04-06', '2023-04-06', '2023-04-06', 'P001', 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '56169', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '1564', NULL, 'ALUMINIUM CASTING', 'KGS', '10000', '15', '150000.00', '0', 'percent_wise', '0.00', '150000.00', '9', '13500.00', '9', '13500.00', '18', '27000.00', '177000.00', '177000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '177000.00', 'P001060423', 'P001-2023', 1, '177000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (2, '2023-04-06', '2023-04-06', '2023-04-06', 'P002', 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '14651', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '5456||7654||65464||1651', NULL, 'PLC Panel||Stabilizer||Stator||Control Panel', 'NOS||NOS||NOS||NOS', '245||550||750||345', '15||15||15||15', '3675.00||8250.00||11250.00||5175.00', '0||0||0||0', 'percent_wise', '0.00||0.00||0.00||0.00', '3675.00||8250.00||11250.00||5175.00', '9||9||9||6', '330.75||742.50||1012.50||310.50', '9||9||9||6', '330.75||742.50||1012.50||310.50', '9||9||9||6', '330.75||742.50||1012.50||310.50', '4336.50||9735.00||13275.00||5796.00', '33142.50', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1', '33142.50', '0002060423', '0002-2023', 1, '33142.50', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (3, '2023-04-06', '2023-04-06', '2023-04-06', 'P003', 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '5362', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '6844', NULL, 'DC Motor', 'KGS', '155', '10', '1550.00', '0', 'percent_wise', '0.00', '1550.00', '9', '139.50', '9', '139.50', '18', '279.00', '1829.00', '1829.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '1829.00', '0003060423', '0003-2023', 1, '1829.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (4, '2023-04-07', '2023-04-07', '2023-04-07', 'P004', 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '9684', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '65464', NULL, 'Stator', 'NOS', '750', '25', '18750.00', '0', 'percent_wise', '0.00', '18750.00', '9', '1687.50', '9', '1687.50', '18', '3375.00', '22125.00', '22125.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '22125.00', '0004070423', '0004-2023', 1, '22125.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (5, '2023-04-07', '2023-04-07', '2023-04-07', 'P005', 4, 'Hydrotech Engineering Works', 'DSIDC Complex, B-13, Sultanpuri, , New Delhi, Delhi', '5563', 'interstate', 'interstate', '', '', 'igst', '7654', NULL, 'Stabilizer', 'NOS', '550', '30', '16500.00', '0', 'percent_wise', '0.00', '16500.00', '9', '1485.00', '9', '1485.00', '18', '2970.00', '19470.00', '19470.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '19470.00', '0005070423', '0005-2023', 1, '19470.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (6, '2023-04-07', '2023-04-07', '2023-04-07', 'P006', 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '5452', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '1564', NULL, 'ALUMINIUM CASTING', 'KGS', '10000', '30', '300000.00', '0', 'percent_wise', '0.00', '300000.00', '9', '27000.00', '9', '27000.00', '18', '54000.00', '354000.00', '354000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '354000.00', '0006070423', '0006-2023', 1, '354000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (7, '2023-04-07', '2023-04-07', '2023-04-07', 'P007', 4, 'Hydrotech Engineering Works', 'DSIDC Complex, B-13, Sultanpuri, , New Delhi, Delhi', '38563', 'interstate', 'interstate', '', '', 'igst', '6844', NULL, 'DC Motor', 'KGS', '155', '30', '4650.00', '0', 'percent_wise', '0.00', '4650.00', '9', '418.50', '9', '418.50', '18', '837.00', '5487.00', '5487.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '5487.00', '0007070423', '0007-2023', 1, '5487.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (8, '2023-04-07', '2023-04-07', '2023-04-07', 'P008', 4, 'Hydrotech Engineering Works', 'DSIDC Complex, B-13, Sultanpuri, , New Delhi, Delhi', '3453', 'interstate', 'interstate', '', '', 'igst', '5456', NULL, 'PLC Panel', 'NOS', '245', '30', '7350.00', '0', 'percent_wise', '0.00', '7350.00', '9', '661.50', '9', '661.50', '18', '1323.00', '8673.00', '8673.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '8673.00', '0008070423', '0008-2023', 1, '8673.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (9, '2023-04-07', '2023-04-07', '2023-04-07', 'P009', 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '23453', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '1651', NULL, 'Control Panel', 'NOS', '345', '30', '10350.00', '0', 'percent_wise', '0.00', '10350.00', '6', '621.00', '6', '621.00', '12', '1242.00', '11592.00', '11592.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '11592.00', '0009070423', '0009-2023', 1, '11592.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (10, '2023-04-17', '2023-04-17', '2023-04-17', 'P010', 4, 'Hydrotech Engineering Works', 'DSIDC Complex, B-13, Sultanpuri, , New Delhi, Delhi', '1651', 'interstate', 'interstate', '', '', 'igst', '5456', NULL, 'PLC Panel', 'NOS', '245', '20', '4900.00', '0', 'percent_wise', '0.00', '4900.00', '9', '441.00', '9', '441.00', '18', '882.00', '5782.00', '5782.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '5782.00', '0010170423', '0010-2023', 1, '5782.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (11, '2023-04-17', '2023-04-17', '2023-04-17', 'P011', 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '3216', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '1564', NULL, 'ALUMINIUM CASTING', 'KGS', '10000', '20', '200000.00', '0', 'percent_wise', '0.00', '200000.00', '9', '18000.00', '9', '18000.00', '18', '36000.00', '236000.00', '236000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '236000.00', '0011170423', '0011-2023', 1, '236000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (12, '2023-04-17', '2023-04-17', '2023-04-17', 'P012', 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '23145', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '7654', NULL, 'Stabilizer', 'NOS', '550', '20', '11000.00', '0', 'percent_wise', '0.00', '11000.00', '9', '990.00', '9', '990.00', '18', '1980.00', '12980.00', '12980.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '12980.00', '0012170423', '0012-2023', 1, '12980.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (13, '2023-04-17', '2023-04-17', '2023-04-17', 'P013', 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '161561', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '65464', NULL, 'Stator', 'NOS', '750', '20', '15000.00', '0', 'percent_wise', '0.00', '15000.00', '9', '1350.00', '9', '1350.00', '18', '2700.00', '17700.00', '17700.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '17700.00', '0013170423', '0013-2023', 1, '17700.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (14, '2023-04-17', '2023-04-17', '2023-04-17', 'P014', 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '61945', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '6844', NULL, 'DC Motor', 'KGS', '155', '20', '3100.00', '0', 'percent_wise', '0.00', '3100.00', '9', '279.00', '9', '279.00', '18', '558.00', '3658.00', '3658.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '3658.00', '0014170423', '0014-2023', 1, '3658.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (15, '2023-04-17', '2023-04-17', '2023-04-17', 'P015', 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '6514', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '65464', NULL, 'Stator', 'NOS', '750', '15', '11250.00', '0', 'percent_wise', '0.00', '11250.00', '9', '1012.50', '9', '1012.50', '18', '2025.00', '13275.00', '13275.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '13275.00', '0015170423', '0015-2023', 1, '13275.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (16, '2023-04-17', '2023-04-17', '2023-04-17', 'P016', 4, 'Hydrotech Engineering Works', 'DSIDC Complex, B-13, Sultanpuri, , New Delhi, Delhi', '1361', 'interstate', 'interstate', '', '', 'igst', '1651', NULL, 'Control Panel', 'NOS', '345', '15', '5175.00', '0', 'percent_wise', '0.00', '5175.00', '6', '310.50', '6', '310.50', '12', '621.00', '5796.00', '5796.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '5796.00', '0016170423', '0016-2023', 1, '5796.00', 1, 1);


#
# TABLE STRUCTURE FOR: purchase_details_backup
#

DROP TABLE IF EXISTS `purchase_details_backup`;

CREATE TABLE `purchase_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchase_reports
#

DROP TABLE IF EXISTS `purchase_reports`;

CREATE TABLE `purchase_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (1, '1', '2023-04-06', 'P001', '2023-04-06', NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '56169', '2023-04-06', NULL, NULL, '1564', 'ALUMINIUM CASTING', '1', '15', '1', '177000.00', NULL, NULL, NULL, NULL, NULL, '177000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2023', 'P001060423');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (2, '2', '2023-04-06', '0002', '2023-04-06', NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '14651', '2023-04-06', NULL, NULL, '5456', 'PLC Panel', '2', '15', '4', '33142.50', NULL, NULL, NULL, NULL, NULL, '33142.50', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, '0002-2023', '0002060423');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (3, '2', '2023-04-06', '0002', '2023-04-06', NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '14651', '2023-04-06', NULL, NULL, '7654', 'Stabilizer', '4', '15', '3', '33142.50', NULL, NULL, NULL, NULL, NULL, '33142.50', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, '0002-2023', '0002060423');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (4, '2', '2023-04-06', '0002', '2023-04-06', NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '14651', '2023-04-06', NULL, NULL, '65464', 'Stator', '5', '15', '3', '33142.50', NULL, NULL, NULL, NULL, NULL, '33142.50', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, '0002-2023', '0002060423');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (5, '2', '2023-04-06', '0002', '2023-04-06', NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '14651', '2023-04-06', NULL, NULL, '1651', 'Control Panel', '|', '15', '6', '33142.50', NULL, NULL, NULL, NULL, NULL, '33142.50', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, '0002-2023', '0002060423');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (6, '3', '2023-04-06', '0003', '2023-04-06', NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '5362', '2023-04-06', NULL, NULL, '6844', 'DC Motor', '1', '10', '1', '1829.00', NULL, NULL, NULL, NULL, NULL, '1829.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, '0003-2023', '0003060423');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (7, '4', '2023-04-07', '0004', '2023-04-07', NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '9684', '2023-04-07', NULL, NULL, '65464', 'Stator', '7', '25', '2', '22125.00', NULL, NULL, NULL, NULL, NULL, '22125.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, '0004-2023', '0004070423');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (8, '5', '2023-04-07', '0005', '2023-04-07', NULL, 4, 'Hydrotech Engineering Works', 'DSIDC Complex, B-13, Sultanpuri, , New Delhi, Delhi', '5563', '2023-04-07', NULL, NULL, '7654', 'Stabilizer', '5', '30', '1', '19470.00', NULL, NULL, NULL, NULL, NULL, '19470.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, '0005-2023', '0005070423');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (9, '6', '2023-04-07', '0006', '2023-04-07', NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '5452', '2023-04-07', NULL, NULL, '1564', 'ALUMINIUM CASTING', '1', '30', '3', '354000.00', NULL, NULL, NULL, NULL, NULL, '354000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, '0006-2023', '0006070423');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (10, '7', '2023-04-07', '0007', '2023-04-07', NULL, 4, 'Hydrotech Engineering Works', 'DSIDC Complex, B-13, Sultanpuri, , New Delhi, Delhi', '38563', '2023-04-07', NULL, NULL, '6844', 'DC Motor', '1', '30', '5', '5487.00', NULL, NULL, NULL, NULL, NULL, '5487.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, '0007-2023', '0007070423');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (11, '8', '2023-04-07', '0008', '2023-04-07', NULL, 4, 'Hydrotech Engineering Works', 'DSIDC Complex, B-13, Sultanpuri, , New Delhi, Delhi', '3453', '2023-04-07', NULL, NULL, '5456', 'PLC Panel', '2', '30', '8', '8673.00', NULL, NULL, NULL, NULL, NULL, '8673.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, '0008-2023', '0008070423');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (12, '9', '2023-04-07', '0009', '2023-04-07', NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '23453', '2023-04-07', NULL, NULL, '1651', 'Control Panel', '3', '30', '1', '11592.00', NULL, NULL, NULL, NULL, NULL, '11592.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, '0009-2023', '0009070423');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (13, '10', '2023-04-17', '0010', '2023-04-17', NULL, 4, 'Hydrotech Engineering Works', 'DSIDC Complex, B-13, Sultanpuri, , New Delhi, Delhi', '1651', '2023-04-17', NULL, NULL, '5456', 'PLC Panel', '2', '20', '5', '5782.00', NULL, NULL, NULL, NULL, NULL, '5782.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, '0010-2023', '0010170423');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (14, '11', '2023-04-17', '0011', '2023-04-17', NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '3216', '2023-04-17', NULL, NULL, '1564', 'ALUMINIUM CASTING', '1', '20', '2', '236000.00', NULL, NULL, NULL, NULL, NULL, '236000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, '0011-2023', '0011170423');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (15, '12', '2023-04-17', '0012', '2023-04-17', NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '23145', '2023-04-17', NULL, NULL, '7654', 'Stabilizer', '5', '20', '1', '12980.00', NULL, NULL, NULL, NULL, NULL, '12980.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, '0012-2023', '0012170423');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (16, '13', '2023-04-17', '0013', '2023-04-17', NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '161561', '2023-04-17', NULL, NULL, '65464', 'Stator', '7', '20', '1', '17700.00', NULL, NULL, NULL, NULL, NULL, '17700.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, '0013-2023', '0013170423');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (17, '14', '2023-04-17', '0014', '2023-04-17', NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '61945', '2023-04-17', NULL, NULL, '6844', 'DC Motor', '1', '20', '3', '3658.00', NULL, NULL, NULL, NULL, NULL, '3658.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, '0014-2023', '0014170423');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (18, '15', '2023-04-17', '0015', '2023-04-17', NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '6514', '2023-04-17', NULL, NULL, '65464', 'Stator', '7', '15', '1', '13275.00', NULL, NULL, NULL, NULL, NULL, '13275.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, '0015-2023', '0015170423');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (19, '16', '2023-04-17', '0016', '2023-04-17', NULL, 4, 'Hydrotech Engineering Works', 'DSIDC Complex, B-13, Sultanpuri, , New Delhi, Delhi', '1361', '2023-04-17', NULL, NULL, '1651', 'Control Panel', '3', '15', '5', '5796.00', NULL, NULL, NULL, NULL, NULL, '5796.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, '0016-2023', '0016170423');


#
# TABLE STRUCTURE FOR: purchaseorder_details
#

DROP TABLE IF EXISTS `purchaseorder_details`;

CREATE TABLE `purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` longtext,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` longtext NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` longtext,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (1, '2023-04-07', '2023-04-07', '2023-04-07', 'Direct PO', 'P', '001', NULL, 1, 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '7654||1651', 'ST-04||CP-03', 'Stabilizer||Control Panel', 'NOS||NOS', '550||345', '5||5', '5||5', '', '2750.00||1725.00', '||0', 'percent_wise', '||0.00', '2750.00||1725.00', '9||6', '247.50||103.50', '9||6', '247.50||103.50', '0||0', '0||0', '3245.00||1932.00', '5177.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '5177.00', 'P070423', 'P-2023', 1, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (2, '2023-04-07', '2023-04-07', '2023-04-07', 'Direct PO', 'P1', '1615', NULL, 3, 'Annu Industries (P) Ltd', ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '65464||7654||1564', 'STA-06||ST-04||AL-01', 'Stator||Stabilizer||ALUMINIUM CASTING', 'NOS||NOS||KGS', '750||550||10000', '03||03||03', '03||03||03', '', '2250.00||1650.00||30000.00', '||0||0', 'percent_wise', '||0.00||0.00', '2250.00||1650.00||30000.00', '9||9||9', '202.50||148.50||2700.00', '9||9||9', '202.50||148.50||2700.00', '0||0||0', '0||0||0', '2655.00||1947.00||35400.00', '40002.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1', '40002.00', 'P1070423', 'P1-2023', 1, 0);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (3, '2023-04-08', '2023-04-08', '2023-04-08', 'Direct PO', 'P2', '14654', NULL, 1, 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '1651||5456||7654||65464||6844||1564', 'CP-03||PLC-02||ST-04||STA-06||DC-05||AL-01', 'Control Panel||PLC Panel||Stabilizer||Stator||DC Motor||ALUMINIUM CASTING', 'NOS||NOS||NOS||NOS||KGS||KGS', '345||245||550||750||155||10000', '03||03||03||03||03||03', '03||03||03||03||03||03', '', '1035.00||735.00||1650.00||2250.00||465.00||30000.00', '||0||0||0||0||0', 'percent_wise', '||0.00||0.00||0.00||0.00||0.00', '1035.00||735.00||1650.00||2250.00||465.00||30000.00', '6||9||9||9||9||9', '62.10||66.15||148.50||202.50||41.85||2700.00', '6||9||9||9||9||9', '62.10||66.15||148.50||202.50||41.85||2700.00', '0||0||0||0||0||0', '0||0||0||0||0||0', '1159.20||867.30||1947.00||2655.00||548.70||35400.00', '42577.20', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1||1||1', '42577.20', 'P2080423', 'P2-2023', 1, 0);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (4, '2023-04-17', '2023-04-17', '2023-04-17', 'Direct PO', 'P3', '213131', NULL, 3, 'Annu Industries (P) Ltd', ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '1564||7654||5456||1651||6844||65464', 'AL-01||ST-04||PLC-02||CP-03||DC-05||STA-06', 'ALUMINIUM CASTING||Stabilizer||PLC Panel||Control Panel||DC Motor||Stator', 'KGS||NOS||NOS||NOS||KGS||NOS', '10000||550||245||345||155||750', '10||10||10||10||10||10', '10||10||10||10||10||10', '', '100000.00||5500.00||2450.00||3450.00||1550.00||7500.00', '||0||0||0||0||0', 'percent_wise', '||0.00||0.00||0.00||0.00||0.00', '100000.00||5500.00||2450.00||3450.00||1550.00||7500.00', '9||9||9||6||9||9', '9000.00||495.00||220.50||207.00||139.50||675.00', '9||9||9||6||9||9', '9000.00||495.00||220.50||207.00||139.50||675.00', '0||0||0||0||0||0', '0||0||0||0||0||0', '118000.00||6490.00||2891.00||3864.00||1829.00||8850.00', '141924.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1||1||1', '141924.00', 'P3170423', 'P3-2023', 1, 0);


#
# TABLE STRUCTURE FOR: purchaseorder_details_backup
#

DROP TABLE IF EXISTS `purchaseorder_details_backup`;

CREATE TABLE `purchaseorder_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchaseorder_reports
#

DROP TABLE IF EXISTS `purchaseorder_reports`;

CREATE TABLE `purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (1, '1', '2023-04-07', 'Direct PO', 'P', '001', NULL, '2023-04-07', NULL, 1, 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', '0', '2023-04-07', NULL, 'ST-04', '7654', 'Stabilizer', 'NOS', '550', '5', '5', '', '3245.00', '5177.00', NULL, NULL, NULL, NULL, NULL, '5177.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P-2023', 'P070423');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (2, '1', '2023-04-07', 'Direct PO', 'P', '001', NULL, '2023-04-07', NULL, 1, 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', '0', '2023-04-07', NULL, 'CP-03', '1651', 'Control Panel', 'NOS', '345', '5', '5', '', '1932.00', '5177.00', NULL, NULL, NULL, NULL, NULL, '5177.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P-2023', 'P070423');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (3, '2', '2023-04-07', 'Direct PO', 'P1', '1615', NULL, '2023-04-07', NULL, 3, 'Annu Industries (P) Ltd', ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', '0', '2023-04-07', NULL, 'STA-06', '65464', 'Stator', 'NOS', '750', '03', '0', '', '2655.00', '40002.00', NULL, NULL, NULL, NULL, NULL, '40002.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P1-2023', 'P1070423');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (4, '2', '2023-04-07', 'Direct PO', 'P1', '1615', NULL, '2023-04-07', NULL, 3, 'Annu Industries (P) Ltd', ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', '0', '2023-04-07', NULL, 'ST-04', '7654', 'Stabilizer', 'NOS', '550', '03', '0', '', '1947.00', '40002.00', NULL, NULL, NULL, NULL, NULL, '40002.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P1-2023', 'P1070423');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (5, '2', '2023-04-07', 'Direct PO', 'P1', '1615', NULL, '2023-04-07', NULL, 3, 'Annu Industries (P) Ltd', ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', '0', '2023-04-07', NULL, 'AL-01', '1564', 'ALUMINIUM CASTING', 'KGS', '10000', '03', '0', '', '35400.00', '40002.00', NULL, NULL, NULL, NULL, NULL, '40002.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P1-2023', 'P1070423');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (6, '3', '2023-04-08', 'Direct PO', 'P2', '14654', NULL, '2023-04-08', NULL, 1, 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', '0', '2023-04-08', NULL, 'CP-03', '1651', 'Control Panel', 'NOS', '345', '03', '0', '', '1159.20', '42577.20', NULL, NULL, NULL, NULL, NULL, '42577.20', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P2-2023', 'P2080423');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (7, '3', '2023-04-08', 'Direct PO', 'P2', '14654', NULL, '2023-04-08', NULL, 1, 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', '0', '2023-04-08', NULL, 'PLC-02', '5456', 'PLC Panel', 'NOS', '245', '03', '0', '', '867.30', '42577.20', NULL, NULL, NULL, NULL, NULL, '42577.20', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P2-2023', 'P2080423');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (8, '3', '2023-04-08', 'Direct PO', 'P2', '14654', NULL, '2023-04-08', NULL, 1, 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', '0', '2023-04-08', NULL, 'ST-04', '7654', 'Stabilizer', 'NOS', '550', '03', '0', '', '1947.00', '42577.20', NULL, NULL, NULL, NULL, NULL, '42577.20', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P2-2023', 'P2080423');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (9, '3', '2023-04-08', 'Direct PO', 'P2', '14654', NULL, '2023-04-08', NULL, 1, 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', '0', '2023-04-08', NULL, 'STA-06', '65464', 'Stator', 'NOS', '750', '03', '0', '', '2655.00', '42577.20', NULL, NULL, NULL, NULL, NULL, '42577.20', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P2-2023', 'P2080423');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (10, '3', '2023-04-08', 'Direct PO', 'P2', '14654', NULL, '2023-04-08', NULL, 1, 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', '0', '2023-04-08', NULL, 'DC-05', '6844', 'DC Motor', 'KGS', '155', '03', '0', '', '548.70', '42577.20', NULL, NULL, NULL, NULL, NULL, '42577.20', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P2-2023', 'P2080423');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (11, '3', '2023-04-08', 'Direct PO', 'P2', '14654', NULL, '2023-04-08', NULL, 1, 'Tex-Tech Industries (India) Private Limited', 'V. N. Industrial Estate, 27-D,  Bharathi Colony Rd, Peelamedu,, coimbatore, Tamil Nadu', '0', '2023-04-08', NULL, 'AL-01', '1564', 'ALUMINIUM CASTING', 'KGS', '10000', '03', '0', '', '35400.00', '42577.20', NULL, NULL, NULL, NULL, NULL, '42577.20', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P2-2023', 'P2080423');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (12, '4', '2023-04-17', 'Direct PO', 'P3', '213131', NULL, '2023-04-17', NULL, 3, 'Annu Industries (P) Ltd', ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', '0', '2023-04-17', NULL, 'AL-01', '1564', 'ALUMINIUM CASTING', 'KGS', '10000', '10', '0', '', '118000.00', '141924.00', NULL, NULL, NULL, NULL, NULL, '141924.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P3-2023', 'P3170423');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (13, '4', '2023-04-17', 'Direct PO', 'P3', '213131', NULL, '2023-04-17', NULL, 3, 'Annu Industries (P) Ltd', ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', '0', '2023-04-17', NULL, 'ST-04', '7654', 'Stabilizer', 'NOS', '550', '10', '0', '', '6490.00', '141924.00', NULL, NULL, NULL, NULL, NULL, '141924.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P3-2023', 'P3170423');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (14, '4', '2023-04-17', 'Direct PO', 'P3', '213131', NULL, '2023-04-17', NULL, 3, 'Annu Industries (P) Ltd', ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', '0', '2023-04-17', NULL, 'PLC-02', '5456', 'PLC Panel', 'NOS', '245', '10', '0', '', '2891.00', '141924.00', NULL, NULL, NULL, NULL, NULL, '141924.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P3-2023', 'P3170423');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (15, '4', '2023-04-17', 'Direct PO', 'P3', '213131', NULL, '2023-04-17', NULL, 3, 'Annu Industries (P) Ltd', ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', '0', '2023-04-17', NULL, 'CP-03', '1651', 'Control Panel', 'NOS', '345', '10', '0', '', '3864.00', '141924.00', NULL, NULL, NULL, NULL, NULL, '141924.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P3-2023', 'P3170423');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (16, '4', '2023-04-17', 'Direct PO', 'P3', '213131', NULL, '2023-04-17', NULL, 3, 'Annu Industries (P) Ltd', ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', '0', '2023-04-17', NULL, 'DC-05', '6844', 'DC Motor', 'KGS', '155', '10', '0', '', '1829.00', '141924.00', NULL, NULL, NULL, NULL, NULL, '141924.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P3-2023', 'P3170423');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (17, '4', '2023-04-17', 'Direct PO', 'P3', '213131', NULL, '2023-04-17', NULL, 3, 'Annu Industries (P) Ltd', ' Ground Floor, C-582, Saraswati Vihar Rd, ,  Block C, Saraswati Vihar, Pitam Pura, New Delhi, Delhi', '0', '2023-04-17', NULL, 'STA-06', '65464', 'Stator', 'NOS', '750', '10', '0', '', '8850.00', '141924.00', NULL, NULL, NULL, NULL, NULL, '141924.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P3-2023', 'P3170423');


#
# TABLE STRUCTURE FOR: quotation_details
#

DROP TABLE IF EXISTS `quotation_details`;

CREATE TABLE `quotation_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `description` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: quotation_details_backup
#

DROP TABLE IF EXISTS `quotation_details_backup`;

CREATE TABLE `quotation_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `description` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sales_return
#

DROP TABLE IF EXISTS `sales_return`;

CREATE TABLE `sales_return` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext,
  `itemname` longtext,
  `rate` longtext,
  `qty` longtext,
  `uom` longtext,
  `amount` longtext,
  `discount` longtext,
  `taxableamount` longtext,
  `discountamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sales_return_backup
#

DROP TABLE IF EXISTS `sales_return_backup`;

CREATE TABLE `sales_return_backup` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext,
  `itemname` longtext,
  `rate` longtext,
  `qty` longtext,
  `uom` longtext,
  `amount` longtext,
  `discount` longtext,
  `taxableamount` longtext,
  `discountamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: statecode
#

DROP TABLE IF EXISTS `statecode`;

CREATE TABLE `statecode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) NOT NULL,
  `stateCode` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (1, 'Jammu & Kashmir', '01', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (2, 'Himachal Pradesh', '02', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (3, 'Punjab', '03', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (4, 'Chandigarh', '04', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (5, 'Uttarakhand', '05', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (6, 'Haryana', '06', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (7, 'Delhi', '07', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (8, 'Rajasthan', '08', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (9, 'Uttar Pradesh', '09', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (10, 'Bihar', '10', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (11, 'Sikkim', '11', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (12, 'Arunachal Pradesh', '12', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (13, 'Nagaland', '13', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (14, 'Manipur', '14', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (15, 'Mizoram', '15', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (16, 'Tripura', '16', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (17, 'Meghalaya', '17', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (18, 'Assam', '18', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (19, 'West Bengal', '19', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (20, 'Jharkhand', '20', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (21, 'odisha', '21', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (22, 'Chattisgarh', '22', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (23, 'Madhya Pradesh', '23', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (24, 'Daman & Diu', '25', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (25, 'Gujarat', '24', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (26, 'Dadra & Nagar Haveli', '26', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (27, 'Maharashtra', '27', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (28, 'Andhra Pradesh', '28', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (29, 'Karnataka', '29', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (30, 'Goa', '30', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (31, 'Lakshadweep', '31', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (32, 'Kerala', '32', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (33, 'Tamil Nadu', '33', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (34, 'Puducherry', '34', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (35, 'Andaman & Nicobar Islands', '35', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (36, 'Telengana', '36', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (37, 'Andrapradesh(New)', '37', 1);


#
# TABLE STRUCTURE FOR: stock
#

DROP TABLE IF EXISTS `stock`;

CREATE TABLE `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `updatestock` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `balance` varchar(255) NOT NULL,
  `oldqty` varchar(255) DEFAULT NULL,
  `currentstock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (1, '2023-04-17', '1564', NULL, '9', '9', '18', 'ALUMINIUM CASTING', '20', '10000', '20', '', '', '4', NULL, NULL, '', '2023-04-17', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (2, '2023-04-17', '5456', NULL, '9', '9', '18', 'PLC Panel', '20', '245', '20', '', '', '7', NULL, NULL, '', '2023-04-17', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (3, '2023-04-17', '7654', NULL, '9', '9', '18', 'Stabilizer', '20', '550', '20', '', '', '4', NULL, NULL, '', '2023-04-17', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (4, '2023-04-17', '65464', NULL, '9', '9', '18', 'Stator', '15', '750', '15', '', '', '9', NULL, NULL, '', '2023-04-17', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (5, '2023-04-17', '1651', NULL, '6', '6', '12', 'Control Panel', '15', '345', '15', '', '', '7', NULL, NULL, '', '2023-04-17', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (6, '2023-04-17', '6844', NULL, '9', '9', '18', 'DC Motor', '20', '155', '20', '', '', '7', NULL, NULL, '', '2023-04-17', 'Exclusive');


#
# TABLE STRUCTURE FOR: stock_reports
#

DROP TABLE IF EXISTS `stock_reports`;

CREATE TABLE `stock_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `updatestock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  `balance` varchar(225) DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (1, '2023-04-06', '1564', NULL, 'ALUMINIUM CASTING', NULL, '15', '', '2023-04-06', '1', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (2, '2023-04-06', '5456', NULL, 'PLC Panel', NULL, '15', '', '2023-04-06', '2', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (3, '2023-04-06', '7654', NULL, 'Stabilizer', NULL, '15', '', '2023-04-06', '2', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (4, '2023-04-06', '65464', NULL, 'Stator', NULL, '15', '', '2023-04-06', '2', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (5, '2023-04-06', '1651', NULL, 'Control Panel', NULL, '15', '', '2023-04-06', '2', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (6, '2023-04-06', '6844', NULL, 'DC Motor', NULL, '10', '', '2023-04-06', '3', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (7, '2023-04-07', '65464', NULL, 'Stator', NULL, '25', '', NULL, '4', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (8, '2023-04-07', '7654', NULL, 'Stabilizer', NULL, '30', '', NULL, '5', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (9, '2023-04-07', '1564', NULL, 'ALUMINIUM CASTING', NULL, '30', '', NULL, '6', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (10, '2023-04-07', '6844', NULL, 'DC Motor', NULL, '30', '', NULL, '7', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (11, '2023-04-07', '5456', NULL, 'PLC Panel', NULL, '30', '', NULL, '8', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (12, '2023-04-07', '1651', NULL, 'Control Panel', NULL, '30', '', NULL, '9', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (13, '2023-04-17', '5456', NULL, 'PLC Panel', NULL, '20', '', NULL, '10', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (14, '2023-04-17', '1564', NULL, 'ALUMINIUM CASTING', NULL, '20', '', NULL, '11', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (15, '2023-04-17', '7654', NULL, 'Stabilizer', NULL, '20', '', NULL, '12', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (16, '2023-04-17', '65464', NULL, 'Stator', NULL, '20', '', NULL, '13', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (17, '2023-04-17', '6844', NULL, 'DC Motor', NULL, '20', '', NULL, '14', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (18, '2023-04-17', '65464', NULL, 'Stator', NULL, '15', '', NULL, '15', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (19, '2023-04-17', '1651', NULL, 'Control Panel', NULL, '15', '', NULL, '16', NULL, 'Exclusive');


#
# TABLE STRUCTURE FOR: sup_purchaseorder_details
#

DROP TABLE IF EXISTS `sup_purchaseorder_details`;

CREATE TABLE `sup_purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (1, '2023-04-06', '2023-04-06', NULL, 'Direct PO', 'P001', NULL, NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '5456||7654||65464||1651', 'PLC Panel||Stabilizer||Stator||Control Panel', 'NOS||NOS||NOS||NOS', '245||550||750||345', '15||15||15||15', '15||15||15||15', '', '3675.00||8250.00||11250.00||5175.00', '||0||0||0', 'percent_wise', '||0.00||0.00||0.00', '3675.00||8250.00||11250.00||5175.00', '9||9||9||6', '330.75||742.50||1012.50||310.50', '9||9||9||6', '330.75||742.50||1012.50||310.50', '0||0||0||0', '0||0||0||0', '4336.50||9735.00||13275.00||5796.00', '33142.50', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1', '33142.50', 'P001060423', 'P001-2023', 1, 1);


#
# TABLE STRUCTURE FOR: sup_purchaseorder_details_backup
#

DROP TABLE IF EXISTS `sup_purchaseorder_details_backup`;

CREATE TABLE `sup_purchaseorder_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sup_purchaseorder_reports
#

DROP TABLE IF EXISTS `sup_purchaseorder_reports`;

CREATE TABLE `sup_purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (1, '1', '2023-04-06', 'Direct PO', 'P001', NULL, NULL, '2023-04-06', NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '5456', 'PLC Panel', 'NOS', '2', '15', '15', '', '4336.50', '33142.50', NULL, NULL, NULL, NULL, NULL, '33142.50', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2023', 'P001060423');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (2, '1', '2023-04-06', 'Direct PO', 'P001', NULL, NULL, '2023-04-06', NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '7654', 'Stabilizer', 'NOS', '4', '15', '15', '', '9735.00', '33142.50', NULL, NULL, NULL, NULL, NULL, '33142.50', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2023', 'P001060423');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (3, '1', '2023-04-06', 'Direct PO', 'P001', NULL, NULL, '2023-04-06', NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '65464', 'Stator', 'NOS', '5', '15', '15', '', '13275.00', '33142.50', NULL, NULL, NULL, NULL, NULL, '33142.50', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2023', 'P001060423');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemno`, `hsnno`, `itemname`, `uom`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (4, '1', '2023-04-06', 'Direct PO', 'P001', NULL, NULL, '2023-04-06', NULL, 2, 'SRI CHENDUR PUMP INDUSTRIES', '29, Nava India Rd, near Yamaha Service Centre,, KR Puram, Post,, coimbatore, Tamil Nadu', '0', NULL, NULL, NULL, '1651', 'Control Panel', 'NOS', '|', '15', '15', '', '5796.00', '33142.50', NULL, NULL, NULL, NULL, NULL, '33142.50', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2023', 'P001060423');


#
# TABLE STRUCTURE FOR: tbl_person
#

DROP TABLE IF EXISTS `tbl_person`;

CREATE TABLE `tbl_person` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: uom
#

DROP TABLE IF EXISTS `uom`;

CREATE TABLE `uom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (1, '2023-04-05', 'KGS', 1);
INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (2, '2023-04-05', 'NOS', 1);


#
# TABLE STRUCTURE FOR: user_menu
#

DROP TABLE IF EXISTS `user_menu`;

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) NOT NULL,
  `main_menu` varchar(255) NOT NULL,
  `sub_menu` varchar(255) NOT NULL,
  `sub_menu_link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: vat_details
#

DROP TABLE IF EXISTS `vat_details`;

CREATE TABLE `vat_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `sgst` varchar(225) DEFAULT NULL,
  `cgst` varchar(225) DEFAULT NULL,
  `igst` varchar(225) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `vat_details` (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (1, '2023-04-05', 'GST', '18', 'GST @ 18 %', '9', '9', '18', '1');
INSERT INTO `vat_details` (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (2, '2023-04-05', 'GST', '12', 'GST @ 12 %', '6', '6', '12', '1');


#
# TABLE STRUCTURE FOR: vendor_details
#

DROP TABLE IF EXISTS `vendor_details`;

CREATE TABLE `vendor_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `vendorname` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: voucher
#

DROP TABLE IF EXISTS `voucher`;

CREATE TABLE `voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `balance_amt` varchar(255) DEFAULT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `voucher` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (1, '2023-04-06', 'V/22-23/-001', 1, 'Tex-Tech Industries (India) Private Limited', '2023-04-06', 'payment', 'Business', 'Cash', '0', '', '', '0', '', '35000', 'Cash', NULL, NULL, '35000', '35000', '1', NULL, NULL, '', 0);
INSERT INTO `voucher` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (2, '2023-04-07', 'V/22-23/-002', 2, 'SRI CHENDUR PUMP INDUSTRIES', '2023-04-07', 'receipt', 'Business', 'Cash', '0', '', '', '0', '', '200000', 'Cash', NULL, NULL, '200000', '200000', '1', NULL, NULL, '', 0);
INSERT INTO `voucher` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (3, '2023-04-17', 'V/22-23/-003', 3, 'Annu Industries (P) Ltd', '2023-04-17', 'payment', 'Business', 'Cash', '0', '', '', '0', '', '36460.3', 'Cash', NULL, NULL, '36460.3', '36460.3', '1', NULL, NULL, '', 0);


#
# TABLE STRUCTURE FOR: voucher_backup
#

DROP TABLE IF EXISTS `voucher_backup`;

CREATE TABLE `voucher_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `purchaseno` varchar(255) NOT NULL,
  `balance_amt` varchar(255) NOT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

