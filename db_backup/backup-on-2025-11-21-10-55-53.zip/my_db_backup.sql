#
# TABLE STRUCTURE FOR: add_staff
#

DROP TABLE IF EXISTS `add_staff`;

CREATE TABLE `add_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `staff_name` varchar(255) NOT NULL,
  `mobileno` varchar(255) NOT NULL,
  `amobileno` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `referred` varchar(255) NOT NULL,
  `salary` varchar(255) NOT NULL,
  `salarytype` varchar(255) NOT NULL,
  `perdaysalary` varchar(255) NOT NULL,
  `ot` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: additem
#

DROP TABLE IF EXISTS `additem`;

CREATE TABLE `additem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` text CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `patterncode` varchar(255) NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `pattern_material` varchar(255) NOT NULL,
  `casting_weight` varchar(255) NOT NULL,
  `liquid_weight` varchar(255) NOT NULL,
  `yield` varchar(255) NOT NULL,
  `price` varchar(255) DEFAULT NULL,
  `taxtype` varchar(225) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `priceType` varchar(10) NOT NULL,
  `itemtype` varchar(255) NOT NULL,
  `purchaseNo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (1, '2025-08-11', '1', '002', 'Coal Nozzle', '1001', '001', 'Yield', '250', '100', '250', '15000', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (3, '2025-11-17', '1', '003', 'Zozzle', '1003', '0003', 'Yield', '250', '100', '250.00', '10000', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);


#
# TABLE STRUCTURE FOR: attendance
#

DROP TABLE IF EXISTS `attendance`;

CREATE TABLE `attendance` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `attendancedate` date NOT NULL,
  `staff` varchar(255) NOT NULL,
  `attendances` varchar(255) NOT NULL,
  `intime` varchar(255) NOT NULL,
  `outtime` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `lastupdate` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: backup_details
#

DROP TABLE IF EXISTS `backup_details`;

CREATE TABLE `backup_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` longtext DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (1, 'backup-on-2025-06-21-09-29-14.zip', '2025-06-21');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (2, 'backup-on-2025-06-23-10-32-40.zip', '2025-06-23');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (3, 'backup-on-2025-06-24-12-15-22.zip', '2025-06-24');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (4, 'backup-on-2025-06-25-15-18-12.zip', '2025-06-25');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (5, 'backup-on-2025-06-28-11-57-40.zip', '2025-06-28');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (6, 'backup-on-2025-07-01-15-17-26.zip', '2025-07-01');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (7, 'backup-on-2025-07-02-11-36-22.zip', '2025-07-02');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (8, 'backup-on-2025-07-03-12-06-54.zip', '2025-07-03');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (9, 'backup-on-2025-07-11-17-20-54.zip', '2025-07-11');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (10, 'backup-on-2025-07-13-10-28-41.zip', '2025-07-13');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (11, 'backup-on-2025-07-14-16-02-07.zip', '2025-07-14');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (12, 'backup-on-2025-07-17-12-20-39.zip', '2025-07-17');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (13, 'backup-on-2025-07-19-12-34-18.zip', '2025-07-19');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (14, 'backup-on-2025-07-20-12-06-32.zip', '2025-07-20');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (15, 'backup-on-2025-07-22-15-22-23.zip', '2025-07-22');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (16, 'backup-on-2025-07-23-12-24-23.zip', '2025-07-23');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (17, 'backup-on-2025-07-24-11-53-24.zip', '2025-07-24');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (18, 'backup-on-2025-07-25-15-20-00.zip', '2025-07-25');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (19, 'backup-on-2025-08-04-10-18-51.zip', '2025-08-04');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (20, 'backup-on-2025-08-11-14-38-18.zip', '2025-08-11');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (21, 'backup-on-2025-08-13-18-55-03.zip', '2025-08-13');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (22, 'backup-on-2025-08-14-11-06-34.zip', '2025-08-14');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (23, 'backup-on-2025-08-18-12-13-01.zip', '2025-08-18');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (24, 'backup-on-2025-08-19-15-31-40.zip', '2025-08-19');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (25, 'backup-on-2025-08-21-10-24-45.zip', '2025-08-21');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (26, 'backup-on-2025-08-23-11-25-14.zip', '2025-08-23');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (27, 'backup-on-2025-08-25-18-08-57.zip', '2025-08-25');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (28, 'backup-on-2025-08-26-10-43-44.zip', '2025-08-26');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (29, 'backup-on-2025-08-28-13-20-40.zip', '2025-08-28');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (30, 'backup-on-2025-09-01-11-18-03.zip', '2025-09-01');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (31, 'backup-on-2025-09-02-11-00-26.zip', '2025-09-02');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (32, 'backup-on-2025-09-03-09-53-12.zip', '2025-09-03');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (33, 'backup-on-2025-09-04-18-16-21.zip', '2025-09-04');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (34, 'backup-on-2025-09-05-10-48-29.zip', '2025-09-05');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (35, 'backup-on-2025-09-06-11-07-45.zip', '2025-09-06');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (36, 'backup-on-2025-09-11-16-39-38.zip', '2025-09-11');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (37, 'backup-on-2025-09-12-10-52-25.zip', '2025-09-12');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (38, 'backup-on-2025-09-18-11-32-59.zip', '2025-09-18');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (39, 'backup-on-2025-09-24-14-38-55.zip', '2025-09-24');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (40, 'backup-on-2025-09-25-11-16-25.zip', '2025-09-25');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (41, 'backup-on-2025-10-06-15-54-49.zip', '2025-10-06');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (42, 'backup-on-2025-10-08-12-15-16.zip', '2025-10-08');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (43, 'backup-on-2025-10-12-13-12-11.zip', '2025-10-12');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (44, 'backup-on-2025-10-13-10-37-12.zip', '2025-10-13');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (45, 'backup-on-2025-10-21-11-32-56.zip', '2025-10-21');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (46, 'backup-on-2025-10-22-18-02-59.zip', '2025-10-22');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (47, 'backup-on-2025-11-10-10-30-10.zip', '2025-11-10');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (48, 'backup-on-2025-11-11-10-42-43.zip', '2025-11-11');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (49, 'backup-on-2025-11-14-11-02-49.zip', '2025-11-14');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (50, 'backup-on-2025-11-15-15-54-17.zip', '2025-11-15');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (51, 'backup-on-2025-11-17-12-29-34.zip', '2025-11-17');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (52, 'backup-on-2025-11-19-10-40-12.zip', '2025-11-19');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (53, 'backup-on-2025-11-20-11-20-58.zip', '2025-11-20');


#
# TABLE STRUCTURE FOR: backup_url
#

DROP TABLE IF EXISTS `backup_url`;

CREATE TABLE `backup_url` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: bed_details
#

DROP TABLE IF EXISTS `bed_details`;

CREATE TABLE `bed_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `bed` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: card
#

DROP TABLE IF EXISTS `card`;

CREATE TABLE `card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: cash_bill
#

DROP TABLE IF EXISTS `cash_bill`;

CREATE TABLE `cash_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `dcno` longtext DEFAULT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `dcnos` longtext DEFAULT NULL,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: cashbill_details
#

DROP TABLE IF EXISTS `cashbill_details`;

CREATE TABLE `cashbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `cust_mobno` varchar(255) NOT NULL,
  `address` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `systemDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: cashbill_reports
#

DROP TABLE IF EXISTS `cashbill_reports`;

CREATE TABLE `cashbill_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `systemDate` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `category` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: collection_details
#

DROP TABLE IF EXISTS `collection_details`;

CREATE TABLE `collection_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `collection_details` (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2025-06-20', NULL, '2025-06-20', NULL, 'V/25-26/-001', 'jack', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '800', NULL, NULL, NULL);
INSERT INTO `collection_details` (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '2025-06-20', NULL, '2025-06-20', NULL, 'V/25-26/-002', 'jack', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cheque INDIAN OVERSEAS 484654355454', NULL, NULL, NULL, NULL, '8000', NULL, NULL, NULL);
INSERT INTO `collection_details` (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (3, '2025-06-21', NULL, '2025-06-21', NULL, 'V/25-26/-002', 'SIGMA POWER & ENERGY ENGINEERS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '8800', NULL, NULL, NULL);
INSERT INTO `collection_details` (`id`, `date`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `customername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `invoiceno`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `payment`, `paid`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (4, '2025-06-24', NULL, '2025-06-24', NULL, 'V/25-26/-004', 'IT Solution', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, NULL, '500', NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: company_logo
#

DROP TABLE IF EXISTS `company_logo`;

CREATE TABLE `company_logo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `company_logo` (`id`, `date`, `image`, `status`) VALUES (1, '2025-07-14', 'Untitled.png', '1');


#
# TABLE STRUCTURE FOR: customer_details
#

DROP TABLE IF EXISTS `customer_details`;

CREATE TABLE `customer_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `contactperson` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `old_openingBal` varchar(255) DEFAULT NULL,
  `salesamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  `accountpay` varchar(255) NOT NULL,
  `chequeno` varchar(100) NOT NULL,
  `last_modified` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (1, '2025-06-20', 'Intra customer', 'jack', '7806876370', 'jack@gmail.com', 'gandhipuram', 'singanallur', 'maddy', 'Tamil Nadu', 'karaikudi', '', '', NULL, '0.00', NULL, '45159970', '300', '47153070', NULL, '', NULL, '654616', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2025-06-20');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (2, '2025-07-17', 'Intra customer', 'SIGMA POWER & ENERGY ENGINEERS', '7339666782', 'sigmapower@sigmapower.in', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE', 'Phase II, VALAVANTHAN KOTTAI, THUVAKUDI', 'NANDHINI.P', 'Tamil Nadu', 'TRICHY', '', '', NULL, '0.00', NULL, '-36000', '8800', '227200', NULL, '', NULL, '620015', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33ABRFS2547Q1ZD', '', '', '', '', '', '2025-07-17');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (3, '2025-06-21', 'Intra supplier', 'CK PRIME ALLOYS', '', '', 'ANNUR ROAD', 'KARUMATTAMPATTY', '', 'Tamil Nadu', 'COIMBATORE', '', '', NULL, '0.00', NULL, '401135120.4', '2400', '382724710.2', NULL, '', NULL, '641659', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2025-06-21');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (4, '2025-06-23', 'Intra customer', 'IT Solution', '09360296512', '', 'Hoysala nagar, Ramamurthy signal', 'Kasthuri nagar', 'Pradeepa D', 'Karnataka', 'Bangalore', '', '', NULL, '0.00', NULL, '2366.7', '500', '1866.7', NULL, '', NULL, '560016', NULL, NULL, NULL, NULL, NULL, '1', '', '', '29', '', '', '', '', '', '', '2025-06-23');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (5, '2025-06-24', 'Intra supplier', 'Gateway', '9500995841', 'lithikutti81@gmail.com', 'Kasthuri nagar, Sri lakshmi apartement', 'Bangalore', 'Lithi', 'Karnataka', 'Bangalore', '', '', NULL, '0.00', NULL, '287626368.5', '500', '287625868.5', '995.50', '', NULL, '560016', NULL, NULL, NULL, NULL, NULL, '1', '', '', '29', '', '', '', '', '', '', '2025-06-24');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (6, '2025-06-25', 'Intra customer', 'Tech AU', '1234567890', 'pradee@gmail.com', 'Hoysala nagar, Ramamurthy signal', 'Avinashi Road, Hopes College', 'Pradeepa D', 'Tamil Nadu', 'Bangalore', '', '', NULL, '0.00', NULL, NULL, NULL, '0.00', NULL, '', NULL, '560016', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2025-06-25');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (7, '2025-07-17', 'Intra customer', 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '7708330192', 'sales@cadalan.com.sg', 'No:54 SRI VIGNESHWAR ILLAM', 'MGR NAGAR, GOLDWINS', 'SELVARAJ', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '0.00', NULL, '7109500', NULL, '14189500', NULL, '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33AAICC6141M1ZK', '', '', '', '', '', '2025-07-17');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (8, '2025-11-15', 'Intra supplier', 'Jack', '9361201234', 'jack@gmail.com', 'cbe', 'cbe', 'jack', 'Tamil Nadu', 'CBE', '', '', NULL, '0.00', NULL, '345150000', NULL, '318600000', NULL, '', NULL, '641001', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2025-11-15');


#
# TABLE STRUCTURE FOR: customerpo_details
#

DROP TABLE IF EXISTS `customerpo_details`;

CREATE TABLE `customerpo_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `cuspodate` date DEFAULT NULL,
  `invoicetype` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `cuspono` varchar(255) DEFAULT NULL,
  `transport` varchar(255) DEFAULT NULL,
  `customerpodate` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `cstname` varchar(255) DEFAULT NULL,
  `cstamount` varchar(255) DEFAULT NULL,
  `pf` varchar(255) DEFAULT NULL,
  `freight` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `pfadjus` varchar(255) DEFAULT NULL,
  `freightadjus` varchar(255) DEFAULT NULL,
  `roundoff` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: dc_delivery
#

DROP TABLE IF EXISTS `dc_delivery`;

CREATE TABLE `dc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(100) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `grade` varchar(100) NOT NULL,
  `weight` varchar(100) NOT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (4, '2025-06-20', 2, 9, 'Against Inward', 'SDC/25-26/-001', '2025-06-20', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-rotor', '1', '', '', '50', '50', '50', '0001', NULL, 'KGS', '', '', '', 'SDC/25-26/-001-25', 'SDC/25-26/-001200625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (5, '2025-06-20', 2, 10, 'Against Inward', 'SDC/25-26/-001', '2025-06-20', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-motor', '2', '', '', '50', '50', '50', '0002', NULL, 'KGS', '', '', '', 'SDC/25-26/-001-25', 'SDC/25-26/-001200625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (6, '2025-06-20', 2, 11, 'Against Inward', 'SDC/25-26/-001', '2025-06-20', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-rotor', '1', '', '', '50', '50', '50', '0001', NULL, 'KGS', '', '', '', 'SDC/25-26/-001-25', 'SDC/25-26/-001200625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (7, '2025-06-20', 3, NULL, 'Direct DC', 'SDC/25-26/-002', '2025-06-20', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-rotor', '1', '', '', '100', '50', '', '0001', NULL, 'KGS', '', '', '', 'SDC/25-26/-002-25', 'SDC/25-26/-002200625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (8, '2025-06-20', 3, NULL, 'Direct DC', 'SDC/25-26/-002', '2025-06-20', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-motor', '2', '', '', '100', '50', '', '0002', NULL, 'KGS', '', '', '', 'SDC/25-26/-002-25', 'SDC/25-26/-002200625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (9, '2025-06-20', 4, NULL, 'Direct DC', 'SDC/25-26/-003', '2025-06-20', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-rotor', '1', '', '', '100', '100', '', '0001', NULL, 'KGS', '', '', '', 'SDC/25-26/-003-25', 'SDC/25-26/-003200625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (10, '2025-06-20', 4, NULL, 'Direct DC', 'SDC/25-26/-003', '2025-06-20', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-motor', '2', '', '', '100', '100', '', '0002', NULL, 'KGS', '', '', '', 'SDC/25-26/-003-25', 'SDC/25-26/-003200625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (11, '2025-06-20', 5, 12, 'Against Inward', 'SDC/25-26/-004', '2025-06-20', 1, 'jack', '', 'gandhipuram, singanallur', 'I002', NULL, NULL, '1080-rotor', '1', '', '', '50', '25', '', '0001', NULL, 'KGS', '', '', '', 'SDC/25-26/-004-25', 'SDC/25-26/-004200625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (12, '2025-06-20', 5, 13, 'Against Inward', 'SDC/25-26/-004', '2025-06-20', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-motor', '2', '', '', '50', '25', '', '0002', NULL, 'KGS', '', '', '', 'SDC/25-26/-004-25', 'SDC/25-26/-004200625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (13, '2025-06-21', 6, 14, 'Against Inward', 'SDC/25-26/-005', '2025-06-21', 2, 'SIGMA POWER & ENERGY ENGINEERS', '', 'e-5 SIDCO INDUSTRIES ESTATE, THUVAKUDI', 'I003', NULL, NULL, 'EH OUTER BOX', '3', '', '', '50', '50', '', '123456', NULL, 'KGS', '', '', '', 'SDC/25-26/-005-25', 'SDC/25-26/-005210625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (14, '2025-06-25', 7, NULL, 'Direct DC', 'SDC/25-26/-006', '2025-06-25', 4, 'IT Solution', '', 'Hoysala nagar, Ramamurthy signal, Kasthuri nagar', NULL, NULL, NULL, 'Stationary things', '4', '', '', '2', '2', 'Urgent Item', '00002', NULL, 'PACK', '', '', 'Urgent Item', 'SDC/25-26/-006-25', 'SDC/25-26/-006250625', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (21, '2025-07-23', 12, 22, 'Against Inward', 'SDC/25-26/-008', '2025-07-23', 1, 'jack', '', 'gandhipuram, singanallur', 'I006', '', '', '1080 Stator', '8', '1002', '', '50', '49', 'qwerty', '123456', NULL, 'KGS', 'MSS', '', '', 'SDC/25-26/-008-25', 'SDC/25-26/-008230725', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (22, '2025-07-23', 12, 23, 'Against Inward', 'SDC/25-26/-008', '2025-07-23', 1, 'jack', '', 'gandhipuram, singanallur', 'I006', '', '', '1/2\" CL 600 Body', '5', '1003', '', '2', '1', 'qwerty', '73259930', NULL, 'KGS', '', '', '', 'SDC/25-26/-008-25', 'SDC/25-26/-008230725', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (20, '2025-07-23', 12, 21, 'Against Inward', 'SDC/25-26/-008', '2025-07-23', 1, 'jack', '', 'gandhipuram, singanallur', 'I006', '', '', '1080 Rotor', '7', '1001', '', '50', '49', 'qwerty', '123456', NULL, 'KGS', 'MSS', '', '', 'SDC/25-26/-008-25', 'SDC/25-26/-008230725', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (28, '2025-07-23', 13, 23, 'Against Inward', 'SDC/25-26/-009', '2025-07-23', 1, 'jack', '', 'gandhipuram, singanallur', 'I006', '', '', '1/2\" CL 600 Body', '5', '1003', '', '1', '1', 'qwerty', '73259930', NULL, 'KGS', '', '', '', 'SDC/25-26/-009-25', 'SDC/25-26/-009230725', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (27, '2025-07-23', 13, 21, 'Against Inward', 'SDC/25-26/-009', '2025-07-23', 1, 'jack', '', 'gandhipuram, singanallur', 'I006', '', '', '1080 Rotor', '7', '1001', '', '10', '10', 'qwerty', '123456', NULL, 'KGS', 'MSS', '', '', 'SDC/25-26/-009-25', 'SDC/25-26/-009230725', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (26, '2025-07-23', 13, 22, 'Against Inward', 'SDC/25-26/-009', '2025-07-23', 1, 'jack', '', 'gandhipuram, singanallur', 'I006', '', '', '1080 Stator', '8', '1002', '', '10', '10', 'qwerty', '123456', NULL, 'KGS', 'MSS', '', '', 'SDC/25-26/-009-25', 'SDC/25-26/-009230725', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (29, '2025-08-04', 14, NULL, 'Direct DC', 'SDC/25-26/-010', '2025-08-04', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS', NULL, NULL, NULL, 'Coal Nozzle', '6', '200', '', '10', '9', '-', '84803000', '0', 'NOS', 'MSS', '', '', 'SDC/25-26/-010-25', 'SDC/25-26/-010040825', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (30, '2025-09-18', 16, NULL, 'Direct DC', 'SDC/25-26/-011', '2025-09-18', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, 'Coal Nozzle', '1', NULL, '-', '10', '10', '-', '123456', '002', 'KGS', '1', '', NULL, 'SDC/25-26/-011-25', 'SDC/25-26/-011180925', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (31, '2025-09-18', 16, NULL, 'Direct DC', 'SDC/25-26/-011', '2025-09-18', 1, 'jack', '', 'gandhipuram, singanallur', NULL, NULL, NULL, 'Coal Nozzle', '1', NULL, '-', '10', '10', '-', '123456', '002', 'KGS', '1', '', NULL, 'SDC/25-26/-011-25', 'SDC/25-26/-011180925', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (35, '2025-09-18', 17, NULL, 'Direct DC', 'SDC/25-26/-012', '2025-09-18', 1, 'jack', '', 'gandhipuram, singanallur', '', '', '', 'Coal Nozzle', '1', NULL, '-', '50', '50', '-', '123456', '002', 'KGS', '1', '150', NULL, 'SDC/25-26/-012-25', 'SDC/25-26/-012180925', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (34, '2025-09-18', 17, NULL, 'Direct DC', 'SDC/25-26/-012', '2025-09-18', 1, 'jack', '', 'gandhipuram, singanallur', '', '', '', 'Coal Nozzle', '1', NULL, '-', '50', '50', '-', '123456', '002', 'KGS', '1', '100', NULL, 'SDC/25-26/-012-25', 'SDC/25-26/-012180925', 1, 1);
INSERT INTO `dc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `remarkss`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (36, '2025-09-18', 17, NULL, 'Direct DC', 'SDC/25-26/-012', '2025-09-18', 1, 'jack', '', 'gandhipuram, singanallur', '', '', '', 'Coal Nozzle', '', NULL, '-', '50', '50', '-', '123456', '002', 'KGS', '1', '200', NULL, 'SDC/25-26/-012-25', 'SDC/25-26/-012180925', 1, 1);


#
# TABLE STRUCTURE FOR: dcbill_details
#

DROP TABLE IF EXISTS `dcbill_details`;

CREATE TABLE `dcbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` longtext DEFAULT NULL,
  `customerdcdate` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(100) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext DEFAULT NULL,
  `remarks` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `weight` varchar(100) NOT NULL,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (2, '2025-06-20', 'Against Inward', 'SDC/25-26/-001', '2025-06-20', 1, 'jack', '', '07:43:PM', '', '', '', '2000', 'gandhipuram, singanallur', 'I001', NULL, NULL, '1080-rotor||1080-motor||1080-rotor', '1||2||1', '', '||||', '50||50||50', '50||50||50', '0001||0002||0001', NULL, 'KGS||KGS||KGS', '', '', 'SDC/25-26/-001-25', 'SDC/25-26/-001200625', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (3, '2025-06-20', 'Direct DC', 'SDC/25-26/-002', '2025-06-20', 1, 'jack', '', '07:44:PM', '', '', '', '2000', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-rotor||1080-motor', '1||2', '', '||', '100||100', '||', '0001||0002', NULL, 'KGS||KGS', '', '', 'SDC/25-26/-002-25', 'SDC/25-26/-002200625', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (4, '2025-06-20', 'Direct DC', 'SDC/25-26/-003', '2025-06-20', 1, 'jack', '', '08:01:PM', '', '', '', '2000', 'gandhipuram, singanallur', NULL, NULL, NULL, '1080-rotor||1080-motor', '1||2', '', '||', '100||100', '||', '0001||0002', NULL, 'KGS||KGS', '', '', 'SDC/25-26/-003-25', 'SDC/25-26/-003200625', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (5, '2025-06-20', 'Against Inward', 'SDC/25-26/-004', '2025-06-20', 1, 'jack', '', '08:11:PM', '', '', '', '2000', 'gandhipuram, singanallur', 'I002', NULL, NULL, '1080-rotor||1080-motor', '1||2', '', '||', '50||50', '||', '0001||0002', NULL, 'KGS||KGS', '', '', 'SDC/25-26/-004-25', 'SDC/25-26/-004200625', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (6, '2025-06-21', 'Against Inward', 'SDC/25-26/-005', '2025-06-21', 2, 'SIGMA POWER & ENERGY ENGINEERS', '', '09:50:AM', '', '', '', '', 'e-5 SIDCO INDUSTRIES ESTATE, THUVAKUDI', 'I003', NULL, NULL, 'EH OUTER BOX', '3', '', '', '50', '', '123456', NULL, 'KGS', '', '', 'SDC/25-26/-005-25', 'SDC/25-26/-005210625', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (7, '2025-06-25', 'Direct DC', 'SDC/25-26/-006', '2025-06-25', 4, 'IT Solution', '', '10:36:PM', '', '', 'Urgent Item', '', 'Hoysala nagar, Ramamurthy signal, Kasthuri nagar', NULL, NULL, NULL, 'Stationary things', '4', '', '', '2', 'Urgent Item', '00002', '15015', 'PACK', '', '', 'SDC/25-26/-006-25', 'SDC/25-26/-006250625', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (8, '2025-07-23', 'Direct DC', 'SDC/25-26/-007', '2025-07-23', 1, 'jack', '001', '01:02:PM', '', '', '', '', 'gandhipuram, singanallur', '', NULL, NULL, '1080 Rotor||1080 Stator', '7||8', '1001||1002', '||', '10||10', 'qwerty||qwerty', '123456||123456', '001||002', 'KGS||KGS', 'MSS||MSS', '', 'SDC/25-26/-007-25', 'SDC/25-26/-007230725', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (9, '2025-07-23', 'Direct DC', 'SDC/25-26/-007', '2025-07-23', 1, 'jack', '001', '01:02:PM', '', '', '', '', 'gandhipuram, singanallur', '', NULL, NULL, '1080 Rotor||1080 Stator', '7||8', '1001||1002', '||', '10||10', 'qwerty||qwerty', '123456||123456', '001||002', 'KGS||KGS', 'MSS||MSS', '', 'SDC/25-26/-007-25', 'SDC/25-26/-007230725', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (10, '2025-07-23', 'Direct DC', 'SDC/25-26/-007', '2025-07-23', 1, 'jack', '001', '01:02:PM', '', '', '', '', 'gandhipuram, singanallur', '', NULL, NULL, '1080 Rotor||1080 Stator', '7||8', '1001||1002', '||', '10||10', 'qwerty||qwerty', '123456||123456', '001||002', 'KGS||KGS', 'MSS||MSS', '', 'SDC/25-26/-007-25', 'SDC/25-26/-007230725', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (11, '2025-07-23', 'Direct DC', 'SDC/25-26/-007', '2025-07-23', 1, 'jack', '001', '03:25:PM', '', '', '', '10000', 'gandhipuram, singanallur', '', '', '', '1080 Rotor||1080 Stator||1080 Stator', '7||8||8', '1001||1002||', '||||', '10||10||10', 'qwerty||qwerty||qqq', '123456||123456||123456', '001||002||002', 'KGS||KGS||KGS', 'MSS||MSS||MSS', '', 'SDC/25-26/-007-25', 'SDC/25-26/-007230725', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (12, '2025-07-23', 'Against Inward', 'SDC/25-26/-008', '2025-07-23', 1, 'jack', '', '04:23:PM', '', '', '', '250000', 'gandhipuram, singanallur', 'I006', '', '', '1080 Rotor||1080 Stator||1/2', '7||8||5', '1001||1002||1003', '||||', '50||50||2', 'qwerty||qwerty||qwerty', '123456||123456||73259930', '', 'KGS||KGS||KGS', 'MSS||MSS||', '', 'SDC/25-26/-008-25', 'SDC/25-26/-008230725', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (13, '2025-07-23', 'Against Inward', 'SDC/25-26/-009', '2025-07-23', 1, 'jack', '', '04:42:PM', '', '', '', '', 'gandhipuram, singanallur', 'I006', '', '', '1080 Stator||1080 Rotor||1/2\" CL 600 Body', '8||7||5', '1002||1001||1003', '||||', '10||10||1', 'qwerty||qwerty||qwerty', '123456||123456||73259930', '', 'KGS||KGS||KGS', 'MSS||MSS||', '', 'SDC/25-26/-009-25', 'SDC/25-26/-009230725', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (14, '2025-08-04', 'Direct DC', 'SDC/25-26/-010', '2025-08-04', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '', '11:51:AM', '', '', '', '10000', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS', '', NULL, NULL, 'Coal Nozzle', '6', '200', '', '10', '-', '84803000', '0', 'NOS', 'MSS', '', 'SDC/25-26/-010-25', 'SDC/25-26/-010040825', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (15, '2025-09-18', 'Direct DC', 'SDC/25-26/-011', '2025-09-18', 1, 'jack', '', '12:39:PM', '', '', NULL, '', 'gandhipuram, singanallur', '', NULL, NULL, 'Coal Nozzle||Coal Nozzle', '1||1', NULL, '-||-', '10||10', '-||-', '123456||123456', '002||002', 'KGS||KGS', '1||1', '', 'SDC/25-26/-011-25', 'SDC/25-26/-011180925', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (16, '2025-09-18', 'Direct DC', 'SDC/25-26/-011', '2025-09-18', 1, 'jack', '', '12:39:PM', '', '', NULL, '', 'gandhipuram, singanallur', '', NULL, NULL, 'Coal Nozzle||Coal Nozzle', '1||1', NULL, '-||-', '10||10', '-||-', '123456||123456', '002||002', 'KGS||KGS', '1||1', '', 'SDC/25-26/-011-25', 'SDC/25-26/-011180925', 1, 1, '');
INSERT INTO `dcbill_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `heatno`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `weight`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (17, '2025-09-18', 'Direct DC', 'SDC/25-26/-012', '2025-09-18', 1, 'jack', '', '02:39:PM', '', '', NULL, '50000', 'gandhipuram, singanallur', '', '', '', 'Coal Nozzle||Coal Nozzle||Coal Nozzle', '1||1||', NULL, '-||-||-', '50||50||50', '-||-||-', '123456||123456||123456', '002||002||002', 'KGS||KGS||KGS', '1||1||1', '100||150||200', 'SDC/25-26/-012-25', 'SDC/25-26/-012180925', 1, 1, '');


#
# TABLE STRUCTURE FOR: dcbill_details_backup
#

DROP TABLE IF EXISTS `dcbill_details_backup`;

CREATE TABLE `dcbill_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` longtext DEFAULT NULL,
  `customerdcdate` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext DEFAULT NULL,
  `remarks` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: dpt_report
#

DROP TABLE IF EXISTS `dpt_report`;

CREATE TABLE `dpt_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `dpt_report_no` varchar(100) NOT NULL,
  `dpt_date` varchar(100) NOT NULL,
  `customername` varchar(100) NOT NULL,
  `customerid` varchar(100) NOT NULL,
  `report_no` varchar(100) NOT NULL,
  `stage_of_test` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `type_of_penetrant` varchar(100) NOT NULL,
  `casting_temperature` varchar(100) NOT NULL,
  `type_of_developer` varchar(100) NOT NULL,
  `surface_condition` varchar(100) NOT NULL,
  `testing_date` varchar(100) NOT NULL,
  `acceptance_standard` varchar(100) NOT NULL,
  `dwell_time` varchar(100) NOT NULL,
  `procedure_ref` varchar(100) NOT NULL,
  `fluosrecent` varchar(100) NOT NULL,
  `area_method_of_test` varchar(100) NOT NULL,
  `penetrant_apply_method` varchar(10) NOT NULL,
  `precleaning_method` varchar(100) NOT NULL,
  `post_of_test_cleaning` varchar(100) NOT NULL,
  `light_indensity` varchar(100) NOT NULL,
  `background` varchar(100) NOT NULL,
  `result` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `drawing_no` text NOT NULL,
  `heat_no` text NOT NULL,
  `dp_no` text NOT NULL,
  `qty` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `dpt_report` (`id`, `date`, `dpt_report_no`, `dpt_date`, `customername`, `customerid`, `report_no`, `stage_of_test`, `grade`, `type_of_penetrant`, `casting_temperature`, `type_of_developer`, `surface_condition`, `testing_date`, `acceptance_standard`, `dwell_time`, `procedure_ref`, `fluosrecent`, `area_method_of_test`, `penetrant_apply_method`, `precleaning_method`, `post_of_test_cleaning`, `light_indensity`, `background`, `result`, `description`, `drawing_no`, `heat_no`, `dp_no`, `qty`, `status`, `created_at`) VALUES (1, '2025-10-22', 'DPT001', '22-10-2025', 'jack', '1', 'DPT', 'DPT', '3', 'DPT', 'DPT', '22-10-2025', 'DPT', '22-10-2025', 'DPT', 'DPT', 'DPT', 'Flourecent', 'DPT', 'DPT', 'DPT', 'DPT', 'DPT', 'DPT', 'DPT', 'Coal Nozzle,Coal Nozzle,Coal Nozzle,Coal Nozzle', '001,001,001,001', 'DPT,DPT,DPT,DPT', 'DPT,DPT,DPT,DPT', 'DPT,DPT,DPT,DPT', 1, '2025-10-22 20:38:46');


#
# TABLE STRUCTURE FOR: einvoicetoken
#

DROP TABLE IF EXISTS `einvoicetoken`;

CREATE TABLE `einvoicetoken` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tokenexpiry` varchar(255) NOT NULL,
  `authtoken` varchar(255) NOT NULL,
  `sek` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS `expenses`;

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `expenses` (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (1, '2025-06-23', '001', 'Pradeepa', '2025-06-23', 'Advance salary', 'Cash', '0', '', '', '0', '', '30000', NULL, 'Cash', '30000', '1', 'Salary ', '');
INSERT INTO `expenses` (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (3, '2025-06-23', '002', 'RM Company', '2025-06-23', 'tea', 'Cheque', 'AXIS', '1224335', '3', '0', '', '', NULL, 'Cheque AXIS 1224335', '3', '1', 'Salary ', '');
INSERT INTO `expenses` (`id`, `date`, `expensesid`, `name`, `expensesdate`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `cardtype`, `paymentdetails`, `overallamount`, `status`, `headers`, `transactionid`) VALUES (4, '2025-06-23', '003', 'RM Company', '2025-06-23', 'tea', 'Cash', 'AXIS', '1224335', '3', '0', '', '30000', NULL, 'Cash', '30000', '1', 'Salary ', '');


#
# TABLE STRUCTURE FOR: expenses_backup
#

DROP TABLE IF EXISTS `expenses_backup`;

CREATE TABLE `expenses_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: grade
#

DROP TABLE IF EXISTS `grade`;

CREATE TABLE `grade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `heat_treatment` varchar(255) DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `hsnno` varchar(100) NOT NULL,
  `element` text DEFAULT NULL,
  `min_value` text DEFAULT NULL,
  `max_value` text DEFAULT NULL,
  `mechanicalelement` text DEFAULT NULL,
  `mechanicalminvalue` text DEFAULT NULL,
  `mechanicalmaxvalue` text DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `grade` (`id`, `date`, `heat_treatment`, `grade`, `hsnno`, `element`, `min_value`, `max_value`, `mechanicalelement`, `mechanicalminvalue`, `mechanicalmaxvalue`, `remarks`, `status`) VALUES (3, '2025-10-08', 'SOLUTION ANNEALING: Heated  to  1080°C soak for  3 Hrs and  then  water quenched.', 'ASTM A351 GR CF3M', '641024', 'C,Mn,Si,P,S,Cr,Ni,Mo,,,,,,,', '-,-,-,-,-,17.000,9.000,2.000,,,,,,,', '-,-,-,-,-,17.000,9.000,2.000,,,,,,,', 'Yield Strength,Tensile Strength,% Elongation,% Reduction of Area,Hardness,Bend Test,Impact Test in Joules', '205,485,30,-,-,-,-', '-,-,-,-,200,-,-', '<p><span style=\"font-size: 14px;\">Separate test bar poured and the same bar tested for chemical and mechanical properties</span></p><p><span style=\"font-size: 14px;\">&nbsp; Tensile Testing conducted on round specimen at room temperature</span></p><p><span style=\"font-size: 14px;\">&nbsp;Visual inspection carried out at as per MSS SP-55, found satisfied</span></p><p>Radio active contamination not found in the castings</p>', 1);


#
# TABLE STRUCTURE FOR: headers
#

DROP TABLE IF EXISTS `headers`;

CREATE TABLE `headers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `headers` (`id`, `date`, `status`, `name`) VALUES (1, '2025-06-23', 1, 'Salary ');


#
# TABLE STRUCTURE FOR: hsnmaster
#

DROP TABLE IF EXISTS `hsnmaster`;

CREATE TABLE `hsnmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `party` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `hsnmaster` (`id`, `date`, `hsnno`, `party`, `status`) VALUES (2, '2025-08-11', '145311090', NULL, 1);


#
# TABLE STRUCTURE FOR: inspection_report
#

DROP TABLE IF EXISTS `inspection_report`;

CREATE TABLE `inspection_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `insno` varchar(100) NOT NULL,
  `inspection_date` varchar(100) NOT NULL,
  `customername` varchar(100) NOT NULL,
  `customerid` varchar(100) NOT NULL,
  `itemname` varchar(100) NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `dimension_in` varchar(100) NOT NULL,
  `sno` longtext NOT NULL,
  `view` longtext NOT NULL,
  `length` longtext NOT NULL,
  `inspection1` longtext NOT NULL,
  `inspection2` longtext NOT NULL,
  `inspection3` longtext NOT NULL,
  `inspection4` longtext NOT NULL,
  `remark` longtext NOT NULL,
  `ndt` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `result` varchar(255) NOT NULL,
  `ndt_remarks` text NOT NULL,
  `overall_remarks` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: invoice_details
#

DROP TABLE IF EXISTS `invoice_details`;

CREATE TABLE `invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `pino` varchar(255) DEFAULT NULL,
  `purchaseordernos` varchar(255) DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerdcnos` varchar(100) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `removalDate` date NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToId` varchar(255) DEFAULT NULL,
  `shipToAddress` longtext DEFAULT NULL,
  `deliveryAddress1` longtext DEFAULT NULL,
  `deliveryAddress2` longtext DEFAULT NULL,
  `mobileNo` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `dcnos` longtext DEFAULT NULL,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `weight` varchar(100) NOT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `totalqty` varchar(255) DEFAULT NULL,
  `acno` varchar(255) NOT NULL,
  `acdate` varchar(255) NOT NULL,
  `irn` varchar(255) NOT NULL,
  `signedinvoice` longtext NOT NULL,
  `signedqrcode` longtext NOT NULL,
  `status_ein` longtext NOT NULL,
  `ewayno` varchar(255) NOT NULL,
  `ewaydate` varchar(255) NOT NULL,
  `ewbvalidtill` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `status_cd` varchar(255) NOT NULL,
  `status_desc` varchar(255) NOT NULL,
  `einvoice_status` int(11) NOT NULL,
  `eway_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (13, '2025-07-17', '2025-03-21', '2025361', '2025-03-18', 'INV/25-26/-', NULL, 'P1', NULL, 'P1', 'Tax Invoice', 'Against PO', '', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', NULL, NULL, '', '2025-07-17', '01:20 PM', 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '7', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, '4', '73259930', 'CA16', '1/2', '', '', '', 'KGS', '', '1250', '20', '', '25000.00', '0', 'amount_wise', NULL, '25000.00', '9', '2250.00', '9', '2250.00', '18', '', NULL, '25000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '29500.00', '29500.00', 1, 'INV/25-26/-170725', 'INV/25-26/--2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (14, '2025-07-17', '2025-07-17', '3704', '1970-01-01', 'INV/25-26/-1', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 2, 'SIGMA POWER & ENERGY ENGINEERS', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', NULL, NULL, '', '2025-07-17', '01:33 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '84803000', 'SP01', 'Coal Nozzle', '', '', '', 'NOS', '', '200000', '1', '', '200000.00', '0', 'amount_wise', '0', '200000.00', '9', '18000.00', '9', '18000.00', '', '', NULL, '200000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '236000.00', '236000.00', 1, 'INV/25-26/-1170725', 'INV/25-26/-1-2025', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (15, '2025-07-25', '2025-07-25', '', '1970-01-01', 'INV/25-26/-2', '', '', NULL, '', 'Tax Invoice', 'Direct Invoice', '', 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', NULL, NULL, '', '2025-07-25', '03:22 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '', '123456||123456', '001||002', '1080 Rotor||1080 Stator', '||', '001||001', '||', 'KGS||KGS', 'MSS||MSS', '15000||15000', '10||10', '', '150000.00||150000.00', '0||0', 'amount_wise', '0||0', '150000.00||150000.00', '9', '', '9', '', '18', '', '', '300000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '300000.00', '300000.00', 1, 'INV/25-26/-2250725', 'INV/25-26/-2-2025', 1, 1, '20.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (16, '2025-07-25', '2025-07-25', '', '1970-01-01', 'INV/25-26/-3', '', '', NULL, '', 'Tax Invoice', 'Direct Invoice', '', 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', NULL, NULL, '', '2025-07-25', '04:43 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '', '123456||123456||123456', '001||002||001', '1080 Rotor||1080 Stator||1080 Rotor', '1001||||1002', '1001||1002||1003', '||||', 'KGS||KGS||KGS', 'MSS||MSS||MSS', '15000||15000||15000', '10||10||5', '', '150000.00||150000.00||75000.00', '0||0||0', 'amount_wise', '0||0||0', '150000.00||150000.00||75000.00', '9', '33750.00', '9', '33750.00', '18', '', '', '375000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1||1', '442500.00', '442500.00', 1, 'INV/25-26/-3250725', 'INV/25-26/-3-2025', 1, 1, '20.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (17, '2025-07-25', '2025-07-25', '', '1970-01-01', 'INV/25-26/-4', 'SDC/25-26/-008', '', NULL, '', 'Tax Invoice', 'Against DC', '', 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', NULL, NULL, '', '2025-07-25', '07:01 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', 'SDC/25-26/-008||SDC/25-26/-008||SDC/25-26/-008', '12', '21||22||20', '123456||73259930||123456', '002||CA16||001', '1080 Stator||1/2\" CL 600 Body||1080 Rotor', '8||5||7', '1002||1003||1001', '||||', 'KGS||KGS||KGS', 'MSS||||MSS', '15000||1500||15000', '1||1||1', '', '15000.00||1500.00||15000.00', '0||0||0', 'amount_wise', '||||', '15000.00||1500.00||15000.00', '9', '2835.00', '9', '2835.00', '18', '', '15000.00||1500.00||15000.00', '31500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1||1', '37170.00', '37170.00', 1, 'INV/25-26/-4250725', 'INV/25-26/-4-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (18, '2025-08-04', '2025-08-04', '', '1970-01-01', 'INV/25-26/-5', '', '', NULL, '', 'Tax Invoice', 'Direct Invoice', '', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', NULL, NULL, '', '2025-08-04', '10:35 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '', '84803000||84803000', '0||0', 'Coal Nozzle||Coal Nozzle', '||6', '001||002', 'Casting||Core vox', 'NOS||NOS', 'MSS||MSS', '200000||200000', '1||1', '', '2000000.00||2000000.00', '0||0', 'amount_wise', '0||0', '2000000.00||2000000.00', '9', '360000.00', '9', '360000.00', '18', '', '', '4000000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '4720000.00', '4720000.00', 1, 'INV/25-26/-5040825', 'INV/25-26/-5-2025', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (19, '2025-08-04', '2025-08-04', '', '1970-01-01', 'INV/25-26/-6', '', '', NULL, '', 'Tax Invoice', 'Direct Invoice', '', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', NULL, NULL, '', '2025-08-04', '11:10 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '', '84803000||84803000', '0||0', 'Coal Nozzle||Coal Nozzle', '||6', '001||002', '||', 'NOS||NOS', 'MSS||MSS', '200000||200000', '1||1', '10||10', '2000000.00||2000000.00', '0||0', 'amount_wise', '0||0', '2000000.00||2000000.00', '9', '360000.00', '9', '360000.00', '18', '', '', '4000000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '4720000.00', '4720000.00', 1, 'INV/25-26/-6040825', 'INV/25-26/-6-2025', 1, 1, '3.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (20, '2025-08-04', '2025-08-04', '', '1970-01-01', 'INV/25-26/-7', 'SDC/25-26/-010', '', NULL, '', 'Tax Invoice', 'Against DC', '', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', NULL, NULL, '', '2025-08-04', '11:58 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', 'SDC/25-26/-010', '14', '29', '84803000', '0', 'Coal Nozzle', '6', '200', '', 'NOS', 'MSS', '200000', '1', '20', '4000000.00', '0', 'amount_wise', '', '4000000.00', '9', '360000.00', '9', '360000.00', '18', '', '4000000.00', '4000000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '4720000.00', '4720000.00', 1, 'INV/25-26/-7040825', 'INV/25-26/-7-2025', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (21, '2025-11-19', '2025-11-19', '', '1970-01-01', 'INV/25-26/-8', '', '', NULL, '', 'Tax Invoice', 'Direct Invoice', '', 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', NULL, NULL, '', '2025-11-19', '02:42 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '', '641024||641024', '002||002', 'Coal Nozzle||Coal Nozzle', '||1', '002||002', '002||002', 'KGS||KGS', '3||3', '15000||15000', '5||5', '250||250', '18750000.00||18750000.00', '0||0', 'amount_wise', '0||0', '18750000.00||18750000.00', '9', '3375000.00', '9', '3375000.00', '18', '', '', '37500000.00', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '44250000.00', '44250000.00', 1, 'INV/25-26/-8191125', 'INV/25-26/-8-2025', 1, 1, '10.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0);


#
# TABLE STRUCTURE FOR: invoice_details_backup
#

DROP TABLE IF EXISTS `invoice_details_backup`;

CREATE TABLE `invoice_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `pino` varchar(255) DEFAULT NULL,
  `purchaseordernos` varchar(255) DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerdcnos` varchar(100) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `removalDate` date NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToId` varchar(255) DEFAULT NULL,
  `shipToAddress` longtext DEFAULT NULL,
  `deliveryAddress1` longtext DEFAULT NULL,
  `deliveryAddress2` longtext DEFAULT NULL,
  `mobileNo` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `dcnos` longtext DEFAULT NULL,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `heatno` varchar(100) NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `itemcode` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `weight` varchar(100) NOT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `totalqty` varchar(255) DEFAULT NULL,
  `acno` varchar(255) NOT NULL,
  `acdate` varchar(255) NOT NULL,
  `irn` varchar(255) NOT NULL,
  `signedinvoice` longtext NOT NULL,
  `signedqrcode` longtext NOT NULL,
  `status_ein` longtext NOT NULL,
  `ewayno` varchar(255) NOT NULL,
  `ewaydate` varchar(255) NOT NULL,
  `ewbvalidtill` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `status_cd` varchar(255) NOT NULL,
  `status_desc` varchar(255) NOT NULL,
  `einvoice_status` int(11) NOT NULL,
  `eway_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: invoice_party_statement
#

DROP TABLE IF EXISTS `invoice_party_statement`;

CREATE TABLE `invoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `weight` varchar(100) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (9, 'V/25-26/-001', '', NULL, '2025-06-20', '-', 0, 'jack', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2025-06-20', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '583000', NULL, NULL, NULL, 'Cash', NULL, '1100', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (13, 'V/25-26/-002', '', NULL, '2025-06-21', '-', 0, 'SIGMA POWER & ENERGY ENGINEERS', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2025-06-21', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '180000', NULL, NULL, NULL, 'Cash', NULL, '8800', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (16, 'V/25-26/-004', '', NULL, '2025-06-24', '-', 0, 'IT Solution', '', '', '', '', '', '', '', '', NULL, NULL, '', '', '1', '2025-06-24', '0000-00-00', '', '', NULL, '', '', NULL, NULL, NULL, '-500', NULL, NULL, NULL, 'Cash', NULL, '500', '-', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (19, '-', '-', NULL, '2025-03-21', 'INV/25-26/-', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '', '', '', '1/2', '', '', '', '', NULL, NULL, '', '', '1', '2025-03-21', '2025-03-21', '29500.00', '-', '-', '', '', '-', '-', NULL, '29500', '-', '-', '-', '-', '29500.00', '-', '29500.00', NULL, NULL, 'INV/25-26/--2025', 'INV/25-26/-170725', '13');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (21, '-', '-', NULL, '2025-07-17', 'INV/25-26/-1', 2, 'SIGMA POWER & ENERGY ENGINEERS', '', '', '', 'Coal Nozzle', '', '', '', '', NULL, NULL, '', '', '1', '2025-07-17', '2025-07-17', '236000.00', '-', '-', '', '', '-', '-', NULL, '227200', '-', '-', '-', '-', '236000.00', '-', '236000.00', NULL, NULL, NULL, NULL, '14');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (22, '-', '-', NULL, '2025-07-25', 'INV/25-26/-2', 1, 'jack', '', '', '', '1080 Rotor||1080 Stator', '||', '', '', '', NULL, NULL, '', '', '1', '2025-07-25', '2025-07-25', '300000.00', '-', '-', '', '', '-', '-', NULL, '2423400', '-', '-', '-', '-', '300000.00', '-', '300000.00', NULL, NULL, 'INV/25-26/-2-2025', 'INV/25-26/-2250725', '15');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (24, '-', '-', NULL, '2025-07-25', 'INV/25-26/-3', 1, 'jack', '', '', '', '1080 Rotor||1080 Stator||1080 Rotor', '||||', '', '', '', NULL, NULL, '', '', '1', '2025-07-25', '2025-07-25', '442500.00', '-', '-', '', '', '-', '-', NULL, '2865900', '-', '-', '-', '-', '442500.00', '-', '442500.00', NULL, NULL, NULL, NULL, '16');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (25, '-', '-', NULL, '2025-07-25', 'INV/25-26/-4', 1, 'jack', '', '', '', '1080 Stator||1/2\" CL 600 Body||1080 Rotor', '||||', '', '', '', NULL, NULL, '', '', '1', '2025-07-25', '2025-07-25', '37170.00', '-', '-', '', '', '-', '-', NULL, '2903070', '-', '-', '-', '-', '37170.00', '-', '37170.00', NULL, NULL, 'INV/25-26/-4-2025', 'INV/25-26/-4250725', '17');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (26, '-', '-', NULL, '2025-08-04', 'INV/25-26/-5', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '', '', '', 'Coal Nozzle||Coal Nozzle', 'Casting||Core vox', '', '', '', NULL, NULL, '', '', '1', '2025-08-04', '2025-08-04', '4720000.00', '-', '-', '', '', '-', '-', NULL, '4749500', '-', '-', '-', '-', '4720000.00', '-', '4720000.00', NULL, NULL, 'INV/25-26/-5-2025', 'INV/25-26/-5040825', '18');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (29, '-', '-', NULL, '2025-08-04', 'INV/25-26/-6', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '', '', '', 'Coal Nozzle||Coal Nozzle', '||', '', '', '', NULL, NULL, '', '', '1', '2025-08-04', '2025-08-04', '4720000.00', '-', '-', '', '', '-', '-', NULL, '9469500', '-', '-', '-', '-', '4720000.00', '-', '4720000.00', NULL, NULL, NULL, NULL, '19');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (30, '-', '-', NULL, '2025-08-04', 'INV/25-26/-7', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '', '', '', 'Coal Nozzle', '', '', '', '', NULL, NULL, '', '', '1', '2025-08-04', '2025-08-04', '4720000.00', '-', '-', '', '', '-', '-', NULL, '14189500', '-', '-', '-', '-', '4720000.00', '-', '4720000.00', NULL, NULL, 'INV/25-26/-7-2025', 'INV/25-26/-7040825', '20');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (31, '-', '-', NULL, '2025-11-19', 'INV/25-26/-8', 1, 'jack', '', '', '', 'Coal Nozzle||Coal Nozzle', '002||002', '', '', '', NULL, NULL, '', '', '1', '2025-11-19', '2025-11-19', '44250000.00', '-', '-', '', '', '-', '-', NULL, '47153070', '-', '-', '-', '-', '44250000.00', '-', '44250000.00', NULL, NULL, 'INV/25-26/-8-2025', 'INV/25-26/-8191125', '21');


#
# TABLE STRUCTURE FOR: invoice_party_statement_backup
#

DROP TABLE IF EXISTS `invoice_party_statement_backup`;

CREATE TABLE `invoice_party_statement_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `weight` varchar(100) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: invoice_reports
#

DROP TABLE IF EXISTS `invoice_reports`;

CREATE TABLE `invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `heatno` varchar(100) NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `uom` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `weight` varchar(100) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (28, '2025-07-17', 'INV/25-26/-', '2025-03-21', NULL, NULL, 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', NULL, NULL, NULL, 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '2025-03-18', '2025361', NULL, '73259930', '', '', 'CA16', NULL, '1/2', '', '1', '', '', '20', '', NULL, NULL, '25000.00', NULL, NULL, '29500.00', NULL, NULL, '1', 'INV/25-26/--2025', 'INV/25-26/-170725', '13');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (30, '2025-07-17', 'INV/25-26/-1', '2025-07-17', NULL, NULL, 0, 'SIGMA POWER & ENERGY ENGINEERS', NULL, NULL, NULL, 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '3704', NULL, '84803000', '', '', '1', NULL, 'Coal Nozzle', '', '200000', '', '', '1', '', NULL, NULL, '200000.00', NULL, NULL, '236000.00', NULL, NULL, '1', NULL, NULL, '14');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (31, '2025-07-25', 'INV/25-26/-2', '2025-07-25', NULL, NULL, 1, 'jack', NULL, NULL, NULL, 'gandhipuram, singanallur, karaikudi, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '123456', '001', '', '001', NULL, '1080 Rotor', '', '1', '', 'MSS', '10', '', '', NULL, '300000.00', NULL, NULL, '300000.00', NULL, NULL, '1', 'INV/25-26/-2-2025', 'INV/25-26/-2250725', '15');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (32, '2025-07-25', 'INV/25-26/-2', '2025-07-25', NULL, NULL, 1, 'jack', NULL, NULL, NULL, 'gandhipuram, singanallur, karaikudi, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '123456', '001', '', '002', NULL, '1080 Stator', '', '5', '', 'MSS', '10', '', '', NULL, '300000.00', NULL, NULL, '300000.00', NULL, NULL, '1', 'INV/25-26/-2-2025', 'INV/25-26/-2250725', '15');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (38, '2025-07-25', 'INV/25-26/-3', '2025-07-25', NULL, NULL, 0, 'jack', NULL, NULL, NULL, 'gandhipuram, singanallur, karaikudi, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '123456', '1002', '', '002', NULL, '1080 Stator', '', '15000', '', 'MSS', '10', '', NULL, NULL, '375000.00', NULL, NULL, '442500.00', NULL, NULL, '1', NULL, NULL, '16');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (37, '2025-07-25', 'INV/25-26/-3', '2025-07-25', NULL, NULL, 0, 'jack', NULL, NULL, NULL, 'gandhipuram, singanallur, karaikudi, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '123456', '1001', '1001', '001', NULL, '1080 Rotor', '', '15000', '', 'MSS', '10', '', NULL, NULL, '375000.00', NULL, NULL, '442500.00', NULL, NULL, '1', NULL, NULL, '16');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (39, '2025-07-25', 'INV/25-26/-3', '2025-07-25', NULL, NULL, 0, 'jack', NULL, NULL, NULL, 'gandhipuram, singanallur, karaikudi, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '123456', '1003', '1002', '001', NULL, '1080 Rotor', '', '15000', '', 'MSS', '5', '', NULL, NULL, '375000.00', NULL, NULL, '442500.00', NULL, NULL, '1', NULL, NULL, '16');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (40, '2025-07-25', 'INV/25-26/-4', '2025-07-25', NULL, NULL, 1, 'jack', NULL, NULL, NULL, 'gandhipuram, singanallur, karaikudi, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '123456', '1002', '8', '002', NULL, '1080 Stator', '', '1', '', 'MSS', '1', '', '1', NULL, '31500.00', NULL, NULL, '37170.00', NULL, NULL, '1', 'INV/25-26/-4-2025', 'INV/25-26/-4250725', '17');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (41, '2025-07-25', 'INV/25-26/-4', '2025-07-25', NULL, NULL, 1, 'jack', NULL, NULL, NULL, 'gandhipuram, singanallur, karaikudi, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '73259930', '1003', '5', 'CA16', NULL, '1/2\" CL 600 Body', '', '5', '', '', '1', '', '5', NULL, '31500.00', NULL, NULL, '37170.00', NULL, NULL, '1', 'INV/25-26/-4-2025', 'INV/25-26/-4250725', '17');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (42, '2025-07-25', 'INV/25-26/-4', '2025-07-25', NULL, NULL, 1, 'jack', NULL, NULL, NULL, 'gandhipuram, singanallur, karaikudi, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '123456', '1001', '7', '001', NULL, '1080 Rotor', '', '0', '', 'MSS', '1', '', '0', NULL, '31500.00', NULL, NULL, '37170.00', NULL, NULL, '1', 'INV/25-26/-4-2025', 'INV/25-26/-4250725', '17');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (43, '2025-08-04', 'INV/25-26/-5', '2025-08-04', NULL, NULL, 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', NULL, NULL, NULL, 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '84803000', '001', '', '0', NULL, 'Coal Nozzle', 'Casting', '2', '', 'MSS', '1', '', '', NULL, '4000000.00', NULL, NULL, '4720000.00', NULL, NULL, '1', 'INV/25-26/-5-2025', 'INV/25-26/-5040825', '18');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (44, '2025-08-04', 'INV/25-26/-5', '2025-08-04', NULL, NULL, 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', NULL, NULL, NULL, 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '84803000', '002', '6', '0', NULL, 'Coal Nozzle', 'Core vox', '0', '', 'MSS', '1', '', '', NULL, '4000000.00', NULL, NULL, '4720000.00', NULL, NULL, '1', 'INV/25-26/-5-2025', 'INV/25-26/-5040825', '18');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (50, '2025-08-04', 'INV/25-26/-6', '2025-08-04', NULL, NULL, 0, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', NULL, NULL, NULL, 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '84803000', '002', '6', '0', NULL, 'Coal Nozzle', '', '200000', '', 'MSS', '1', '10', NULL, NULL, '4000000.00', NULL, NULL, '4720000.00', NULL, NULL, '1', NULL, NULL, '19');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (49, '2025-08-04', 'INV/25-26/-6', '2025-08-04', NULL, NULL, 0, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', NULL, NULL, NULL, 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '84803000', '001', '', '0', NULL, 'Coal Nozzle', '', '200000', '', 'MSS', '1', '10', NULL, NULL, '4000000.00', NULL, NULL, '4720000.00', NULL, NULL, '1', NULL, NULL, '19');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (51, '2025-08-04', 'INV/25-26/-7', '2025-08-04', NULL, NULL, 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', NULL, NULL, NULL, 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '84803000', '200', '6', '0', NULL, 'Coal Nozzle', '', '2', '', 'MSS', '1', '20', '4', NULL, '4000000.00', NULL, NULL, '4720000.00', NULL, NULL, '1', 'INV/25-26/-7-2025', 'INV/25-26/-7040825', '20');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (52, '2025-11-19', 'INV/25-26/-8', '2025-11-19', NULL, NULL, 1, 'jack', NULL, NULL, NULL, 'gandhipuram, singanallur, karaikudi, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '641024', '002', '', '002', NULL, 'Coal Nozzle', '002', '1', '', '3', '5', '250', '', NULL, '37500000.00', NULL, NULL, '44250000.00', NULL, NULL, '1', 'INV/25-26/-8-2025', 'INV/25-26/-8191125', '21');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (53, '2025-11-19', 'INV/25-26/-8', '2025-11-19', NULL, NULL, 1, 'jack', NULL, NULL, NULL, 'gandhipuram, singanallur, karaikudi, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '641024', '002', '1', '002', NULL, 'Coal Nozzle', '002', '5', '', '3', '5', '250', '', NULL, '37500000.00', NULL, NULL, '44250000.00', NULL, NULL, '1', 'INV/25-26/-8-2025', 'INV/25-26/-8191125', '21');


#
# TABLE STRUCTURE FOR: inward_delivery
#

DROP TABLE IF EXISTS `inward_delivery`;

CREATE TABLE `inward_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insertid` int(11) NOT NULL,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(50) NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `lastupdatedqty` int(11) NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(50) NOT NULL,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `inward_status` int(11) DEFAULT NULL,
  `lastupdated` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (9, 4, '2025-06-20', 'I001', '2025-06-20', 'jack', 'gandhipuram, singanallur', '001', '2025-06-20', '1', '', '1080-rotor', '', '100', '50', 100, '', '0001', NULL, 'KGS', '', 'I001-25', 'I001200625', 1, 1, '2025-06-20 19:42:54');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (10, 4, '2025-06-20', 'I001', '2025-06-20', 'jack', 'gandhipuram, singanallur', '001', '2025-06-20', '2', '', '1080-motor', '', '100', '50', 100, '', '0002', NULL, 'KGS', '', 'I001-25', 'I001200625', 1, 1, '2025-06-20 19:42:54');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (11, 4, '2025-06-20', 'I001', '2025-06-20', 'jack', 'gandhipuram, singanallur', '001', '2025-06-20', '1', '', '1080-rotor', '', '100', '50', 100, '', '0001', NULL, 'KGS', '', 'I001-25', 'I001200625', 1, 1, '2025-06-20 19:42:54');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (12, 5, '2025-06-20', 'I002', '2025-06-20', 'jack', 'gandhipuram, singanallur', '002', '2025-06-20', '1', '', '1080-rotor', '', '100', '50', 100, '', '0001', NULL, 'KGS', '', 'I002-25', 'I002200625', 1, 1, '2025-06-20 20:11:08');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (13, 5, '2025-06-20', 'I002', '2025-06-20', 'jack', 'gandhipuram, singanallur', '002', '2025-06-20', '2', '', '1080-motor', '', '100', '50', 100, '', '0002', NULL, 'KGS', '', 'I002-25', 'I002200625', 1, 1, '2025-06-20 20:11:08');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (14, 6, '2025-06-20', 'I003', '2025-06-20', 'SIGMA POWER & ENERGY ENGINEERS', 'e-5 SIDCO INDUSTRIES ESTATE, THUVAKUDI', '001', '2025-06-20', '3', '', 'EH OUTER BOX', '', '100', '50', 100, '', '123456', NULL, 'KGS', '', 'I003-25', 'I003200625', 1, 1, '2025-06-21 09:48:40');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (15, 7, '2025-06-25', 'I004', '2025-06-25', 'IT Solution', 'Hoysala nagar, Ramamurthy signal, Kasthuri nagar', 'Hosur', '2025-06-25', '4', '', 'Stationary things', '', '2', '2', 2, 'Urgent needed', '00002', NULL, 'PACK', '', 'I004-25', 'I004250625', 1, 1, '2025-06-25 21:36:23');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (19, 8, '2025-07-22', 'I005', '2025-07-22', 'jack', 'gandhipuram, singanallur', '001', '2025-07-22', '8', '1001', '1080 Stator', '', '100', '100', 100, 'qwerty', '123456', '002', 'KGS', '', 'I005-25', 'I005220725', 1, 1, '2025-07-22 19:24:30');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (17, 8, '2025-07-22', 'I005', '2025-07-22', 'jack', 'gandhipuram, singanallur', '001', '2025-07-22', '8', '', '1080 Stator', '', '100', '100', 100, 'qwerty', '123456', '1002', 'KGS', '', 'I005-25', 'I005220725', 1, 1, '2025-07-22 19:24:30');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (16, 8, '2025-07-22', 'I005', '2025-07-22', 'jack', 'gandhipuram, singanallur', '001', '2025-07-22', '7', '', '1080 Rotor', '', '100', '100', 100, 'qwerty', '123456', '1001', 'KGS', '', 'I005-25', 'I005220725', 1, 1, '2025-07-22 19:24:30');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (20, 8, '2025-07-22', 'I005', '2025-07-22', 'jack', 'gandhipuram, singanallur', '001', '2025-07-22', '5', '', '1/2\" CL 600 Body', '', '5', '5', 5, 'Machining', '73259930', 'CA16', 'KGS', '', 'I005-25', 'I005220725', 1, 1, '2025-07-22 19:24:30');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (22, 9, '2025-07-23', 'I006', '2025-07-23', 'jack', 'gandhipuram, singanallur', '002', '2025-07-23', '8', '1002', '1080 Stator', '', '100', '40', 100, 'qwerty', '123456', '002', 'KGS', 'MSS', 'I006-25', 'I006230725', 1, 1, '2025-07-23 15:39:02');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (21, 9, '2025-07-23', 'I006', '2025-07-23', 'jack', 'gandhipuram, singanallur', '002', '2025-07-23', '7', '1001', '1080 Rotor', '', '100', '40', 100, 'qwerty', '123456', '001', 'KGS', 'MSS', 'I006-25', 'I006230725', 1, 1, '2025-07-23 15:39:02');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (23, 9, '2025-07-23', 'I006', '2025-07-23', 'jack', 'gandhipuram, singanallur', '002', '2025-07-23', '5', '1003', '1/2\" CL 600 Body', '', '5', '2', 5, 'qwerty', '73259930', 'CA16', 'KGS', '', 'I006-25', 'I006230725', 1, 1, '2025-07-23 15:39:02');


#
# TABLE STRUCTURE FOR: inward_details
#

DROP TABLE IF EXISTS `inward_details`;

CREATE TABLE `inward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(50) NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(50) NOT NULL,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (4, '2025-06-20', 'I001', '2025-06-20', 'jack', 'gandhipuram, singanallur', '001', '2025-06-20', '1||2||1', '', '1080-rotor||1080-motor||1080-rotor', '', '100||100||100', '', '0001||0002||0001', NULL, 'KGS||KGS||KGS', '', 'I001-25', 'I001200625', 1, 0, '9,10,11');
INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (5, '2025-06-20', 'I002', '2025-06-20', 'jack', 'gandhipuram, singanallur', '002', '2025-06-20', '1||2', '', '1080-rotor||1080-motor', '', '100||100', '', '0001||0002', NULL, 'KGS||KGS', '', 'I002-25', 'I002200625', 1, 0, '12,13');
INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (6, '2025-06-20', 'I003', '2025-06-20', 'SIGMA POWER & ENERGY ENGINEERS', 'e-5 SIDCO INDUSTRIES ESTATE, THUVAKUDI', '001', '2025-06-20', '3', '', 'EH OUTER BOX', '', '100', '', '123456', NULL, 'KGS', '', 'I003-25', 'I003200625', 1, 0, '14');
INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (7, '2025-06-25', 'I004', '2025-06-25', 'IT Solution', 'Hoysala nagar, Ramamurthy signal, Kasthuri nagar', 'Hosur', '2025-06-25', '4', '', 'Stationary things', '', '2', 'Urgent needed', '00002', NULL, 'PACK', '', 'I004-25', 'I004250625', 1, 1, '15');
INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (8, '2025-07-22', 'I005', '2025-07-22', 'jack', 'gandhipuram, singanallur', '001', '2025-07-22', '7||8||8||5', '001||002||003||004', '1080 Rotor||1080 Stator||1080 Stator||1/2\" CL 600 Body', '', '100||100||100||5', 'qwerty||qwerty||qwerty||Machining', '123456||123456||123456||73259930', '1001||1002||002||CA16', 'KGS||KGS||KGS||KGS', 'MSS||MSS||MSS', 'I005-25', 'I005220725', 1, 1, '16,17,19,20');
INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (9, '2025-07-23', 'I006', '2025-07-23', 'jack', 'gandhipuram, singanallur', '002', '2025-07-23', '7||8||5', '1001||1002||1003', '1080 Rotor||1080 Stator||1/2\" CL 600 Body', '', '100||100||5', 'qwerty||qwerty||qwerty', '123456||123456||73259930', '001||002||CA16', 'KGS||KGS||KGS', 'MSS||MSS', 'I006-25', 'I006230725', 1, 0, '21,22,23');


#
# TABLE STRUCTURE FOR: inward_details_backup
#

DROP TABLE IF EXISTS `inward_details_backup`;

CREATE TABLE `inward_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(100) NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: job_data
#

DROP TABLE IF EXISTS `job_data`;

CREATE TABLE `job_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: job_details
#

DROP TABLE IF EXISTS `job_details`;

CREATE TABLE `job_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `joborderdate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext DEFAULT NULL,
  `category` longtext DEFAULT NULL,
  `jobdescription` longtext DEFAULT NULL,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: jobinward_data
#

DROP TABLE IF EXISTS `jobinward_data`;

CREATE TABLE `jobinward_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `joborderqty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobinward_details
#

DROP TABLE IF EXISTS `jobinward_details`;

CREATE TABLE `jobinward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `jobinwarddate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `category` longtext DEFAULT NULL,
  `jobdescription` longtext DEFAULT NULL,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobworkdc_delivery
#

DROP TABLE IF EXISTS `jobworkdc_delivery`;

CREATE TABLE `jobworkdc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `jobworkdc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `balanceqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (1, '2025-06-25', 1, NULL, 'Direct DC', 'PDC/25-26/001', '2025-06-25', 0, 'Tech AU', '', 'Avinashi Road, Hopes College', NULL, NULL, NULL, 'Stationary things', '', '2', '2', 'Urgent', '00002', '15015', 'PACK', 'PDC/25-26/001-25', 'PDC/25-26/001250625', 1, 1);


#
# TABLE STRUCTURE FOR: jobworkdc_delivery_backup
#

DROP TABLE IF EXISTS `jobworkdc_delivery_backup`;

CREATE TABLE `jobworkdc_delivery_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: jobworkdc_details
#

DROP TABLE IF EXISTS `jobworkdc_details`;

CREATE TABLE `jobworkdc_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` longtext DEFAULT NULL,
  `customerdcdate` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext DEFAULT NULL,
  `remarks` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `jobworkdc_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `delete_status`, `billtype`) VALUES (1, '2025-06-25', 'Direct DC', 'PDC/25-26/001', '2025-06-25', 0, 'Tech AU', '', '12:50:PM', 'Online Purchase', '', '', '', 'Avinashi Road, Hopes College', NULL, NULL, NULL, 'Stationary things', '', '2', 'Urgent', '00002', '15015', 'PACK', 'PDC/25-26/001-25', 'PDC/25-26/001250625', 1, 1, '');


#
# TABLE STRUCTURE FOR: jobworkdc_details_backup
#

DROP TABLE IF EXISTS `jobworkdc_details_backup`;

CREATE TABLE `jobworkdc_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` longtext DEFAULT NULL,
  `customerdcdate` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext DEFAULT NULL,
  `remarks` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: login_details
#

DROP TABLE IF EXISTS `login_details`;

CREATE TABLE `login_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userType` char(1) NOT NULL,
  `date` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `sub_menu_link` text DEFAULT NULL,
  `selectedMainMenu` text NOT NULL,
  `selectedSubMenu` text NOT NULL,
  `add_party` int(11) DEFAULT NULL,
  `add_expenses` int(11) DEFAULT NULL,
  `add_quotation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (1, 'A', '2017-01-26', 'admin', '', 'test@gmail.com', '876049652', '0000-00-00', 'admin', 'admin001', '1', '', '', '', NULL, NULL, NULL);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (5, 'U', '2018-05-02', 'purchase', 'Purchase Team', '', '', '1970-01-01', 'purchase', '123456', '1', 'purchase,inward,inward/view,inward/pending,stockmaster,daily_stockreports,customer/view', 'Purchase,Inward,Inward,Inward,Stock,Stock,Reports', 'Purchase Receipt,Add Inward,Inward Reports,Inward Pending,Add Stock,Daily Stock Reports,Party Reports', 1, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (6, 'U', '2018-05-02', 'Accounts', 'Accounts Team', '', '', '1970-01-01', 'Accounts', '123456', '1', 'invoice_statement/view,tax/view,cashbill/listing,purchase_statement/view,purchasetax/view,voucher,voucher/reports,stockmaster,daily_stockreports,itemwise_report,expenses/reports,quotation/view', 'Sales Invoice,Sales Invoice,Cash Bill,Purchase,Purchase,Voucher,Voucher,Stock,Stock,Stock,Reports,Reports', 'Invoice Party Statement,Invoice Tax Reports,Cash Bill Reports,Purchase Party Statement,Purchase Tax Reports,Add Voucher,Voucher Reports,Add Stock,Daily Stock Reports,Itemwise Reports,Expenses Reports,Quotation Reports', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (7, 'U', '2018-08-10', 'ramesh', 'developer', '', '', '1970-01-01', 'ramesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/reports,purchase_statement/view,purchasetax/view,stockmaster,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Stock,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Add Stock,Add Item', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (8, 'U', '2018-08-10', 'tester1', 'testing', '', '', '1970-01-01', 'tester1', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/view,purchase_statement/view,purchasetax/view,taxtype,uom,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Settings,Settings,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Tax Type,Add UOM,Add Item', 1, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (9, 'U', '2021-06-28', 'parmesh', 'developer', 'pshm956@gmail.com', '8344031191', '2021-06-28', 'parmesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,proforma_invoice/view', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Proforma Invoice Reports', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (10, 'U', '2023-09-12', 'jp', 'quotation', 'jp@idreamdevelopers.com', '7810028222', '2023-09-12', 'jp', '123456', '1', 'taxtype,uom,itemmaster,headers,profile,backup,support,usermaster', 'Settings,Settings,Settings,Settings,Settings,Settings,Settings,Settings', 'Tax Type,Add UOM,Add Item,Account Headers,Company Profile,Backup Settings,Support,User Manager', 1, 1, 1);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (12, 'U', '2025-06-20', 'Pradeepa ', 'Technical support', 'pradee@gmail.com', '9500995841', '2025-06-03', 'Pradeepa ', 'adminoo1', '1', '', '', '', 0, 0, 0);


#
# TABLE STRUCTURE FOR: materialdc_delivery
#

DROP TABLE IF EXISTS `materialdc_delivery`;

CREATE TABLE `materialdc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: materialdc_details
#

DROP TABLE IF EXISTS `materialdc_details`;

CREATE TABLE `materialdc_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` longtext DEFAULT NULL,
  `customerdcdate` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext DEFAULT NULL,
  `remarks` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: materialdc_details_backup
#

DROP TABLE IF EXISTS `materialdc_details_backup`;

CREATE TABLE `materialdc_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` longtext DEFAULT NULL,
  `customerdcdate` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext DEFAULT NULL,
  `remarks` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: mpt_report
#

DROP TABLE IF EXISTS `mpt_report`;

CREATE TABLE `mpt_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `mpt_report_no` varchar(100) NOT NULL,
  `mpt_date` varchar(100) NOT NULL,
  `customername` varchar(100) NOT NULL,
  `customerid` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `equipment_make` varchar(100) NOT NULL,
  `magnetic_powder_color` varchar(100) NOT NULL,
  `equipment_type` varchar(100) NOT NULL,
  `prod_spacing` varchar(100) NOT NULL,
  `procedure_ref` varchar(100) NOT NULL,
  `current_amps` varchar(100) NOT NULL,
  `stage_of_test` varchar(100) NOT NULL,
  `magnetisation` varchar(100) NOT NULL,
  `process` varchar(100) NOT NULL,
  `surface_condition` varchar(100) NOT NULL,
  `inspection_date` varchar(100) NOT NULL,
  `acceptance_standard` varchar(100) NOT NULL,
  `current` varchar(100) NOT NULL,
  `medium` varchar(100) NOT NULL,
  `light_indensity` varchar(100) NOT NULL,
  `fluosrecent` varchar(100) NOT NULL,
  `area_of_test` varchar(100) NOT NULL,
  `casting_temp` varchar(100) NOT NULL,
  `demagnetization` varchar(100) NOT NULL,
  `observation` varchar(100) NOT NULL,
  `po_no_dt` longtext NOT NULL,
  `description` longtext NOT NULL,
  `drawing_no` longtext NOT NULL,
  `heat_no` longtext NOT NULL,
  `mpi_no` longtext NOT NULL,
  `desp_qty` longtext NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_by` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `mpt_report` (`id`, `date`, `mpt_report_no`, `mpt_date`, `customername`, `customerid`, `grade`, `equipment_make`, `magnetic_powder_color`, `equipment_type`, `prod_spacing`, `procedure_ref`, `current_amps`, `stage_of_test`, `magnetisation`, `process`, `surface_condition`, `inspection_date`, `acceptance_standard`, `current`, `medium`, `light_indensity`, `fluosrecent`, `area_of_test`, `casting_temp`, `demagnetization`, `observation`, `po_no_dt`, `description`, `drawing_no`, `heat_no`, `mpi_no`, `desp_qty`, `status`, `created_by`) VALUES (1, '2025-10-22', 'MPT001', '22-10-2025', 'jack', '1', '3', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm', '22-10-2025', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm', 'Flourecent', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm', 'mtcForm,mtcForm,mtcForm,mtcForm', 'Coal Nozzle,Coal Nozzle,Coal Nozzle,Coal Nozzle', '001,001,001,001', 'mtcForm,mtcForm,mtcForm,mtcForm', 'mtcForm,mtcForm,mtcForm,mtcForm', 'mtcForm,mtcForm,mtcForm,mtcForm', 1, '2025-10-22 19:09:39');


#
# TABLE STRUCTURE FOR: mtc_report
#

DROP TABLE IF EXISTS `mtc_report`;

CREATE TABLE `mtc_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `tcno` varchar(100) NOT NULL,
  `tcdate` varchar(100) NOT NULL,
  `heatno` varchar(100) NOT NULL,
  `customername` varchar(100) NOT NULL,
  `customerid` varchar(100) NOT NULL,
  `purchaseorderno` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `heat_treatment` text NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `drawing_no` varchar(100) NOT NULL,
  `partno` varchar(100) NOT NULL,
  `poured_qty` varchar(100) NOT NULL,
  `chemical_element` text NOT NULL,
  `chemical_minvalue` text NOT NULL,
  `chemical_maxvalue` text NOT NULL,
  `chemical_actualvalue` text NOT NULL,
  `mechanical_element` longtext NOT NULL,
  `mechanical_minvalue` text NOT NULL,
  `mechanical_maxvalue` text NOT NULL,
  `mechanical_actualvalue` text NOT NULL,
  `remarks` longtext NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `mtc_report` (`id`, `date`, `tcno`, `tcdate`, `heatno`, `customername`, `customerid`, `purchaseorderno`, `grade`, `heat_treatment`, `product_code`, `itemname`, `drawing_no`, `partno`, `poured_qty`, `chemical_element`, `chemical_minvalue`, `chemical_maxvalue`, `chemical_actualvalue`, `mechanical_element`, `mechanical_minvalue`, `mechanical_maxvalue`, `mechanical_actualvalue`, `remarks`, `status`) VALUES (1, '2025-10-08', 'MTC001', '08-10-2025', '0001', 'jack', '1', 'P001', '3', 'SOLUTION ANNEALING: Heated  to  1080°C soak for  3 Hrs and  then  water quenched.', '002', 'Coal Nozzle', '001', '001', '10', 'C,Mn,Si,P,S,Cr,Ni,Mo,,,,,,,', '-,-,-,-,-,17.000,9.000,2.000,,,,,,,', '-,-,-,-,-,17.000,9.000,2.000,,,,,,,', '-,-,-,-,-,15,8,1,,,,,,,', 'Yield Strength,Tensile Strength,% Elongation,% Reduction of Area,Hardness,Bend Test,Impact Test in Joules', '205,485,30,-,-,-,-', '-,-,-,-,200,-,-', '-,-,-,-,-,-,-', '<p><span style=\"font-size: 14px;\">Separate test bar poured and the same bar tested for chemical and mechanical properties</span></p><p><span style=\"font-size: 14px;\">&nbsp; Tensile Testing conducted on round specimen at room temperature</span></p><p><span style=\"font-size: 14px;\">&nbsp;Visual inspection carried out at as per MSS SP-55, found satisfied</span></p><p>Radio active contamination not found in the castings</p>', 1);


#
# TABLE STRUCTURE FOR: po_party_statements
#

DROP TABLE IF EXISTS `po_party_statements`;

CREATE TABLE `po_party_statements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (1, '2025-06-21', '2025-06-21', '-', 'P001', 3, 'CK PRIME ALLOYS', NULL, NULL, 'EH OUTER BOX', NULL, '212400.00', '-', '-', '-', NULL, '-', '212400', NULL, '-', '-', '-', '-', '-', '212400.00', '-', NULL, '-', NULL, '212400.00', NULL, 'OO1', '2025-06-21', '1', 'P001210625', 'P001-2025', '1');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (2, '2025-06-21', NULL, 'V/25-26/-003', NULL, 0, 'CK PRIME ALLOYS', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '210000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Cash', NULL, '2400', NULL, '-', NULL, '-', NULL, '1', NULL, NULL, NULL);
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (3, '2025-06-21', '2025-06-21', '-', 'P0002', 3, 'CK PRIME ALLOYS', NULL, NULL, 'EH OUTER BOX', NULL, '442500.00', '-', '-', '-', NULL, '-', '652500', NULL, '-', '-', '-', '-', '-', '442500.00', '-', NULL, '-', NULL, '442500.00', NULL, '0098', '2025-06-21', '1', 'P0002210625', 'P0002-2025', '2');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (4, '2025-06-24', '2025-06-24', '-', 'P0003', 5, 'Gateway', NULL, NULL, 'Stationary things', NULL, '2364.00', '-', '-', '-', NULL, '-', '2364', NULL, '-', '-', '-', '-', '-', '2346.00', '-', NULL, '-', NULL, '2364.00', NULL, '001', '2025-06-24', '1', 'P0003240625', 'P0003-2025', '3');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (5, '2025-06-24', NULL, 'V/25-26/-005', NULL, 0, 'Gateway', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '1864', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Cash', NULL, '500', NULL, '-', NULL, '-', NULL, '1', NULL, NULL, NULL);
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (6, '2025-06-24', '2025-06-24', 'C001', 'P003', 0, 'Gateway', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, '868.5', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Package damage', NULL, NULL, '995.50', NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL);
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (7, '2025-09-11', '2025-09-11', '-', 'P0004', 3, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle||Coal Nozzle', NULL, '177000.00', '-', '-', '-', NULL, '-', '1891500', NULL, '-', '-', '-', '-', '-', '88500.00||88500.00', '-', NULL, '-', NULL, '177000.00', NULL, '001', '2025-09-11', '1', 'P0004110925', 'P0004-2025', '5');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (10, '2025-09-11', '2025-09-11', '-', 'P006', 0, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle||Coal Nozzle', NULL, '212400.00', '-', '-', '-', NULL, '-', '2174700', NULL, '-', '-', '-', '-', '-', '106200.00||106200.00', '-', NULL, '-', NULL, '212400.00', NULL, '001', '2025-09-11', '1', NULL, NULL, '6');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (11, '2025-11-14', '2025-11-14', '-', 'P0007', 3, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', NULL, '30975000.00', '-', '-', '-', NULL, '-', '33149700', NULL, '-', '-', '-', '-', '-', '8850000.00||4425000.00||8850000.00||8850000.00||13275000.00', '-', NULL, '-', NULL, '30975000.00', NULL, '002', '2025-11-14', '1', 'P0007141125', 'P0007-2025', '7');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (12, '2025-11-14', '2025-11-14', '-', 'P0008', 3, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', NULL, '26550000.00', '-', '-', '-', NULL, '-', '59699700', NULL, '-', '-', '-', '-', '-', '4425000.00||4425000.00||4425000.00||8850000.00||4425000.00||17700000.00', '-', NULL, '-', NULL, '26550000.00', NULL, '003', '2025-11-14', '1', 'P0008141125', 'P0008-2025', '8');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (13, '2025-11-14', '2025-11-14', '-', 'P0009', 3, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', NULL, '44250000.00', '-', '-', '-', NULL, '-', '103949700', NULL, '-', '-', '-', '-', '-', '8850000.00||8850000.00||4425000.00||22125000.00', '-', NULL, '-', NULL, '44250000.00', NULL, '004', '2025-11-14', '1', 'P0009141125', 'P0009-2025', '9');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (14, '2025-11-14', '2025-11-14', '-', 'P0010', 3, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', NULL, '4425000.00', '-', '-', '-', NULL, '-', '108374700', NULL, '-', '-', '-', '-', '-', '4425000.00||4425000.00||4425000.00||4425000.00||4425000.00', '-', NULL, '-', NULL, '4425000.00', NULL, '1', '2025-11-14', '1', 'P0010141125', 'P0010-2025', '10');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (15, '2025-11-14', '2025-11-14', '-', 'P0011', 3, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle', NULL, '22125000.00', '-', '-', '-', NULL, '-', '130499700', NULL, '-', '-', '-', '-', '-', '22125000.00', '-', NULL, '-', NULL, '22125000.00', NULL, '001', '2025-11-14', '1', 'P0011141125', 'P0011-2025', '11');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (16, '2025-11-14', '2025-11-14', '-', 'P0012', 3, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle', NULL, '22125000.00', '-', '-', '-', NULL, '-', '152624700', NULL, '-', '-', '-', '-', '-', '22125000.00', '-', NULL, '-', NULL, '22125000.00', NULL, '1', '2025-11-14', '1', 'P0012141125', 'P0012-2025', '12');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (17, '2025-11-14', '2025-11-14', '-', 'P0013', 3, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle', NULL, '22125000.00', '-', '-', '-', NULL, '-', '174749700', NULL, '-', '-', '-', '-', '-', '22125000.00', '-', NULL, '-', NULL, '22125000.00', NULL, '001', '2025-11-14', '1', 'P0013141125', 'P0013-2025', '13');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (18, '2025-11-15', '2025-11-15', '-', 'P0014', 3, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle||Coal Nozzle', NULL, '8850000.00', '-', '-', '-', NULL, '-', '183599700', NULL, '-', '-', '-', '-', '-', '8850000.00||4425000.00', '-', NULL, '-', NULL, '8850000.00', NULL, '005', '2025-11-15', '1', 'P0014151125', 'P0014-2025', '14');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (19, '2025-11-15', '2025-11-15', '-', 'P0015', 3, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', NULL, '53100000.00', '-', '-', '-', NULL, '-', '236699700', NULL, '-', '-', '-', '-', '-', '22125000.00||8850000.00||22125000.00||4425000.00', '-', NULL, '-', NULL, '53100000.00', NULL, '006', '2025-11-15', '1', 'P0015151125', 'P0015-2025', '15');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (20, '2025-11-15', '2025-11-15', '-', 'P0016', 3, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', NULL, '17700000.00', '-', '-', '-', NULL, '-', '254399700', NULL, '-', '-', '-', '-', '-', '4425000.00||4425000.00||8850000.00||4425000.00', '-', NULL, '-', NULL, '17700000.00', NULL, '777', '2025-11-15', '1', 'P0016151125', 'P0016-2025', '16');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (21, '2025-11-15', '2025-11-15', '-', 'P0017', 3, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', NULL, '17700000.00', '-', '-', '-', NULL, '-', '272099700', NULL, '-', '-', '-', '-', '-', '4425000.00||4425000.00||8850000.00||4425000.00', '-', NULL, '-', NULL, '17700000.00', NULL, '888', '2025-11-15', '1', 'P0017151125', 'P0017-2025', '17');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (22, '2025-11-15', '2025-11-15', '-', 'P0018', 3, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', NULL, '17700000.00', '-', '-', '-', NULL, '-', '289799700', NULL, '-', '-', '-', '-', '-', '4425000.00||4425000.00||8850000.00||4425000.00', '-', NULL, '-', NULL, '17700000.00', NULL, '1010', '2025-11-15', '1', 'P0018151125', 'P0018-2025', '18');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (23, '2025-11-17', '2025-11-17', '-', 'P0019', 5, 'Gateway', NULL, NULL, 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', NULL, '132750000.00', '-', '-', '-', NULL, '-', '132750868.5', NULL, '-', '-', '-', '-', '-', '44250000.00||44250000.00||44250000.00||22125000.00', '-', NULL, '-', NULL, '132750000.00', NULL, '0019', '2025-11-17', '1', 'P0019171125', 'P0019-2025', '19');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (24, '2025-11-17', '2025-11-17', '-', 'P0020', 5, 'Gateway', NULL, NULL, 'Zozzle||Zozzle||Zozzle||Zozzle', NULL, '23600000.00', '-', '-', '-', NULL, '-', '156350868.5', NULL, '-', '-', '-', '-', '-', '8850000.00||5900000.00||8850000.00||5900000.00', '-', NULL, '-', NULL, '23600000.00', NULL, '11313', '2025-11-17', '1', 'P0020171125', 'P0020-2025', '20');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (25, '2025-11-17', '2025-11-17', '-', 'P0021', 5, 'Gateway', NULL, NULL, 'Zozzle||Zozzle', NULL, '14750000.00', '-', '-', '-', NULL, '-', '171100868.5', NULL, '-', '-', '-', '-', '-', '8850000.00||5900000.00', '-', NULL, '-', NULL, '14750000.00', NULL, '1414', '2025-11-17', '1', 'P0021171125', 'P0021-2025', '21');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (26, '2025-11-17', '2025-11-17', '-', 'P0022', 5, 'Gateway', NULL, NULL, 'Zozzle||Zozzle', NULL, '14750000.00', '-', '-', '-', '-', '-', '185850868.5', NULL, '-', '-', '-', '-', '-', '5900000.00||8850000.00', '-', NULL, '-', NULL, '14750000.00', NULL, '1414', '2025-11-17', '1', 'P0022171125', 'P0022-2025', '22');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (27, '2025-11-17', '2025-11-17', '-', 'P0023', 3, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle||Zozzle', NULL, '30975000.00', '-', '-', '-', '-', '-', '320774700', NULL, '-', '-', '-', '-', '-', '4425000.00||8850000.00||4425000.00||4425000.00||8850000.00', '-', NULL, '-', NULL, '30975000.00', NULL, '100', '2025-11-17', '1', 'P0023171125', 'P0023-2025', '23');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (28, '2025-11-17', '2025-11-17', '-', 'P0024', 5, 'Gateway', NULL, NULL, 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', NULL, '57525000.00', '-', '-', '-', '-', '-', '243375868.5', NULL, '-', '-', '-', '-', '-', '22125000.00||22125000.00||13275000.00||8850000.00', '-', NULL, '-', NULL, '57525000.00', NULL, '1515', '2025-11-17', '1', 'P0024171125', 'P0024-2025', '24');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (29, '2025-11-17', '2025-11-17', '-', 'P0025', 5, 'Gateway', NULL, NULL, 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', NULL, '44250000.00', '-', '-', '-', '-', '-', '287625868.5', NULL, '-', '-', '-', '-', '-', '8850000.00||8850000.00||8850000.00||8850000.00||8850000.00||8850000.00||8850000.00||8850000.00', '-', NULL, '-', NULL, '44250000.00', NULL, '1616', '2025-11-17', '1', 'P0025171125', 'P0025-2025', '25');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (34, '2025-11-19', '2025-11-19', '-', 'P026', 0, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', NULL, '17700010.20', '-', '-', '-', '-', '-', '338474710.2', NULL, '-', '-', '-', '-', '-', '4425000.00||4425000.00||4425000.00||4425000.00', '-', NULL, '-', NULL, '17700010.20', NULL, '26', '2025-11-19', '1', 'P026191125', 'P026-2025', '26');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (33, '2025-11-19', '2025-11-19', '-', 'P027', 0, 'Jack', NULL, NULL, 'Coal Nozzle||Coal Nozzle', NULL, '13275000.00', '-', '-', '-', '-', '-', '97350000', NULL, '-', '-', '-', '-', '-', '8850000.00||4425000.00', '-', NULL, '-', NULL, '13275000.00', NULL, '0027', '2025-11-19', '1', 'P027191125', 'P027-2025', '27');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (35, '2025-11-20', '2025-11-20', '-', 'P0028', 3, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle||Coal Nozzle', NULL, '8850000.00', '-', '-', '-', '-', '-', '365024710.2', NULL, '-', '-', '-', '-', '-', '8850000.00||', '-', NULL, '-', NULL, '8850000.00', NULL, '002', '2025-11-20', '1', 'P0028201125', 'P0028-2025', '30');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (36, '2025-11-20', '2025-11-20', '-', 'P0028', 3, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle||Coal Nozzle', NULL, '8850000.00', '-', '-', '-', '-', '-', '373874710.2', NULL, '-', '-', '-', '-', '-', '8850000.00||', '-', NULL, '-', NULL, '8850000.00', NULL, '002', '2025-11-20', '1', 'P0028201125', 'P0028-2025', '31');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (37, '2025-11-20', '2025-11-20', '-', 'P0032', 3, 'CK PRIME ALLOYS', NULL, NULL, 'Coal Nozzle||Coal Nozzle', NULL, '8850000.00', '-', '-', '-', '-', '-', '382724710.2', NULL, '-', '-', '-', '-', '-', '8850000.00||', '-', NULL, '-', NULL, '8850000.00', NULL, '002', '2025-11-20', '1', 'P0032201125', 'P0032-2025', '32');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (38, '2025-11-20', '2025-11-20', '-', 'P0033', 8, 'Jack', NULL, NULL, 'Coal Nozzle', NULL, '221250000.00', '-', '-', '-', '-', '-', '318600000', NULL, '-', '-', '-', '-', '-', '221250000.00', '-', NULL, '-', NULL, '221250000.00', NULL, '0033', '2025-11-20', '1', 'P0033201125', 'P0033-2025', '33');


#
# TABLE STRUCTURE FOR: po_party_statements_backup
#

DROP TABLE IF EXISTS `po_party_statements_backup`;

CREATE TABLE `po_party_statements_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: preference_details
#

DROP TABLE IF EXISTS `preference_details`;

CREATE TABLE `preference_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `sed` varchar(255) DEFAULT NULL,
  `edc` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: preference_settings
#

DROP TABLE IF EXISTS `preference_settings`;

CREATE TABLE `preference_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotationPrefix` varchar(255) NOT NULL,
  `quotation` varchar(255) NOT NULL,
  `expenses` varchar(255) NOT NULL,
  `expensePrefix` varchar(255) NOT NULL,
  `dc` varchar(255) NOT NULL,
  `voucherPrefix` varchar(255) NOT NULL,
  `voucher` varchar(255) NOT NULL,
  `debitPrefix` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `creditPrefix` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `purchasePrefix` varchar(255) NOT NULL,
  `purchase` varchar(255) NOT NULL,
  `invoicePrefix` varchar(255) NOT NULL,
  `invoice` varchar(255) NOT NULL,
  `salesdcPrefix` varchar(255) NOT NULL,
  `materialdcPrefix` varchar(255) NOT NULL,
  `jobdcPrefix` varchar(255) NOT NULL,
  `proforma_invoicePrefix` varchar(255) NOT NULL,
  `proforma_invoice` varchar(255) NOT NULL,
  `inwardPrefix` varchar(255) NOT NULL,
  `inward` varchar(255) NOT NULL,
  `cashbillPrefix` varchar(255) NOT NULL,
  `cashbill_invoice` varchar(255) NOT NULL,
  `mtcPrefix` varchar(100) NOT NULL,
  `tcno` varchar(100) NOT NULL,
  `insPrefix` varchar(100) NOT NULL,
  `insno` varchar(100) NOT NULL,
  `utPrefix` varchar(100) NOT NULL,
  `utno` varchar(100) NOT NULL,
  `mptPrefix` varchar(100) NOT NULL,
  `mptno` varchar(100) NOT NULL,
  `dptPrefix` varchar(100) NOT NULL,
  `dptno` varchar(100) NOT NULL,
  `creditnote` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) NOT NULL,
  `supplierpurchaseorder` varchar(100) NOT NULL,
  `jobworkdc` varchar(255) DEFAULT NULL,
  `materialdc` varchar(255) DEFAULT NULL,
  `cmp_companyname` varchar(255) NOT NULL,
  `cmp_phoneno` varchar(255) NOT NULL,
  `cmp_mobileno` varchar(255) NOT NULL,
  `cmp_address1` varchar(255) NOT NULL,
  `cmp_address2` varchar(255) NOT NULL,
  `cmp_city` varchar(255) NOT NULL,
  `cmp_pincode` varchar(255) NOT NULL,
  `cmp_stateCode` varchar(255) NOT NULL,
  `cmp_website` varchar(255) NOT NULL,
  `cmp_emailid` varchar(255) NOT NULL,
  `cmp_logo` varchar(255) NOT NULL,
  `cont_companyname` varchar(255) NOT NULL,
  `cont_phoneno` varchar(255) NOT NULL,
  `cont_mobileno` varchar(255) NOT NULL,
  `cont_address1` varchar(255) NOT NULL,
  `cont_address2` varchar(255) NOT NULL,
  `cont_city` varchar(255) NOT NULL,
  `cont_pincode` varchar(255) NOT NULL,
  `cont_stateCode` varchar(255) NOT NULL,
  `cont_website` varchar(255) NOT NULL,
  `cont_emailid` varchar(255) NOT NULL,
  `cont_logo` varchar(255) NOT NULL,
  `discountBy` varchar(255) NOT NULL,
  `invoiceBy` varchar(255) NOT NULL,
  `itemType` varchar(255) NOT NULL,
  `bill_type` varchar(255) DEFAULT NULL,
  `quot_bill_type` varchar(255) DEFAULT NULL,
  `voucher_receivable` varchar(255) DEFAULT NULL,
  `voucher_payable` varchar(255) DEFAULT NULL,
  `last_backup` date NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `inward_add` varchar(255) NOT NULL,
  `cashbill_add` varchar(255) NOT NULL,
  `cashbill_tax_type` varchar(255) NOT NULL,
  `priceType` varchar(255) DEFAULT NULL,
  `priceType1` varchar(255) DEFAULT NULL,
  `sales_dc` int(11) NOT NULL,
  `material_dc` int(11) NOT NULL,
  `jobwork_dc` int(11) NOT NULL,
  `cpo_type` varchar(255) NOT NULL,
  `spo_type` varchar(255) NOT NULL,
  `proforma_type` varchar(255) NOT NULL,
  `attendance` int(11) NOT NULL,
  `status` int(10) NOT NULL,
  `einvoice` int(11) NOT NULL,
  `eway` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `preference_settings` (`id`, `quotationPrefix`, `quotation`, `expenses`, `expensePrefix`, `dc`, `voucherPrefix`, `voucher`, `debitPrefix`, `debit`, `creditPrefix`, `credit`, `purchasePrefix`, `purchase`, `invoicePrefix`, `invoice`, `salesdcPrefix`, `materialdcPrefix`, `jobdcPrefix`, `proforma_invoicePrefix`, `proforma_invoice`, `inwardPrefix`, `inward`, `cashbillPrefix`, `cashbill_invoice`, `mtcPrefix`, `tcno`, `insPrefix`, `insno`, `utPrefix`, `utno`, `mptPrefix`, `mptno`, `dptPrefix`, `dptno`, `creditnote`, `purchaseorder`, `supplierpurchaseorder`, `jobworkdc`, `materialdc`, `cmp_companyname`, `cmp_phoneno`, `cmp_mobileno`, `cmp_address1`, `cmp_address2`, `cmp_city`, `cmp_pincode`, `cmp_stateCode`, `cmp_website`, `cmp_emailid`, `cmp_logo`, `cont_companyname`, `cont_phoneno`, `cont_mobileno`, `cont_address1`, `cont_address2`, `cont_city`, `cont_pincode`, `cont_stateCode`, `cont_website`, `cont_emailid`, `cont_logo`, `discountBy`, `invoiceBy`, `itemType`, `bill_type`, `quot_bill_type`, `voucher_receivable`, `voucher_payable`, `last_backup`, `itemcode`, `inward_add`, `cashbill_add`, `cashbill_tax_type`, `priceType`, `priceType1`, `sales_dc`, `material_dc`, `jobwork_dc`, `cpo_type`, `spo_type`, `proforma_type`, `attendance`, `status`, `einvoice`, `eway`) VALUES (1, 'Q', '', '', 'E', '', 'V/25-26/-', '', 'D', '001', 'C', '', 'P', '', 'INV/25-26/-', '', 'SDC/25-26/-', 'MDC/25-26/-', 'PDC/25-26/', 'PI/25-26/', '', 'I', '', 'CB', '001', 'MTC', '', 'INS', '001', 'UT', '', 'MPT', '', 'DPT', '', NULL, '', '', '', '001', 'Myoffice Solutions', '7373333321', '8608701222', ' #91 Dr. Jaganathan Nagar', 'Civil Aerodrome Post, Coimbatore', 'Coimbatore', '641014', '33', 'www.idreamdevelopers.org', 'info@idreamdevelopers.com', '12832299_1579401915712151_5416626780361493206_n.png', 'IDREAMDEVELOPERS', '7373333321', '8608701333', ' #91 Dr. Jaganathan Nagar', 'Civil Aerodrome Post, Coimbatore', 'Coimbatore', '641014', '33', 'www.idreamdevelopers.com', 'info@idreamdevelopers.com', 'idream_logo.PNG', 'amount_wise', 'without_stock', 'with_item', 'Overall Tax', 'Overall Tax', 'Without Invoice', 'Without Purchase', '2025-03-01', '1', 'With Inward', 'Without Cashbill', 'Overall Tax', '1', '0', 1, 0, 3, 'Overall Tax', 'Overall Tax', 'Overall Tax', 0, 1, 0, 0);


#
# TABLE STRUCTURE FOR: profile
#

DROP TABLE IF EXISTS `profile`;

CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `companyname` varchar(255) DEFAULT NULL,
  `softwarename` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `stateCode` varchar(255) NOT NULL,
  `emailid` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `gstin` varchar(225) DEFAULT NULL,
  `aadharno` varchar(225) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `bankname` varchar(255) DEFAULT NULL,
  `accountno` varchar(255) DEFAULT NULL,
  `bankbranch` varchar(255) DEFAULT NULL,
  `ifsccode` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `profile` (`id`, `date`, `companyname`, `softwarename`, `mobileno`, `phoneno`, `address1`, `address2`, `city`, `pincode`, `stateCode`, `emailid`, `website`, `tinno`, `cstno`, `gstin`, `aadharno`, `status`, `username`, `password`, `bankname`, `accountno`, `bankbranch`, `ifsccode`, `state`) VALUES (1, NULL, 'CK PRIME ALLOYS', 'MYOFFICE ERP', '8608701222', '9159531600', 'SF.NO:845B, Door No:1J(4) Annur road, Rayarpalayam, Karumathampatti', 'Avinashi Road, Hopes College', 'Coimbatore', '641659', 'Karnataka', 'info@idreamdevelopers.com', 'www.ckprimealloys.com', '12345', '54321', '29AABCT1332L000', '', '1', 'admin', 'admin001', '', '', '', '', NULL);


#
# TABLE STRUCTURE FOR: proforma_invoice_details
#

DROP TABLE IF EXISTS `proforma_invoice_details`;

CREATE TABLE `proforma_invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `dcnos` longtext DEFAULT NULL,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `proforma_invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `bill_type`, `invoicetype`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`) VALUES (1, '2025-06-25', '2025-06-25', '101', '2025-06-25', 'PI/25-26/001', NULL, 'Sales Invoice', NULL, 4, 'IT Solution', 'Hoysala nagar, Ramamurthy signal, Kasthuri nagar, Bangalore, Karnataka', 'Hosur', 'Eicher', 'TN7 V1234', 'intrastate', 'intrastate', 'sgst', 'cgst', '', NULL, NULL, NULL, '00002', '15015', 'Stationary things', '', 'PACK', '170', '12', '2040.00', '0', 'amount_wise', '0', '2040.00', '7.5', '154.35', '7.5', '154.35', '15', '', NULL, '2040.00', '6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '12', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2366.70', 'PI/25-26/001250625', 'PI/25-26/001-2025', 1, 1);


#
# TABLE STRUCTURE FOR: proforma_invoice_details_backup
#

DROP TABLE IF EXISTS `proforma_invoice_details_backup`;

CREATE TABLE `proforma_invoice_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `dcnos` longtext DEFAULT NULL,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) NOT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: proforma_invoice_reports
#

DROP TABLE IF EXISTS `proforma_invoice_reports`;

CREATE TABLE `proforma_invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `proforma_invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `uom`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2025-06-25', 'PI/25-26/001', '2025-06-25', NULL, NULL, 4, 'IT Solution', NULL, NULL, NULL, 'Hoysala nagar, Ramamurthy signal, Kasthuri nagar, Bangalore, Karnataka', 'intrastate', 'intrastate', 'Hosur', 'TN7 V1234', NULL, '2025-06-25', '101', NULL, '00002', '15015', NULL, 'Stationary things', '', '1', '12', 'PACK', NULL, NULL, '2040.00', NULL, NULL, '2366.70', NULL, NULL, '1', 'PI/25-26/001-2025', 'PI/25-26/001250625', '1');


#
# TABLE STRUCTURE FOR: proinvoice_party_statement
#

DROP TABLE IF EXISTS `proinvoice_party_statement`;

CREATE TABLE `proinvoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `proinvoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '-', '-', NULL, '2025-06-25', 'PI/25-26/001', 4, 'IT Solution', '', '', '', 'Stationary things', '', '', '', NULL, NULL, '', '', '1', '2025-06-25', '2025-06-25', '2366.70', '-', '-', '', '', '-', '-', NULL, '2844.2', '-', '-', '-', '-', '2366.70', '-', '2366.70', NULL, NULL, 'PI/25-26/001-2025', 'PI/25-26/001250625', '1');


#
# TABLE STRUCTURE FOR: purchase_collection
#

DROP TABLE IF EXISTS `purchase_collection`;

CREATE TABLE `purchase_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `date_po` date NOT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) NOT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `currentlypaid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `purchase_collection` (`id`, `date`, `date_po`, `purchasedate`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `suppliername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bamount`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `purchaseno`, `currentlypaid`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `payment`, `paid`, `invoiceamt`, `invoiceno`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (1, '2025-06-21', '0000-00-00', NULL, NULL, '2025-06-21', NULL, 'V/25-26/-003', 'CK PRIME ALLOYS', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, '2400', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `purchase_collection` (`id`, `date`, `date_po`, `purchasedate`, `invoicedate`, `receiptdate`, `throughcheck`, `receiptno`, `suppliername`, `mobileno`, `totalamount`, `purpose`, `alreadypaid`, `alreadybalance`, `chamount`, `banktransfer`, `bamount`, `bankamount`, `chequeno`, `paymentmode`, `amount`, `purchaseno`, `currentlypaid`, `balance`, `status`, `paymentdetails`, `overallamount`, `receiptamt`, `payment`, `paid`, `invoiceamt`, `invoiceno`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (2, '2025-06-24', '0000-00-00', NULL, NULL, '2025-06-24', NULL, 'V/25-26/-005', 'Gateway', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, '1', 'Cash', NULL, NULL, NULL, '500', NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: purchase_details
#

DROP TABLE IF EXISTS `purchase_details`;

CREATE TABLE `purchase_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchasetype` varchar(100) NOT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `heatno` text DEFAULT NULL,
  `itemid` text DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `weight` varchar(20) NOT NULL,
  `grade` varchar(50) NOT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (1, '2025-06-21', '2025-06-21', '2025-06-21', 'Direct Purchase', 'P001', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', 'OO1', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '123456', NULL, NULL, NULL, 'EH OUTER BOX', 'KGS', '', '', '15000', '12', '180000.00', '0', 'amount_wise', '0', '180000.00', '9', '16200.00', '9', '16200.00', '18', '32400.00', '212400.00', '212400.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '212400.00', 'P001210625', 'P001-2025', 1, '212400.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (2, '2025-06-21', '2025-06-21', '2025-06-21', 'purchase Order', 'P002', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '0098', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '123456', NULL, NULL, NULL, 'EH OUTER BOX', 'KGS', '', '', '15000', '25', '375000.00', '0', 'amount_wise', '0', '375000.00', '9', '33750.00', '9', '33750.00', '9', '33750.00', '442500.00', '442500.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '442500.00', 'P0002210625', 'P0002-2025', 1, '442500.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (3, '2025-06-24', '2025-06-24', '2025-06-24', 'Direct Purchase', 'P003', 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '001', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '00002', NULL, NULL, NULL, 'Stationary things', 'PACK', '', '', '170', '12', '2040.00', '0', 'amount_wise', '0', '2040.00', '7.5', '153.00', '7.5', '153.00', '15', '306.00', '2346.00', '2364.00', '6', '0', '0.00', '0', '0.00', '0', '0.00', '6.00', '12', '0', '0.00', '0', '0.00', '0', '0.00', '12.00', '0', '0', '0', '2364.00', 'P0003240625', 'P0003-2025', 1, '2364.00', 1, 0);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (4, '2025-09-11', '2025-09-11', '2025-09-11', 'purchase Order', 'P004', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '001', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '123456||123456', '002||002', '001||001', '1||1', 'Coal Nozzle||Coal Nozzle', 'KGS||KGS', '', '', '15000||15000', '5||5', '75000.00||75000.00', '0||0', 'amount_wise', '0||0', '75000.00||75000.00', '9||9', '6750.00||6750.00', '9||9', '6750.00||6750.00', '9||9', '6750.00||6750.00', '88500.00||88500.00', '177000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '177000.00', 'P0004110925', 'P0004-2025', 1, '177000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (5, '2025-09-11', '2025-09-11', '2025-09-11', 'purchase Order', 'P005', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '001', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '123456||123456', '002||002', '001||001', '1||1', 'Coal Nozzle||Coal Nozzle', 'KGS||KGS', '', '', '15000||15000', '5||5', '75000.00||75000.00', '0||0', 'amount_wise', '0||0', '75000.00||75000.00', '9||9', '6750.00||6750.00', '9||9', '6750.00||6750.00', '9||9', '6750.00||6750.00', '88500.00||88500.00', '177000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '177000.00', 'P0004110925', 'P0004-2025', 1, '177000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (6, '2025-09-11', '2025-09-11', '2025-09-11', 'purchase Order', 'P006', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '001', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '123456||123456', '002||002', '001||002', '1||1', 'Coal Nozzle||Coal Nozzle', 'KGS||KGS', '', '', '15000||15000', '6||6', '90000.00||90000.00', '0||0', 'amount_wise', '0||0', '90000.00||90000.00', '9||9', '8100.00||8100.00', '9||9', '8100.00||8100.00', '9||9', '6750.00||6750.00', '106200.00||106200.00', '212400.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '212400.00', 'P0006110925', 'P0006-2025', 1, '177000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (7, '2025-11-14', '2025-11-14', '2025-11-14', 'purchase Order', 'P007', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '002', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '123456||123456||123456||123456||123456', '002||002||002||002||002', '101||102||103||104||105', '1||1||1||1||1', 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', 'KGS||KGS||KGS||KGS||KGS', '', '', '15000||15000||15000||15000||15000', '2||1||2||2||3', '7500000.00||3750000.00||7500000.00||7500000.00||11250000.00', '0||0||0||0||0', 'amount_wise', '0.00||0.00||0.00||0.00||0.00', '7500000.00||3750000.00||7500000.00||7500000.00||11250000.00', '9||9||9||9||9', '675000.00||337500.00||675000.00||675000.00||1012500.00', '9||9||9||9||9', '675000.00||337500.00||675000.00||675000.00||1012500.00', '18||18||18||18||18', '1350000.00||675000.00||1350000.00||1350000.00||2025000.00', '8850000.00||4425000.00||8850000.00||8850000.00||13275000.00', '30975000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1||1', '30975000.00', 'P0007141125', 'P0007-2025', 1, '30975000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (8, '2025-11-14', '2025-11-14', '2025-11-14', 'purchase Order', 'P008', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '003', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '123456||123456||123456||123456||123456||123456', '002||002||002||002||002||002', '101||102||103||104||105||106', '1||1||1||1||1||1', 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', 'KGS||KGS||KGS||KGS||KGS||KGS', '', '', '15000||15000||15000||15000||15000||15000', '1||1||1||2||1||4', '3750000.00||3750000.00||3750000.00||7500000.00||3750000.00||15000000.00', '0||0||0||0||0||0', 'amount_wise', '0.00||0.00||0.00||0.00||0.00||0.00', '3750000.00||3750000.00||3750000.00||7500000.00||3750000.00||15000000.00', '9||9||9||9||9||9', '337500.00||337500.00||337500.00||675000.00||337500.00||1350000.00', '9||9||9||9||9||9', '337500.00||337500.00||337500.00||675000.00||337500.00||1350000.00', '18||18||18||18||18||18', '675000.00||675000.00||675000.00||1350000.00||675000.00||2700000.00', '4425000.00||4425000.00||4425000.00||8850000.00||4425000.00||17700000.00', '26550000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1||1||1', '26550000.00', 'P0008141125', 'P0008-2025', 1, '26550000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (9, '2025-11-14', '2025-11-14', '2025-11-14', 'purchase Order', 'P009', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '004', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '123456||123456||123456||123456', '002||002||002||002', '200||200||20||200', '1||1||1||1', 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', 'KGS||KGS||KGS||KGS', '', '', '15000||15000||15000||15000', '2||2||1||5', '7500000.00||7500000.00||3750000.00||18750000.00', '0||0||0||0', 'amount_wise', '0.00||0.00||0.00||0.00', '7500000.00||7500000.00||3750000.00||18750000.00', '9||9||9||9', '675000.00||675000.00||337500.00||1687500.00', '9||9||9||9', '675000.00||675000.00||337500.00||1687500.00', '18||18||18||18', '1350000.00||1350000.00||675000.00||3375000.00', '8850000.00||8850000.00||4425000.00||22125000.00', '44250000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1', '44250000.00', 'P0009141125', 'P0009-2025', 1, '44250000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (10, '2025-11-14', '2025-11-14', '2025-11-14', 'purchase Order', 'P010', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '1', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '123456||123456||123456||123456||123456', '002||002||002||002||002', '1||1||1||1||1', '1||1||1||1||1', 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', 'KGS||KGS||KGS||KGS||KGS', '', '', '15000||15000||15000||15000||15000', '1||1||1||1||1', '3750000.00||3750000.00||3750000.00||3750000.00||3750000.00', '0||0||0||0||0', 'amount_wise', '0.00||0.00||0.00||0.00||0.00', '3750000.00||3750000.00||3750000.00||3750000.00||3750000.00', '9||9||9||9||9', '337500.00||337500.00||337500.00||337500.00||337500.00', '9||9||9||9||9', '337500.00||337500.00||337500.00||337500.00||337500.00', '18||18||18||18||18', '675000.00||675000.00||675000.00||675000.00||675000.00', '4425000.00||4425000.00||4425000.00||4425000.00||4425000.00', '4425000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1||1', '4425000.00', 'P0010141125', 'P0010-2025', 1, '4425000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (11, '2025-11-14', '2025-11-14', '2025-11-14', 'purchase Order', 'P011', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '001', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '123456', '002', '1', '1', 'Coal Nozzle', 'KGS', '', '', '15000', '5', '18750000.00', '0', 'amount_wise', '0.00', '18750000.00', '9', '1687500.00', '9', '1687500.00', '18', '3375000.00', '22125000.00', '22125000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '22125000.00', 'P0011141125', 'P0011-2025', 1, '22125000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (12, '2025-11-14', '2025-11-14', '2025-11-14', 'purchase Order', 'P012', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '1', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '123456', '002', '1', '1', 'Coal Nozzle', 'KGS', '', '', '15000', '5', '18750000.00', '0', 'amount_wise', '0.00', '18750000.00', '9', '1687500.00', '9', '1687500.00', '18', '3375000.00', '22125000.00', '22125000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '22125000.00', 'P0012141125', 'P0012-2025', 1, '22125000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (13, '2025-11-14', '2025-11-14', '2025-11-14', 'purchase Order', 'P013', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '001', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '123456', '002', '1', '1', 'Coal Nozzle', 'KGS', '', '', '15000', '5', '18750000.00', '0', 'amount_wise', '0.00', '18750000.00', '9', '1687500.00', '9', '1687500.00', '18', '3375000.00', '22125000.00', '22125000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '22125000.00', 'P0013141125', 'P0013-2025', 1, '22125000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (14, '2025-11-15', '2025-11-15', '2025-11-15', 'purchase Order', 'P014', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '005', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '123456||123456', '002||002', '001||002', '1||1', 'Coal Nozzle||Coal Nozzle', 'KGS||KGS', '', '', '15000||15000', '2||1', '7500000.00||3750000.00', '0||0', 'amount_wise', '0.00||0.00', '7500000.00||3750000.00', '9||9', '675000.00||337500.00', '9||9', '675000.00||337500.00', '18||18', '1350000.00||675000.00', '8850000.00||4425000.00', '8850000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '8850000.00', 'P0014151125', 'P0014-2025', 1, '8850000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (15, '2025-11-15', '2025-11-15', '2025-11-15', 'purchase Order', 'P015', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '006', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '123456||123456||123456||123456', '002||002||002||002', '006||006||006||006', '1||1||1||1', 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', 'KGS||KGS||KGS||KGS', '', '', '15000||15000||15000||15000', '5||2||5||1', '18750000.00||7500000.00||18750000.00||3750000.00', '0||0||0||0', 'amount_wise', '0.00||0.00||0.00||0.00', '18750000.00||7500000.00||18750000.00||3750000.00', '9||9||9||9', '1687500.00||675000.00||1687500.00||337500.00', '9||9||9||9', '1687500.00||675000.00||1687500.00||337500.00', '18||18||18||18', '3375000.00||1350000.00||3375000.00||675000.00', '22125000.00||8850000.00||22125000.00||4425000.00', '53100000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1', '53100000.00', 'P0015151125', 'P0015-2025', 1, '53100000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (16, '2025-11-15', '2025-11-15', '2025-11-15', 'purchase Order', 'P016', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '777', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024||641024||641024', '002||002||002||002', '001||001||002||002', '1||1||1||1', 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', 'KGS||KGS||KGS||KGS', '', '', '15000||15000||15000||15000', '1||1||2||1', '3750000.00||3750000.00||7500000.00||3750000.00', '0||0||0||0', 'amount_wise', '0.00||0.00||0.00||0.00', '3750000.00||3750000.00||7500000.00||3750000.00', '9||9||9||9', '337500.00||337500.00||675000.00||337500.00', '9||9||9||9', '337500.00||337500.00||675000.00||337500.00', '18||18||18||18', '675000.00||675000.00||1350000.00||675000.00', '4425000.00||4425000.00||8850000.00||4425000.00', '17700000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1', '17700000.00', 'P0016151125', 'P0016-2025', 1, '17700000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (17, '2025-11-15', '2025-11-15', '2025-11-15', 'purchase Order', 'P017', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '888', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024||641024||641024', '002||002||002||002', '001||001||002||002', '1||1||1||1', 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', 'KGS||KGS||KGS||KGS', '', '', '15000||15000||15000||15000', '1||1||2||1', '3750000.00||3750000.00||7500000.00||3750000.00', '0||0||0||0', 'amount_wise', '0.00||0.00||0.00||0.00', '3750000.00||3750000.00||7500000.00||3750000.00', '9||9||9||9', '337500.00||337500.00||675000.00||337500.00', '9||9||9||9', '337500.00||337500.00||675000.00||337500.00', '18||18||18||18', '675000.00||675000.00||1350000.00||675000.00', '4425000.00||4425000.00||8850000.00||4425000.00', '17700000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1', '17700000.00', 'P0017151125', 'P0017-2025', 1, '17700000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (18, '2025-11-15', '2025-11-15', '2025-11-15', 'purchase Order', 'P018', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '1010', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024||641024||641024', '002||002||002||002', '001||001||002||002', '1||1||1||1', 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', 'KGS||KGS||KGS||KGS', '', '', '15000||15000||15000||15000', '1||1||2||1', '3750000.00||3750000.00||7500000.00||3750000.00', '0||0||0||0', 'amount_wise', '0.00||0.00||0.00||0.00', '3750000.00||3750000.00||7500000.00||3750000.00', '9||9||9||9', '337500.00||337500.00||675000.00||337500.00', '9||9||9||9', '337500.00||337500.00||675000.00||337500.00', '18||18||18||18', '675000.00||675000.00||1350000.00||675000.00', '4425000.00||4425000.00||8850000.00||4425000.00', '17700000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1', '17700000.00', 'P0018151125', 'P0018-2025', 1, '17700000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (19, '2025-11-17', '2025-11-17', '2025-11-17', 'purchase Order', 'P019', 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '0019', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024||641024||641024', '002||002||002||002', '001||001||002||0002', '1||1||1||1', 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', 'KGS||KGS||KGS||KGS', '', '', '15000||15000||15000||15000', '10||10||10||5', '37500000.00||37500000.00||37500000.00||18750000.00', '0||0||0||0', 'amount_wise', '0.00||0.00||0.00||0.00', '37500000.00||37500000.00||37500000.00||18750000.00', '9||9||9||9', '3375000.00||3375000.00||3375000.00||1687500.00', '9||9||9||9', '3375000.00||3375000.00||3375000.00||1687500.00', '18||18||18||18', '6750000.00||6750000.00||6750000.00||3375000.00', '44250000.00||44250000.00||44250000.00||22125000.00', '132750000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1', '132750000.00', 'P0019171125', 'P0019-2025', 1, '132750000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (20, '2025-11-17', '2025-11-17', '2025-11-17', 'purchase Order', 'P020', 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '11313', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024||641024||641024', '003||003||003||003', '003||003||004||004', '3||3||3||3', 'Zozzle||Zozzle||Zozzle||Zozzle', 'KGS||KGS||KGS||KGS', '', '', '10000||10000||10000||10000', '3||2||3||2', '7500000.00||5000000.00||7500000.00||5000000.00', '0||0||0||0', 'amount_wise', '0.00||0.00||0.00||0.00', '7500000.00||5000000.00||7500000.00||5000000.00', '9||9||9||9', '675000.00||450000.00||675000.00||450000.00', '9||9||9||9', '675000.00||450000.00||675000.00||450000.00', '18||18||18||18', '1350000.00||900000.00||1350000.00||900000.00', '8850000.00||5900000.00||8850000.00||5900000.00', '23600000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1', '23600000.00', 'P0020171125', 'P0020-2025', 1, '23600000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (21, '2025-11-17', '2025-11-17', '2025-11-17', 'purchase Order', 'P021', 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1414', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024', '003||003', '2||3', '3||3', 'Zozzle||Zozzle', 'KGS||KGS', '', '', '10000||10000', '3||2', '7500000.00||5000000.00', '0||0', 'amount_wise', '0.00||0.00', '7500000.00||5000000.00', '9||9', '675000.00||450000.00', '9||9', '675000.00||450000.00', '18||18', '1350000.00||900000.00', '8850000.00||5900000.00', '14750000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '14750000.00', 'P0021171125', 'P0021-2025', 1, '14750000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (22, '2025-11-17', '2025-11-17', '2025-11-17', 'purchase Order', 'P022', 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1414', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024', '003||003', '003||004', '3||3', 'Zozzle||Zozzle', 'KGS||KGS', '', '', '10000||10000', '2||3', '5000000.00||7500000.00', '0||0', 'amount_wise', '0.00||0.00', '5000000.00||7500000.00', '9||9', '450000.00||675000.00', '9||9', '450000.00||675000.00', '18||18', '900000.00||1350000.00', '5900000.00||8850000.00', '14750000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '14750000.00', 'P0022171125', 'P0022-2025', 1, '14750000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (23, '2025-11-17', '2025-11-17', '2025-11-17', 'purchase Order', 'P023', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '100', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024||641024||641024||641024', '002||002||002||002||003', '100||101||102||103||205', '1||1||1||1||3', 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle||Zozzle', 'KGS||KGS||KGS||KGS||KGS', '', '', '15000||15000||15000||15000||10000', '1||2||1||1||3', '3750000.00||7500000.00||3750000.00||3750000.00||7500000.00', '0||0||0||0||0', 'amount_wise', '0.00||0.00||0.00||0.00||0.00', '3750000.00||7500000.00||3750000.00||3750000.00||7500000.00', '9||9||9||9||9', '337500.00||675000.00||337500.00||337500.00||675000.00', '9||9||9||9||9', '337500.00||675000.00||337500.00||337500.00||675000.00', '18||18||18||18||18', '675000.00||1350000.00||675000.00||675000.00||1350000.00', '4425000.00||8850000.00||4425000.00||4425000.00||8850000.00', '30975000.00', '0', '0', '0.00', '0', '0.00', '0', '0.00', '0.00', '', '0', '0.00', '0', '0.00', '0', '0.00', '0.00', '0', '0', '1||1||1||1||1', '30975000.00', 'P0023171125', 'P0023-2025', 1, '30975000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (24, '2025-11-17', '2025-11-17', '2025-11-17', 'purchase Order', 'P024', 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1515', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024||641024||641024', '002||002||002||002', '001||001||002||002', '1||1||1||1', 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', 'KGS||KGS||KGS||KGS', '', '', '15000||15000||15000||15000', '5||5||3||2', '18750000.00||18750000.00||11250000.00||7500000.00', '0||0||0||0', 'amount_wise', '0.00||0.00||0.00||0.00', '18750000.00||18750000.00||11250000.00||7500000.00', '9||9||9||9', '1687500.00||1687500.00||1012500.00||675000.00', '9||9||9||9', '1687500.00||1687500.00||1012500.00||675000.00', '18||18||18||18', '3375000.00||3375000.00||2025000.00||1350000.00', '22125000.00||22125000.00||13275000.00||8850000.00', '57525000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1', '57525000.00', 'P0024171125', 'P0024-2025', 1, '57525000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (25, '2025-11-17', '2025-11-17', '2025-11-17', 'purchase Order', 'P025', 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1616', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024||641024||641024||641024||641024||641024||641024', '002||002||002||002||002||002||002||002', '001||001||001||001||002||002||002||002', '1||1||1||1||1||1||1||1', 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', 'KGS||KGS||KGS||KGS||KGS||KGS||KGS||KGS', '', '', '15000||15000||15000||15000||15000||15000||15000||15000', '2||2||2||2||2||2||2||2', '7500000.00||7500000.00||7500000.00||7500000.00||7500000.00||7500000.00||7500000.00||7500000.00', '0||0||0||0||0||0||0||0', 'amount_wise', '0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00', '7500000.00||7500000.00||7500000.00||7500000.00||7500000.00||7500000.00||7500000.00||7500000.00', '9||9||9||9||9||9||9||9', '675000.00||675000.00||675000.00||675000.00||675000.00||675000.00||675000.00||675000.00', '9||9||9||9||9||9||9||9', '675000.00||675000.00||675000.00||675000.00||675000.00||675000.00||675000.00||675000.00', '18||18||18||18||18||18||18||18', '1350000.00||1350000.00||1350000.00||1350000.00||1350000.00||1350000.00||1350000.00||1350000.00', '8850000.00||8850000.00||8850000.00||8850000.00||8850000.00||8850000.00||8850000.00||8850000.00', '44250000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1||1||1||1||1||1||1', '44250000.00', 'P0025171125', 'P0025-2025', 1, '44250000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (26, '2025-11-19', '2025-11-19', '2025-11-19', 'purchase Order', 'P026', 0, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '26', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024||641024||641024', '002||002||002||002', '002||002||002||002', '1||1||1||1', 'Coal Nozzle||Coal Nozzle||Coal Nozzle||Coal Nozzle', 'KGS||KGS||KGS||KGS', '250||250||250||250', '3||3||3||3', '15000||15000||15000||15000', '1||1||1||1', '3750000.00||3750000.00||3750000.00||3750000.00', '0||0||0||0', 'amount_wise', '||||||', '3750000.00||3750000.00||3750000.00||3750000.00', '9||9||9||9', '337500.00||337500.00||337500.00||337500.00', '9||9||9||9', '337500.00||337500.00||337500.00||337500.00', '18||18||18||18', '675000.00||675000.00||675000.00||675000.00', '4425000.00||4425000.00||4425000.00||4425000.00', '17700000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '10.2', '1||1||1||1', '17700010.20', 'P0026191125', 'P0026-2025', 1, '17700010.20', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (27, '2025-11-19', '2025-11-19', '2025-11-19', 'Direct Purchase', 'P027', 8, 'Jack', 'cbe, cbe, CBE, Tamil Nadu', '0027', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024', '', '', '||', 'Coal Nozzle||Coal Nozzle', 'KGS||KGS', '250||250', '3||3', '15000||15000', '2||1', '7500000.00||3750000.00', '0||0', 'amount_wise', '||', '7500000.00||3750000.00', '9||9', '675000.00||337500.00', '9||9', '675000.00||337500.00', '18||18', '1350000.00||675000.00', '8850000.00||4425000.00', '13275000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '13275000.00', 'P0027191125', 'P0027-2025', 1, '13275000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (28, '2025-11-20', '2025-11-20', '2025-11-20', 'purchase Order', 'P028', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '002', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024', '002||003', '002||', '1||3', 'Coal Nozzle||Coal Nozzle', 'KGS||KGS', '250||250', '', '15000||10000', '2||', '7500000.00||', '0||0', 'amount_wise', '0.00||', '7500000.00||', '9||9', '675000.00||', '9||9', '675000.00||', '18||18', '1350000.00||', '8850000.00||', '8850000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '8850000.00', 'P0028201125', 'P0028-2025', 1, '8850000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (29, '2025-11-20', '2025-11-20', '2025-11-20', 'purchase Order', 'P029', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '002', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024', '002||003', '002||', '1||3', 'Coal Nozzle||Coal Nozzle', 'KGS||KGS', '250||250', '', '15000||10000', '2||', '7500000.00||', '0||0', 'amount_wise', '0.00||', '7500000.00||', '9||9', '675000.00||', '9||9', '675000.00||', '18||18', '1350000.00||', '8850000.00||', '8850000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '8850000.00', 'P0028201125', 'P0028-2025', 1, '8850000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (30, '2025-11-20', '2025-11-20', '2025-11-20', 'purchase Order', 'P030', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '002', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024', '002||003', '002||', '1||3', 'Coal Nozzle||Coal Nozzle', 'KGS||KGS', '250||250', '', '15000||10000', '2||', '7500000.00||', '0||0', 'amount_wise', '0.00||', '7500000.00||', '9||9', '675000.00||', '9||9', '675000.00||', '18||18', '1350000.00||', '8850000.00||', '8850000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '8850000.00', 'P0028201125', 'P0028-2025', 1, '8850000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (31, '2025-11-20', '2025-11-20', '2025-11-20', 'purchase Order', 'P031', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '002', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024', '002||003', '002||', '1||3', 'Coal Nozzle||Coal Nozzle', 'KGS||KGS', '250||250', '', '15000||10000', '2||', '7500000.00||', '0||0', 'amount_wise', '0.00||', '7500000.00||', '9||9', '675000.00||', '9||9', '675000.00||', '18||18', '1350000.00||', '8850000.00||', '8850000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '8850000.00', 'P0028201125', 'P0028-2025', 1, '8850000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (32, '2025-11-20', '2025-11-20', '2025-11-20', 'purchase Order', 'P032', 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '002', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024', '002||003', '001||', '1||3', 'Coal Nozzle||Coal Nozzle', 'KGS||KGS', '250||250', '', '15000||10000', '2||', '7500000.00||', '0||0', 'amount_wise', '0.00||', '7500000.00||', '9||9', '675000.00||', '9||9', '675000.00||', '18||18', '1350000.00||', '8850000.00||', '8850000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '8850000.00', 'P0032201125', 'P0032-2025', 1, '8850000.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (33, '2025-11-20', '2025-11-20', '2025-11-20', 'purchase Order', 'P033', 8, 'Jack', 'cbe, cbe, CBE, Tamil Nadu', '0033', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024', '002', '0033', '1', 'Coal Nozzle', 'KGS', '250', '', '15000', '50', '187500000.00', '0', 'amount_wise', '0.00', '187500000.00', '9', '16875000.00', '9', '16875000.00', '18', '33750000.00', '221250000.00', '221250000.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '221250000.00', 'P0033201125', 'P0033-2025', 1, '221250000.00', 1, 1);


#
# TABLE STRUCTURE FOR: purchase_details_backup
#

DROP TABLE IF EXISTS `purchase_details_backup`;

CREATE TABLE `purchase_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: purchase_reports
#

DROP TABLE IF EXISTS `purchase_reports`;

CREATE TABLE `purchase_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `heatno` varchar(255) DEFAULT NULL,
  `weight` varchar(20) NOT NULL,
  `grade` varchar(50) NOT NULL,
  `itemid` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=103 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (1, '1', '2025-06-21', 'P001', '2025-06-21', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', 'OO1', '2025-06-21', NULL, NULL, NULL, '', '', NULL, '123456', 'EH OUTER BOX', '1', '12', '2', '212400.00', NULL, NULL, NULL, NULL, NULL, '212400.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2025', 'P001210625');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (2, '2', '2025-06-21', 'P0002', '2025-06-21', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '0098', '2025-06-21', NULL, NULL, NULL, '', '', NULL, '123456', 'EH OUTER BOX', '1', '25', '4', '442500.00', NULL, NULL, NULL, NULL, NULL, '442500.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0002-2025', 'P0002210625');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (3, '3', '2025-06-24', 'P0003', '2025-06-24', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '001', '2025-06-24', NULL, NULL, NULL, '', '', NULL, '00002', 'Stationary things', '1', '12', '2', '2364.00', NULL, NULL, NULL, NULL, NULL, '2364.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0003-2025', 'P0003240625');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (4, '5', '2025-09-11', 'P0004', '2025-09-11', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '001', '2025-09-11', NULL, '002', '001', '', '', '1', '123456', 'Coal Nozzle', '1', '5', '8', '177000.00', NULL, NULL, NULL, NULL, NULL, '177000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0004-2025', 'P0004110925');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (5, '5', '2025-09-11', 'P0004', '2025-09-11', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '001', '2025-09-11', NULL, '002', '001', '', '', '1', '123456', 'Coal Nozzle', '5', '5', '8', '177000.00', NULL, NULL, NULL, NULL, NULL, '177000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0004-2025', 'P0004110925');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (11, '6', '2025-09-12', 'P006', '2025-09-11', NULL, 0, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '001', '2025-09-11', NULL, '002', NULL, '', '', '|', '123456', 'Coal Nozzle', '5', '6', '0', '212400.00', NULL, NULL, NULL, NULL, NULL, '212400.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (10, '6', '2025-09-12', 'P006', '2025-09-11', NULL, 0, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '001', '2025-09-11', NULL, '002', NULL, '', '', '|', '123456', 'Coal Nozzle', '1', '6', '1', '212400.00', NULL, NULL, NULL, NULL, NULL, '212400.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (12, '7', '2025-11-14', 'P0007', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '002', '2025-11-14', NULL, '002', '101', '', '', '1', '123456', 'Coal Nozzle', '1', '2', '8', '30975000.00', NULL, NULL, NULL, NULL, NULL, '30975000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0007-2025', 'P0007141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (13, '7', '2025-11-14', 'P0007', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '002', '2025-11-14', NULL, '002', '102', '', '', '1', '123456', 'Coal Nozzle', '5', '1', '8', '30975000.00', NULL, NULL, NULL, NULL, NULL, '30975000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0007-2025', 'P0007141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (14, '7', '2025-11-14', 'P0007', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '002', '2025-11-14', NULL, '002', '103', '', '', '1', '123456', 'Coal Nozzle', '0', '2', '5', '30975000.00', NULL, NULL, NULL, NULL, NULL, '30975000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0007-2025', 'P0007141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (15, '7', '2025-11-14', 'P0007', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '002', '2025-11-14', NULL, '002', '104', '', '', '1', '123456', 'Coal Nozzle', '0', '2', '0', '30975000.00', NULL, NULL, NULL, NULL, NULL, '30975000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0007-2025', 'P0007141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (16, '7', '2025-11-14', 'P0007', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '002', '2025-11-14', NULL, '002', '105', '', '', '1', '123456', 'Coal Nozzle', '0', '3', '0', '30975000.00', NULL, NULL, NULL, NULL, NULL, '30975000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0007-2025', 'P0007141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (17, '8', '2025-11-14', 'P0008', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '003', '2025-11-14', NULL, '002', '101', '', '', '1', '123456', 'Coal Nozzle', '1', '1', '4', '26550000.00', NULL, NULL, NULL, NULL, NULL, '26550000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0008-2025', 'P0008141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (18, '8', '2025-11-14', 'P0008', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '003', '2025-11-14', NULL, '002', '102', '', '', '1', '123456', 'Coal Nozzle', '5', '1', '4', '26550000.00', NULL, NULL, NULL, NULL, NULL, '26550000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0008-2025', 'P0008141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (19, '8', '2025-11-14', 'P0008', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '003', '2025-11-14', NULL, '002', '103', '', '', '1', '123456', 'Coal Nozzle', '0', '1', '2', '26550000.00', NULL, NULL, NULL, NULL, NULL, '26550000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0008-2025', 'P0008141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (20, '8', '2025-11-14', 'P0008', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '003', '2025-11-14', NULL, '002', '104', '', '', '1', '123456', 'Coal Nozzle', '0', '2', '5', '26550000.00', NULL, NULL, NULL, NULL, NULL, '26550000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0008-2025', 'P0008141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (21, '8', '2025-11-14', 'P0008', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '003', '2025-11-14', NULL, '002', '105', '', '', '1', '123456', 'Coal Nozzle', '0', '1', '0', '26550000.00', NULL, NULL, NULL, NULL, NULL, '26550000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0008-2025', 'P0008141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (22, '8', '2025-11-14', 'P0008', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '003', '2025-11-14', NULL, '002', '106', '', '', '1', '123456', 'Coal Nozzle', '|', '4', '0', '26550000.00', NULL, NULL, NULL, NULL, NULL, '26550000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0008-2025', 'P0008141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (23, '9', '2025-11-14', 'P0009', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '004', '2025-11-14', NULL, '002', '200', '', '', '1', '123456', 'Coal Nozzle', '1', '2', '8', '44250000.00', NULL, NULL, NULL, NULL, NULL, '44250000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0009-2025', 'P0009141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (24, '9', '2025-11-14', 'P0009', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '004', '2025-11-14', NULL, '002', '200', '', '', '1', '123456', 'Coal Nozzle', '5', '2', '8', '44250000.00', NULL, NULL, NULL, NULL, NULL, '44250000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0009-2025', 'P0009141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (25, '9', '2025-11-14', 'P0009', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '004', '2025-11-14', NULL, '002', '20', '', '', '1', '123456', 'Coal Nozzle', '0', '1', '5', '44250000.00', NULL, NULL, NULL, NULL, NULL, '44250000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0009-2025', 'P0009141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (26, '9', '2025-11-14', 'P0009', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '004', '2025-11-14', NULL, '002', '200', '', '', '1', '123456', 'Coal Nozzle', '0', '5', '0', '44250000.00', NULL, NULL, NULL, NULL, NULL, '44250000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0009-2025', 'P0009141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (27, '10', '2025-11-14', 'P0010', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '1', '2025-11-14', NULL, '002', '1', '', '', '1', '123456', 'Coal Nozzle', '1', '1', '4', '4425000.00', NULL, NULL, NULL, NULL, NULL, '4425000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0010-2025', 'P0010141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (28, '10', '2025-11-14', 'P0010', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '1', '2025-11-14', NULL, '002', '1', '', '', '1', '123456', 'Coal Nozzle', '5', '1', '4', '4425000.00', NULL, NULL, NULL, NULL, NULL, '4425000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0010-2025', 'P0010141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (29, '10', '2025-11-14', 'P0010', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '1', '2025-11-14', NULL, '002', '1', '', '', '1', '123456', 'Coal Nozzle', '0', '1', '2', '4425000.00', NULL, NULL, NULL, NULL, NULL, '4425000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0010-2025', 'P0010141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (30, '10', '2025-11-14', 'P0010', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '1', '2025-11-14', NULL, '002', '1', '', '', '1', '123456', 'Coal Nozzle', '0', '1', '5', '4425000.00', NULL, NULL, NULL, NULL, NULL, '4425000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0010-2025', 'P0010141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (31, '10', '2025-11-14', 'P0010', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '1', '2025-11-14', NULL, '002', '1', '', '', '1', '123456', 'Coal Nozzle', '0', '1', '0', '4425000.00', NULL, NULL, NULL, NULL, NULL, '4425000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0010-2025', 'P0010141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (32, '11', '2025-11-14', 'P0011', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '001', '2025-11-14', NULL, '002', '1', '', '', '1', '123456', 'Coal Nozzle', '1', '5', '2', '22125000.00', NULL, NULL, NULL, NULL, NULL, '22125000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0011-2025', 'P0011141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (33, '12', '2025-11-14', 'P0012', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '1', '2025-11-14', NULL, '002', '1', '', '', '1', '123456', 'Coal Nozzle', '1', '5', '2', '22125000.00', NULL, NULL, NULL, NULL, NULL, '22125000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0012-2025', 'P0012141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (34, '13', '2025-11-14', 'P0013', '2025-11-14', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '001', '2025-11-14', NULL, '002', '1', '', '', '1', '123456', 'Coal Nozzle', '1', '5', '2', '22125000.00', NULL, NULL, NULL, NULL, NULL, '22125000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0013-2025', 'P0013141125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (35, '14', '2025-11-15', 'P0014', '2025-11-15', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '005', '2025-11-15', NULL, '002', '001', '', '', '1', '123456', 'Coal Nozzle', '1', '2', '8', '8850000.00', NULL, NULL, NULL, NULL, NULL, '8850000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0014-2025', 'P0014151125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (36, '14', '2025-11-15', 'P0014', '2025-11-15', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '005', '2025-11-15', NULL, '002', '002', '', '', '1', '123456', 'Coal Nozzle', '5', '1', '8', '8850000.00', NULL, NULL, NULL, NULL, NULL, '8850000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0014-2025', 'P0014151125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (37, '15', '2025-11-15', 'P0015', '2025-11-15', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '006', '2025-11-15', NULL, '002', '006', '', '', '1', '123456', 'Coal Nozzle', '1', '5', '2', '53100000.00', NULL, NULL, NULL, NULL, NULL, '53100000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0015-2025', 'P0015151125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (38, '15', '2025-11-15', 'P0015', '2025-11-15', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '006', '2025-11-15', NULL, '002', '006', '', '', '1', '123456', 'Coal Nozzle', '5', '2', '2', '53100000.00', NULL, NULL, NULL, NULL, NULL, '53100000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0015-2025', 'P0015151125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (39, '15', '2025-11-15', 'P0015', '2025-11-15', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '006', '2025-11-15', NULL, '002', '006', '', '', '1', '123456', 'Coal Nozzle', '0', '5', '1', '53100000.00', NULL, NULL, NULL, NULL, NULL, '53100000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0015-2025', 'P0015151125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (40, '15', '2025-11-15', 'P0015', '2025-11-15', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '006', '2025-11-15', NULL, '002', '006', '', '', '1', '123456', 'Coal Nozzle', '0', '1', '2', '53100000.00', NULL, NULL, NULL, NULL, NULL, '53100000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0015-2025', 'P0015151125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (41, '16', '2025-11-15', 'P0016', '2025-11-15', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '777', '2025-11-15', NULL, '002', '001', '', '', '1', '641024', 'Coal Nozzle', '1', '1', '4', '17700000.00', NULL, NULL, NULL, NULL, NULL, '17700000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0016-2025', 'P0016151125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (42, '16', '2025-11-15', 'P0016', '2025-11-15', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '777', '2025-11-15', NULL, '002', '001', '', '', '1', '641024', 'Coal Nozzle', '5', '1', '4', '17700000.00', NULL, NULL, NULL, NULL, NULL, '17700000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0016-2025', 'P0016151125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (43, '16', '2025-11-15', 'P0016', '2025-11-15', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '777', '2025-11-15', NULL, '002', '002', '', '', '1', '641024', 'Coal Nozzle', '0', '2', '2', '17700000.00', NULL, NULL, NULL, NULL, NULL, '17700000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0016-2025', 'P0016151125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (44, '16', '2025-11-15', 'P0016', '2025-11-15', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '777', '2025-11-15', NULL, '002', '002', '', '', '1', '641024', 'Coal Nozzle', '0', '1', '5', '17700000.00', NULL, NULL, NULL, NULL, NULL, '17700000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0016-2025', 'P0016151125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (45, '17', '2025-11-15', 'P0017', '2025-11-15', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '888', '2025-11-15', NULL, '002', '001', '', '', '1', '641024', 'Coal Nozzle', '1', '1', '4', '17700000.00', NULL, NULL, NULL, NULL, NULL, '17700000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0017-2025', 'P0017151125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (46, '17', '2025-11-15', 'P0017', '2025-11-15', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '888', '2025-11-15', NULL, '002', '001', '', '', '1', '641024', 'Coal Nozzle', '5', '1', '4', '17700000.00', NULL, NULL, NULL, NULL, NULL, '17700000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0017-2025', 'P0017151125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (47, '17', '2025-11-15', 'P0017', '2025-11-15', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '888', '2025-11-15', NULL, '002', '002', '', '', '1', '641024', 'Coal Nozzle', '0', '2', '2', '17700000.00', NULL, NULL, NULL, NULL, NULL, '17700000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0017-2025', 'P0017151125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (48, '17', '2025-11-15', 'P0017', '2025-11-15', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '888', '2025-11-15', NULL, '002', '002', '', '', '1', '641024', 'Coal Nozzle', '0', '1', '5', '17700000.00', NULL, NULL, NULL, NULL, NULL, '17700000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0017-2025', 'P0017151125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (49, '18', '2025-11-15', 'P0018', '2025-11-15', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '1010', '2025-11-15', NULL, '002', '001', '', '', '1', '641024', 'Coal Nozzle', '1', '1', '4', '17700000.00', NULL, NULL, NULL, NULL, NULL, '17700000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0018-2025', 'P0018151125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (50, '18', '2025-11-15', 'P0018', '2025-11-15', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '1010', '2025-11-15', NULL, '002', '001', '', '', '1', '641024', 'Coal Nozzle', '5', '1', '4', '17700000.00', NULL, NULL, NULL, NULL, NULL, '17700000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0018-2025', 'P0018151125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (51, '18', '2025-11-15', 'P0018', '2025-11-15', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '1010', '2025-11-15', NULL, '002', '002', '', '', '1', '641024', 'Coal Nozzle', '0', '2', '2', '17700000.00', NULL, NULL, NULL, NULL, NULL, '17700000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0018-2025', 'P0018151125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (52, '18', '2025-11-15', 'P0018', '2025-11-15', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '1010', '2025-11-15', NULL, '002', '002', '', '', '1', '641024', 'Coal Nozzle', '0', '1', '5', '17700000.00', NULL, NULL, NULL, NULL, NULL, '17700000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0018-2025', 'P0018151125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (53, '19', '2025-11-17', 'P0019', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '0019', '2025-11-17', NULL, '002', '001', '', '', '1', '641024', 'Coal Nozzle', '1', '10', '4', '132750000.00', NULL, NULL, NULL, NULL, NULL, '132750000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0019-2025', 'P0019171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (54, '19', '2025-11-17', 'P0019', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '0019', '2025-11-17', NULL, '002', '001', '', '', '1', '641024', 'Coal Nozzle', '5', '10', '4', '132750000.00', NULL, NULL, NULL, NULL, NULL, '132750000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0019-2025', 'P0019171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (55, '19', '2025-11-17', 'P0019', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '0019', '2025-11-17', NULL, '002', '002', '', '', '1', '641024', 'Coal Nozzle', '0', '10', '2', '132750000.00', NULL, NULL, NULL, NULL, NULL, '132750000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0019-2025', 'P0019171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (56, '19', '2025-11-17', 'P0019', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '0019', '2025-11-17', NULL, '002', '0002', '', '', '1', '641024', 'Coal Nozzle', '0', '5', '5', '132750000.00', NULL, NULL, NULL, NULL, NULL, '132750000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0019-2025', 'P0019171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (57, '20', '2025-11-17', 'P0020', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '11313', '2025-11-17', NULL, '003', '003', '', '', '3', '641024', 'Zozzle', '1', '3', '8', '23600000.00', NULL, NULL, NULL, NULL, NULL, '23600000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0020-2025', 'P0020171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (58, '20', '2025-11-17', 'P0020', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '11313', '2025-11-17', NULL, '003', '003', '', '', '3', '641024', 'Zozzle', '0', '2', '8', '23600000.00', NULL, NULL, NULL, NULL, NULL, '23600000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0020-2025', 'P0020171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (59, '20', '2025-11-17', 'P0020', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '11313', '2025-11-17', NULL, '003', '004', '', '', '3', '641024', 'Zozzle', '0', '3', '5', '23600000.00', NULL, NULL, NULL, NULL, NULL, '23600000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0020-2025', 'P0020171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (60, '20', '2025-11-17', 'P0020', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '11313', '2025-11-17', NULL, '003', '004', '', '', '3', '641024', 'Zozzle', '0', '2', '0', '23600000.00', NULL, NULL, NULL, NULL, NULL, '23600000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0020-2025', 'P0020171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (61, '21', '2025-11-17', 'P0021', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1414', '2025-11-17', NULL, '003', '2', '', '', '3', '641024', 'Zozzle', '1', '3', '8', '14750000.00', NULL, NULL, NULL, NULL, NULL, '14750000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0021-2025', 'P0021171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (62, '21', '2025-11-17', 'P0021', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1414', '2025-11-17', NULL, '003', '3', '', '', '3', '641024', 'Zozzle', '0', '2', '8', '14750000.00', NULL, NULL, NULL, NULL, NULL, '14750000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0021-2025', 'P0021171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (63, '22', '2025-11-17', 'P0022', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1414', '2025-11-17', NULL, '003', '003', '', '', '3', '641024', 'Zozzle', '1', '2', '5', '14750000.00', NULL, NULL, NULL, NULL, NULL, '14750000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0022-2025', 'P0022171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (64, '22', '2025-11-17', 'P0022', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1414', '2025-11-17', NULL, '003', '004', '', '', '3', '641024', 'Zozzle', '0', '3', '9', '14750000.00', NULL, NULL, NULL, NULL, NULL, '14750000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0022-2025', 'P0022171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (65, '23', '2025-11-17', 'P0023', '2025-11-17', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '100', '2025-11-17', NULL, '002', '100', '', '', '1', '641024', 'Coal Nozzle', '1', '1', '4', '30975000.00', NULL, NULL, NULL, NULL, NULL, '30975000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0023-2025', 'P0023171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (66, '23', '2025-11-17', 'P0023', '2025-11-17', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '100', '2025-11-17', NULL, '002', '101', '', '', '1', '641024', 'Coal Nozzle', '5', '2', '4', '30975000.00', NULL, NULL, NULL, NULL, NULL, '30975000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0023-2025', 'P0023171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (67, '23', '2025-11-17', 'P0023', '2025-11-17', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '100', '2025-11-17', NULL, '002', '102', '', '', '1', '641024', 'Coal Nozzle', '0', '1', '2', '30975000.00', NULL, NULL, NULL, NULL, NULL, '30975000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0023-2025', 'P0023171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (68, '23', '2025-11-17', 'P0023', '2025-11-17', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '100', '2025-11-17', NULL, '002', '103', '', '', '1', '641024', 'Coal Nozzle', '0', '1', '5', '30975000.00', NULL, NULL, NULL, NULL, NULL, '30975000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0023-2025', 'P0023171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (69, '23', '2025-11-17', 'P0023', '2025-11-17', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '100', '2025-11-17', NULL, '003', '205', '', '', '3', '641024', 'Zozzle', '0', '3', '0', '30975000.00', NULL, NULL, NULL, NULL, NULL, '30975000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0023-2025', 'P0023171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (70, '24', '2025-11-17', 'P0024', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1515', '2025-11-17', NULL, '002', '001', '', '', '1', '641024', 'Coal Nozzle', '1', '5', '2', '57525000.00', NULL, NULL, NULL, NULL, NULL, '57525000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0024-2025', 'P0024171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (71, '24', '2025-11-17', 'P0024', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1515', '2025-11-17', NULL, '002', '001', '', '', '1', '641024', 'Coal Nozzle', '5', '5', '2', '57525000.00', NULL, NULL, NULL, NULL, NULL, '57525000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0024-2025', 'P0024171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (72, '24', '2025-11-17', 'P0024', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1515', '2025-11-17', NULL, '002', '002', '', '', '1', '641024', 'Coal Nozzle', '0', '3', '1', '57525000.00', NULL, NULL, NULL, NULL, NULL, '57525000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0024-2025', 'P0024171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (73, '24', '2025-11-17', 'P0024', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1515', '2025-11-17', NULL, '002', '002', '', '', '1', '641024', 'Coal Nozzle', '0', '2', '2', '57525000.00', NULL, NULL, NULL, NULL, NULL, '57525000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0024-2025', 'P0024171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (74, '25', '2025-11-17', 'P0025', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1616', '2025-11-17', NULL, '002', '001', '', '', '1', '641024', 'Coal Nozzle', '1', '2', '8', '44250000.00', NULL, NULL, NULL, NULL, NULL, '44250000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0025-2025', 'P0025171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (75, '25', '2025-11-17', 'P0025', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1616', '2025-11-17', NULL, '002', '001', '', '', '1', '641024', 'Coal Nozzle', '5', '2', '8', '44250000.00', NULL, NULL, NULL, NULL, NULL, '44250000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0025-2025', 'P0025171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (76, '25', '2025-11-17', 'P0025', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1616', '2025-11-17', NULL, '002', '001', '', '', '1', '641024', 'Coal Nozzle', '0', '2', '5', '44250000.00', NULL, NULL, NULL, NULL, NULL, '44250000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0025-2025', 'P0025171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (77, '25', '2025-11-17', 'P0025', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1616', '2025-11-17', NULL, '002', '001', '', '', '1', '641024', 'Coal Nozzle', '0', '2', '0', '44250000.00', NULL, NULL, NULL, NULL, NULL, '44250000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0025-2025', 'P0025171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (78, '25', '2025-11-17', 'P0025', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1616', '2025-11-17', NULL, '002', '002', '', '', '1', '641024', 'Coal Nozzle', '0', '2', '0', '44250000.00', NULL, NULL, NULL, NULL, NULL, '44250000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0025-2025', 'P0025171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (79, '25', '2025-11-17', 'P0025', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1616', '2025-11-17', NULL, '002', '002', '', '', '1', '641024', 'Coal Nozzle', '|', '2', '0', '44250000.00', NULL, NULL, NULL, NULL, NULL, '44250000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0025-2025', 'P0025171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (80, '25', '2025-11-17', 'P0025', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1616', '2025-11-17', NULL, '002', '002', '', '', '1', '641024', 'Coal Nozzle', '|', '2', '0', '44250000.00', NULL, NULL, NULL, NULL, NULL, '44250000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0025-2025', 'P0025171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (81, '25', '2025-11-17', 'P0025', '2025-11-17', NULL, 5, 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '1616', '2025-11-17', NULL, '002', '002', '', '', '1', '641024', 'Coal Nozzle', '1', '2', '.', '44250000.00', NULL, NULL, NULL, NULL, NULL, '44250000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0025-2025', 'P0025171125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (95, '26', '2025-11-19', 'P026', '2025-11-19', NULL, 0, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '26', '2025-11-19', NULL, '002', NULL, '250', '3', '|', '641024', 'Coal Nozzle', '0', '1', '5', '17700000.00', NULL, NULL, NULL, NULL, NULL, '17700010.20', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P026-2025', 'P026191125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (94, '26', '2025-11-19', 'P026', '2025-11-19', NULL, 0, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '26', '2025-11-19', NULL, '002', NULL, '250', '3', '|', '641024', 'Coal Nozzle', '0', '1', '2', '17700000.00', NULL, NULL, NULL, NULL, NULL, '17700010.20', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P026-2025', 'P026191125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (93, '26', '2025-11-19', 'P026', '2025-11-19', NULL, 0, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '26', '2025-11-19', NULL, '002', NULL, '250', '3', '|', '641024', 'Coal Nozzle', '5', '1', '4', '17700000.00', NULL, NULL, NULL, NULL, NULL, '17700010.20', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P026-2025', 'P026191125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (92, '26', '2025-11-19', 'P026', '2025-11-19', NULL, 0, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '26', '2025-11-19', NULL, '002', NULL, '250', '3', '|', '641024', 'Coal Nozzle', '1', '1', '4', '17700000.00', NULL, NULL, NULL, NULL, NULL, '17700010.20', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P026-2025', 'P026191125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (91, '27', '2025-11-19', 'P027', '2025-11-19', NULL, 8, 'Jack', 'cbe, cbe, CBE, Tamil Nadu', '0027', '2025-11-19', NULL, NULL, NULL, '250', '3', '', '641024', 'Coal Nozzle', '5', '1', '8', '13275000.00', NULL, NULL, NULL, NULL, NULL, '13275000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P027-2025', 'P027191125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (90, '27', '2025-11-19', 'P027', '2025-11-19', NULL, 8, 'Jack', 'cbe, cbe, CBE, Tamil Nadu', '0027', '2025-11-19', NULL, NULL, NULL, '250', '3', '', '641024', 'Coal Nozzle', '1', '2', '8', '13275000.00', NULL, NULL, NULL, NULL, NULL, '13275000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P027-2025', 'P027191125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (96, '30', '2025-11-20', 'P0028', '2025-11-20', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '002', '2025-11-20', NULL, '002', '002', '250', '', '1', '641024', 'Coal Nozzle', '1', '2', '8', '8850000.00', NULL, NULL, NULL, NULL, NULL, '8850000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0028-2025', 'P0028201125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (97, '30', '2025-11-20', 'P0028', '2025-11-20', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '002', '2025-11-20', NULL, '003', '', '250', '', '3', '641024', 'Coal Nozzle', '5', '', '8', '8850000.00', NULL, NULL, NULL, NULL, NULL, '8850000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0028-2025', 'P0028201125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (98, '31', '2025-11-20', 'P0028', '2025-11-20', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '002', '2025-11-20', NULL, '002', '002', '250', '', '1', '641024', 'Coal Nozzle', '1', '2', '8', '8850000.00', NULL, NULL, NULL, NULL, NULL, '8850000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0028-2025', 'P0028201125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (99, '31', '2025-11-20', 'P0028', '2025-11-20', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '002', '2025-11-20', NULL, '003', '', '250', '', '3', '641024', 'Coal Nozzle', '5', '', '8', '8850000.00', NULL, NULL, NULL, NULL, NULL, '8850000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0028-2025', 'P0028201125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (100, '32', '2025-11-20', 'P0032', '2025-11-20', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '002', '2025-11-20', NULL, '002', '001', '250', '', '1', '641024', 'Coal Nozzle', '1', '2', '8', '8850000.00', NULL, NULL, NULL, NULL, NULL, '8850000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0032-2025', 'P0032201125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (101, '32', '2025-11-20', 'P0032', '2025-11-20', NULL, 3, 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '002', '2025-11-20', NULL, '003', '', '250', '', '3', '641024', 'Coal Nozzle', '5', '', '8', '8850000.00', NULL, NULL, NULL, NULL, NULL, '8850000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0032-2025', 'P0032201125');
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (102, '33', '2025-11-20', 'P0033', '2025-11-20', NULL, 8, 'Jack', 'cbe, cbe, CBE, Tamil Nadu', '0033', '2025-11-20', NULL, '002', '0033', '250', '', '1', '641024', 'Coal Nozzle', '1', '50', '2', '221250000.00', NULL, NULL, NULL, NULL, NULL, '221250000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P0033-2025', 'P0033201125');


#
# TABLE STRUCTURE FOR: purchaseorder_details
#

DROP TABLE IF EXISTS `purchaseorder_details`;

CREATE TABLE `purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `deliverydate` varchar(100) NOT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` longtext DEFAULT NULL,
  `heatno` text DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `uom` longtext DEFAULT NULL,
  `weight` varchar(100) NOT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `balanceqty` longtext DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` longtext NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` longtext DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `oa_status` int(11) NOT NULL,
  `oa_deliverydate` varchar(255) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`) VALUES (1, '2025-09-01', '2025-09-01', '2025-09-01', '01-09-2025', 'Direct PO', 'P001', '001', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '123456||123456', '002||002', NULL, 'Coal Nozzle||Coal Nozzle', '||', '001||001', '1||1', 'KGS||KGS', '250||250', '15000||15000', '10||10', '10||10', '', '37500000.00||37500000.00', '0||0', 'amount_wise', '0||0', '37500000.00||37500000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1', NULL, 'P001010925', 'P001-2025', 1, 2, '05-09-2025||25-09-2025', 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`) VALUES (2, '2025-11-15', '2025-11-15', '2025-11-15', '15-11-2025', 'Direct PO', 'P002', '555', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '641024||641024', '002||003', NULL, 'Coal Nozzle||Coal Nozzle', '002||003', '001||001', '3||3', 'KGS||KGS', '250||250', '15000||15000', '20||30', '20||30', '', '75000000.00||112500000.00', '0||0', 'amount_wise', '0||0', '75000000.00||112500000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1', NULL, 'P002151125', 'P002-2025', 1, 2, '01-12-2025||01-12-2025', 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`) VALUES (3, '2025-11-15', '2025-11-15', '2025-11-15', '15-11-2025', 'Direct PO', 'P003', '666', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '641024||641024', '002||003', NULL, 'Coal Nozzle||Coal Nozzle', '||', '001||001', '3||3', 'KGS||KGS', '250||250', '15000||15000', '20||20', '20||20', '', '75000000.00||75000000.00', '0||0', 'amount_wise', '0||0', '75000000.00||75000000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1', NULL, 'P003151125', 'P003-2025', 1, 2, '28-11-2025||29-11-2025', 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`) VALUES (4, '2025-11-15', '2025-11-15', '2025-11-15', '15-11-2025', 'Direct PO', 'P004', '005', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '641024||641024', '002||003', NULL, 'Coal Nozzle||Coal Nozzle', '||', '001||005', '3||3', 'KGS||KGS', '250||250', '15000||15000', '10||10', '10||10', '', '37500000.00||37500000.00', '0||0', 'amount_wise', '0||0', '37500000.00||37500000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1', NULL, 'P004151125', 'P004-2025', 1, 2, '01-12-2025||01-12-2025', 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`) VALUES (5, '2025-11-17', '2025-11-17', '2025-11-17', '17-11-2025', 'Direct PO', 'P005', '1111', NULL, 6, 'Tech AU', 'Hoysala nagar, Ramamurthy signal, Avinashi Road, Hopes College, Bangalore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '641024||641024', '002||002', NULL, 'Coal Nozzle||Coal Nozzle', '002||002', '001||001', '3||3', 'KGS||KGS', '250||250', '15000||15000', '50||40', '50||40', '', '187500000.00||150000000.00', '0||0', 'amount_wise', '0||0', '187500000.00||150000000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1', NULL, 'P005171125', 'P005-2025', 1, 2, '01-12-2025||01-12-2025', 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`) VALUES (6, '2025-11-17', '2025-11-17', '2025-11-17', '17-11-2025', 'Direct PO', 'P006', '1212', NULL, 6, 'Tech AU', 'Hoysala nagar, Ramamurthy signal, Avinashi Road, Hopes College, Bangalore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '641024||641024', '003||003', NULL, 'Zozzle||Zozzle', '003||003', '0003||0003', '3||3', 'KGS||KGS', '250||250', '10000||10000', '20||20', '20||20', '', '50000000.00||50000000.00', '0||0', 'amount_wise', '0||0', '50000000.00||50000000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1', NULL, 'P006171125', 'P006-2025', 1, 2, '01-12-2025||01-12-2025', 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`) VALUES (7, '2025-11-17', '2025-11-17', '2025-11-17', '17-11-2025', 'Direct PO', 'P007', '100', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '641024||641024', '002||003', NULL, 'Coal Nozzle||Zozzle', '||', '001||0003', '3||3', 'KGS||KGS', '250||250', '15000||10000', '10||10', '10||10', '', '37500000.00||25000000.00', '0||0', 'amount_wise', '0||0', '37500000.00||25000000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1', NULL, 'P007171125', 'P007-2025', 1, 2, '01-12-2025||01-12-2025', 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`) VALUES (8, '2025-11-20', '2025-11-20', '2025-11-20', '20-11-2025', 'Direct PO', 'P008', '1001', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '641024', '002', NULL, 'Coal Nozzle', '', '001', '3', 'KGS', '250', '15000', '50', '50', '', '187500000.00', '0', 'amount_wise', '0', '187500000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, 'P008201125', 'P008-2025', 1, 1, NULL, 1);


#
# TABLE STRUCTURE FOR: purchaseorder_details_backup
#

DROP TABLE IF EXISTS `purchaseorder_details_backup`;

CREATE TABLE `purchaseorder_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: purchaseorder_reports
#

DROP TABLE IF EXISTS `purchaseorder_reports`;

CREATE TABLE `purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `heatno` text DEFAULT NULL,
  `itemid` text DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `weight` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `workorderbalance` varchar(100) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (1, '1', '2025-09-01', 'Direct PO', 'P001', '001', NULL, '2025-09-01', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', '2025-09-01', NULL, '002', NULL, NULL, '123456', 'Coal Nozzle', 'KGS', '250', '1', '001', '15000', '10', '10', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5', '1', NULL, NULL, NULL, NULL, NULL, 'P001-2025', 'P001010925');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (2, '1', '2025-09-01', 'Direct PO', 'P001', '001', NULL, '2025-09-01', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', '2025-09-01', NULL, '002', NULL, NULL, '123456', 'Coal Nozzle', 'KGS', '250', '1', '001', '15000', '10', '10', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5', '1', NULL, NULL, NULL, NULL, NULL, 'P001-2025', 'P001010925');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (3, '2', '2025-11-15', 'Direct PO', 'P002', '555', NULL, '2025-11-15', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', '2025-11-15', NULL, '002', NULL, NULL, '641024', 'Coal Nozzle', 'KGS', '250', '3', '001', '15000', '20', '20', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '15', '1', NULL, NULL, NULL, NULL, NULL, 'P002-2025', 'P002151125');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (4, '2', '2025-11-15', 'Direct PO', 'P002', '555', NULL, '2025-11-15', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', '2025-11-15', NULL, '003', NULL, NULL, '641024', 'Coal Nozzle', 'KGS', '250', '3', '001', '15000', '30', '30', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '25', '1', NULL, NULL, NULL, NULL, NULL, 'P002-2025', 'P002151125');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (5, '3', '2025-11-15', 'Direct PO', 'P003', '666', NULL, '2025-11-15', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', '2025-11-15', NULL, '002', NULL, NULL, '641024', 'Coal Nozzle', 'KGS', '250', '3', '001', '15000', '20', '20', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '10', '1', NULL, NULL, NULL, NULL, NULL, 'P003-2025', 'P003151125');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (6, '3', '2025-11-15', 'Direct PO', 'P003', '666', NULL, '2025-11-15', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', '2025-11-15', NULL, '003', NULL, NULL, '641024', 'Coal Nozzle', 'KGS', '250', '3', '001', '15000', '20', '20', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '10', '1', NULL, NULL, NULL, NULL, NULL, 'P003-2025', 'P003151125');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (7, '4', '2025-11-15', 'Direct PO', 'P004', '005', NULL, '2025-11-15', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', '2025-11-15', NULL, '002', NULL, NULL, '641024', 'Coal Nozzle', 'KGS', '250', '3', '001', '15000', '10', '10', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5', '1', NULL, NULL, NULL, NULL, NULL, 'P004-2025', 'P004151125');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (8, '4', '2025-11-15', 'Direct PO', 'P004', '005', NULL, '2025-11-15', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', '2025-11-15', NULL, '003', NULL, NULL, '641024', 'Coal Nozzle', 'KGS', '250', '3', '005', '15000', '10', '10', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5', '1', NULL, NULL, NULL, NULL, NULL, 'P004-2025', 'P004151125');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (9, '5', '2025-11-17', 'Direct PO', 'P005', '1111', NULL, '2025-11-17', NULL, 6, 'Tech AU', 'Hoysala nagar, Ramamurthy signal, Avinashi Road, Hopes College, Bangalore, Tamil Nadu', '0', '2025-11-17', NULL, '002', NULL, NULL, '641024', 'Coal Nozzle', 'KGS', '250', '3', '001', '15000', '50', '50', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '10', '1', NULL, NULL, NULL, NULL, NULL, 'P005-2025', 'P005171125');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (10, '5', '2025-11-17', 'Direct PO', 'P005', '1111', NULL, '2025-11-17', NULL, 6, 'Tech AU', 'Hoysala nagar, Ramamurthy signal, Avinashi Road, Hopes College, Bangalore, Tamil Nadu', '0', '2025-11-17', NULL, '002', NULL, NULL, '641024', 'Coal Nozzle', 'KGS', '250', '3', '001', '15000', '40', '40', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '10', '1', NULL, NULL, NULL, NULL, NULL, 'P005-2025', 'P005171125');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (11, '6', '2025-11-17', 'Direct PO', 'P006', '1212', NULL, '2025-11-17', NULL, 6, 'Tech AU', 'Hoysala nagar, Ramamurthy signal, Avinashi Road, Hopes College, Bangalore, Tamil Nadu', '0', '2025-11-17', NULL, '003', NULL, NULL, '641024', 'Zozzle', 'KGS', '250', '3', '0003', '10000', '20', '20', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '10', '1', NULL, NULL, NULL, NULL, NULL, 'P006-2025', 'P006171125');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (12, '6', '2025-11-17', 'Direct PO', 'P006', '1212', NULL, '2025-11-17', NULL, 6, 'Tech AU', 'Hoysala nagar, Ramamurthy signal, Avinashi Road, Hopes College, Bangalore, Tamil Nadu', '0', '2025-11-17', NULL, '003', NULL, NULL, '641024', 'Zozzle', 'KGS', '250', '3', '0003', '10000', '20', '20', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '10', '1', NULL, NULL, NULL, NULL, NULL, 'P006-2025', 'P006171125');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (13, '7', '2025-11-17', 'Direct PO', 'P007', '100', NULL, '2025-11-17', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', '2025-11-17', NULL, '002', NULL, NULL, '641024', 'Coal Nozzle', 'KGS', '250', '3', '001', '15000', '10', '10', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5', '1', NULL, NULL, NULL, NULL, NULL, 'P007-2025', 'P007171125');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (14, '7', '2025-11-17', 'Direct PO', 'P007', '100', NULL, '2025-11-17', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', '2025-11-17', NULL, '003', NULL, NULL, '641024', 'Zozzle', 'KGS', '250', '3', '0003', '10000', '10', '10', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '5', '1', NULL, NULL, NULL, NULL, NULL, 'P007-2025', 'P007171125');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (15, '8', '2025-11-20', 'Direct PO', 'P008', '1001', NULL, '2025-11-20', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', '2025-11-20', NULL, '002', NULL, NULL, '641024', 'Coal Nozzle', 'KGS', '250', '3', '001', '15000', '50', '50', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', NULL, NULL, NULL, NULL, NULL, 'P008-2025', 'P008201125');


#
# TABLE STRUCTURE FOR: quotation_details
#

DROP TABLE IF EXISTS `quotation_details`;

CREATE TABLE `quotation_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `quotation_details` (`id`, `date`, `quotationdate`, `gstinno`, `invoicedate`, `quotationno`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemname`, `description`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightcharges`, `packingcharges`, `othercharges`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (1, '2025-06-23', '2025-06-23', NULL, NULL, 'Q001', 4, 'IT Solution', 'Hoysala nagar, Ramamurthy signal, Kasthuri nagar, Bangalore, Karnataka', NULL, NULL, 'intrastate', NULL, NULL, NULL, '00002', 'Stationary things', NULL, 'PACK', '170', '12', '2040.00', '0', '0', '2040.00', '7.5', '153.00', '7.5', '153.00', '15', '', '2040.00', '2040.00', NULL, NULL, NULL, NULL, '2346.00', NULL, NULL, 1, 1);


#
# TABLE STRUCTURE FOR: quotation_details_backup
#

DROP TABLE IF EXISTS `quotation_details_backup`;

CREATE TABLE `quotation_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: sales_return
#

DROP TABLE IF EXISTS `sales_return`;

CREATE TABLE `sales_return` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `discountamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `sales_return` (`id`, `date`, `returndate`, `types`, `time`, `dateofissue`, `customername`, `customerid`, `supplierid`, `gsttype`, `suppliername`, `openingbal`, `outstandingamount`, `returnno`, `description`, `invoiceno`, `purchaseno`, `itemno`, `hsnno`, `itemname`, `rate`, `qty`, `uom`, `amount`, `discount`, `taxableamount`, `discountamount`, `cgst`, `cgstamount`, `sgst`, `sgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `grandtotal`, `status`) VALUES (1, '2025-06-24', '2025-06-24', 'Credit', '11:14:26 PM', '2025-06-24', '-', '-', '5', 'intrastate', 'Gateway', '1864', NULL, 'C001', 'Package damage', '-', 'P003', NULL, '00002', 'Stationary things', '170', '5', 'PACK', '850.00', '0', '850.00', '0.00', '7.5', '63.75', '7.5', '63.75', '15', '', '977.50', '995.50', '6', '0', '0.00', '0', '0.00', '0', '0.00', '6.00', '12', '0', '0.00', '0', '0.00', '0', '0.00', '12.00', '0', '995.50', '1');


#
# TABLE STRUCTURE FOR: sales_return_backup
#

DROP TABLE IF EXISTS `sales_return_backup`;

CREATE TABLE `sales_return_backup` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `discountamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: statecode
#

DROP TABLE IF EXISTS `statecode`;

CREATE TABLE `statecode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) NOT NULL,
  `stateCode` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (1, 'Jammu & Kashmir', '01', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (2, 'Himachal Pradesh', '02', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (3, 'Punjab', '03', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (4, 'Chandigarh', '04', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (5, 'Uttarakhand', '05', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (6, 'Haryana', '06', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (7, 'Delhi', '07', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (8, 'Rajasthan', '08', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (9, 'Uttar Pradesh', '09', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (10, 'Bihar', '10', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (11, 'Sikkim', '11', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (12, 'Arunachal Pradesh', '12', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (13, 'Nagaland', '13', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (14, 'Manipur', '14', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (15, 'Mizoram', '15', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (16, 'Tripura', '16', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (17, 'Meghalaya', '17', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (18, 'Assam', '18', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (19, 'West Bengal', '19', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (20, 'Jharkhand', '20', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (21, 'odisha', '21', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (22, 'Chattisgarh', '22', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (23, 'Madhya Pradesh', '23', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (24, 'Daman & Diu', '25', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (25, 'Gujarat', '24', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (26, 'Dadra & Nagar Haveli', '26', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (27, 'Maharashtra', '27', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (28, 'Andhra Pradesh', '28', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (29, 'Karnataka', '29', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (30, 'Goa', '30', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (31, 'Lakshadweep', '31', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (32, 'Kerala', '32', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (33, 'Tamil Nadu', '33', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (34, 'Puducherry', '34', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (35, 'Andaman & Nicobar Islands', '35', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (36, 'Telengana', '36', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (37, 'Andrapradesh(New)', '37', 1);


#
# TABLE STRUCTURE FOR: stock
#

DROP TABLE IF EXISTS `stock`;

CREATE TABLE `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `heatno` varchar(255) DEFAULT NULL,
  `itemid` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `updatestock` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `balance` varchar(255) NOT NULL,
  `oldqty` varchar(255) DEFAULT NULL,
  `currentstock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (1, '2025-11-15', '123456', '001', '1', '002', '9', '9', '18', 'Coal Nozzle', '2', '15000', '2', '', '', '-22', NULL, NULL, '', '2025-11-15', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (2, '2025-11-15', '123456', '002', '|', '002', '9', '9', '18', 'Coal Nozzle', '1', '15000', '1', '', '', '-23', NULL, NULL, '', '2025-11-15', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (3, '2025-11-14', '123456', '101', '1', '002', '9', '9', '18', 'Coal Nozzle', '1', '15000', '1', '', '', '3', NULL, NULL, '', '2025-11-14', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (4, '2025-11-14', '123456', '102', '|', '002', '9', '9', '18', 'Coal Nozzle', '1', '15000', '1', '', '', '2', NULL, NULL, '', '2025-11-14', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (5, '2025-11-14', '123456', '103', '|', '002', '9', '9', '18', 'Coal Nozzle', '1', '15000', '1', '', '', '3', NULL, NULL, '', '2025-11-14', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (6, '2025-11-14', '123456', '104', '1', '002', '9', '9', '18', 'Coal Nozzle', '2', '15000', '2', '', '', '4', NULL, NULL, '', '2025-11-14', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (7, '2025-11-14', '123456', '105', '|', '002', '9', '9', '18', 'Coal Nozzle', '1', '15000', '1', '', '', '4', NULL, NULL, '', '2025-11-14', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (8, '2025-11-14', '123456', '106', '|', '002', '9', '9', '18', 'Coal Nozzle', '4', '15000', '4', '', '', '4', NULL, NULL, '', '2025-11-14', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (9, '2025-11-14', '123456', '200', '1', '002', '9', '9', '18', 'Coal Nozzle', '5', '15000', '5', '', '', '9', NULL, NULL, '', '2025-11-14', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (10, '2025-11-14', '123456', '20', '|', '002', '9', '9', '18', 'Coal Nozzle', '1', '15000', '1', '', '', '1', NULL, NULL, '', '2025-11-14', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (11, '2025-11-14', '123456', '1', '1', '002', '9', '9', '18', 'Coal Nozzle', '5', '15000', '5', '', '', '20', NULL, NULL, '', '2025-11-14', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (12, '2025-11-15', '123456', '006', '1', '002', '9', '9', '18', 'Coal Nozzle', '1', '15000', '1', '', '', '13', NULL, NULL, '', '2025-11-15', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (13, '2025-11-20', '641024', '001', '1', '002', '9', '9', '18', 'Coal Nozzle', '2', '15000', '2', '', '', '-11', NULL, NULL, '', '2025-11-20', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (14, '2025-11-20', '641024', '002', '1', '002', '9', '9', '18', 'Coal Nozzle', '2', '15000', '2', '', '', '-1', NULL, NULL, '', '2025-11-20', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (25, '2025-11-19', '641024', NULL, '', NULL, '9', '9', '18', 'Coal Nozzle', '1', '15000', '1', '', '', '7', NULL, NULL, '', '2025-11-19', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (15, '2025-11-19', '641024', '0002', '1', '002', '9', '9', '18', 'Coal Nozzle', '5', '15000', '5', '', '', '-13', NULL, NULL, '', '2025-11-17', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (16, '2025-11-17', '641024', '003', '3', '003', '9', '9', '18', 'Zozzle', '2', '10000', '2', '', '', '7', NULL, NULL, '', '2025-11-17', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (17, '2025-11-17', '641024', '004', '|', '003', '9', '9', '18', 'Zozzle', '3', '10000', '3', '', '', '8', NULL, NULL, '', '2025-11-17', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (18, '2025-11-17', '641024', '2', '3', '003', '9', '9', '18', 'Zozzle', '3', '10000', '3', '', '', '3', NULL, NULL, '', '2025-11-17', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (19, '2025-11-17', '641024', '3', '|', '003', '9', '9', '18', 'Zozzle', '2', '10000', '2', '', '', '2', NULL, NULL, '', '2025-11-17', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (20, '2025-11-19', '641024', '100', '1', '002', '9', '9', '18', 'Coal Nozzle', '1', '15000', '1', '', '', '-13', NULL, NULL, '', '2025-11-17', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (21, '2025-11-19', '641024', '101', '|', '002', '9', '9', '18', 'Coal Nozzle', '2', '15000', '2', '', '', '-13', NULL, NULL, '', '2025-11-17', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (22, '2025-11-19', '641024', '102', '|', '002', '9', '9', '18', 'Coal Nozzle', '1', '15000', '1', '', '', '-13', NULL, NULL, '', '2025-11-17', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (23, '2025-11-19', '641024', '103', '1', '002', '9', '9', '18', 'Coal Nozzle', '1', '15000', '1', '', '', '-13', NULL, NULL, '', '2025-11-17', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (24, '2025-11-17', '641024', '205', '|', '003', '9', '9', '18', 'Zozzle', '3', '10000', '3', '', '', '3', NULL, NULL, '', '2025-11-17', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (26, '2025-11-20', '641024', '', '|', '003', '9', '9', '18', 'Coal Nozzle', '', '10000', '', '', '', '0', NULL, NULL, '', '2025-11-20', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (27, '2025-11-20', '641024', '0033', '1', '002', '9', '9', '18', 'Coal Nozzle', '50', '15000', '50', '', '', '50', NULL, NULL, '', '2025-11-20', 'Exclusive');


#
# TABLE STRUCTURE FOR: stock_reports
#

DROP TABLE IF EXISTS `stock_reports`;

CREATE TABLE `stock_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `heatno` varchar(255) DEFAULT NULL,
  `itemid` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `updatestock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  `balance` varchar(225) DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (6, '2025-09-12', '123456', '002', '|', '002', 'Coal Nozzle', NULL, '6', '', '2025-09-11', '6', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (5, '2025-09-12', '123456', '001', '1', '002', 'Coal Nozzle', NULL, '6', '', '2025-09-11', '6', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (7, '2025-11-14', '123456', '101', '1', '002', 'Coal Nozzle', NULL, '2', '', '2025-11-14', '7', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (8, '2025-11-14', '123456', '102', '|', '002', 'Coal Nozzle', NULL, '1', '', '2025-11-14', '7', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (9, '2025-11-14', '123456', '103', '|', '002', 'Coal Nozzle', NULL, '2', '', '2025-11-14', '7', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (10, '2025-11-14', '123456', '104', '1', '002', 'Coal Nozzle', NULL, '2', '', '2025-11-14', '7', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (11, '2025-11-14', '123456', '105', '|', '002', 'Coal Nozzle', NULL, '3', '', '2025-11-14', '7', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (12, '2025-11-14', '123456', '101', '1', '002', 'Coal Nozzle', NULL, '1', '', NULL, '8', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (13, '2025-11-14', '123456', '102', '|', '002', 'Coal Nozzle', NULL, '1', '', NULL, '8', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (14, '2025-11-14', '123456', '103', '|', '002', 'Coal Nozzle', NULL, '1', '', NULL, '8', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (15, '2025-11-14', '123456', '104', '1', '002', 'Coal Nozzle', NULL, '2', '', NULL, '8', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (16, '2025-11-14', '123456', '105', '|', '002', 'Coal Nozzle', NULL, '1', '', NULL, '8', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (17, '2025-11-14', '123456', '106', '|', '002', 'Coal Nozzle', NULL, '4', '', '2025-11-14', '8', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (18, '2025-11-14', '123456', '200', '1', '002', 'Coal Nozzle', NULL, '2', '', '2025-11-14', '9', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (19, '2025-11-14', '123456', '200', '|', '002', 'Coal Nozzle', NULL, '2', '', NULL, '9', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (20, '2025-11-14', '123456', '20', '|', '002', 'Coal Nozzle', NULL, '1', '', '2025-11-14', '9', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (21, '2025-11-14', '123456', '200', '1', '002', 'Coal Nozzle', NULL, '5', '', NULL, '9', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (22, '2025-11-14', '123456', '1', '1', '002', 'Coal Nozzle', NULL, '1', '', '2025-11-14', '10', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (23, '2025-11-14', '123456', '1', '|', '002', 'Coal Nozzle', NULL, '1', '', NULL, '10', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (24, '2025-11-14', '123456', '1', '|', '002', 'Coal Nozzle', NULL, '1', '', NULL, '10', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (25, '2025-11-14', '123456', '1', '1', '002', 'Coal Nozzle', NULL, '1', '', NULL, '10', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (26, '2025-11-14', '123456', '1', '|', '002', 'Coal Nozzle', NULL, '1', '', NULL, '10', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (27, '2025-11-14', '123456', '1', '1', '002', 'Coal Nozzle', NULL, '5', '', NULL, '11', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (28, '2025-11-14', '123456', '1', '1', '002', 'Coal Nozzle', NULL, '5', '', NULL, '12', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (29, '2025-11-14', '123456', '1', '1', '002', 'Coal Nozzle', NULL, '5', '', NULL, '13', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (30, '2025-11-15', '123456', '001', '1', '002', 'Coal Nozzle', NULL, '2', '', NULL, '14', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (31, '2025-11-15', '123456', '002', '|', '002', 'Coal Nozzle', NULL, '1', '', NULL, '14', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (32, '2025-11-15', '123456', '006', '1', '002', 'Coal Nozzle', NULL, '5', '', '2025-11-15', '15', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (33, '2025-11-15', '123456', '006', '|', '002', 'Coal Nozzle', NULL, '2', '', NULL, '15', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (34, '2025-11-15', '123456', '006', '|', '002', 'Coal Nozzle', NULL, '5', '', NULL, '15', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (35, '2025-11-15', '123456', '006', '1', '002', 'Coal Nozzle', NULL, '1', '', NULL, '15', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (36, '2025-11-15', '641024', '001', '1', '002', 'Coal Nozzle', NULL, '1', '', '2025-11-15', '16', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (37, '2025-11-15', '641024', '001', '|', '002', 'Coal Nozzle', NULL, '1', '', NULL, '16', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (38, '2025-11-15', '641024', '002', '|', '002', 'Coal Nozzle', NULL, '2', '', '2025-11-15', '16', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (39, '2025-11-15', '641024', '002', '1', '002', 'Coal Nozzle', NULL, '1', '', NULL, '16', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (40, '2025-11-15', '641024', '001', '1', '002', 'Coal Nozzle', NULL, '1', '', NULL, '17', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (41, '2025-11-15', '641024', '001', '|', '002', 'Coal Nozzle', NULL, '1', '', NULL, '17', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (42, '2025-11-15', '641024', '002', '|', '002', 'Coal Nozzle', NULL, '2', '', NULL, '17', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (43, '2025-11-15', '641024', '002', '1', '002', 'Coal Nozzle', NULL, '1', '', NULL, '17', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (44, '2025-11-15', '641024', '001', '1', '002', 'Coal Nozzle', NULL, '1', '', NULL, '18', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (45, '2025-11-15', '641024', '001', '|', '002', 'Coal Nozzle', NULL, '1', '', NULL, '18', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (46, '2025-11-15', '641024', '002', '|', '002', 'Coal Nozzle', NULL, '2', '', NULL, '18', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (47, '2025-11-15', '641024', '002', '1', '002', 'Coal Nozzle', NULL, '1', '', NULL, '18', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (48, '2025-11-17', '641024', '001', '1', '002', 'Coal Nozzle', NULL, '10', '', NULL, '19', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (49, '2025-11-17', '641024', '001', '|', '002', 'Coal Nozzle', NULL, '10', '', NULL, '19', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (50, '2025-11-17', '641024', '002', '|', '002', 'Coal Nozzle', NULL, '10', '', NULL, '19', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (51, '2025-11-17', '641024', '0002', '1', '002', 'Coal Nozzle', NULL, '5', '', '2025-11-17', '19', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (52, '2025-11-17', '641024', '003', '3', '003', 'Zozzle', NULL, '3', '', '2025-11-17', '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (53, '2025-11-17', '641024', '003', '|', '003', 'Zozzle', NULL, '2', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (54, '2025-11-17', '641024', '004', '|', '003', 'Zozzle', NULL, '3', '', '2025-11-17', '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (55, '2025-11-17', '641024', '004', '3', '003', 'Zozzle', NULL, '2', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (56, '2025-11-17', '641024', '2', '3', '003', 'Zozzle', NULL, '3', '', '2025-11-17', '21', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (57, '2025-11-17', '641024', '3', '|', '003', 'Zozzle', NULL, '2', '', '2025-11-17', '21', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (58, '2025-11-17', '641024', '003', '3', '003', 'Zozzle', NULL, '2', '', NULL, '22', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (59, '2025-11-17', '641024', '004', '|', '003', 'Zozzle', NULL, '3', '', NULL, '22', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (60, '2025-11-17', '641024', '100', '1', '002', 'Coal Nozzle', NULL, '1', '', '2025-11-17', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (61, '2025-11-17', '641024', '101', '|', '002', 'Coal Nozzle', NULL, '2', '', '2025-11-17', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (62, '2025-11-17', '641024', '102', '|', '002', 'Coal Nozzle', NULL, '1', '', '2025-11-17', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (63, '2025-11-17', '641024', '103', '1', '002', 'Coal Nozzle', NULL, '1', '', '2025-11-17', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (64, '2025-11-17', '641024', '205', '|', '003', 'Zozzle', NULL, '3', '', '2025-11-17', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (65, '2025-11-17', '641024', '001', '1', '002', 'Coal Nozzle', NULL, '5', '', NULL, '24', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (66, '2025-11-17', '641024', '001', '|', '002', 'Coal Nozzle', NULL, '5', '', NULL, '24', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (67, '2025-11-17', '641024', '002', '|', '002', 'Coal Nozzle', NULL, '3', '', NULL, '24', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (68, '2025-11-17', '641024', '002', '1', '002', 'Coal Nozzle', NULL, '2', '', NULL, '24', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (69, '2025-11-17', '641024', '001', '1', '002', 'Coal Nozzle', NULL, '2', '', NULL, '25', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (70, '2025-11-17', '641024', '001', '|', '002', 'Coal Nozzle', NULL, '2', '', NULL, '25', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (71, '2025-11-17', '641024', '001', '|', '002', 'Coal Nozzle', NULL, '2', '', NULL, '25', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (72, '2025-11-17', '641024', '001', '1', '002', 'Coal Nozzle', NULL, '2', '', NULL, '25', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (73, '2025-11-17', '641024', '002', '|', '002', 'Coal Nozzle', NULL, '2', '', NULL, '25', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (74, '2025-11-17', '641024', '002', '|', '002', 'Coal Nozzle', NULL, '2', '', NULL, '25', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (75, '2025-11-17', '641024', '002', '1', '002', 'Coal Nozzle', NULL, '2', '', NULL, '25', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (76, '2025-11-17', '641024', '002', '|', '002', 'Coal Nozzle', NULL, '2', '', NULL, '25', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (90, '2025-11-19', '641024', '002', '1', '002', 'Coal Nozzle', NULL, '1', '', '2025-11-19', '26', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (89, '2025-11-19', '641024', '002', '|', '002', 'Coal Nozzle', NULL, '1', '', '2025-11-19', '26', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (88, '2025-11-19', '641024', '002', '|', '002', 'Coal Nozzle', NULL, '1', '', '2025-11-19', '26', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (87, '2025-11-19', '641024', '002', '1', '002', 'Coal Nozzle', NULL, '1', '', '2025-11-19', '26', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (86, '2025-11-19', '641024', NULL, '|', NULL, 'Coal Nozzle', NULL, '1', '', '2025-11-19', '27', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (91, '2025-11-20', '641024', '002', '1', '002', 'Coal Nozzle', NULL, '2', '', NULL, '28', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (85, '2025-11-19', '641024', NULL, '|', NULL, 'Coal Nozzle', NULL, '2', '', '2025-11-19', '27', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (92, '2025-11-20', '641024', '', '|', '003', 'Coal Nozzle', NULL, '', '', '2025-11-20', '28', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (93, '2025-11-20', '641024', '002', '1', '002', 'Coal Nozzle', NULL, '2', '', NULL, '29', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (94, '2025-11-20', '641024', '002', '1', '002', 'Coal Nozzle', NULL, '2', '', NULL, '30', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (95, '2025-11-20', '641024', '', '|', '003', 'Coal Nozzle', NULL, '', '', NULL, '30', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (96, '2025-11-20', '641024', '002', '1', '002', 'Coal Nozzle', NULL, '2', '', NULL, '31', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (97, '2025-11-20', '641024', '', '|', '003', 'Coal Nozzle', NULL, '', '', NULL, '31', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (98, '2025-11-20', '641024', '001', '1', '002', 'Coal Nozzle', NULL, '2', '', NULL, '32', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (99, '2025-11-20', '641024', '', '|', '003', 'Coal Nozzle', NULL, '', '', NULL, '32', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (100, '2025-11-20', '641024', '0033', '1', '002', 'Coal Nozzle', NULL, '50', '', '2025-11-20', '33', NULL, 'Exclusive');


#
# TABLE STRUCTURE FOR: sup_purchaseorder_details
#

DROP TABLE IF EXISTS `sup_purchaseorder_details`;

CREATE TABLE `sup_purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `deliverydate` varchar(100) NOT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `supplierid` varchar(100) NOT NULL,
  `suppliername` varchar(100) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToAddress` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(100) NOT NULL,
  `itemname` longtext DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `workorderno` varchar(100) NOT NULL,
  `workorderid` varchar(100) NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `uom` longtext DEFAULT NULL,
  `weight` varchar(100) DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (1, '2025-09-01', '2025-09-01', NULL, '01-09-2025', 'workorder', 'P001', NULL, NULL, '3', 'CK PRIME ALLOYS', 1, 'jack', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', NULL, NULL, '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '123456||123456', '002||002', 'Coal Nozzle||Coal Nozzle', '1||1', 'P001', '1||2', '001||001', 'KGS||KGS', '250||250', '15000||15000', '5||5', '5||5', '', '18750000.00||18750000.00', NULL, 'amount_wise', '||', '18750000.00||18750000.00', '6', '2250000.00', '6', '2250000.00', '0||0', '0||0', NULL, '37500000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1||1', '42000000.00', 'P001010925', 'P001-2025', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (2, '2025-11-15', '2025-11-15', NULL, '15-11-2025', 'workorder', 'P002', NULL, NULL, '3', 'CK PRIME ALLOYS', 1, 'jack', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', NULL, NULL, '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024', '002||003', 'Coal Nozzle||Coal Nozzle', '3||3', 'P002', '3||4', '001||001', 'KGS||KGS', '250||250', '15000||15000', '5||5', '5||5', '', '18750000.00||18750000.00', NULL, 'amount_wise', '||', '18750000.00||18750000.00', '9', '3375000.00', '9', '3375000.00', '0||0', '0||0', NULL, '37500000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1||1', '44250000.00', 'P002151125', 'P002-2025', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (3, '2025-11-15', '2025-11-15', NULL, '15-11-2025', 'workorder', 'P003', NULL, NULL, '3', 'CK PRIME ALLOYS', 1, 'jack', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', NULL, NULL, '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024', '002||003', 'Coal Nozzle||Coal Nozzle', '3||3', 'P003', '5||6', '001||001', 'KGS||KGS', '250||250', '15000||15000', '10||10', '10||10', '', '37500000.00||37500000.00', NULL, 'amount_wise', '||', '37500000.00||37500000.00', '', '0.00', '0', '0.00', '0||0', '0||0', NULL, '75000000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1||1', '75000000.00', 'P003151125', 'P003-2025', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (4, '2025-11-15', '2025-11-15', NULL, '15-11-2025', 'workorder', 'P004', NULL, NULL, '3', 'CK PRIME ALLOYS', 1, 'jack', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', NULL, NULL, '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024', '002||003', 'Coal Nozzle||Coal Nozzle', '3||3', 'P004', '7||8', '001||005', 'KGS||KGS', '250||250', '15000||15000', '5||5', '5||5', '', '18750000.00||18750000.00', NULL, 'amount_wise', '||', '18750000.00||18750000.00', '9', '3375000.00', '9', '3375000.00', '0||0', '0||0', NULL, '37500000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1||1', '44250000.00', 'P004151125', 'P004-2025', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (5, '2025-11-17', '2025-11-17', NULL, '17-11-2025', 'workorder', 'P005', NULL, NULL, '5', 'Gateway', 6, 'Tech AU', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', NULL, NULL, '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024', '002||002', 'Coal Nozzle||Coal Nozzle', '3||3', 'P005', '9||10', '001||001', 'KGS||KGS', '250||250', '15000||15000', '40||30', '40||30', '', '150000000.00||112500000.00', NULL, 'amount_wise', '||', '150000000.00||112500000.00', '9', '23625000.00', '9', '23625000.00', '0||0', '0||0', NULL, '262500000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1||1', '309750000.00', 'P005171125', 'P005-2025', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (6, '2025-11-17', '2025-11-17', NULL, '17-11-2025', 'workorder', 'P006', NULL, NULL, '5', 'Gateway', 6, 'Tech AU', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', NULL, NULL, '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024', '003||003', 'Zozzle||Zozzle', '3||3', 'P006', '11||12', '0003||0003', 'KGS||KGS', '250||250', '10000||10000', '10||10', '10||10', '', '25000000.00||25000000.00', NULL, 'amount_wise', '||', '25000000.00||25000000.00', '9', '4500000.00', '9', '4500000.00', '0||0', '0||0', NULL, '50000000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1||1', '59000000.00', 'P006171125', 'P006-2025', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (7, '2025-11-17', '2025-11-17', NULL, '17-11-2025', 'workorder', 'P007', NULL, NULL, '3', 'CK PRIME ALLOYS', 1, 'jack', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', NULL, NULL, '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024||641024', '002||003', 'Coal Nozzle||Zozzle', '3||3', 'P007', '13||14', '001||0003', 'KGS||KGS', '250||250', '15000||10000', '5||5', '5||5', '', '18750000.00||12500000.00', NULL, 'amount_wise', '||', '18750000.00||12500000.00', '9', '2812500.00', '9', '2812500.00', '0||0', '0||0', NULL, '31250000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1||1', '36875000.00', 'P007171125', 'P007-2025', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemname`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (8, '2025-11-20', '2025-11-20', NULL, '20-11-2025', 'workorder', 'P008', NULL, NULL, '8', 'Jack', 1, 'jack', 'cbe, cbe, CBE, Tamil Nadu', NULL, NULL, '0', 'intrastate', 'intrastate', 'sgst', 'cgst', '', '641024', '002', 'Coal Nozzle', '3', 'P008', '15', '001', 'KGS', '250', '15000', '50', '50', '', '187500000.00', NULL, 'amount_wise', '', '187500000.00', '9', '16875000.00', '9', '16875000.00', '0', '0', NULL, '187500000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', '221250000.00', 'P008201125', 'P008-2025', 1, 1);


#
# TABLE STRUCTURE FOR: sup_purchaseorder_details_backup
#

DROP TABLE IF EXISTS `sup_purchaseorder_details_backup`;

CREATE TABLE `sup_purchaseorder_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: sup_purchaseorder_reports
#

DROP TABLE IF EXISTS `sup_purchaseorder_reports`;

CREATE TABLE `sup_purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `supplierid` varchar(100) NOT NULL,
  `suppliername` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `deliverydate` varchar(100) NOT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(100) NOT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `weight` varchar(100) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `workorderid` varchar(100) NOT NULL,
  `workorderno` varchar(100) NOT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemname`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (1, '1', '2025-09-01', 'workorder', 'P001', NULL, NULL, '2025-09-01', NULL, 1, 'jack', '3', 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '0', NULL, '01-09-2025', NULL, NULL, '123456', '002', 'Coal Nozzle', 'KGS', '250', '1', '20', '1', '001', '1||2', 'P001', '3', '', NULL, '37500000.00', NULL, NULL, NULL, NULL, NULL, '42000000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2025', 'P001010925');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemname`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (2, '1', '2025-09-01', 'workorder', 'P001', NULL, NULL, '2025-09-01', NULL, 1, 'jack', '3', 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '0', NULL, '01-09-2025', NULL, NULL, '123456', '002', 'Coal Nozzle', 'KGS', '250', '5', '20', '1', '001', '1||2', 'P001', '4', '', NULL, '37500000.00', NULL, NULL, NULL, NULL, NULL, '42000000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P001-2025', 'P001010925');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemname`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (3, '2', '2025-11-15', 'workorder', 'P002', NULL, NULL, '2025-11-15', NULL, 1, 'jack', '3', 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '0', NULL, '15-11-2025', NULL, NULL, '641024', '002', 'Coal Nozzle', 'KGS', '250', '1', '5', '3', '001', '3||4', 'P002', '5', '', NULL, '37500000.00', NULL, NULL, NULL, NULL, NULL, '44250000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P002-2025', 'P002151125');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemname`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (4, '2', '2025-11-15', 'workorder', 'P002', NULL, NULL, '2025-11-15', NULL, 1, 'jack', '3', 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '0', NULL, '15-11-2025', NULL, NULL, '641024', '003', 'Coal Nozzle', 'KGS', '250', '5', '5', '3', '001', '3||4', 'P002', '5', '', NULL, '37500000.00', NULL, NULL, NULL, NULL, NULL, '44250000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P002-2025', 'P002151125');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemname`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (5, '3', '2025-11-15', 'workorder', 'P003', NULL, NULL, '2025-11-15', NULL, 1, 'jack', '3', 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '0', NULL, '15-11-2025', NULL, NULL, '641024', '002', 'Coal Nozzle', 'KGS', '250', '1', '10', '3', '001', '5||6', 'P003', '4', '', NULL, '75000000.00', NULL, NULL, NULL, NULL, NULL, '75000000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P003-2025', 'P003151125');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemname`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (6, '3', '2025-11-15', 'workorder', 'P003', NULL, NULL, '2025-11-15', NULL, 1, 'jack', '3', 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '0', NULL, '15-11-2025', NULL, NULL, '641024', '003', 'Coal Nozzle', 'KGS', '250', '5', '10', '3', '001', '5||6', 'P003', '10', '', NULL, '75000000.00', NULL, NULL, NULL, NULL, NULL, '75000000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P003-2025', 'P003151125');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemname`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (7, '4', '2025-11-15', 'workorder', 'P004', NULL, NULL, '2025-11-15', NULL, 1, 'jack', '3', 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '0', NULL, '15-11-2025', NULL, NULL, '641024', '002', 'Coal Nozzle', 'KGS', '250', '1', '5', '3', '001', '7||8', 'P004', '1', '', NULL, '37500000.00', NULL, NULL, NULL, NULL, NULL, '44250000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P004-2025', 'P004151125');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemname`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (8, '4', '2025-11-15', 'workorder', 'P004', NULL, NULL, '2025-11-15', NULL, 1, 'jack', '3', 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '0', NULL, '15-11-2025', NULL, NULL, '641024', '002', 'Coal Nozzle', 'KGS', '250', '5', '5', '3', '005', '7||8', 'P004', '0', '', NULL, '37500000.00', NULL, NULL, NULL, NULL, NULL, '44250000.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P004-2025', 'P004151125');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemname`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (9, '5', '2025-11-17', 'workorder', 'P005', NULL, NULL, '2025-11-17', NULL, 6, 'Tech AU', '5', 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '0', NULL, '17-11-2025', NULL, NULL, '641024', '002', 'Coal Nozzle', 'KGS', '250', '1', '40', '3', '001', '9||10', 'P005', '2', '', NULL, '262500000.00', NULL, NULL, NULL, NULL, NULL, '309750000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P005-2025', 'P005171125');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemname`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (10, '5', '2025-11-17', 'workorder', 'P005', NULL, NULL, '2025-11-17', NULL, 6, 'Tech AU', '5', 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '0', NULL, '17-11-2025', NULL, NULL, '641024', '002', 'Coal Nozzle', 'KGS', '250', '5', '30', '3', '001', '9||10', 'P005', '2', '', NULL, '262500000.00', NULL, NULL, NULL, NULL, NULL, '309750000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P005-2025', 'P005171125');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemname`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (11, '6', '2025-11-17', 'workorder', 'P006', NULL, NULL, '2025-11-17', NULL, 6, 'Tech AU', '5', 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '0', NULL, '17-11-2025', NULL, NULL, '641024', '003', 'Zozzle', 'KGS', '250', '1', '10', '3', '0003', '11||12', 'P006', '0', '', NULL, '50000000.00', NULL, NULL, NULL, NULL, NULL, '59000000.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P006-2025', 'P006171125');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemname`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (12, '6', '2025-11-17', 'workorder', 'P006', NULL, NULL, '2025-11-17', NULL, 6, 'Tech AU', '5', 'Gateway', 'Kasthuri nagar, Sri lakshmi apartement, Bangalore, Bangalore, Karnataka', '0', NULL, '17-11-2025', NULL, NULL, '641024', '003', 'Zozzle', 'KGS', '250', '0', '10', '3', '0003', '11||12', 'P006', '0', '', NULL, '50000000.00', NULL, NULL, NULL, NULL, NULL, '59000000.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P006-2025', 'P006171125');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemname`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (13, '7', '2025-11-17', 'workorder', 'P007', NULL, NULL, '2025-11-17', NULL, 1, 'jack', '3', 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '0', NULL, '17-11-2025', NULL, NULL, '641024', '002', 'Coal Nozzle', 'KGS', '250', '1', '5', '3', '001', '13||14', 'P007', '0', '', NULL, '31250000.00', NULL, NULL, NULL, NULL, NULL, '36875000.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P007-2025', 'P007171125');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemname`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (14, '7', '2025-11-17', 'workorder', 'P007', NULL, NULL, '2025-11-17', NULL, 1, 'jack', '3', 'CK PRIME ALLOYS', 'ANNUR ROAD, KARUMATTAMPATTY, COIMBATORE, Tamil Nadu', '0', NULL, '17-11-2025', NULL, NULL, '641024', '003', 'Zozzle', 'KGS', '250', '5', '5', '3', '0003', '13||14', 'P007', '2', '', NULL, '31250000.00', NULL, NULL, NULL, NULL, NULL, '36875000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'P007-2025', 'P007171125');
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemname`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (15, '8', '2025-11-20', 'workorder', 'P008', NULL, NULL, '2025-11-20', NULL, 1, 'jack', '8', 'Jack', 'cbe, cbe, CBE, Tamil Nadu', '0', NULL, '20-11-2025', NULL, NULL, '641024', '002', 'Coal Nozzle', 'KGS', '250', '1', '50', '3', '001', '15', 'P008', '0', '', NULL, '187500000.00', NULL, NULL, NULL, NULL, NULL, '221250000.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'P008-2025', 'P008201125');


#
# TABLE STRUCTURE FOR: tbl_person
#

DROP TABLE IF EXISTS `tbl_person`;

CREATE TABLE `tbl_person` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: uom
#

DROP TABLE IF EXISTS `uom`;

CREATE TABLE `uom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (1, '2025-06-20', 'KGS', 1);
INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (2, '2025-06-21', 'NOS', 1);
INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (3, '2025-06-23', 'PACK', 1);


#
# TABLE STRUCTURE FOR: user_menu
#

DROP TABLE IF EXISTS `user_menu`;

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) NOT NULL,
  `main_menu` varchar(255) NOT NULL,
  `sub_menu` varchar(255) NOT NULL,
  `sub_menu_link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: ut_report
#

DROP TABLE IF EXISTS `ut_report`;

CREATE TABLE `ut_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `ut_report_no` varchar(100) NOT NULL,
  `ut_date` varchar(100) NOT NULL,
  `customername` varchar(100) NOT NULL,
  `customerid` varchar(100) NOT NULL,
  `stage_of_test` varchar(100) NOT NULL,
  `test_date` varchar(100) NOT NULL,
  `surface_condition` varchar(100) NOT NULL,
  `calibration_block` varchar(100) NOT NULL,
  `equipment` varchar(100) NOT NULL,
  `couplant` varchar(100) NOT NULL,
  `probe` varchar(100) NOT NULL,
  `range_of_crt` varchar(100) NOT NULL,
  `frequency` varchar(100) NOT NULL,
  `gain` varchar(100) NOT NULL,
  `area_coverage` varchar(100) NOT NULL,
  `procedure_ref` varchar(100) NOT NULL,
  `acceptance_standard` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `drawing` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `heat_no` varchar(100) NOT NULL,
  `ut_no` varchar(100) NOT NULL,
  `result` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `ut_report` (`id`, `date`, `ut_report_no`, `ut_date`, `customername`, `customerid`, `stage_of_test`, `test_date`, `surface_condition`, `calibration_block`, `equipment`, `couplant`, `probe`, `range_of_crt`, `frequency`, `gain`, `area_coverage`, `procedure_ref`, `acceptance_standard`, `description`, `itemid`, `drawing`, `grade`, `heat_no`, `ut_no`, `result`, `status`, `created_at`) VALUES (1, '2025-10-21', 'UT001', '21-10-2025', 'jack', '1', 'FINA', '21-10-2025', 'MODSONIC EINSTEIN - II DFT COUPLANT', 'V1 BLOCK', 'ROUGH CASTING', 'OIL+GREASE', 'DUALCRYSTAL PROBE', '0 TO 600', 'DIA 24MM & 4 MHZ', '80 dB', '100%', 'ASME SEC V ART 5 & 23/ CP014', 'ASME B16.34 APP-4', 'Coal Nozzle', '1', '001', '3', 'D3693', 'UT24-73', 'OK FOUND ACCEPTABL', 1, '2025-10-21 12:53:29');


#
# TABLE STRUCTURE FOR: vat_details
#

DROP TABLE IF EXISTS `vat_details`;

CREATE TABLE `vat_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `sgst` varchar(225) DEFAULT NULL,
  `cgst` varchar(225) DEFAULT NULL,
  `igst` varchar(225) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `vat_details` (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (1, '2025-06-20', 'gst', '18', 'gst @ 18 %', '9', '9', '18', '1');
INSERT INTO `vat_details` (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (2, '2025-06-21', 'GSt', '12', 'GSt @ 12 %', '6', '6', '12', '1');
INSERT INTO `vat_details` (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (3, '2025-06-23', 'GST', '15', 'GST @ 15 %', '7.5', '7.5', '15', '1');


#
# TABLE STRUCTURE FOR: vendor_details
#

DROP TABLE IF EXISTS `vendor_details`;

CREATE TABLE `vendor_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `vendorname` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: voucher
#

DROP TABLE IF EXISTS `voucher`;

CREATE TABLE `voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `tdsamount` varchar(100) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `balance_amt` varchar(255) DEFAULT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `voucher` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `tdsamount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (1, '2025-06-20', 'V/25-26/-001', 1, 'jack', '2025-06-20', 'payment', '', 'Cash', '', '', '', '', '', '1100', 'Cash', NULL, NULL, '1100', '1100', '', '1', NULL, NULL, '', 0);
INSERT INTO `voucher` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `tdsamount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (3, '2025-06-21', 'V/25-26/-002', 2, 'SIGMA POWER', '2025-06-21', 'payment', '', 'Cash', '0', '', '', '0', '', '8800', 'Cash', NULL, NULL, '8800', '8800', '', '1', NULL, NULL, '', 0);
INSERT INTO `voucher` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `tdsamount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (4, '2025-06-21', 'V/25-26/-003', 3, 'CK PRIME ALLOYS', '2025-06-21', 'receipt', '', 'Cash', '0', '', '', '0', '', '2400', 'Cash', NULL, NULL, '2400', '2400', '', '1', NULL, NULL, '', 0);
INSERT INTO `voucher` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `tdsamount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (5, '2025-06-24', 'V/25-26/-004', 4, 'IT Solution', '2025-06-24', 'payment', 'Online Purchase', 'Cash', '0', '', '', '0', '', '500', 'Cash', NULL, NULL, '500', '500', '', '1', NULL, NULL, '', 0);
INSERT INTO `voucher` (`id`, `date`, `voucherid`, `cus_suppId`, `name`, `voucherdate`, `vouchertype`, `purpose`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bamount`, `amount`, `paymentdetails`, `transactionid`, `chequedate`, `overallamount`, `voucheramount`, `tdsamount`, `status`, `invoiceno`, `purchaseno`, `balance_amt`, `otherBank`) VALUES (6, '2025-06-24', 'V/25-26/-005', 5, 'Gateway', '2025-06-24', 'receipt', 'Online Purchase', 'Cash', '0', '', '', '0', '', '500', 'Cash', NULL, NULL, '500', '500', '', '1', NULL, NULL, '', 0);


#
# TABLE STRUCTURE FOR: voucher_backup
#

DROP TABLE IF EXISTS `voucher_backup`;

CREATE TABLE `voucher_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `purchaseno` varchar(255) NOT NULL,
  `balance_amt` varchar(255) NOT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

