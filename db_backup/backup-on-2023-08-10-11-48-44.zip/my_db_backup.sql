#
# TABLE STRUCTURE FOR: add_staff
#

DROP TABLE IF EXISTS `add_staff`;

CREATE TABLE `add_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `staff_name` varchar(255) NOT NULL,
  `mobileno` varchar(255) NOT NULL,
  `amobileno` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `referred` varchar(255) NOT NULL,
  `salary` varchar(255) NOT NULL,
  `salarytype` varchar(255) NOT NULL,
  `perdaysalary` varchar(255) NOT NULL,
  `ot` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: additem
#

DROP TABLE IF EXISTS `additem`;

CREATE TABLE `additem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` text CHARACTER SET utf8,
  `price` varchar(255) DEFAULT NULL,
  `taxtype` varchar(225) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `priceType` varchar(10) NOT NULL,
  `itemtype` varchar(255) NOT NULL,
  `purchaseNo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (1, '2023-07-28', '1', '850300', '0', '1080R2-2PM 70MM CLEATED STATOR', '1500', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `hsnno`, `itemcode`, `itemname`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (2, '2023-07-28', '1', '7204', '0', '1080R2-2PM STATOR STAMPING-GANG', '2000', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);


#
# TABLE STRUCTURE FOR: attendance
#

DROP TABLE IF EXISTS `attendance`;

CREATE TABLE `attendance` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `attendancedate` date NOT NULL,
  `staff` varchar(255) NOT NULL,
  `attendances` varchar(255) NOT NULL,
  `intime` varchar(255) NOT NULL,
  `outtime` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `lastupdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: backup_details
#

DROP TABLE IF EXISTS `backup_details`;

CREATE TABLE `backup_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` longtext,
  `date_created` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (1, 'backup-on-2023-07-28-19-21-05.zip', '2023-07-28');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (2, 'backup-on-2023-07-29-10-41-28.zip', '2023-07-29');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (3, 'backup-on-2023-08-01-17-50-00.zip', '2023-08-01');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (4, 'backup-on-2023-08-03-12-03-37.zip', '2023-08-03');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (5, 'backup-on-2023-08-04-10-41-23.zip', '2023-08-04');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (6, 'backup-on-2023-08-07-12-44-36.zip', '2023-08-07');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (7, 'backup-on-2023-08-08-10-32-02.zip', '2023-08-08');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (8, 'backup-on-2023-08-09-15-39-08.zip', '2023-08-09');


#
# TABLE STRUCTURE FOR: backup_url
#

DROP TABLE IF EXISTS `backup_url`;

CREATE TABLE `backup_url` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: bed_details
#

DROP TABLE IF EXISTS `bed_details`;

CREATE TABLE `bed_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `bed` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: card
#

DROP TABLE IF EXISTS `card`;

CREATE TABLE `card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cash_bill
#

DROP TABLE IF EXISTS `cash_bill`;

CREATE TABLE `cash_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cashbill_details
#

DROP TABLE IF EXISTS `cashbill_details`;

CREATE TABLE `cashbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `cust_mobno` varchar(255) NOT NULL,
  `address` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `systemDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: cashbill_reports
#

DROP TABLE IF EXISTS `cashbill_reports`;

CREATE TABLE `cashbill_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `systemDate` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `category` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: collection_details
#

DROP TABLE IF EXISTS `collection_details`;

CREATE TABLE `collection_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: company_logo
#

DROP TABLE IF EXISTS `company_logo`;

CREATE TABLE `company_logo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `company_logo` (`id`, `date`, `image`, `status`) VALUES (1, '2023-08-07', '12832299_1579401915712151_5416626780361493206_n.png', '1');


#
# TABLE STRUCTURE FOR: customer_details
#

DROP TABLE IF EXISTS `customer_details`;

CREATE TABLE `customer_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `contactperson` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `old_openingBal` varchar(255) DEFAULT NULL,
  `salesamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  `accountpay` varchar(255) NOT NULL,
  `chequeno` varchar(100) NOT NULL,
  `last_modified` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (1, '2023-07-29', 'Inter customer', 'SMK INDUSTRIES', '7810028222', 'jp@idreamdevelopers.com', '3/226D, NADUPALAYAM ROAD', 'PATTANAM POST,ONDIPUDUR (VIA)', '', 'Tamil Nadu', 'COIMBATORE', '', '', NULL, '0.00', NULL, '168740', NULL, '168740', NULL, '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33ADXPT3291N2ZJ', '', '', '', '', '', '2023-07-29');


#
# TABLE STRUCTURE FOR: customerpo_details
#

DROP TABLE IF EXISTS `customerpo_details`;

CREATE TABLE `customerpo_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `cuspodate` date DEFAULT NULL,
  `invoicetype` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `cuspono` varchar(255) DEFAULT NULL,
  `transport` varchar(255) DEFAULT NULL,
  `customerpodate` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `cstname` varchar(255) DEFAULT NULL,
  `cstamount` varchar(255) DEFAULT NULL,
  `pf` varchar(255) DEFAULT NULL,
  `freight` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `pfadjus` varchar(255) DEFAULT NULL,
  `freightadjus` varchar(255) DEFAULT NULL,
  `roundoff` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: dc_delivery
#

DROP TABLE IF EXISTS `dc_delivery`;

CREATE TABLE `dc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: dcbill_details
#

DROP TABLE IF EXISTS `dcbill_details`;

CREATE TABLE `dcbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `itemid` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: dcbill_details_backup
#

DROP TABLE IF EXISTS `dcbill_details_backup`;

CREATE TABLE `dcbill_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `itemid` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: einvoicetoken
#

DROP TABLE IF EXISTS `einvoicetoken`;

CREATE TABLE `einvoicetoken` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tokenexpiry` varchar(255) NOT NULL,
  `authtoken` varchar(255) NOT NULL,
  `sek` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `einvoicetoken` (`id`, `tokenexpiry`, `authtoken`, `sek`, `status`, `created_at`) VALUES (1, '2023-08-09 16:31:43', 'CTwCL8tgMnh8OGGT1cdEfZ2Di', 'oXHq0km3A92kG8ypQ0tGXKpUuO7NImrKrx6dsMgLTYXh6W4vNMz8aEDoX5jNNRrK', 1, '2023-08-07 16:40:00');


#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS `expenses`;

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: expenses_backup
#

DROP TABLE IF EXISTS `expenses_backup`;

CREATE TABLE `expenses_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: headers
#

DROP TABLE IF EXISTS `headers`;

CREATE TABLE `headers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: hsnmaster
#

DROP TABLE IF EXISTS `hsnmaster`;

CREATE TABLE `hsnmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `party` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: invoice_details
#

DROP TABLE IF EXISTS `invoice_details`;

CREATE TABLE `invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `pono` varchar(255) DEFAULT NULL,
  `pino` varchar(255) DEFAULT NULL,
  `purchaseordernos` varchar(255) DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerdcnos'` varchar(100) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `removalDate` date NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToId` varchar(255) DEFAULT NULL,
  `shipToAddress` longtext,
  `deliveryAddress1` longtext,
  `deliveryAddress2` longtext,
  `mobileNo` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemcode` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `totalqty` varchar(255) DEFAULT NULL,
  `acno` varchar(255) NOT NULL,
  `acdate` varchar(255) NOT NULL,
  `irn` varchar(255) NOT NULL,
  `signedinvoice` longtext NOT NULL,
  `signedqrcode` longtext NOT NULL,
  `status_ein` longtext NOT NULL,
  `ewayno` varchar(255) NOT NULL,
  `ewaydate` varchar(255) NOT NULL,
  `ewbvalidtill` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `status_cd` varchar(255) NOT NULL,
  `status_desc` varchar(255) NOT NULL,
  `einvoice_status` int(11) NOT NULL,
  `eway_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=latin1;

INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (1, '2023-07-28', '2023-07-28', '', '1970-01-01', 'INV/23-24/-001', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-07-28', '04:04 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300||7204', NULL, '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', 'KGS||KGS', '1500||2000', '1||1', '1500.00||2000.00', '0||0', 'percent_wise', '0.00||0.00', '1500.00||2000.00', '9||9', '135.00||180.00', '9||9', '135.00||180.00', '18||18', '270.00||360.00', '1770.00||2360.00', '4130.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', NULL, '1||1', '4130.00', '4130.00', 1, 'INV/23-24/-001280723', 'INV/23-24/-001-2023', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (2, '2023-07-28', '2023-07-28', '', '1970-01-01', 'INV/23-24/-002', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-07-28', '07:03 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300||7204', NULL, '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', 'KGS||KGS', '1500||2000', '1||1', '1500.00||2000.00', '0||0', 'percent_wise', '0.00||0.00', '1500.00||2000.00', '9', '', '9', '', '18', '630.00', NULL, '3500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '4130.00', '4130.00', 1, 'INV/23-24/-002280723', 'INV/23-24/-002-2023', 1, 1, '4.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (3, '2023-07-29', '2023-07-29', '', '1970-01-01', 'INV/23-24/-003', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-07-29', '03:53 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300||7204', NULL, '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', 'KGS||KGS', '1500||2000', '1||1', '1500.00||2000.00', '0||0', 'percent_wise', '0.00||0.00', '1500.00||2000.00', '9', '', '9', '', '18', '630.00', NULL, '3500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '4130.00', '4130.00', 1, 'INV/23-24/-003290723', 'INV/23-24/-003-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (4, '2023-07-29', '2023-07-29', '', '1970-01-01', 'INV/23-24/-004', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-07-29', '03:56 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300||7204', NULL, '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', 'KGS||KGS', '1500||2000', '1||1', '1500.00||2000.00', '0||0', 'percent_wise', '0.00||0.00', '1500.00||2000.00', '9', '', '9', '', '18', '630.00', NULL, '3500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '4130.00', '4130.00', 1, 'INV/23-24/-004290723', 'INV/23-24/-004-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (5, '2023-07-29', '2023-07-29', '', '1970-01-01', 'INV/23-24/-005', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-07-29', '03:57 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204||850300', NULL, '1080R2-2PM STATOR STAMPING-GANG||1080R2-2PM 70MM CLEATED STATOR', '||', 'KGS||KGS', '2000||1500', '1||1', '2000.00||1500.00', '0||0', 'percent_wise', '0.00||0.00', '2000.00||1500.00', '9', '', '9', '', '18', '630.00', NULL, '3500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '4130.00', '4130.00', 1, 'INV/23-24/-005290723', 'INV/23-24/-005-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (6, '2023-07-29', '2023-07-29', '', '1970-01-01', 'INV/23-24/-006', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-07-29', '06:04 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300||7204', NULL, '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', 'KGS||KGS', '1500||2000', '1||1', '1500.00||2000.00', '0||0', 'percent_wise', '0.00||0.00', '1500.00||2000.00', '9', '', '9', '', '18', '630.00', NULL, '3500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1', '4130.00', '4130.00', 1, 'INV/23-24/-006290723', 'INV/23-24/-006-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (7, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-007', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '12:03 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-007030823', 'INV/23-24/-007-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (8, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-008', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '12:05 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-008030823', 'INV/23-24/-008-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (9, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-009', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '03:20 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-009030823', 'INV/23-24/-009-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (10, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-010', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '03:38 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-010030823', 'INV/23-24/-010-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (11, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-011', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '03:39 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-011030823', 'INV/23-24/-011-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (12, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-012', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '03:50 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-012030823', 'INV/23-24/-012-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (13, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-013', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '04:45 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-013030823', 'INV/23-24/-013-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (14, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-014', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '04:45 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-014030823', 'INV/23-24/-014-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (15, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-015', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '04:47 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-015030823', 'INV/23-24/-015-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (16, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-016', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '04:48 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-016030823', 'INV/23-24/-016-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (17, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-017', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '04:51 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-017030823', 'INV/23-24/-017-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (18, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-018', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '04:53 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-018030823', 'INV/23-24/-018-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (19, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-019', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '04:54 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-019030823', 'INV/23-24/-019-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (20, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-020', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '04:59 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-020030823', 'INV/23-24/-020-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (21, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-021', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '06:09 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-021030823', 'INV/23-24/-021-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (22, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-022', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:16 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-022030823', 'INV/23-24/-022-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (23, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-023', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:17 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-023030823', 'INV/23-24/-023-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (24, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-024', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:19 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-024030823', 'INV/23-24/-024-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (25, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-025', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:20 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-025030823', 'INV/23-24/-025-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (26, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-026', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:25 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-026030823', 'INV/23-24/-026-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (27, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-027', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:26 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-027030823', 'INV/23-24/-027-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (28, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-028', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:27 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-028030823', 'INV/23-24/-028-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (29, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-029', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:36 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-029030823', 'INV/23-24/-029-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (30, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-030', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:36 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-030030823', 'INV/23-24/-030-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (31, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-031', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:37 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-031030823', 'INV/23-24/-031-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (32, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-032', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:41 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-032030823', 'INV/23-24/-032-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (33, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-033', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:43 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-033030823', 'INV/23-24/-033-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (34, '2023-08-03', '2023-08-03', '', '1970-01-01', 'INV/23-24/-034', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-03', '07:46 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-034030823', 'INV/23-24/-034-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (35, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-035', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '10:48 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-035040823', 'INV/23-24/-035-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (36, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-036', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '10:49 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-036040823', 'INV/23-24/-036-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (37, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-037', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '10:57 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-037040823', 'INV/23-24/-037-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (38, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-038', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '10:57 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-038040823', 'INV/23-24/-038-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (39, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-039', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '11:01 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-039040823', 'INV/23-24/-039-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (40, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-040', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '11:03 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-040040823', 'INV/23-24/-040-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (41, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-041', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '11:14 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-041040823', 'INV/23-24/-041-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (42, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-042', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '11:15 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-042040823', 'INV/23-24/-042-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (43, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-043', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '11:17 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-043040823', 'INV/23-24/-043-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (44, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-044', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '12:13 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-044040823', 'INV/23-24/-044-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (45, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-045', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '12:16 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-045040823', 'INV/23-24/-045-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (46, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-046', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '12:18 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-046040823', 'INV/23-24/-046-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (47, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-047', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '12:19 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-047040823', 'INV/23-24/-047-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (48, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-048', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '02:40 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-048040823', 'INV/23-24/-048-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (49, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-049', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '02:44 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-049040823', 'INV/23-24/-049-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (50, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-050', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '02:59 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-050040823', 'INV/23-24/-050-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (51, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-051', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '03:00 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-051040823', 'INV/23-24/-051-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (52, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-052', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '03:01 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-052040823', 'INV/23-24/-052-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (53, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-053', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '03:02 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-053040823', 'INV/23-24/-053-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (54, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-054', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '03:04 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-054040823', 'INV/23-24/-054-2023', 1, 1, '1.00', '112310168366820', '2023-08-04 15:07:00', 'ab4b654a5d42bc42719a38c036f53120ce7369bad7b316e606de289527df6ff6', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjgzNjY4MTksXCJBY2tEdFwiOlwiMjAyMy0wOC0wNCAxNTowNzowMFwiLFwiSXJuXCI6XCJhYjRiNjU0YTVkNDJiYzQyNzE5YTM4YzAzNmY1MzEyMGNlNzM2OWJhZDdiMzE2ZTYwNmRlMjg5NTI3ZGY2ZmY2XCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDU0XCIsXCJEdFwiOlwiMDQvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjg1MDMwMFwiLFwiUXR5XCI6MSxcIlVuaXRcIjpcIktHU1wiLFwiVW5pdFByaWNlXCI6MTUwMCxcIlRvdEFtdFwiOjE1MDAsXCJEaXNjb3VudFwiOjAsXCJBc3NBbXRcIjoxNTAwLFwiR3N0UnRcIjoxOCxcIklnc3RBbXRcIjoyNzAsXCJDZ3N0QW10XCI6MCxcIlNnc3RBbXRcIjowLFwiVG90SXRlbVZhbFwiOjE3NzB9XSxcIlZhbER0bHNcIjp7XCJBc3NWYWxcIjoxNTAwLFwiQ2dzdFZhbFwiOjAsXCJTZ3N0VmFsXCI6MCxcIklnc3RWYWxcIjoyNzAsXCJPdGhDaHJnXCI6MCxcIlJuZE9mZkFtdFwiOjAsXCJUb3RJbnZWYWxcIjoxNzcwfSxcIkFkZGxEb2NEdGxzXCI6W3tcIlVybFwiOlwiaHR0cHM6Ly9laW52LWFwaXNhbmRib3gubmljLmluXCIsXCJEb2NzXCI6XCJUZXN0IERvY1wiLFwiSW5mb1wiOlwiRG9jdW1lbnQgVGVzdFwifV19IiwiaXNzIjoiTklDIFNhbmRib3gifQ.dOCrWZ2Vk4bMlJy6BT241WqL5agq9e_L7btmB08zKIGxRAwzgdVl26-GpZ1sXSab09G5zdWkwY-JzFFfy5lEkEdCZ0VzfShDuCa_uCykeaNA5CxG4NDimJ9ybY56swXnPuFCglBIA49pDDwRoJlyHpFBgRI0VoL6TxgcvDn5NAgK4mdwhk9Fd7MP99AZ9ZmbiB9d16b7hIINQ2UOUBhyz0ECoe8sUYD4l0yiWkavsuqVYdw0AgfmGumHiTwYNuVQu54ATAmg5Cje88Lq11wjPe3GNwGq1BLH9rPS__-gRapyORRxG1RWq7NBBPbkEw-sCmgtqPm7qc9ty-QL4ZpQVw', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wNTRcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDQvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MTc3MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjg1MDMwMFwiLFwiSXJuXCI6XCJhYjRiNjU0YTVkNDJiYzQyNzE5YTM4YzAzNmY1MzEyMGNlNzM2OWJhZDdiMzE2ZTYwNmRlMjg5NTI3ZGY2ZmY2XCIsXCJJcm5EdFwiOlwiMjAyMy0wOC0wNCAxNTowNzowMFwifSIsImlzcyI6Ik5JQyBTYW5kYm94In0.NOyPWGv1GHQIa8W1n_PbgrCgzxI7D9qbEi3EXkqH6iWA3m5tIQNoYnZEo8VGgPzBahNE6HlENlzHf4fZFtfAPIKRyhStrOpvFb3T5VJctmB4QDbNiZzVh8lRg0m3OeMG1vY3L6wnB1o60MkXcjQyg0vZCBGzuSuw-RBHhH2sPvU_fMZ7P_7LdZN2H1Kv5lUvfkDMKabf6M74P8rxxdF6NZ6f1NWijhex30eqrQgy0xE_OxnIxWQzbogCOZAOPynYjt9kSl-svdBOYpCtgEcnmD5SbPP6QoMssn39mIgHh2fEYcc6fmBI79nPlAQLiFQ8fqpxiPo2Yu_mi5HGJZ9vOg', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (55, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-055', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '03:06 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-055040823', 'INV/23-24/-055-2023', 1, 1, '1.00', '112310168366890', '2023-08-04 15:09:00', 'ea72ff53d4727db553105da244ae013cde78dc450afe96f766581bb6de609fae', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjgzNjY4OTEsXCJBY2tEdFwiOlwiMjAyMy0wOC0wNCAxNTowOTowMFwiLFwiSXJuXCI6XCJlYTcyZmY1M2Q0NzI3ZGI1NTMxMDVkYTI0NGFlMDEzY2RlNzhkYzQ1MGFmZTk2Zjc2NjU4MWJiNmRlNjA5ZmFlXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDU1XCIsXCJEdFwiOlwiMDQvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjcyMDRcIixcIlF0eVwiOjEsXCJVbml0XCI6XCJLR1NcIixcIlVuaXRQcmljZVwiOjIwMDAsXCJUb3RBbXRcIjoyMDAwLFwiRGlzY291bnRcIjowLFwiQXNzQW10XCI6MjAwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6MzYwLFwiQ2dzdEFtdFwiOjAsXCJTZ3N0QW10XCI6MCxcIlRvdEl0ZW1WYWxcIjoyMzYwfV0sXCJWYWxEdGxzXCI6e1wiQXNzVmFsXCI6MjAwMCxcIkNnc3RWYWxcIjowLFwiU2dzdFZhbFwiOjAsXCJJZ3N0VmFsXCI6MzYwLFwiT3RoQ2hyZ1wiOjAsXCJSbmRPZmZBbXRcIjowLFwiVG90SW52VmFsXCI6MjM2MH0sXCJBZGRsRG9jRHRsc1wiOlt7XCJVcmxcIjpcImh0dHBzOi8vZWludi1hcGlzYW5kYm94Lm5pYy5pblwiLFwiRG9jc1wiOlwiVGVzdCBEb2NcIixcIkluZm9cIjpcIkRvY3VtZW50IFRlc3RcIn1dfSIsImlzcyI6Ik5JQyBTYW5kYm94In0.y9afKzE6YqANWnGhX8eK3MjLVPwqJKovjvOknca5xtENE-WODRZFJmB_i9ZtLICZxLOkCWPC9Q1w0JC9Jq9Fsji7NIecSCR_-PHSHjv-30-aFMstjgg_Z610ZOIRLbDVrLwtZinXBiCjknogE82aeZj1gU_9J3BIoa3NNmcEJy27Gl8jFWyoofQU-7P9tGE4HHuzFAxMUniO0kM8aDLtUvtgA4M5HOcbs5N1iaty6qZ69tYV5TntLfCiz5AUVAOyPYqLvZBb-2rwpVxBuGWmRqsq7vJiXEN2lRXWlE_mwWb1vfLQQWlfuL6HJWZZfL8MqbY4p4Pl0o1Cg8Phi450MA', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wNTVcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDQvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MjM2MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjcyMDRcIixcIklyblwiOlwiZWE3MmZmNTNkNDcyN2RiNTUzMTA1ZGEyNDRhZTAxM2NkZTc4ZGM0NTBhZmU5NmY3NjY1ODFiYjZkZTYwOWZhZVwiLFwiSXJuRHRcIjpcIjIwMjMtMDgtMDQgMTU6MDk6MDBcIn0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.WGfc-u-VxB4UQc1wo4tsKUJQ-UHOuG-TvOz542Rk1PYipqVNze1J-2alLQjCMeZPE-NG7NcE-vzHu1eA9A9NppSAGyyBnVLsb8gpOdIpNOcuq5FWyCydWmI6k0O9K85eyFo6VFjjogApgm3jMIelcJqGX8bRrSFQYPGEubP_WHZe16bxhvr5IrC8T6O6uqKsZXbCLi-xbD97fx81BQ-adExEU_nYLDysS7U2H-55z7-SZ727Y4OoaW7tx6e5LaBw80kfOlmKUa8v4CBCdxIXtZ66JEHJiG0RXaqBIFJxfRviOgyD-Wi4-A5Oijl-uiNP-pPEnLdPxB4GTtGrzl35nQ', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (56, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-056', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '03:06 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-056040823', 'INV/23-24/-056-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (57, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-057', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '03:54 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-057040823', 'INV/23-24/-057-2023', 1, 1, '1.00', '112310168367940', '2023-08-04 15:57:00', 'e26fbe175e71c773017565a1dd62fdb2102707aaa6b7830c2e4c3df6a96c97b3', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjgzNjc5NDIsXCJBY2tEdFwiOlwiMjAyMy0wOC0wNCAxNTo1NzowMFwiLFwiSXJuXCI6XCJlMjZmYmUxNzVlNzFjNzczMDE3NTY1YTFkZDYyZmRiMjEwMjcwN2FhYTZiNzgzMGMyZTRjM2RmNmE5NmM5N2IzXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDU3XCIsXCJEdFwiOlwiMDQvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjcyMDRcIixcIlF0eVwiOjEsXCJVbml0XCI6XCJLR1NcIixcIlVuaXRQcmljZVwiOjIwMDAsXCJUb3RBbXRcIjoyMDAwLFwiRGlzY291bnRcIjowLFwiQXNzQW10XCI6MjAwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6MzYwLFwiQ2dzdEFtdFwiOjAsXCJTZ3N0QW10XCI6MCxcIlRvdEl0ZW1WYWxcIjoyMzYwfV0sXCJWYWxEdGxzXCI6e1wiQXNzVmFsXCI6MjAwMCxcIkNnc3RWYWxcIjowLFwiU2dzdFZhbFwiOjAsXCJJZ3N0VmFsXCI6MzYwLFwiT3RoQ2hyZ1wiOjAsXCJSbmRPZmZBbXRcIjowLFwiVG90SW52VmFsXCI6MjM2MH0sXCJBZGRsRG9jRHRsc1wiOlt7XCJVcmxcIjpcImh0dHBzOi8vZWludi1hcGlzYW5kYm94Lm5pYy5pblwiLFwiRG9jc1wiOlwiVGVzdCBEb2NcIixcIkluZm9cIjpcIkRvY3VtZW50IFRlc3RcIn1dfSIsImlzcyI6Ik5JQyBTYW5kYm94In0.AMg_Lw_BHSzGgonxgqcILwSOaOLnKkmQuITo3ksYyjdg_nUcVZOvRl3pUFmh_xp9GWh1RYYfNjw2CAGpjqIt6_mfgwHM-BQaRx0QP-ZDoGXxikD6mhsYI2fDFtgu1-G4E5co9BDn3JByLN7EUk2iHsGrCSWd9IBtTxyKPOIlpZu1V_kzCS0IM1Binlz8vBXuvpXYg5HSEj78cuTy964DsBCts7dPSV7z8eUYvoHPwxW_RoIJpGbjkEbp3d_cerY8D6DFojqqRTE61ItSdFyyxHZo0wReKvcgiHKmCdPmVlnAfkTFF1A9Z-eEXiH9mnd0pkgu6MJoNzORiZcpk3z5FA', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wNTdcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDQvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MjM2MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjcyMDRcIixcIklyblwiOlwiZTI2ZmJlMTc1ZTcxYzc3MzAxNzU2NWExZGQ2MmZkYjIxMDI3MDdhYWE2Yjc4MzBjMmU0YzNkZjZhOTZjOTdiM1wiLFwiSXJuRHRcIjpcIjIwMjMtMDgtMDQgMTU6NTc6MDBcIn0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.KBNENzjnvH3f8jLotjZDWTrQ-twsSXjDAdwPi2lxxHHvs0CpvTSiHS_O1zcAqB-2-55Xg1UOxyJ2yfUqNjwTPoSyrGPHfLWB1C0wUXGiiiBNNG64NFDlzoNzbyUpJ1NRdTIAdOTXri3bdtwlNqNKBD817ChkW0-DKm2xBV7feZh3J5j4v93WEljlD2Mftm3tbOsEhGS6L5CEwttgvOUM0uKbccetatHEaL3ABmgDMZO94MG0w6QyUegOj7QIJ6H_k9CPmCl5u5ImVW8GY_HD-yi_H_4M4aqJym5On1kGpPFHwu6eT0zyh2zStav7JiG0QAIPJdTvhABv_aTsKWUtrA', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (58, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-058', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '04:55 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-058040823', 'INV/23-24/-058-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (59, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-059', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '04:57 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-059040823', 'INV/23-24/-059-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (60, '2023-08-04', '2023-08-04', '', '1970-01-01', 'INV/23-24/-060', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-04', '04:57 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-060040823', 'INV/23-24/-060-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (61, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-061', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '03:52 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-061070823', 'INV/23-24/-061-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (62, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-062', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '03:53 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-062070823', 'INV/23-24/-062-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (63, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-063', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '03:59 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-063070823', 'INV/23-24/-063-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (64, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-064', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '04:00 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-064070823', 'INV/23-24/-064-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (65, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-065', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '04:03 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-065070823', 'INV/23-24/-065-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (66, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-066', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '04:03 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-066070823', 'INV/23-24/-066-2023', 1, 1, '1.00', '112310168521870', '2023-08-07 16:59:00', '36248801028c3873bc3921ffc06e412f40ee627894f92a73092012565b29b297', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjg1MjE4NjksXCJBY2tEdFwiOlwiMjAyMy0wOC0wNyAxNjo1OTowMFwiLFwiSXJuXCI6XCIzNjI0ODgwMTAyOGMzODczYmMzOTIxZmZjMDZlNDEyZjQwZWU2Mjc4OTRmOTJhNzMwOTIwMTI1NjViMjliMjk3XCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDY2XCIsXCJEdFwiOlwiMDcvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjg1MDMwMFwiLFwiUXR5XCI6MSxcIlVuaXRcIjpcIktHU1wiLFwiVW5pdFByaWNlXCI6MTUwMCxcIlRvdEFtdFwiOjE1MDAsXCJEaXNjb3VudFwiOjAsXCJBc3NBbXRcIjoxNTAwLFwiR3N0UnRcIjoxOCxcIklnc3RBbXRcIjoyNzAsXCJDZ3N0QW10XCI6MCxcIlNnc3RBbXRcIjowLFwiVG90SXRlbVZhbFwiOjE3NzB9XSxcIlZhbER0bHNcIjp7XCJBc3NWYWxcIjoxNTAwLFwiQ2dzdFZhbFwiOjAsXCJTZ3N0VmFsXCI6MCxcIklnc3RWYWxcIjoyNzAsXCJPdGhDaHJnXCI6MCxcIlJuZE9mZkFtdFwiOjAsXCJUb3RJbnZWYWxcIjoxNzcwfSxcIkFkZGxEb2NEdGxzXCI6W3tcIlVybFwiOlwiaHR0cHM6Ly9laW52LWFwaXNhbmRib3gubmljLmluXCIsXCJEb2NzXCI6XCJUZXN0IERvY1wiLFwiSW5mb1wiOlwiRG9jdW1lbnQgVGVzdFwifV19IiwiaXNzIjoiTklDIFNhbmRib3gifQ.yIkgqB2Hnn6i6xzeD8AbP1MqNmrfodm5DiH_IIyLa5HfmX3mKE5vrV0xHEzojM0SVdzGdURhEa5kPcmCq35NnmaKKAu1E-xKImekOFYwJTn-SBIWXLV_xb82aHQVoxm5060Z1139vvA1ccXwEc1MvEFdQ1ErJzDKn3evPTIY9Pugb3j9Q7RTI1R2bK8tROewifvc1BrZ8u4Za_853sDUSFyHjYsE2bExSS2onuVMtl9u8jkRCsFV3i28mfktd8dguP9wS5vPQOM0SNctnMhM-XJ3_KVra1mpNGDiurLaUQ9EKDXbF2_c6agxzRFCrIvpabRLWNMcZRjp8dtVps9WPg', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wNjZcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDcvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MTc3MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjg1MDMwMFwiLFwiSXJuXCI6XCIzNjI0ODgwMTAyOGMzODczYmMzOTIxZmZjMDZlNDEyZjQwZWU2Mjc4OTRmOTJhNzMwOTIwMTI1NjViMjliMjk3XCIsXCJJcm5EdFwiOlwiMjAyMy0wOC0wNyAxNjo1OTowMFwifSIsImlzcyI6Ik5JQyBTYW5kYm94In0.1DFkrWUw_ZizsCHQFIiXcb6z9ci4VV8GzhUoSg1ySoHuglHvYKUo2bf7547HTAhBPzz5UMGuX5fA2VCqmiquzZyzz8qz-98SgzjKYSMKp3Pxkor0ZS4b4UTX_WZaWJRvm5jjhTpZoM8nqrWojsCiOAEh6u9_3bythSSK1x-wHnfKyGKWv-O1lt0k0eYh9NqFJPCxyfRSB5TvQEkN4m3fZz01jMIi4S80lPXeiphi9uddwQ16zPWnC3wmkYHcPQRZhGl1F_IijvpMwAbUM0-7Yb9N-MdjFJo9osg9SwEdw_jaktYFUajW53wshAOWjiQ6hiGhuNsQyty1DedhXOCinQ', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (67, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-067', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '05:00 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-067070823', 'INV/23-24/-067-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (68, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-068', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '05:00 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-068070823', 'INV/23-24/-068-2023', 1, 1, '1.00', '112310168522340', '2023-08-07 17:26:00', '0aa7897a8d17eec182bedfd602c5e81778f9a848b436d9cc0fd7f6e445f1402e', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjg1MjIzNDUsXCJBY2tEdFwiOlwiMjAyMy0wOC0wNyAxNzoyNjowMFwiLFwiSXJuXCI6XCIwYWE3ODk3YThkMTdlZWMxODJiZWRmZDYwMmM1ZTgxNzc4ZjlhODQ4YjQzNmQ5Y2MwZmQ3ZjZlNDQ1ZjE0MDJlXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDY4XCIsXCJEdFwiOlwiMDcvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjg1MDMwMFwiLFwiUXR5XCI6MSxcIlVuaXRcIjpcIktHU1wiLFwiVW5pdFByaWNlXCI6MTUwMCxcIlRvdEFtdFwiOjE1MDAsXCJEaXNjb3VudFwiOjAsXCJBc3NBbXRcIjoxNTAwLFwiR3N0UnRcIjoxOCxcIklnc3RBbXRcIjoyNzAsXCJDZ3N0QW10XCI6MCxcIlNnc3RBbXRcIjowLFwiVG90SXRlbVZhbFwiOjE3NzB9XSxcIlZhbER0bHNcIjp7XCJBc3NWYWxcIjoxNTAwLFwiQ2dzdFZhbFwiOjAsXCJTZ3N0VmFsXCI6MCxcIklnc3RWYWxcIjoyNzAsXCJPdGhDaHJnXCI6MCxcIlJuZE9mZkFtdFwiOjAsXCJUb3RJbnZWYWxcIjoxNzcwfSxcIkFkZGxEb2NEdGxzXCI6W3tcIlVybFwiOlwiaHR0cHM6Ly9laW52LWFwaXNhbmRib3gubmljLmluXCIsXCJEb2NzXCI6XCJUZXN0IERvY1wiLFwiSW5mb1wiOlwiRG9jdW1lbnQgVGVzdFwifV19IiwiaXNzIjoiTklDIFNhbmRib3gifQ.K_I5PLuaMeLzICBIYNxChSh417Vkylk70FK_Kmq3T5SfRs7HkxTFVrbwH1nLAT9EDrxvwK7we_tTyYOsolWV6cFIHba5-_TORvdU6xB6bH5lsGWUqQsH1X9bhBzE96exEs5w-T-dBaYtbZfr2-tFtglOq06WPU9BAxgmb8enVmEoXNq-nYsj4KdA0rMQknK5X1qYoa8PhRFh9XrHXhJ7NR-rmM4lzu9bCkPJ50FiH5C-6lROBCh7MgeeawAr4Lt62gjGLVI42wj0Gy-CihVQ9Al3bs5IZnc9YLL46fsgD0P08rNqS8IsNAyaogyGEimvJAhZs7YTuDvkRXEXgvobuw', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wNjhcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDcvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MTc3MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjg1MDMwMFwiLFwiSXJuXCI6XCIwYWE3ODk3YThkMTdlZWMxODJiZWRmZDYwMmM1ZTgxNzc4ZjlhODQ4YjQzNmQ5Y2MwZmQ3ZjZlNDQ1ZjE0MDJlXCIsXCJJcm5EdFwiOlwiMjAyMy0wOC0wNyAxNzoyNjowMFwifSIsImlzcyI6Ik5JQyBTYW5kYm94In0.fRg968H_rDru2X30LLOixu2xMAdoieXDyYumDNaRWECYScis8CAF5ftwe4tHZmYxIWRfhApUStMaFL9vy6NeXLKu1P5wQtCh9IrpzCxjauMSa7T3uZGOeqkOBV_plXKVXQAvXPT32umZTZf-BObU150v8gilTA2iwa8LXb1C7x6ONxaCc6zS8I5TRCNvx5ep2mQ-BNUGhFQXegMx2l7G35H79a_wloY5nzScnEVq6MqVhgriVhxYwwmC6z6VJ0U6Dzk3CdKj_LoN0WD_hNIfhqnFrvHUEuh0tty81gnArA3YzPYT9XbIasgmupCkj-Q_yLDEksmNbiRKo9KVTxLE1g', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (69, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-069', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '06:10 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-069070823', 'INV/23-24/-069-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (70, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-070', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '06:12 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-070070823', 'INV/23-24/-070-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (71, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-071', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '06:13 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-071070823', 'INV/23-24/-071-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (72, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-072', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '06:22 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-072070823', 'INV/23-24/-072-2023', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (73, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-073', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '06:26 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-073070823', 'INV/23-24/-073-2023', 1, 1, '1.00', '112310168523270', '2023-08-07 18:30:00', '4b70c4783a6a2cf9c3aa68e1b95dc3444b4408ed12ae48cbf92a3c9c48769d45', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjg1MjMyNzQsXCJBY2tEdFwiOlwiMjAyMy0wOC0wNyAxODozMDowMFwiLFwiSXJuXCI6XCI0YjcwYzQ3ODNhNmEyY2Y5YzNhYTY4ZTFiOTVkYzM0NDRiNDQwOGVkMTJhZTQ4Y2JmOTJhM2M5YzQ4NzY5ZDQ1XCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDczXCIsXCJEdFwiOlwiMDcvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjg1MDMwMFwiLFwiUXR5XCI6MSxcIlVuaXRcIjpcIktHU1wiLFwiVW5pdFByaWNlXCI6MTUwMCxcIlRvdEFtdFwiOjE1MDAsXCJEaXNjb3VudFwiOjAsXCJBc3NBbXRcIjoxNTAwLFwiR3N0UnRcIjoxOCxcIklnc3RBbXRcIjoyNzAsXCJDZ3N0QW10XCI6MCxcIlNnc3RBbXRcIjowLFwiVG90SXRlbVZhbFwiOjE3NzB9XSxcIlZhbER0bHNcIjp7XCJBc3NWYWxcIjoxNTAwLFwiQ2dzdFZhbFwiOjAsXCJTZ3N0VmFsXCI6MCxcIklnc3RWYWxcIjoyNzAsXCJPdGhDaHJnXCI6MCxcIlJuZE9mZkFtdFwiOjAsXCJUb3RJbnZWYWxcIjoxNzcwfSxcIkFkZGxEb2NEdGxzXCI6W3tcIlVybFwiOlwiaHR0cHM6Ly9laW52LWFwaXNhbmRib3gubmljLmluXCIsXCJEb2NzXCI6XCJUZXN0IERvY1wiLFwiSW5mb1wiOlwiRG9jdW1lbnQgVGVzdFwifV19IiwiaXNzIjoiTklDIFNhbmRib3gifQ.B0lgxk5sOxP0YxAZykh5t79toOFM5z5WNq6ipO3aXJnW5OlXhESVo5uwSHK2EpgKN6yZhCYCYZHgmSb8RORu6hZtMlycoKRcxUxwDHiA9BGgLIahTah_wv1kYUx-9vmbMEv5HYXHVKn11MBnTRySz_6t04sd468ei8fXnMk5u7lfhQnrSxQg856ie9Kvof8Ndnk1ge5AjXqdBvManw581cmazEb4fHRZNRCU9FJjWErWlDXKrmZEejALpVIXLVbdcZQ74hrh7AfBlr3Q7JzofQRBNsKfqLg4TQdVckjaPnL59nuStGVfDMV6IzqE3wRl7LxypbpngcC1AGWllqLmRQ', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wNzNcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDcvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MTc3MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjg1MDMwMFwiLFwiSXJuXCI6XCI0YjcwYzQ3ODNhNmEyY2Y5YzNhYTY4ZTFiOTVkYzM0NDRiNDQwOGVkMTJhZTQ4Y2JmOTJhM2M5YzQ4NzY5ZDQ1XCIsXCJJcm5EdFwiOlwiMjAyMy0wOC0wNyAxODozMDowMFwifSIsImlzcyI6Ik5JQyBTYW5kYm94In0.UmVBWQ-klLcIH-vi7XoNrHIOHPH2WcbBLlfWY02_3nq4FfVb-8BFO-zcWrhGGCtSdkg5Jwvcsl4BkxLI5qT7G2Zcq3zwZdFK3ZNC9Sr5OWqAM1K_I_8VGM7frCB2RtwlyS1_EMRqftdbIZqGPGfOyUp2t1GfiBnB1DtzinUXuBQwgegzZ7LLsMXkZs43muiSHu0Rl2AdiYL4Sj-xf4BCAtJRE_FDCvWtPcPq_8SK2HGiW2FJb1D6Wk2F6VNzwKW2_-oXRPlsgO4xK61FDAftQQ2hGbeJAUR9jZDqwpH2muOVcqDAOL9JXzsoNf1WC3US2B4QipJ-yNOzZES06sfrdQ', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (75, '2023-08-07', '2023-08-07', '', '1970-01-01', 'INV/23-24/-074', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-07', '08:13 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '2', '4000.00', '0', 'percent_wise', '0.00', '4000.00', '9', '', '9', '', '18', '720.00', NULL, '4000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '4720.00', '4720.00', 1, 'INV/23-24/-074070823', 'INV/23-24/-074-2023', 1, 1, '2.00', '', '', '', '', '', '', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (78, '2023-08-08', '2023-08-08', '', '1970-01-01', 'INV/23-24/-076', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-08', '11:01 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-076080823', 'INV/23-24/-076-2023', 1, 1, '1.00', '112310168532080', '2023-08-08 11:08:00', '7b4401eee3305ece3af67db3a287f4d6955976f8099d909b7a6ed6151a672bb5', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjg1MzIwNzgsXCJBY2tEdFwiOlwiMjAyMy0wOC0wOCAxMTowODowMFwiLFwiSXJuXCI6XCI3YjQ0MDFlZWUzMzA1ZWNlM2FmNjdkYjNhMjg3ZjRkNjk1NTk3NmY4MDk5ZDkwOWI3YTZlZDYxNTFhNjcyYmI1XCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDc2XCIsXCJEdFwiOlwiMDgvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjcyMDRcIixcIlF0eVwiOjEsXCJVbml0XCI6XCJLR1NcIixcIlVuaXRQcmljZVwiOjIwMDAsXCJUb3RBbXRcIjoyMDAwLFwiRGlzY291bnRcIjowLFwiQXNzQW10XCI6MjAwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6MzYwLFwiQ2dzdEFtdFwiOjAsXCJTZ3N0QW10XCI6MCxcIlRvdEl0ZW1WYWxcIjoyMzYwfV0sXCJWYWxEdGxzXCI6e1wiQXNzVmFsXCI6MjAwMCxcIkNnc3RWYWxcIjowLFwiU2dzdFZhbFwiOjAsXCJJZ3N0VmFsXCI6MzYwLFwiT3RoQ2hyZ1wiOjAsXCJSbmRPZmZBbXRcIjowLFwiVG90SW52VmFsXCI6MjM2MH0sXCJBZGRsRG9jRHRsc1wiOlt7XCJVcmxcIjpcImh0dHBzOi8vZWludi1hcGlzYW5kYm94Lm5pYy5pblwiLFwiRG9jc1wiOlwiVGVzdCBEb2NcIixcIkluZm9cIjpcIkRvY3VtZW50IFRlc3RcIn1dfSIsImlzcyI6Ik5JQyBTYW5kYm94In0.BgBgJCOOWv5-5riYDvsmv9kb_etW2b_BHMcJtdoTLLskkKrE4MTRQiRV3CiO-l7p-wRV5dPK-cFXz5xWGv_b7ce68eqARx1NHcwZU5WlG1qiC5h-zci3R7vkPtkD36RAB6un6MudAHpT7MpX5Qwx-THsavr8ZoVz8Sdi4drPvCVVyoznwe2fY7X0OSLt_GD0_XhvlicnMtk_WTLmL2bPA6zlhTEDIaS_hNmEVHFxPVfRnLo4z5KyaXZbunomOi0cJFEt74oPWG78s55I8uEA86JXDgBu4rftQtwlNWy3jPG9DmogwtTIByXNhDXLwl1rYM_GPSJqQFKykYqvFHT4dg', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wNzZcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDgvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MjM2MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjcyMDRcIixcIklyblwiOlwiN2I0NDAxZWVlMzMwNWVjZTNhZjY3ZGIzYTI4N2Y0ZDY5NTU5NzZmODA5OWQ5MDliN2E2ZWQ2MTUxYTY3MmJiNVwiLFwiSXJuRHRcIjpcIjIwMjMtMDgtMDggMTE6MDg6MDBcIn0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.2EU1G9AnJtDLhU9prlEJU86MH-dEXQPc6bgxvBajWkmMC4OqjyOQv1bwe3l4UAJ7dYTcJf_uuKqlAuKHmfRnvoeqdbiU9ZCERgkzal0AjM4jPGzuNyTiRBY7u65IZ624YDQA9qd4KOkBaIu5Sw1daLQNTm4czZLB4ylzVQw8XFF5RLvCc346ldLgSefAIRZBA-MekT3d7M2It7FwYJnfj6hAfXxC19kGl1aV6IM5gvZw90EGCmotzLUxAGJEDwue_nwI5pe4D3KAgMgUxqSxg8WfwLjAIiwfGshVWHgyeGVRoHSfq9DA0O866rlxphl2-J0380svEWp7IqFV15fqWw', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (79, '2023-08-08', '2023-08-08', '', '1970-01-01', 'INV/23-24/-077', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-08', '11:10 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '850300', NULL, '1080R2-2PM 70MM CLEATED STATOR', '', 'KGS', '1500', '1', '1500.00', '0', 'percent_wise', '0.00', '1500.00', '9', '', '9', '', '18', '270.00', NULL, '1500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1770.00', '1770.00', 1, 'INV/23-24/-077080823', 'INV/23-24/-077-2023', 1, 1, '1.00', '112310168532180', '2023-08-08 11:15:00', 'd1315471d05e0ad90f848123c752dfd3f84525ffe0b8dcf5864dcab1c77fbb32', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjg1MzIxNzUsXCJBY2tEdFwiOlwiMjAyMy0wOC0wOCAxMToxNTowMFwiLFwiSXJuXCI6XCJkMTMxNTQ3MWQwNWUwYWQ5MGY4NDgxMjNjNzUyZGZkM2Y4NDUyNWZmZTBiOGRjZjU4NjRkY2FiMWM3N2ZiYjMyXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDc3XCIsXCJEdFwiOlwiMDgvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjg1MDMwMFwiLFwiUXR5XCI6MSxcIlVuaXRcIjpcIktHU1wiLFwiVW5pdFByaWNlXCI6MTUwMCxcIlRvdEFtdFwiOjE1MDAsXCJEaXNjb3VudFwiOjAsXCJBc3NBbXRcIjoxNTAwLFwiR3N0UnRcIjoxOCxcIklnc3RBbXRcIjoyNzAsXCJDZ3N0QW10XCI6MCxcIlNnc3RBbXRcIjowLFwiVG90SXRlbVZhbFwiOjE3NzB9XSxcIlZhbER0bHNcIjp7XCJBc3NWYWxcIjoxNTAwLFwiQ2dzdFZhbFwiOjAsXCJTZ3N0VmFsXCI6MCxcIklnc3RWYWxcIjoyNzAsXCJPdGhDaHJnXCI6MCxcIlJuZE9mZkFtdFwiOjAsXCJUb3RJbnZWYWxcIjoxNzcwfSxcIkFkZGxEb2NEdGxzXCI6W3tcIlVybFwiOlwiaHR0cHM6Ly9laW52LWFwaXNhbmRib3gubmljLmluXCIsXCJEb2NzXCI6XCJUZXN0IERvY1wiLFwiSW5mb1wiOlwiRG9jdW1lbnQgVGVzdFwifV19IiwiaXNzIjoiTklDIFNhbmRib3gifQ.XHxUtENpqyC8jlhx9xKaRZgaor-pGFIKDl67E9Kj9kqsOt8cZMoeZhdcOXkgzVzLtJZdyBXq4W_HhuRpnttnog1amXB9OW7S0MRRhludMDK7DtuFz7ycLVgYPLM4Sie7mAkbpispnHL0omlVYXM_5pAufserEQvI1y6qWoz76mpu2NU-UU9Tthqzd_DClNMiAIRX02MRoC8FmGr76SpYEGP20mMsHzDvk6ME9DWV1KLJ90qqgtynY303hsv1ecS4AmTdCTxtCcKBxvdKmueazPvwSbO-VnDXWbLdCe_X29z15agNRT2LmbyyGPfNME_x0nZ2fQHkBxHLOHLsIQ8bww', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wNzdcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDgvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MTc3MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjg1MDMwMFwiLFwiSXJuXCI6XCJkMTMxNTQ3MWQwNWUwYWQ5MGY4NDgxMjNjNzUyZGZkM2Y4NDUyNWZmZTBiOGRjZjU4NjRkY2FiMWM3N2ZiYjMyXCIsXCJJcm5EdFwiOlwiMjAyMy0wOC0wOCAxMToxNTowMFwifSIsImlzcyI6Ik5JQyBTYW5kYm94In0.MdMXRGiwxftgA6MJ6K0ButP9AWgV8HGeJ-0gZEKkM9gPynQA8nr9B3M30-6V9sOXmhEtKCAHV3KesUPGwkqhEjxyI6_1pN-pCTfupNyKOOdLmUzPhEl_OuAeceB7s-mgk9ASdcR22LknDFIMYPpFRlJCF5c_XKHCtJMOBk7j9xMLUahPpNKYV-M_1Jxr15iEa75kvUgXhqBCj17dj_uVaM8oWOpT4d4sSOgTWNcoDDen0O0E1fQy7tg8oG56vP0ZvHQom0fwZYyN84qAYY7RSsL7_9cD_oh6EeZjDfCempk6t4B6cMk7DbtYA6DrvrcM4DhhM4-NYC4PeVoEb_c4UA', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (80, '2023-08-08', '2023-08-08', '', '1970-01-01', 'INV/23-24/-078', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-08', '11:27 AM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '1', '2000.00', '0', 'percent_wise', '0.00', '2000.00', '9', '', '9', '', '18', '360.00', NULL, '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '2360.00', '2360.00', 1, 'INV/23-24/-078080823', 'INV/23-24/-078-2023', 1, 1, '1.00', '112310168533130', '2023-08-08 11:46:00', '6cad16a07be8df50a51ff4b2fefebaa6ca23d44388dda13824d9a8e81ad3c790', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjg1MzMxMjksXCJBY2tEdFwiOlwiMjAyMy0wOC0wOCAxMTo0NjowMFwiLFwiSXJuXCI6XCI2Y2FkMTZhMDdiZThkZjUwYTUxZmY0YjJmZWZlYmFhNmNhMjNkNDQzODhkZGExMzgyNGQ5YThlODFhZDNjNzkwXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDc4XCIsXCJEdFwiOlwiMDgvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjcyMDRcIixcIlF0eVwiOjEsXCJVbml0XCI6XCJLR1NcIixcIlVuaXRQcmljZVwiOjIwMDAsXCJUb3RBbXRcIjoyMDAwLFwiRGlzY291bnRcIjowLFwiQXNzQW10XCI6MjAwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6MzYwLFwiQ2dzdEFtdFwiOjAsXCJTZ3N0QW10XCI6MCxcIlRvdEl0ZW1WYWxcIjoyMzYwfV0sXCJWYWxEdGxzXCI6e1wiQXNzVmFsXCI6MjAwMCxcIkNnc3RWYWxcIjowLFwiU2dzdFZhbFwiOjAsXCJJZ3N0VmFsXCI6MzYwLFwiT3RoQ2hyZ1wiOjAsXCJSbmRPZmZBbXRcIjowLFwiVG90SW52VmFsXCI6MjM2MH0sXCJBZGRsRG9jRHRsc1wiOlt7XCJVcmxcIjpcImh0dHBzOi8vZWludi1hcGlzYW5kYm94Lm5pYy5pblwiLFwiRG9jc1wiOlwiVGVzdCBEb2NcIixcIkluZm9cIjpcIkRvY3VtZW50IFRlc3RcIn1dfSIsImlzcyI6Ik5JQyBTYW5kYm94In0.KSqsmaRPwuZMLYUULwofH6TcvztuufBBQzGZIVgSs_Yf_FxtvW4nkDJPHCauSwASj8R68a8v5jh1DAM2Df5CC4ptgI6TQO0z3umx9AJFtXBkWGctDUKodxB_B8cG-0_5mZbnnuuwq15uPxIUbX3DAoCyZsJfUs9WNl4InmoWsvl3e7swI6EEj5gEUgl3aocp80QbqGV23GdsLkSosjVk45cGV4pVZximQD6Ci1u28AFtvaTe8wN9esRhWubglsqM_i3d7qLkwxCX9KLeM7_qtB6mF9u64l35jUmiY59t2jqxMOiVLskklzhpF95g9uGoK1uUprMMdaO3mEJF1qU32Q', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wNzhcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDgvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6MjM2MCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjcyMDRcIixcIklyblwiOlwiNmNhZDE2YTA3YmU4ZGY1MGE1MWZmNGIyZmVmZWJhYTZjYTIzZDQ0Mzg4ZGRhMTM4MjRkOWE4ZTgxYWQzYzc5MFwiLFwiSXJuRHRcIjpcIjIwMjMtMDgtMDggMTE6NDY6MDBcIn0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.13s9El9wl2wr3l3E8PxGBd3FQiyqC4a9iHvGxFuxnX7PBPtvxJ6wkukjyjnOwXXDKeEi9m32TyGYUwkKgXv5q0itjmF_xlxZb8eXBOflSeqbujkGS7S9_ZbBM4-5JBS8W_vKiun9V1xYuDinQOYf9qkz06r2W4Cxs_ZOwRUlpOoMF1F0aDpmBjdjK6pwp68OpgeJ07-BaLPAqJtBmhRyf9DbmCtN61dauk93FUic5MkzS_NR8k2IrM5EyHoK_U5wdB6fxG9U4V47InrnRPOXQEO059nx5YkwCT0tbl67X1AWTi2wuwxY4rfJLj_xh2u1CWyyjrTlkv1WTn9OBSFaUg', 'ACT', '', '', '', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (85, '2023-08-08', '2023-08-08', '', '1970-01-01', 'INV/23-24/-083', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-08', '04:32 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '2', '4000.00', '0', 'percent_wise', '0.00', '4000.00', '9', '', '9', '', '18', '720.00', NULL, '4000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '4720.00', '4720.00', 1, 'INV/23-24/-083080823', 'INV/23-24/-083-2023', 1, 1, '2.00', '112310168540970', '2023-08-08 16:37:00', '151ce9d601e9d23e6a12919ac1cbea1ffd8a8579e411f950d54f18002269498c', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjg1NDA5NzAsXCJBY2tEdFwiOlwiMjAyMy0wOC0wOCAxNjozNzowMFwiLFwiSXJuXCI6XCIxNTFjZTlkNjAxZTlkMjNlNmExMjkxOWFjMWNiZWExZmZkOGE4NTc5ZTQxMWY5NTBkNTRmMTgwMDIyNjk0OThjXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDgzXCIsXCJEdFwiOlwiMDgvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiSURSRUFNIERFVkVMT1BFUlNcIixcIkFkZHIxXCI6XCI5MSwgRHIuIEphZ2FuYXRoYW4gTmFnYXIsIENpdmlsIEFlcm9kcm9tZSBwb3N0LCBDTUMgb3BwXCIsXCJBZGRyMlwiOlwiQXZpbmFzaGkgUm9hZCwgSG9wZXMgQ29sbGVnZVwiLFwiTG9jXCI6XCJDb2ltYmF0b3JlXCIsXCJQaW5cIjo1NjAwOTEsXCJTdGNkXCI6XCIyOVwiLFwiUGhcIjpcIjczNzMzMzMzMjFcIixcIkVtXCI6XCJpbmZvQGlkcmVhbWRldmVsb3BlcnMuY29tXCJ9LFwiQnV5ZXJEdGxzXCI6e1wiR3N0aW5cIjpcIjMzQURYUFQzMjkxTjJaSlwiLFwiTGdsTm1cIjpcIlNNSyBJTkRVU1RSSUVTXCIsXCJQb3NcIjpcIjMzXCIsXCJBZGRyMVwiOlwiMy8yMjZELCBOQURVUEFMQVlBTSBST0FEXCIsXCJBZGRyMlwiOlwiUEFUVEFOQU0gUE9TVCxPTkRJUFVEVVIgKFZJQSlcIixcIkxvY1wiOlwiQ09JTUJBVE9SRVwiLFwiUGluXCI6NjQxMDE0LFwiUGhcIjpcIjc4MTAwMjgyMjJcIixcIkVtXCI6XCJqcEBpZHJlYW1kZXZlbG9wZXJzLmNvbVwiLFwiU3RjZFwiOlwiMzNcIn0sXCJJdGVtTGlzdFwiOlt7XCJJdGVtTm9cIjowLFwiU2xOb1wiOlwiMVwiLFwiSXNTZXJ2Y1wiOlwiTlwiLFwiSHNuQ2RcIjpcIjcyMDRcIixcIlF0eVwiOjIsXCJVbml0XCI6XCJLR1NcIixcIlVuaXRQcmljZVwiOjIwMDAsXCJUb3RBbXRcIjo0MDAwLFwiRGlzY291bnRcIjowLFwiQXNzQW10XCI6NDAwMCxcIkdzdFJ0XCI6MTgsXCJJZ3N0QW10XCI6NzIwLFwiQ2dzdEFtdFwiOjAsXCJTZ3N0QW10XCI6MCxcIlRvdEl0ZW1WYWxcIjo0NzIwfV0sXCJWYWxEdGxzXCI6e1wiQXNzVmFsXCI6NDAwMCxcIkNnc3RWYWxcIjowLFwiU2dzdFZhbFwiOjAsXCJJZ3N0VmFsXCI6NzIwLFwiT3RoQ2hyZ1wiOjAsXCJSbmRPZmZBbXRcIjowLFwiVG90SW52VmFsXCI6NDcyMH0sXCJBZGRsRG9jRHRsc1wiOlt7XCJVcmxcIjpcImh0dHBzOi8vZWludi1hcGlzYW5kYm94Lm5pYy5pblwiLFwiRG9jc1wiOlwiVGVzdCBEb2NcIixcIkluZm9cIjpcIkRvY3VtZW50IFRlc3RcIn1dfSIsImlzcyI6Ik5JQyBTYW5kYm94In0.hX9ZmcPArxMce8XgBBad2V9ZrE0v54Tbcw4z1ilej8ByZpDMuw544fV5tFiA5snEeyiG-Xw7D2H3l25KtuF6gQ1ui5q5IAxjSZa86IErWd8j4wriHeG-r4A8GNxSGH6LktdVFjPG7dtjzGqFoZdIKSSZi_KBsih0GWFlbzSeCj1oaIKO8PFFYOYQn1yWrco_tbSrTrZIWT4Qms3Em8VRRDO2w_fmsa1942HBD_HLOtGbqbrh3NS4hJ0uj3CO4X8RrGaNDstxL0NbG8vtnnY04j2UTEG7hz1gxTYrF9tF_4EwQBPd7JR09snSNGIWoifIn3-HgCMXmFMowH2CGj0AeQ', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wODNcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDgvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6NDcyMCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjcyMDRcIixcIklyblwiOlwiMTUxY2U5ZDYwMWU5ZDIzZTZhMTI5MTlhYzFjYmVhMWZmZDhhODU3OWU0MTFmOTUwZDU0ZjE4MDAyMjY5NDk4Y1wiLFwiSXJuRHRcIjpcIjIwMjMtMDgtMDggMTY6Mzc6MDBcIn0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.zYmOFn07VTd32oL0FL7xzwjIckE1ppw0EH3rddIIyosH8S1OPgyNha_W5LFPo_sr-TSOrC1IjsiSPeH8kCLRDyPWE8XjXmYtFdhjCdwH3bicvO9_LuQ0e51ahEEut9S7WvzFqR5B04p1CVZMv-5Mif4gfbcBLPow4pZYo-sey5qefDGFBVEJoW166wQiQtgTDuwd7ocMl275_8mNhsrwWrPNjxFdibpIEX7_6yjVVGEt4L8SYnRBnooZ5CkBc1yhcPHtz3gbcLwZa1LMx69XPyT1vqQd-bDC6vFwGJaXhzzXkkGM6gS8ECti4OlwCgmBP31hYRxVUiR4eMRraI_hjQ', 'ACT', '171010257178', '2023-08-08 16:37:00', '2023-08-09 23:59:00', '', '', '', 1, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `bill_type`, `invoicetype`, `customerdcnos'`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `hsnno`, `itemcode`, `itemname`, `item_desc`, `uom`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`) VALUES (86, '2023-08-09', '2023-08-09', '', '1970-01-01', 'INV/23-24/-084', NULL, NULL, NULL, NULL, 'Tax Invoice', 'Direct Invoice', '', 1, 'SMK INDUSTRIES', '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', NULL, NULL, '', '2023-08-09', '03:39 PM', '', '', '', NULL, NULL, NULL, 'interstate', 'interstate', '', '', 'igst', NULL, NULL, NULL, '7204', NULL, '1080R2-2PM STATOR STAMPING-GANG', '', 'KGS', '2000', '2', '4000.00', '0', 'percent_wise', '0.00', '4000.00', '9', '', '9', '', '18', '720.00', NULL, '4000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '4720.00', '4720.00', 1, 'INV/23-24/-084090823', 'INV/23-24/-084-2023', 1, 1, '2.00', '112310168567550', '2023-08-09 15:44:00', '059469e84b98cd0a03db32dbd23bf9c161c7ce19dd1078f83342c5e1a442622a', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiQWNrTm9cIjoxMTIzMTAxNjg1Njc1NTEsXCJBY2tEdFwiOlwiMjAyMy0wOC0wOSAxNTo0NDowMFwiLFwiSXJuXCI6XCIwNTk0NjllODRiOThjZDBhMDNkYjMyZGJkMjNiZjljMTYxYzdjZTE5ZGQxMDc4ZjgzMzQyYzVlMWE0NDI2MjJhXCIsXCJWZXJzaW9uXCI6XCIxLjFcIixcIlRyYW5EdGxzXCI6e1wiVGF4U2NoXCI6XCJHU1RcIixcIlN1cFR5cFwiOlwiQjJCXCIsXCJJZ3N0T25JbnRyYVwiOlwiTlwifSxcIkRvY0R0bHNcIjp7XCJUeXBcIjpcIklOVlwiLFwiTm9cIjpcIklOVi8yMy0yNC8tMDg0XCIsXCJEdFwiOlwiMDkvMDgvMjAyM1wifSxcIlNlbGxlckR0bHNcIjp7XCJHc3RpblwiOlwiMjlBQUJDVDEzMzJMMDAwXCIsXCJMZ2xObVwiOlwiTVlPRkZJQ0UgRVJQXCIsXCJBZGRyMVwiOlwiOTEsIERyLiBKYWdhbmF0aGFuIE5hZ2FyLCBDaXZpbCBBZXJvZHJvbWUgcG9zdCwgQ01DIG9wcFwiLFwiQWRkcjJcIjpcIkF2aW5hc2hpIFJvYWQsIEhvcGVzIENvbGxlZ2VcIixcIkxvY1wiOlwiQ29pbWJhdG9yZVwiLFwiUGluXCI6NTYwMDkxLFwiU3RjZFwiOlwiMjlcIixcIlBoXCI6XCI3MzczMzMzMzIxXCIsXCJFbVwiOlwiaW5mb0BpZHJlYW1kZXZlbG9wZXJzLmNvbVwifSxcIkJ1eWVyRHRsc1wiOntcIkdzdGluXCI6XCIzM0FEWFBUMzI5MU4yWkpcIixcIkxnbE5tXCI6XCJTTUsgSU5EVVNUUklFU1wiLFwiUG9zXCI6XCIzM1wiLFwiQWRkcjFcIjpcIjMvMjI2RCwgTkFEVVBBTEFZQU0gUk9BRFwiLFwiQWRkcjJcIjpcIlBBVFRBTkFNIFBPU1QsT05ESVBVRFVSIChWSUEpXCIsXCJMb2NcIjpcIkNPSU1CQVRPUkVcIixcIlBpblwiOjY0MTAxNCxcIlBoXCI6XCI3ODEwMDI4MjIyXCIsXCJFbVwiOlwianBAaWRyZWFtZGV2ZWxvcGVycy5jb21cIixcIlN0Y2RcIjpcIjMzXCJ9LFwiSXRlbUxpc3RcIjpbe1wiSXRlbU5vXCI6MCxcIlNsTm9cIjpcIjFcIixcIklzU2VydmNcIjpcIk5cIixcIkhzbkNkXCI6XCI3MjA0XCIsXCJRdHlcIjoyLFwiVW5pdFwiOlwiS0dTXCIsXCJVbml0UHJpY2VcIjoyMDAwLFwiVG90QW10XCI6NDAwMCxcIkRpc2NvdW50XCI6MCxcIkFzc0FtdFwiOjQwMDAsXCJHc3RSdFwiOjE4LFwiSWdzdEFtdFwiOjcyMCxcIkNnc3RBbXRcIjowLFwiU2dzdEFtdFwiOjAsXCJUb3RJdGVtVmFsXCI6NDcyMH1dLFwiVmFsRHRsc1wiOntcIkFzc1ZhbFwiOjQwMDAsXCJDZ3N0VmFsXCI6MCxcIlNnc3RWYWxcIjowLFwiSWdzdFZhbFwiOjcyMCxcIk90aENocmdcIjowLFwiUm5kT2ZmQW10XCI6MCxcIlRvdEludlZhbFwiOjQ3MjB9LFwiQWRkbERvY0R0bHNcIjpbe1wiVXJsXCI6XCJodHRwczovL2VpbnYtYXBpc2FuZGJveC5uaWMuaW5cIixcIkRvY3NcIjpcIlRlc3QgRG9jXCIsXCJJbmZvXCI6XCJEb2N1bWVudCBUZXN0XCJ9XX0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.usCF_IVCfEhZLrkmxcVbpHfKPMEilcab2a3NJJsb42f2Zc_dj31Nrl02cSy_rzEicuImGQrWjmtPg88rux3bnfFkpmsQFkrD2dtuLR5MdwICV_lsJkaD3mOdlRXvEbNlJPOmM7tiXDBz2tmb_LtRQetYBJ8_CWvPCHKflXW7W8C4puQDTNi9KcjfQr4Cr0j4DG71kIq7Mo0JSuzxiWm8NClSxWlCGzFd50_1g2HjwEmmvHtaf1iDO6ozbP1SDjaUXVbRfOzkIE-IWRyXLXy5s2RX0DUzw1ojk4tdfmMMIAgs7ajJ-810CEzXSri9qxWcZdE0IEpFSfDvDpWXaesevw', 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjE1MTNCODIxRUU0NkM3NDlBNjNCODZFMzE4QkY3MTEwOTkyODdEMUYiLCJ4NXQiOiJGUk80SWU1R3gwbW1PNGJqR0w5eEVKa29mUjgiLCJ0eXAiOiJKV1QifQ.eyJkYXRhIjoie1wiU2VsbGVyR3N0aW5cIjpcIjI5QUFCQ1QxMzMyTDAwMFwiLFwiQnV5ZXJHc3RpblwiOlwiMzNBRFhQVDMyOTFOMlpKXCIsXCJEb2NOb1wiOlwiSU5WLzIzLTI0Ly0wODRcIixcIkRvY1R5cFwiOlwiSU5WXCIsXCJEb2NEdFwiOlwiMDkvMDgvMjAyM1wiLFwiVG90SW52VmFsXCI6NDcyMCxcIkl0ZW1DbnRcIjoxLFwiTWFpbkhzbkNvZGVcIjpcIjcyMDRcIixcIklyblwiOlwiMDU5NDY5ZTg0Yjk4Y2QwYTAzZGIzMmRiZDIzYmY5YzE2MWM3Y2UxOWRkMTA3OGY4MzM0MmM1ZTFhNDQyNjIyYVwiLFwiSXJuRHRcIjpcIjIwMjMtMDgtMDkgMTU6NDQ6MDBcIn0iLCJpc3MiOiJOSUMgU2FuZGJveCJ9.vpnKl1QHFMLTwsobuMfBed8gcYhC2ScrzoqA8OliCNwkLhi5sTYnQXL7AuoTzlEx24TTv3aHRaRTSpSuZuI4DGIc5E5SOArI6WgY-EA3XaqFWRIbwiBrX0-rG1jJ9HYKL5bV9KAGw35CJss2-NcY68bpu1_XlXqQZV9fnaxQ8PfTAcITKBpe67nHc2iNkPMrjPfPsCdeH1BtcPJ39XkIj5wjThmCC9zHnzb9c6knSQPv_WWgGFLJw2Zpl5N6DBlX-9MuoCIB02GowfC1dx6i-1YHmHEEPS9y6f9i_2jpO6dqHdX3IPNj70kyro5uuBn9QXZHHKJ_Ex1HcuMqHkRjaw', 'ACT', '191010257707', '2023-08-09 15:44:00', '2023-08-10 23:59:00', '', '', '', 1, 1);


#
# TABLE STRUCTURE FOR: invoice_details_backup
#

DROP TABLE IF EXISTS `invoice_details_backup`;

CREATE TABLE `invoice_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `customerdcnos` varchar(100) DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `pino` varchar(100) NOT NULL,
  `purchaseordernos` varchar(255) DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `removalDate` date NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToId` varchar(255) DEFAULT NULL,
  `shipToAddress` longtext,
  `deliveryAddress1` longtext,
  `deliveryAddress2` longtext,
  `mobileNo` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `totalqty` varchar(255) NOT NULL,
  `poNumber` varchar(100) NOT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: invoice_party_statement
#

DROP TABLE IF EXISTS `invoice_party_statement`;

CREATE TABLE `invoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=latin1;

INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '-', '-', NULL, '2023-07-28', 'INV/23-24/-001', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', '', '', NULL, NULL, '', '', '1', '2023-07-28', '2023-07-28', '4130.00', '-', '-', '', '', '-', '-', NULL, '4130', '-', '-', '-', '-', '4130.00', '-', '4130.00', NULL, NULL, 'INV/23-24/-001-2023', 'INV/23-24/-001280723', '1');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (3, '-', '-', NULL, '2023-07-28', 'INV/23-24/-002', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', '', '', NULL, NULL, '', '', '1', '2023-07-28', '2023-07-28', '4130.00', '-', '-', '', '', '-', '-', NULL, '8260', '-', '-', '-', '-', '4130.00', '-', '4130.00', NULL, NULL, NULL, NULL, '2');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (4, '-', '-', NULL, '2023-07-29', 'INV/23-24/-003', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', '', '', NULL, NULL, '', '', '1', '2023-07-29', '2023-07-29', '4130.00', '-', '-', '', '', '-', '-', NULL, '12390', '-', '-', '-', '-', '4130.00', '-', '4130.00', NULL, NULL, 'INV/23-24/-003-2023', 'INV/23-24/-003290723', '3');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (5, '-', '-', NULL, '2023-07-29', 'INV/23-24/-004', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', '', '', NULL, NULL, '', '', '1', '2023-07-29', '2023-07-29', '4130.00', '-', '-', '', '', '-', '-', NULL, '16520', '-', '-', '-', '-', '4130.00', '-', '4130.00', NULL, NULL, 'INV/23-24/-004-2023', 'INV/23-24/-004290723', '4');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (6, '-', '-', NULL, '2023-07-29', 'INV/23-24/-005', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG||1080R2-2PM 70MM CLEATED STATOR', '||', '', '', NULL, NULL, '', '', '1', '2023-07-29', '2023-07-29', '4130.00', '-', '-', '', '', '-', '-', NULL, '20650', '-', '-', '-', '-', '4130.00', '-', '4130.00', NULL, NULL, 'INV/23-24/-005-2023', 'INV/23-24/-005290723', '5');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (7, '-', '-', NULL, '2023-07-29', 'INV/23-24/-006', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR||1080R2-2PM STATOR STAMPING-GANG', '||', '', '', NULL, NULL, '', '', '1', '2023-07-29', '2023-07-29', '4130.00', '-', '-', '', '', '-', '-', NULL, '24780', '-', '-', '-', '-', '4130.00', '-', '4130.00', NULL, NULL, 'INV/23-24/-006-2023', 'INV/23-24/-006290723', '6');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (8, '-', '-', NULL, '2023-08-03', 'INV/23-24/-007', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '26550', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-007-2023', 'INV/23-24/-007030823', '7');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (9, '-', '-', NULL, '2023-08-03', 'INV/23-24/-008', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '28320', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-008-2023', 'INV/23-24/-008030823', '8');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (10, '-', '-', NULL, '2023-08-03', 'INV/23-24/-009', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '30090', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-009-2023', 'INV/23-24/-009030823', '9');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (11, '-', '-', NULL, '2023-08-03', 'INV/23-24/-010', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '31860', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-010-2023', 'INV/23-24/-010030823', '10');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (12, '-', '-', NULL, '2023-08-03', 'INV/23-24/-011', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '33630', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-011-2023', 'INV/23-24/-011030823', '11');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (13, '-', '-', NULL, '2023-08-03', 'INV/23-24/-012', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '35400', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-012-2023', 'INV/23-24/-012030823', '12');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (14, '-', '-', NULL, '2023-08-03', 'INV/23-24/-013', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '37170', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-013-2023', 'INV/23-24/-013030823', '13');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (15, '-', '-', NULL, '2023-08-03', 'INV/23-24/-014', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '38940', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-014-2023', 'INV/23-24/-014030823', '14');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (16, '-', '-', NULL, '2023-08-03', 'INV/23-24/-015', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '2360.00', '-', '-', '', '', '-', '-', NULL, '41300', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-015-2023', 'INV/23-24/-015030823', '15');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (17, '-', '-', NULL, '2023-08-03', 'INV/23-24/-016', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '2360.00', '-', '-', '', '', '-', '-', NULL, '43660', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-016-2023', 'INV/23-24/-016030823', '16');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (18, '-', '-', NULL, '2023-08-03', 'INV/23-24/-017', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '2360.00', '-', '-', '', '', '-', '-', NULL, '46020', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-017-2023', 'INV/23-24/-017030823', '17');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (19, '-', '-', NULL, '2023-08-03', 'INV/23-24/-018', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '47790', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-018-2023', 'INV/23-24/-018030823', '18');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (20, '-', '-', NULL, '2023-08-03', 'INV/23-24/-019', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '49560', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-019-2023', 'INV/23-24/-019030823', '19');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (21, '-', '-', NULL, '2023-08-03', 'INV/23-24/-020', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '2360.00', '-', '-', '', '', '-', '-', NULL, '51920', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-020-2023', 'INV/23-24/-020030823', '20');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (22, '-', '-', NULL, '2023-08-03', 'INV/23-24/-021', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '53690', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-021-2023', 'INV/23-24/-021030823', '21');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (23, '-', '-', NULL, '2023-08-03', 'INV/23-24/-022', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '55460', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-022-2023', 'INV/23-24/-022030823', '22');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (24, '-', '-', NULL, '2023-08-03', 'INV/23-24/-023', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '2360.00', '-', '-', '', '', '-', '-', NULL, '57820', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-023-2023', 'INV/23-24/-023030823', '23');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (25, '-', '-', NULL, '2023-08-03', 'INV/23-24/-024', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '59590', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-024-2023', 'INV/23-24/-024030823', '24');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (26, '-', '-', NULL, '2023-08-03', 'INV/23-24/-025', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '61360', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-025-2023', 'INV/23-24/-025030823', '25');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (27, '-', '-', NULL, '2023-08-03', 'INV/23-24/-026', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '63130', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-026-2023', 'INV/23-24/-026030823', '26');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (28, '-', '-', NULL, '2023-08-03', 'INV/23-24/-027', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '64900', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-027-2023', 'INV/23-24/-027030823', '27');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (29, '-', '-', NULL, '2023-08-03', 'INV/23-24/-028', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '2360.00', '-', '-', '', '', '-', '-', NULL, '67260', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-028-2023', 'INV/23-24/-028030823', '28');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (30, '-', '-', NULL, '2023-08-03', 'INV/23-24/-029', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '69030', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-029-2023', 'INV/23-24/-029030823', '29');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (31, '-', '-', NULL, '2023-08-03', 'INV/23-24/-030', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '2360.00', '-', '-', '', '', '-', '-', NULL, '71390', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-030-2023', 'INV/23-24/-030030823', '30');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (32, '-', '-', NULL, '2023-08-03', 'INV/23-24/-031', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '73160', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-031-2023', 'INV/23-24/-031030823', '31');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (33, '-', '-', NULL, '2023-08-03', 'INV/23-24/-032', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '74930', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-032-2023', 'INV/23-24/-032030823', '32');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (34, '-', '-', NULL, '2023-08-03', 'INV/23-24/-033', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '76700', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-033-2023', 'INV/23-24/-033030823', '33');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (35, '-', '-', NULL, '2023-08-03', 'INV/23-24/-034', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-03', '2023-08-03', '1770.00', '-', '-', '', '', '-', '-', NULL, '78470', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-034-2023', 'INV/23-24/-034030823', '34');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (36, '-', '-', NULL, '2023-08-04', 'INV/23-24/-035', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '80240', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-035-2023', 'INV/23-24/-035040823', '35');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (37, '-', '-', NULL, '2023-08-04', 'INV/23-24/-036', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '82600', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-036-2023', 'INV/23-24/-036040823', '36');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (38, '-', '-', NULL, '2023-08-04', 'INV/23-24/-037', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '84370', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-037-2023', 'INV/23-24/-037040823', '37');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (39, '-', '-', NULL, '2023-08-04', 'INV/23-24/-038', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '86730', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-038-2023', 'INV/23-24/-038040823', '38');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (40, '-', '-', NULL, '2023-08-04', 'INV/23-24/-039', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '88500', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-039-2023', 'INV/23-24/-039040823', '39');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (41, '-', '-', NULL, '2023-08-04', 'INV/23-24/-040', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '90270', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-040-2023', 'INV/23-24/-040040823', '40');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (42, '-', '-', NULL, '2023-08-04', 'INV/23-24/-041', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '92040', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-041-2023', 'INV/23-24/-041040823', '41');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (43, '-', '-', NULL, '2023-08-04', 'INV/23-24/-042', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '93810', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-042-2023', 'INV/23-24/-042040823', '42');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (44, '-', '-', NULL, '2023-08-04', 'INV/23-24/-043', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '95580', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-043-2023', 'INV/23-24/-043040823', '43');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (45, '-', '-', NULL, '2023-08-04', 'INV/23-24/-044', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '97940', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-044-2023', 'INV/23-24/-044040823', '44');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (46, '-', '-', NULL, '2023-08-04', 'INV/23-24/-045', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '100300', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-045-2023', 'INV/23-24/-045040823', '45');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (47, '-', '-', NULL, '2023-08-04', 'INV/23-24/-046', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '102070', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-046-2023', 'INV/23-24/-046040823', '46');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (48, '-', '-', NULL, '2023-08-04', 'INV/23-24/-047', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '104430', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-047-2023', 'INV/23-24/-047040823', '47');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (49, '-', '-', NULL, '2023-08-04', 'INV/23-24/-048', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '106200', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-048-2023', 'INV/23-24/-048040823', '48');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (50, '-', '-', NULL, '2023-08-04', 'INV/23-24/-049', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '108560', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-049-2023', 'INV/23-24/-049040823', '49');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (51, '-', '-', NULL, '2023-08-04', 'INV/23-24/-050', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '110330', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-050-2023', 'INV/23-24/-050040823', '50');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (52, '-', '-', NULL, '2023-08-04', 'INV/23-24/-051', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '112690', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-051-2023', 'INV/23-24/-051040823', '51');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (53, '-', '-', NULL, '2023-08-04', 'INV/23-24/-052', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '115050', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-052-2023', 'INV/23-24/-052040823', '52');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (54, '-', '-', NULL, '2023-08-04', 'INV/23-24/-053', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '117410', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-053-2023', 'INV/23-24/-053040823', '53');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (55, '-', '-', NULL, '2023-08-04', 'INV/23-24/-054', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '119180', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-054-2023', 'INV/23-24/-054040823', '54');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (56, '-', '-', NULL, '2023-08-04', 'INV/23-24/-055', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '121540', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-055-2023', 'INV/23-24/-055040823', '55');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (57, '-', '-', NULL, '2023-08-04', 'INV/23-24/-056', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '123900', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-056-2023', 'INV/23-24/-056040823', '56');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (58, '-', '-', NULL, '2023-08-04', 'INV/23-24/-057', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '126260', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-057-2023', 'INV/23-24/-057040823', '57');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (59, '-', '-', NULL, '2023-08-04', 'INV/23-24/-058', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '128620', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-058-2023', 'INV/23-24/-058040823', '58');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (60, '-', '-', NULL, '2023-08-04', 'INV/23-24/-059', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '1770.00', '-', '-', '', '', '-', '-', NULL, '130390', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-059-2023', 'INV/23-24/-059040823', '59');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (61, '-', '-', NULL, '2023-08-04', 'INV/23-24/-060', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-04', '2023-08-04', '2360.00', '-', '-', '', '', '-', '-', NULL, '132750', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-060-2023', 'INV/23-24/-060040823', '60');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (62, '-', '-', NULL, '2023-08-07', 'INV/23-24/-061', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '134520', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-061-2023', 'INV/23-24/-061070823', '61');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (63, '-', '-', NULL, '2023-08-07', 'INV/23-24/-062', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '136290', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-062-2023', 'INV/23-24/-062070823', '62');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (64, '-', '-', NULL, '2023-08-07', 'INV/23-24/-063', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '138060', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-063-2023', 'INV/23-24/-063070823', '63');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (65, '-', '-', NULL, '2023-08-07', 'INV/23-24/-064', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '139830', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-064-2023', 'INV/23-24/-064070823', '64');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (66, '-', '-', NULL, '2023-08-07', 'INV/23-24/-065', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '141600', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-065-2023', 'INV/23-24/-065070823', '65');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (67, '-', '-', NULL, '2023-08-07', 'INV/23-24/-066', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '143370', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-066-2023', 'INV/23-24/-066070823', '66');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (68, '-', '-', NULL, '2023-08-07', 'INV/23-24/-067', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '145140', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-067-2023', 'INV/23-24/-067070823', '67');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (69, '-', '-', NULL, '2023-08-07', 'INV/23-24/-068', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '146910', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-068-2023', 'INV/23-24/-068070823', '68');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (70, '-', '-', NULL, '2023-08-07', 'INV/23-24/-069', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '148680', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-069-2023', 'INV/23-24/-069070823', '69');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (71, '-', '-', NULL, '2023-08-07', 'INV/23-24/-070', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '150450', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-070-2023', 'INV/23-24/-070070823', '70');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (72, '-', '-', NULL, '2023-08-07', 'INV/23-24/-071', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '152220', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-071-2023', 'INV/23-24/-071070823', '71');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (73, '-', '-', NULL, '2023-08-07', 'INV/23-24/-072', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '153990', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-072-2023', 'INV/23-24/-072070823', '72');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (74, '-', '-', NULL, '2023-08-07', 'INV/23-24/-073', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '1770.00', '-', '-', '', '', '-', '-', NULL, '155760', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-073-2023', 'INV/23-24/-073070823', '73');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (76, '-', '-', NULL, '2023-08-07', 'INV/23-24/-074', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-07', '2023-08-07', '4720.00', '-', '-', '', '', '-', '-', NULL, '160480', '-', '-', '-', '-', '4720.00', '-', '4720.00', NULL, NULL, 'INV/23-24/-074-2023', 'INV/23-24/-074070823', '75');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (79, '-', '-', NULL, '2023-08-08', 'INV/23-24/-076', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-08', '2023-08-08', '2360.00', '-', '-', '', '', '-', '-', NULL, '164610', '-', '-', '-', '-', '2360.00', '-', '2360.00', NULL, NULL, 'INV/23-24/-076-2023', 'INV/23-24/-076080823', '78');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (80, '-', '-', NULL, '2023-08-08', 'INV/23-24/-077', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM 70MM CLEATED STATOR', '', '', '', NULL, NULL, '', '', '1', '2023-08-08', '2023-08-08', '1770.00', '-', '-', '', '', '-', '-', NULL, '166380', '-', '-', '-', '-', '1770.00', '-', '1770.00', NULL, NULL, 'INV/23-24/-077-2023', 'INV/23-24/-077080823', '79');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (86, '-', '-', NULL, '2023-08-08', 'INV/23-24/-083', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-08', '2023-08-08', '4720.00', '-', '-', '', '', '-', '-', NULL, '195290', '-', '-', '-', '-', '4720.00', '-', '4720.00', NULL, NULL, 'INV/23-24/-083-2023', 'INV/23-24/-083080823', '85');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (87, '-', '-', NULL, '2023-08-09', 'INV/23-24/-084', 1, 'SMK INDUSTRIES', '', '', '', '1080R2-2PM STATOR STAMPING-GANG', '', '', '', NULL, NULL, '', '', '1', '2023-08-09', '2023-08-09', '4720.00', '-', '-', '', '', '-', '-', NULL, '200010', '-', '-', '-', '-', '4720.00', '-', '4720.00', NULL, NULL, 'INV/23-24/-084-2023', 'INV/23-24/-084090823', '86');


#
# TABLE STRUCTURE FOR: invoice_party_statement_backup
#

DROP TABLE IF EXISTS `invoice_party_statement_backup`;

CREATE TABLE `invoice_party_statement_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: invoice_reports
#

DROP TABLE IF EXISTS `invoice_reports`;

CREATE TABLE `invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=latin1;

INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (1, '2023-07-28', 'INV/23-24/-001', '2023-07-28', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', '1', NULL, '4130.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-001-2023', 'INV/23-24/-001280723', '1');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (2, '2023-07-28', 'INV/23-24/-001', '2023-07-28', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '5', '1', '7', NULL, '4130.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-001-2023', 'INV/23-24/-001280723', '1');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (5, '2023-07-28', 'INV/23-24/-002', '2023-07-28', NULL, NULL, 0, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1500', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', NULL, NULL, '2');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (6, '2023-07-28', 'INV/23-24/-002', '2023-07-28', NULL, NULL, 0, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2000', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', NULL, NULL, '2');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (7, '2023-07-29', 'INV/23-24/-003', '2023-07-29', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-003-2023', 'INV/23-24/-003290723', '3');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (8, '2023-07-29', 'INV/23-24/-003', '2023-07-29', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '5', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-003-2023', 'INV/23-24/-003290723', '3');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (9, '2023-07-29', 'INV/23-24/-004', '2023-07-29', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-004-2023', 'INV/23-24/-004290723', '4');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (10, '2023-07-29', 'INV/23-24/-004', '2023-07-29', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '5', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-004-2023', 'INV/23-24/-004290723', '4');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (11, '2023-07-29', 'INV/23-24/-005', '2023-07-29', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-005-2023', 'INV/23-24/-005290723', '5');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (12, '2023-07-29', 'INV/23-24/-005', '2023-07-29', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '0', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-005-2023', 'INV/23-24/-005290723', '5');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (13, '2023-07-29', 'INV/23-24/-006', '2023-07-29', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-006-2023', 'INV/23-24/-006290723', '6');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (14, '2023-07-29', 'INV/23-24/-006', '2023-07-29', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '5', '1', NULL, NULL, '3500.00', NULL, NULL, '4130.00', NULL, NULL, '1', 'INV/23-24/-006-2023', 'INV/23-24/-006290723', '6');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (15, '2023-08-03', 'INV/23-24/-007', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-007-2023', 'INV/23-24/-007030823', '7');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (16, '2023-08-03', 'INV/23-24/-008', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-008-2023', 'INV/23-24/-008030823', '8');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (17, '2023-08-03', 'INV/23-24/-009', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-009-2023', 'INV/23-24/-009030823', '9');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (18, '2023-08-03', 'INV/23-24/-010', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-010-2023', 'INV/23-24/-010030823', '10');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (19, '2023-08-03', 'INV/23-24/-011', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-011-2023', 'INV/23-24/-011030823', '11');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (20, '2023-08-03', 'INV/23-24/-012', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-012-2023', 'INV/23-24/-012030823', '12');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (21, '2023-08-03', 'INV/23-24/-013', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-013-2023', 'INV/23-24/-013030823', '13');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (22, '2023-08-03', 'INV/23-24/-014', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-014-2023', 'INV/23-24/-014030823', '14');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (23, '2023-08-03', 'INV/23-24/-015', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-015-2023', 'INV/23-24/-015030823', '15');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (24, '2023-08-03', 'INV/23-24/-016', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-016-2023', 'INV/23-24/-016030823', '16');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (25, '2023-08-03', 'INV/23-24/-017', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-017-2023', 'INV/23-24/-017030823', '17');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (26, '2023-08-03', 'INV/23-24/-018', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-018-2023', 'INV/23-24/-018030823', '18');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (27, '2023-08-03', 'INV/23-24/-019', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-019-2023', 'INV/23-24/-019030823', '19');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (28, '2023-08-03', 'INV/23-24/-020', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-020-2023', 'INV/23-24/-020030823', '20');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (29, '2023-08-03', 'INV/23-24/-021', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-021-2023', 'INV/23-24/-021030823', '21');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (30, '2023-08-03', 'INV/23-24/-022', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-022-2023', 'INV/23-24/-022030823', '22');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (31, '2023-08-03', 'INV/23-24/-023', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-023-2023', 'INV/23-24/-023030823', '23');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (32, '2023-08-03', 'INV/23-24/-024', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-024-2023', 'INV/23-24/-024030823', '24');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (33, '2023-08-03', 'INV/23-24/-025', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-025-2023', 'INV/23-24/-025030823', '25');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (34, '2023-08-03', 'INV/23-24/-026', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-026-2023', 'INV/23-24/-026030823', '26');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (35, '2023-08-03', 'INV/23-24/-027', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-027-2023', 'INV/23-24/-027030823', '27');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (36, '2023-08-03', 'INV/23-24/-028', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-028-2023', 'INV/23-24/-028030823', '28');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (37, '2023-08-03', 'INV/23-24/-029', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-029-2023', 'INV/23-24/-029030823', '29');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (38, '2023-08-03', 'INV/23-24/-030', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-030-2023', 'INV/23-24/-030030823', '30');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (39, '2023-08-03', 'INV/23-24/-031', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-031-2023', 'INV/23-24/-031030823', '31');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (40, '2023-08-03', 'INV/23-24/-032', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-032-2023', 'INV/23-24/-032030823', '32');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (41, '2023-08-03', 'INV/23-24/-033', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-033-2023', 'INV/23-24/-033030823', '33');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (42, '2023-08-03', 'INV/23-24/-034', '2023-08-03', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-034-2023', 'INV/23-24/-034030823', '34');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (43, '2023-08-04', 'INV/23-24/-035', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-035-2023', 'INV/23-24/-035040823', '35');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (44, '2023-08-04', 'INV/23-24/-036', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-036-2023', 'INV/23-24/-036040823', '36');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (45, '2023-08-04', 'INV/23-24/-037', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-037-2023', 'INV/23-24/-037040823', '37');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (46, '2023-08-04', 'INV/23-24/-038', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-038-2023', 'INV/23-24/-038040823', '38');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (47, '2023-08-04', 'INV/23-24/-039', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-039-2023', 'INV/23-24/-039040823', '39');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (48, '2023-08-04', 'INV/23-24/-040', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-040-2023', 'INV/23-24/-040040823', '40');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (49, '2023-08-04', 'INV/23-24/-041', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-041-2023', 'INV/23-24/-041040823', '41');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (50, '2023-08-04', 'INV/23-24/-042', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-042-2023', 'INV/23-24/-042040823', '42');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (51, '2023-08-04', 'INV/23-24/-043', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-043-2023', 'INV/23-24/-043040823', '43');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (52, '2023-08-04', 'INV/23-24/-044', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-044-2023', 'INV/23-24/-044040823', '44');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (53, '2023-08-04', 'INV/23-24/-045', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-045-2023', 'INV/23-24/-045040823', '45');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (54, '2023-08-04', 'INV/23-24/-046', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-046-2023', 'INV/23-24/-046040823', '46');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (55, '2023-08-04', 'INV/23-24/-047', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-047-2023', 'INV/23-24/-047040823', '47');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (56, '2023-08-04', 'INV/23-24/-048', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-048-2023', 'INV/23-24/-048040823', '48');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (57, '2023-08-04', 'INV/23-24/-049', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-049-2023', 'INV/23-24/-049040823', '49');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (58, '2023-08-04', 'INV/23-24/-050', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-050-2023', 'INV/23-24/-050040823', '50');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (59, '2023-08-04', 'INV/23-24/-051', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-051-2023', 'INV/23-24/-051040823', '51');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (60, '2023-08-04', 'INV/23-24/-052', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-052-2023', 'INV/23-24/-052040823', '52');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (61, '2023-08-04', 'INV/23-24/-053', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-053-2023', 'INV/23-24/-053040823', '53');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (62, '2023-08-04', 'INV/23-24/-054', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-054-2023', 'INV/23-24/-054040823', '54');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (63, '2023-08-04', 'INV/23-24/-055', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-055-2023', 'INV/23-24/-055040823', '55');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (64, '2023-08-04', 'INV/23-24/-056', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-056-2023', 'INV/23-24/-056040823', '56');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (65, '2023-08-04', 'INV/23-24/-057', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-057-2023', 'INV/23-24/-057040823', '57');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (66, '2023-08-04', 'INV/23-24/-058', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-058-2023', 'INV/23-24/-058040823', '58');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (67, '2023-08-04', 'INV/23-24/-059', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-059-2023', 'INV/23-24/-059040823', '59');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (68, '2023-08-04', 'INV/23-24/-060', '2023-08-04', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-060-2023', 'INV/23-24/-060040823', '60');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (69, '2023-08-07', 'INV/23-24/-061', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-061-2023', 'INV/23-24/-061070823', '61');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (70, '2023-08-07', 'INV/23-24/-062', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-062-2023', 'INV/23-24/-062070823', '62');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (71, '2023-08-07', 'INV/23-24/-063', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-063-2023', 'INV/23-24/-063070823', '63');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (72, '2023-08-07', 'INV/23-24/-064', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-064-2023', 'INV/23-24/-064070823', '64');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (73, '2023-08-07', 'INV/23-24/-065', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-065-2023', 'INV/23-24/-065070823', '65');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (74, '2023-08-07', 'INV/23-24/-066', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-066-2023', 'INV/23-24/-066070823', '66');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (75, '2023-08-07', 'INV/23-24/-067', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-067-2023', 'INV/23-24/-067070823', '67');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (76, '2023-08-07', 'INV/23-24/-068', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-068-2023', 'INV/23-24/-068070823', '68');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (77, '2023-08-07', 'INV/23-24/-069', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-069-2023', 'INV/23-24/-069070823', '69');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (78, '2023-08-07', 'INV/23-24/-070', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-070-2023', 'INV/23-24/-070070823', '70');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (79, '2023-08-07', 'INV/23-24/-071', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-071-2023', 'INV/23-24/-071070823', '71');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (80, '2023-08-07', 'INV/23-24/-072', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-072-2023', 'INV/23-24/-072070823', '72');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (81, '2023-08-07', 'INV/23-24/-073', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-073-2023', 'INV/23-24/-073070823', '73');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (83, '2023-08-07', 'INV/23-24/-074', '2023-08-07', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '2', NULL, NULL, '4000.00', NULL, NULL, '4720.00', NULL, NULL, '1', 'INV/23-24/-074-2023', 'INV/23-24/-074070823', '75');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (86, '2023-08-08', 'INV/23-24/-076', '2023-08-08', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '1', NULL, NULL, '2000.00', NULL, NULL, '2360.00', NULL, NULL, '1', 'INV/23-24/-076-2023', 'INV/23-24/-076080823', '78');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (87, '2023-08-08', 'INV/23-24/-077', '2023-08-08', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '850300', NULL, NULL, '1080R2-2PM 70MM CLEATED STATOR', '', '1', '1', NULL, NULL, '1500.00', NULL, NULL, '1770.00', NULL, NULL, '1', 'INV/23-24/-077-2023', 'INV/23-24/-077080823', '79');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (93, '2023-08-08', 'INV/23-24/-083', '2023-08-08', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '2', NULL, NULL, '4000.00', NULL, NULL, '4720.00', NULL, NULL, '1', 'INV/23-24/-083-2023', 'INV/23-24/-083080823', '85');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `qty`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (94, '2023-08-09', 'INV/23-24/-084', '2023-08-09', NULL, NULL, 1, 'SMK INDUSTRIES', NULL, NULL, NULL, '3/226D, NADUPALAYAM ROAD, PATTANAM POST,ONDIPUDUR (VIA), COIMBATORE, Tamil Nadu', 'interstate', 'interstate', NULL, '', NULL, '1970-01-01', '', NULL, '7204', NULL, NULL, '1080R2-2PM STATOR STAMPING-GANG', '', '2', '2', NULL, NULL, '4000.00', NULL, NULL, '4720.00', NULL, NULL, '1', 'INV/23-24/-084-2023', 'INV/23-24/-084090823', '86');


#
# TABLE STRUCTURE FOR: inward_delivery
#

DROP TABLE IF EXISTS `inward_delivery`;

CREATE TABLE `inward_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insertid` int(11) NOT NULL,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `lastupdatedqty` int(11) NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `inward_status` int(11) DEFAULT NULL,
  `lastupdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: inward_details
#

DROP TABLE IF EXISTS `inward_details`;

CREATE TABLE `inward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: inward_details_backup
#

DROP TABLE IF EXISTS `inward_details_backup`;

CREATE TABLE `inward_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: job_data
#

DROP TABLE IF EXISTS `job_data`;

CREATE TABLE `job_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: job_details
#

DROP TABLE IF EXISTS `job_details`;

CREATE TABLE `job_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `joborderdate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext,
  `category` longtext,
  `jobdescription` longtext,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobinward_data
#

DROP TABLE IF EXISTS `jobinward_data`;

CREATE TABLE `jobinward_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `joborderqty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobinward_details
#

DROP TABLE IF EXISTS `jobinward_details`;

CREATE TABLE `jobinward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `jobinwarddate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext,
  `joborderno` varchar(225) DEFAULT NULL,
  `category` longtext,
  `jobdescription` longtext,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobworkdc_delivery
#

DROP TABLE IF EXISTS `jobworkdc_delivery`;

CREATE TABLE `jobworkdc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobworkdc_delivery_backup
#

DROP TABLE IF EXISTS `jobworkdc_delivery_backup`;

CREATE TABLE `jobworkdc_delivery_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobworkdc_details
#

DROP TABLE IF EXISTS `jobworkdc_details`;

CREATE TABLE `jobworkdc_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: jobworkdc_details_backup
#

DROP TABLE IF EXISTS `jobworkdc_details_backup`;

CREATE TABLE `jobworkdc_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: login_details
#

DROP TABLE IF EXISTS `login_details`;

CREATE TABLE `login_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userType` char(1) NOT NULL,
  `date` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `sub_menu_link` text,
  `selectedMainMenu` text NOT NULL,
  `selectedSubMenu` text NOT NULL,
  `add_party` int(11) DEFAULT NULL,
  `add_expenses` int(11) DEFAULT NULL,
  `add_quotation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (1, 'A', '2017-01-26', 'admin', '', 'test@gmail.com', '876049652', '0000-00-00', 'admin', 'admin001', '1', '', '', '', NULL, NULL, NULL);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (5, 'U', '2018-05-02', 'purchase', 'Purchase Team', '', '', '1970-01-01', 'purchase', '123456', '1', 'purchase,inward,inward/view,inward/pending,stockmaster,daily_stockreports,customer/view', 'Purchase,Inward,Inward,Inward,Stock,Stock,Reports', 'Purchase Receipt,Add Inward,Inward Reports,Inward Pending,Add Stock,Daily Stock Reports,Party Reports', 1, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (6, 'U', '2018-05-02', 'Accounts', 'Accounts Team', '', '', '1970-01-01', 'Accounts', '123456', '1', 'invoice_statement/view,tax/view,cashbill/listing,purchase_statement/view,purchasetax/view,voucher,voucher/reports,stockmaster,daily_stockreports,itemwise_report,expenses/reports,quotation/view', 'Sales Invoice,Sales Invoice,Cash Bill,Purchase,Purchase,Voucher,Voucher,Stock,Stock,Stock,Reports,Reports', 'Invoice Party Statement,Invoice Tax Reports,Cash Bill Reports,Purchase Party Statement,Purchase Tax Reports,Add Voucher,Voucher Reports,Add Stock,Daily Stock Reports,Itemwise Reports,Expenses Reports,Quotation Reports', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (7, 'U', '2018-08-10', 'ramesh', 'developer', '', '', '1970-01-01', 'ramesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/reports,purchase_statement/view,purchasetax/view,stockmaster,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Stock,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Add Stock,Add Item', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (8, 'U', '2018-08-10', 'tester1', 'testing', '', '', '1970-01-01', 'tester1', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/view,purchase_statement/view,purchasetax/view,taxtype,uom,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Settings,Settings,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Tax Type,Add UOM,Add Item', 1, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (9, 'U', '2021-06-28', 'parmesh', 'developer', 'pshm956@gmail.com', '8344031191', '2021-06-28', 'parmesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,proforma_invoice/view', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Proforma Invoice Reports', 0, 0, 0);


#
# TABLE STRUCTURE FOR: materialdc_delivery
#

DROP TABLE IF EXISTS `materialdc_delivery`;

CREATE TABLE `materialdc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: materialdc_details
#

DROP TABLE IF EXISTS `materialdc_details`;

CREATE TABLE `materialdc_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: materialdc_details_backup
#

DROP TABLE IF EXISTS `materialdc_details_backup`;

CREATE TABLE `materialdc_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext,
  `customerdcno` longtext,
  `customerdcdate` longtext,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `qty` longtext,
  `remarks` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: po_party_statements
#

DROP TABLE IF EXISTS `po_party_statements`;

CREATE TABLE `po_party_statements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: po_party_statements_backup
#

DROP TABLE IF EXISTS `po_party_statements_backup`;

CREATE TABLE `po_party_statements_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: preference_details
#

DROP TABLE IF EXISTS `preference_details`;

CREATE TABLE `preference_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `sed` varchar(255) DEFAULT NULL,
  `edc` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: preference_settings
#

DROP TABLE IF EXISTS `preference_settings`;

CREATE TABLE `preference_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotationPrefix` varchar(255) NOT NULL,
  `quotation` varchar(255) NOT NULL,
  `expenses` varchar(255) NOT NULL,
  `expensePrefix` varchar(255) NOT NULL,
  `dc` varchar(255) NOT NULL,
  `voucherPrefix` varchar(255) NOT NULL,
  `voucher` varchar(255) NOT NULL,
  `debitPrefix` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `creditPrefix` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `purchasePrefix` varchar(255) NOT NULL,
  `purchase` varchar(255) NOT NULL,
  `invoicePrefix` varchar(255) NOT NULL,
  `invoice` varchar(255) NOT NULL,
  `salesdcPrefix` varchar(255) NOT NULL,
  `materialdcPrefix` varchar(255) NOT NULL,
  `jobdcPrefix` varchar(255) NOT NULL,
  `proforma_invoicePrefix` varchar(255) NOT NULL,
  `proforma_invoice` varchar(255) NOT NULL,
  `inwardPrefix` varchar(255) NOT NULL,
  `inward` varchar(255) NOT NULL,
  `cashbillPrefix` varchar(255) NOT NULL,
  `cashbill_invoice` varchar(255) NOT NULL,
  `creditnote` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) NOT NULL,
  `supplierpurchaseorder` varchar(100) NOT NULL,
  `jobworkdc` varchar(255) DEFAULT NULL,
  `materialdc` varchar(255) DEFAULT NULL,
  `cmp_companyname` varchar(255) NOT NULL,
  `cmp_phoneno` varchar(255) NOT NULL,
  `cmp_mobileno` varchar(255) NOT NULL,
  `cmp_address1` varchar(255) NOT NULL,
  `cmp_address2` varchar(255) NOT NULL,
  `cmp_city` varchar(255) NOT NULL,
  `cmp_pincode` varchar(255) NOT NULL,
  `cmp_stateCode` varchar(255) NOT NULL,
  `cmp_website` varchar(255) NOT NULL,
  `cmp_emailid` varchar(255) NOT NULL,
  `cmp_logo` varchar(255) NOT NULL,
  `cont_companyname` varchar(255) NOT NULL,
  `cont_phoneno` varchar(255) NOT NULL,
  `cont_mobileno` varchar(255) NOT NULL,
  `cont_address1` varchar(255) NOT NULL,
  `cont_address2` varchar(255) NOT NULL,
  `cont_city` varchar(255) NOT NULL,
  `cont_pincode` varchar(255) NOT NULL,
  `cont_stateCode` varchar(255) NOT NULL,
  `cont_website` varchar(255) NOT NULL,
  `cont_emailid` varchar(255) NOT NULL,
  `cont_logo` varchar(255) NOT NULL,
  `discountBy` varchar(255) NOT NULL,
  `invoiceBy` varchar(255) NOT NULL,
  `itemType` varchar(255) NOT NULL,
  `bill_type` varchar(255) DEFAULT NULL,
  `quot_bill_type` varchar(255) DEFAULT NULL,
  `voucher_receivable` varchar(255) DEFAULT NULL,
  `voucher_payable` varchar(255) DEFAULT NULL,
  `last_backup` date NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `inward_add` varchar(255) NOT NULL,
  `cashbill_add` varchar(255) NOT NULL,
  `cashbill_tax_type` varchar(255) NOT NULL,
  `priceType` varchar(255) DEFAULT NULL,
  `priceType1` varchar(255) DEFAULT NULL,
  `sales_dc` int(11) NOT NULL,
  `material_dc` int(11) NOT NULL,
  `jobwork_dc` int(11) NOT NULL,
  `cpo_type` varchar(255) NOT NULL,
  `spo_type` varchar(255) NOT NULL,
  `proforma_type` varchar(255) NOT NULL,
  `attendance` int(11) NOT NULL,
  `status` int(10) NOT NULL,
  `einvoice` int(11) NOT NULL,
  `eway` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `preference_settings` (`id`, `quotationPrefix`, `quotation`, `expenses`, `expensePrefix`, `dc`, `voucherPrefix`, `voucher`, `debitPrefix`, `debit`, `creditPrefix`, `credit`, `purchasePrefix`, `purchase`, `invoicePrefix`, `invoice`, `salesdcPrefix`, `materialdcPrefix`, `jobdcPrefix`, `proforma_invoicePrefix`, `proforma_invoice`, `inwardPrefix`, `inward`, `cashbillPrefix`, `cashbill_invoice`, `creditnote`, `purchaseorder`, `supplierpurchaseorder`, `jobworkdc`, `materialdc`, `cmp_companyname`, `cmp_phoneno`, `cmp_mobileno`, `cmp_address1`, `cmp_address2`, `cmp_city`, `cmp_pincode`, `cmp_stateCode`, `cmp_website`, `cmp_emailid`, `cmp_logo`, `cont_companyname`, `cont_phoneno`, `cont_mobileno`, `cont_address1`, `cont_address2`, `cont_city`, `cont_pincode`, `cont_stateCode`, `cont_website`, `cont_emailid`, `cont_logo`, `discountBy`, `invoiceBy`, `itemType`, `bill_type`, `quot_bill_type`, `voucher_receivable`, `voucher_payable`, `last_backup`, `itemcode`, `inward_add`, `cashbill_add`, `cashbill_tax_type`, `priceType`, `priceType1`, `sales_dc`, `material_dc`, `jobwork_dc`, `cpo_type`, `spo_type`, `proforma_type`, `attendance`, `status`, `einvoice`, `eway`) VALUES (1, 'Q', '001', '001', 'E', '001', 'V/23-24/-', '001', 'D', '001', 'C', '001', 'P', '001', 'INV/23-24/-', '', 'SDC/23-24/-', 'MDC/23-24/-', 'PDC/23-24/', 'PI/23-24/', '001', 'I', '001', 'CB', '001', NULL, '', '001', '001', '001', 'Myoffice Solutions', '7373333321', '8608701222', ' #91 Dr. Jaganathan Nagar', 'Civil Aerodrome Post, Coimbatore', 'Coimbatore', '641014', '33', 'www.idreamdevelopers.org', 'info@idreamdevelopers.com', '12832299_1579401915712151_5416626780361493206_n.png', 'IDREAMDEVELOPERS', '7373333321', '8608701333', ' #91 Dr. Jaganathan Nagar', 'Civil Aerodrome Post, Coimbatore', 'Coimbatore', '641014', '33', 'www.idreamdevelopers.com', 'info@idreamdevelopers.com', 'idream_logo.PNG', 'percent_wise', 'without_stock', 'with_item', 'Overall Tax', 'Overall Tax', 'Against Invoice', 'Against Purchase', '2020-05-04', '0', 'With Inward', 'With Cashbill', '', '1', '0', 1, 0, 0, 'Multiple Tax', 'Multiple Tax', 'Overall Tax', 0, 1, 1, 1);


#
# TABLE STRUCTURE FOR: profile
#

DROP TABLE IF EXISTS `profile`;

CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `companyname` varchar(255) DEFAULT NULL,
  `softwarename` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `stateCode` varchar(255) NOT NULL,
  `emailid` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `gstin` varchar(225) DEFAULT NULL,
  `aadharno` varchar(225) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `bankname` varchar(255) DEFAULT NULL,
  `accountno` varchar(255) DEFAULT NULL,
  `bankbranch` varchar(255) DEFAULT NULL,
  `ifsccode` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `profile` (`id`, `date`, `companyname`, `softwarename`, `mobileno`, `phoneno`, `address1`, `address2`, `city`, `pincode`, `stateCode`, `emailid`, `website`, `tinno`, `cstno`, `gstin`, `aadharno`, `status`, `username`, `password`, `bankname`, `accountno`, `bankbranch`, `ifsccode`, `state`) VALUES (1, NULL, 'MYOFFICE ERP', 'MYOFFICE ERP', '8608701222', '7373333321', '91, Dr. Jaganathan Nagar, Civil Aerodrome post, CMC opp', 'Avinashi Road, Hopes College', 'Coimbatore', '560091', 'Karnataka', 'info@idreamdevelopers.com', '', '12345', '54321', '29AABCT1332L000', '', '1', 'admin', 'admin001', '', '', '', '', NULL);


#
# TABLE STRUCTURE FOR: proforma_invoice_details
#

DROP TABLE IF EXISTS `proforma_invoice_details`;

CREATE TABLE `proforma_invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) NOT NULL,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: proforma_invoice_details_backup
#

DROP TABLE IF EXISTS `proforma_invoice_details_backup`;

CREATE TABLE `proforma_invoice_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `dcnos` longtext,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) NOT NULL,
  `itemname` longtext,
  `item_desc` text NOT NULL,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: proforma_invoice_reports
#

DROP TABLE IF EXISTS `proforma_invoice_reports`;

CREATE TABLE `proforma_invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) NOT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: proinvoice_party_statement
#

DROP TABLE IF EXISTS `proinvoice_party_statement`;

CREATE TABLE `proinvoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchase_collection
#

DROP TABLE IF EXISTS `purchase_collection`;

CREATE TABLE `purchase_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `date_po` date NOT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) NOT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `currentlypaid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchase_details
#

DROP TABLE IF EXISTS `purchase_details`;

CREATE TABLE `purchase_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchase_details_backup
#

DROP TABLE IF EXISTS `purchase_details_backup`;

CREATE TABLE `purchase_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchase_reports
#

DROP TABLE IF EXISTS `purchase_reports`;

CREATE TABLE `purchase_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchaseorder_details
#

DROP TABLE IF EXISTS `purchaseorder_details`;

CREATE TABLE `purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` longtext,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` longtext NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` longtext,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

#
# TABLE STRUCTURE FOR: purchaseorder_details_backup
#

DROP TABLE IF EXISTS `purchaseorder_details_backup`;

CREATE TABLE `purchaseorder_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchaseorder_reports
#

DROP TABLE IF EXISTS `purchaseorder_reports`;

CREATE TABLE `purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: quotation_details
#

DROP TABLE IF EXISTS `quotation_details`;

CREATE TABLE `quotation_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `description` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: quotation_details_backup
#

DROP TABLE IF EXISTS `quotation_details_backup`;

CREATE TABLE `quotation_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `description` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `amount` longtext,
  `discount` longtext,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sales_return
#

DROP TABLE IF EXISTS `sales_return`;

CREATE TABLE `sales_return` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext,
  `itemname` longtext,
  `rate` longtext,
  `qty` longtext,
  `uom` longtext,
  `amount` longtext,
  `discount` longtext,
  `taxableamount` longtext,
  `discountamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sales_return_backup
#

DROP TABLE IF EXISTS `sales_return_backup`;

CREATE TABLE `sales_return_backup` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext,
  `itemname` longtext,
  `rate` longtext,
  `qty` longtext,
  `uom` longtext,
  `amount` longtext,
  `discount` longtext,
  `taxableamount` longtext,
  `discountamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: statecode
#

DROP TABLE IF EXISTS `statecode`;

CREATE TABLE `statecode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) NOT NULL,
  `stateCode` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (1, 'Jammu & Kashmir', '01', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (2, 'Himachal Pradesh', '02', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (3, 'Punjab', '03', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (4, 'Chandigarh', '04', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (5, 'Uttarakhand', '05', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (6, 'Haryana', '06', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (7, 'Delhi', '07', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (8, 'Rajasthan', '08', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (9, 'Uttar Pradesh', '09', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (10, 'Bihar', '10', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (11, 'Sikkim', '11', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (12, 'Arunachal Pradesh', '12', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (13, 'Nagaland', '13', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (14, 'Manipur', '14', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (15, 'Mizoram', '15', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (16, 'Tripura', '16', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (17, 'Meghalaya', '17', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (18, 'Assam', '18', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (19, 'West Bengal', '19', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (20, 'Jharkhand', '20', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (21, 'odisha', '21', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (22, 'Chattisgarh', '22', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (23, 'Madhya Pradesh', '23', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (24, 'Daman & Diu', '25', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (25, 'Gujarat', '24', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (26, 'Dadra & Nagar Haveli', '26', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (27, 'Maharashtra', '27', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (28, 'Andhra Pradesh', '28', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (29, 'Karnataka', '29', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (30, 'Goa', '30', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (31, 'Lakshadweep', '31', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (32, 'Kerala', '32', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (33, 'Tamil Nadu', '33', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (34, 'Puducherry', '34', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (35, 'Andaman & Nicobar Islands', '35', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (36, 'Telengana', '36', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (37, 'Andrapradesh(New)', '37', 1);


#
# TABLE STRUCTURE FOR: stock
#

DROP TABLE IF EXISTS `stock`;

CREATE TABLE `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `updatestock` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `balance` varchar(255) NOT NULL,
  `oldqty` varchar(255) DEFAULT NULL,
  `currentstock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: stock_reports
#

DROP TABLE IF EXISTS `stock_reports`;

CREATE TABLE `stock_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `updatestock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  `balance` varchar(225) DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sup_purchaseorder_details
#

DROP TABLE IF EXISTS `sup_purchaseorder_details`;

CREATE TABLE `sup_purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `shipTo` varchar(255) NOT NULL,
  `shipToAddress` varchar(255) NOT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sup_purchaseorder_details_backup
#

DROP TABLE IF EXISTS `sup_purchaseorder_details_backup`;

CREATE TABLE `sup_purchaseorder_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext,
  `typecgst` longtext,
  `typeigst` longtext,
  `hsnno` longtext,
  `itemname` longtext,
  `uom` longtext,
  `rate` longtext,
  `qty` longtext,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext,
  `discount` longtext,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext,
  `taxableamount` longtext,
  `sgst` longtext,
  `sgstamount` longtext,
  `cgst` longtext,
  `cgstamount` longtext,
  `igst` longtext,
  `igstamount` longtext,
  `total` longtext,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sup_purchaseorder_reports
#

DROP TABLE IF EXISTS `sup_purchaseorder_reports`;

CREATE TABLE `sup_purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_person
#

DROP TABLE IF EXISTS `tbl_person`;

CREATE TABLE `tbl_person` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: uom
#

DROP TABLE IF EXISTS `uom`;

CREATE TABLE `uom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (1, '2023-07-28', 'KGS', 1);


#
# TABLE STRUCTURE FOR: user_menu
#

DROP TABLE IF EXISTS `user_menu`;

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) NOT NULL,
  `main_menu` varchar(255) NOT NULL,
  `sub_menu` varchar(255) NOT NULL,
  `sub_menu_link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: vat_details
#

DROP TABLE IF EXISTS `vat_details`;

CREATE TABLE `vat_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `sgst` varchar(225) DEFAULT NULL,
  `cgst` varchar(225) DEFAULT NULL,
  `igst` varchar(225) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `vat_details` (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (1, '2023-07-28', 'GST', '18', 'GST @ 18 %', '9', '9', '18', '1');


#
# TABLE STRUCTURE FOR: vendor_details
#

DROP TABLE IF EXISTS `vendor_details`;

CREATE TABLE `vendor_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `vendorname` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: voucher
#

DROP TABLE IF EXISTS `voucher`;

CREATE TABLE `voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `tdsamount` varchar(100) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `balance_amt` varchar(255) DEFAULT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: voucher_backup
#

DROP TABLE IF EXISTS `voucher_backup`;

CREATE TABLE `voucher_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `purchaseno` varchar(255) NOT NULL,
  `balance_amt` varchar(255) NOT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

