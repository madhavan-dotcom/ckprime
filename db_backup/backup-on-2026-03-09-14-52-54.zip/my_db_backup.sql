#
# TABLE STRUCTURE FOR: add_staff
#

DROP TABLE IF EXISTS `add_staff`;

CREATE TABLE `add_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `staff_name` varchar(255) NOT NULL,
  `mobileno` varchar(255) NOT NULL,
  `amobileno` varchar(255) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `pincode` varchar(255) NOT NULL,
  `referred` varchar(255) NOT NULL,
  `salary` varchar(255) NOT NULL,
  `salarytype` varchar(255) NOT NULL,
  `perdaysalary` varchar(255) NOT NULL,
  `ot` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: additem
#

DROP TABLE IF EXISTS `additem`;

CREATE TABLE `additem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` text CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `patterncode` varchar(255) NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `pattern_material` varchar(255) NOT NULL,
  `casting_weight` varchar(255) NOT NULL,
  `liquid_weight` varchar(255) NOT NULL,
  `yield` varchar(255) NOT NULL,
  `price` varchar(255) DEFAULT NULL,
  `taxtype` varchar(225) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `priceType` varchar(10) NOT NULL,
  `itemtype` varchar(255) NOT NULL,
  `purchaseNo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (1, '2026-02-10', '2', 'SP01', 'Coal Nozzle ', '', 'C-13-004', 'Teakwood Pattern', '-', '-', '', '200000', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (2, '2026-02-10', '2', 'SP01', 'Coal Nozzle(C)', '', 'C-13-004', 'Cast Iron', '95.2', '105.5', '90.24', '590', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (3, '2026-02-11', '2', 'CA16', '1/2\" CL 600 Body', '', '-', 'Aluminium', '3', '9', '33.33', '1250', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (4, '2026-02-11', '2', 'SBM08', 'EH Outer Box', '', 'ST-MSC-017', 'Aluminium', '34.5', '40.2', '85.82', '167', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (5, '2026-02-11', '2', 'SBM03', 'LH Outer Box', '', 'ST-MSC-016', 'Aluminium', '25.4', '35', '72.57', '167', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (6, '2026-02-11', '2', 'SBM05', 'LH Inner Box', '', 'ST-MSC-014-R1', 'Aluminium', '26.1', '45', '58.00', '167', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (7, '2026-02-11', '2', 'SBM10', '12FN Top Plate', '', 'STMSC022 R1', 'Aluminium', '27', '30', '90.00', '167', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (8, '2026-02-11', '2', 'SBM02', 'NH Outer Box', '', 'ST-MSC-015', 'Aluminium', '28', '35', '80.00', '167', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (9, '2026-02-11', '2', 'SBM04', 'NH Inner Box', '', 'ST-MSC-013 R1', 'Aluminium', '28.5', '30', '95.00', '167', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (10, '2026-02-11', '2', 'SBM15', 'EH Inner Box', '', 'ST-MSC-027 R0', 'Aluminium', '29', '40', '72.50', '167', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (11, '2026-02-11', '2', 'SBM09', 'Moving Block', '', 'ST-MSC-012 R1', 'Aluminium', '10.85', '25', '43.40', '167', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (12, '2026-02-11', '2', 'SP02', 'Collector Casting', '', '3-SPG-9473', 'Aluminium', '26.5', '35', '75.71', '538', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (13, '2026-02-11', '2', 'SP03', 'Collector Casting 8557', '', '3-SPG-8557 ', 'Aluminium', '31', '32', '96.88', '342', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (14, '2026-02-11', '2', 'SP04', 'Flame Holder Segment', '', '4-SPG-10462R/01', 'Aluminium', '2.7', '3', '90.00', '542', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (15, '2026-02-11', '2', 'OMI 01', 'Retainer 2.0', '', '2.067398', 'Teakwood', '112.5', '115', '97.83', '185', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (16, '2026-02-11', '2', 'OMI 02', 'Retainer 3.0', '', '3.062269', 'Teakwood', '52', '55', '94.55', '185', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (17, '2026-02-12', '2', '001', 'Inspection', '', '-', '-', '-', '-', '', '2000', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (18, '2026-02-13', '2', 'CA02', '4\" 1500 Body', '', 'CAD-SPS-YST-0001', 'TEAKWOOD', '212', '250', '84.80', '220', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (19, '2026-02-13', '2', 'OMI 01', 'Retainer 2.0  Pattern', '', '2.067398', 'Teakwood', '-', '-', '', '45500', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (20, '2026-02-13', '2', 'OMI 02', 'Retainer 3.0 Pattern', '', '3.062269', 'Teakwood', '-', '-', '', '35000', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (21, '2026-02-14', '2', 'SP03', 'Collector Casting 3-SPG-8557', '', '3-SPG-8557', 'Aluminium Pattern', '-', '-', '', '10000', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (22, '2026-02-14', '2', 'WC1', 'Website Creation', '', '-', '-', '-', '-', '', '6000', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (23, '2026-02-18', '2', 'TB1', 'TEST BAR(300mmX50mmX50mm)', '', '', 'ALUMINIUM', '6', '10', '60.00', '175', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (24, '2026-02-25', '2', 'PR1', 'Pattern Rework Cost', '-', '-', '-', '-', '-', '', '9500', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (25, '2026-02-25', '2', 'FC1', 'Forwarding Cost', '-', '-', '-', '-', '-', '', '1000', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (26, '2026-03-04', '2', 'SW1', 'Customized ERP Software ', '-', '-', '-', '-', '-', '', '30000', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (27, '2026-03-04', '2', 'SP02', 'Collector Casting 3-SPG-9473', '', '3-SPG-9473', 'Aluminium Pattern', '-', '-', '', '30000', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (28, '2026-03-04', '2', 'EP01', 'Casing EO8-250', '', '005.01.2086-0', 'Aluminium', '250', '300', '83.33', '600', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (29, '2026-03-05', '1', '-', 'Aluminium Plate Alloy 20mmX1160X575mm', '-', '-', '-', '-', '-', '', '475', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (30, '2026-03-05', '1', '-', '115mmX260X150mm', '-', '-', '-', '-', '-', '', '500', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);
INSERT INTO `additem` (`id`, `date`, `uom`, `itemcode`, `itemname`, `patterncode`, `drawingno`, `pattern_material`, `casting_weight`, `liquid_weight`, `yield`, `price`, `taxtype`, `sgst`, `cgst`, `igst`, `status`, `priceType`, `itemtype`, `purchaseNo`) VALUES (31, '2026-03-06', '2', '-', 'Test bar (ASTM A148 GR 90-60)', '-', '-', '-', '-', '-', '', '250', '1', '9', '9', '18', '1', 'Exclusive', '', NULL);


#
# TABLE STRUCTURE FOR: attendance
#

DROP TABLE IF EXISTS `attendance`;

CREATE TABLE `attendance` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `attendancedate` date NOT NULL,
  `staff` varchar(255) NOT NULL,
  `attendances` varchar(255) NOT NULL,
  `intime` varchar(255) NOT NULL,
  `outtime` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `lastupdate` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: backup_details
#

DROP TABLE IF EXISTS `backup_details`;

CREATE TABLE `backup_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` longtext DEFAULT NULL,
  `date_created` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (1, 'backup-on-2026-02-09-12-32-46.zip', '2026-02-09');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (2, 'backup-on-2026-02-10-12-45-42.zip', '2026-02-10');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (3, 'backup-on-2026-02-11-11-13-06.zip', '2026-02-11');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (4, 'backup-on-2026-02-12-12-20-25.zip', '2026-02-12');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (5, 'backup-on-2026-02-13-11-41-45.zip', '2026-02-13');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (6, 'backup-on-2026-02-14-13-10-01.zip', '2026-02-14');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (7, 'backup-on-2026-02-16-16-59-54.zip', '2026-02-16');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (8, 'backup-on-2026-02-17-12-04-29.zip', '2026-02-17');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (9, 'backup-on-2026-02-18-11-16-55.zip', '2026-02-18');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (10, 'backup-on-2026-02-20-11-55-50.zip', '2026-02-20');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (11, 'backup-on-2026-02-24-10-05-20.zip', '2026-02-24');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (12, 'backup-on-2026-02-25-11-02-56.zip', '2026-02-25');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (13, 'backup-on-2026-02-27-10-43-02.zip', '2026-02-27');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (14, 'backup-on-2026-02-28-16-01-43.zip', '2026-02-28');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (15, 'backup-on-2026-03-02-17-02-53.zip', '2026-03-02');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (16, 'backup-on-2026-03-03-11-39-04.zip', '2026-03-03');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (17, 'backup-on-2026-03-04-10-16-35.zip', '2026-03-04');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (18, 'backup-on-2026-03-05-12-58-43.zip', '2026-03-05');
INSERT INTO `backup_details` (`id`, `file_name`, `date_created`) VALUES (19, 'backup-on-2026-03-06-10-06-00.zip', '2026-03-06');


#
# TABLE STRUCTURE FOR: backup_url
#

DROP TABLE IF EXISTS `backup_url`;

CREATE TABLE `backup_url` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: bed_details
#

DROP TABLE IF EXISTS `bed_details`;

CREATE TABLE `bed_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `bed` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: card
#

DROP TABLE IF EXISTS `card`;

CREATE TABLE `card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: cash_bill
#

DROP TABLE IF EXISTS `cash_bill`;

CREATE TABLE `cash_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `dcno` longtext DEFAULT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `dcnos` longtext DEFAULT NULL,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: cashbill_details
#

DROP TABLE IF EXISTS `cashbill_details`;

CREATE TABLE `cashbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `cust_mobno` varchar(255) NOT NULL,
  `address` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `systemDate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: cashbill_reports
#

DROP TABLE IF EXISTS `cashbill_reports`;

CREATE TABLE `cashbill_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `systemDate` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `category` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: collection_details
#

DROP TABLE IF EXISTS `collection_details`;

CREATE TABLE `collection_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: company_logo
#

DROP TABLE IF EXISTS `company_logo`;

CREATE TABLE `company_logo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `company_logo` (`id`, `date`, `image`, `status`) VALUES (1, '2025-07-14', 'Untitled.png', '1');


#
# TABLE STRUCTURE FOR: customer_details
#

DROP TABLE IF EXISTS `customer_details`;

CREATE TABLE `customer_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `contactperson` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `old_openingBal` varchar(255) DEFAULT NULL,
  `salesamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  `accountpay` varchar(255) NOT NULL,
  `chequeno` varchar(100) NOT NULL,
  `last_modified` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (1, '2025-09-17', 'Intra customer', 'jack', '7806876370', 'jack@gmail.com', 'gandhipuram', 'singanallur', 'maddy', 'Tamil Nadu', 'karaikudi', '', '', NULL, '0.00', NULL, '54260848.62', '300', '54260548.62', NULL, '', NULL, '654616', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33ADXPT3291N2ZJ', '', '', '', '', '', '2025-09-17');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (2, '2025-07-17', 'Intra customer', 'SIGMA POWER & ENERGY ENGINEERS', '7339666782', 'sigmapower@sigmapower.in', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE', 'Phase II, VALAVANTHAN KOTTAI, THUVAKUDI', 'NANDHINI.P', 'Tamil Nadu', 'TRICHY', '', '', NULL, '0.00', NULL, '910387.84', '8800', '3036648.32', NULL, '', NULL, '620015', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33ABRFS2547Q1ZD', '', '', '', '', '', '2025-07-17');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (3, '2026-01-29', 'Intra supplier', 'CK PRIME ALLOYS', '9159531031', '', 'ANNUR ROAD', 'KARUMATTAMPATTY', 'C.Karthik', 'Tamil Nadu', 'COIMBATORE', '', '', NULL, '0.00', NULL, '4324232.72', '2400', '4321832.72', NULL, '', NULL, '641659', NULL, NULL, NULL, NULL, NULL, '1', '', 'Somanur Branch', '33', '33CGRPR4623R1ZI', '', 'City Union Bank', '510909010332667 ', '', 'CIUB0000097', '2026-01-29');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (4, '2025-06-23', 'Intra customer', 'IT Solution', '09360296512', '', 'Hoysala nagar, Ramamurthy signal', 'Kasthuri nagar', 'Pradeepa D', 'Karnataka', 'Bangalore', '', '', NULL, '0.00', NULL, '2366.7', '500', '1866.7', NULL, '', NULL, '560016', NULL, NULL, NULL, NULL, NULL, '1', '', '', '29', '', '', '', '', '', '', '2025-06-23');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (5, '2025-06-24', 'Intra supplier', 'Gateway', '9500995841', 'lithikutti81@gmail.com', 'Kasthuri nagar, Sri lakshmi apartement', 'Bangalore', 'Lithi', 'Karnataka', 'Bangalore', '', '', NULL, '0.00', NULL, '44370326.66', '500', '22185347.58', '995.50', '', NULL, '560016', NULL, NULL, NULL, NULL, NULL, '1', '', '', '29', '', '', '', '', '', '', '2025-06-24');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (6, '2025-06-25', 'Intra customer', 'Tech AU', '1234567890', 'pradee@gmail.com', 'Hoysala nagar, Ramamurthy signal', 'Avinashi Road, Hopes College', 'Pradeepa D', 'Tamil Nadu', 'Bangalore', '', '', NULL, '0.00', NULL, NULL, NULL, '0.00', NULL, '', NULL, '560016', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2025-06-25');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (7, '2025-07-17', 'Intra customer', 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '7708330192', 'sales@cadalan.com.sg', 'No:54 SRI VIGNESHWAR ILLAM', 'MGR NAGAR, GOLDWINS', 'SELVARAJ', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '0.00', NULL, '6595250.1', NULL, '14778367.7', NULL, '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33AAICC6141M1ZK', '', '', '', '', '', '2025-07-17');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (8, '2025-10-08', 'Intra supplier', 'PREMIER ALLOYS', '9894021872', 'premieralloys@yahoo.com', 'No 2, Goldwins,Avinashi Road, ', 'Civil Aerodrome(po)', 'SARAN', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '0.00', NULL, '8080275.94', NULL, '5739739.62', NULL, '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33AAHFP3172F1ZG', '', '', '', '', '', '2025-10-08');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (9, '2025-11-20', 'Intra customer', 'STAAN BIO MED PVT LTD', '9710240325', 'murugan@staan.in', '190-A, Bharathiar Road', 'Ganapathy', 'MURUGAN', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '0.00', NULL, '-1872511.06', NULL, '1652805.74', NULL, '', NULL, '641006', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33AAICS8026R1ZQ', '', '', '', '', '', '2025-11-20');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (10, '2025-12-15', 'Intra supplier', 'Shristi Engineering Works', '9500990107', 'shrishtienggworks@yahoo.com', 'Door No.3,Ravathur Road,', 'Athappa Gounder Pudur,Irugur', 'SELVARAJ ', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '0.00', NULL, '57348', NULL, '38232', NULL, '', NULL, '641103', NULL, NULL, NULL, NULL, NULL, '1', '', 'AVINASHI ROAD', '33', '33CUBPS7373B1ZO', '', 'SOUTH INDIAN BANK', '0772081000000254', '', 'SIBL0000772', '2025-12-15');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (11, '2026-02-10', 'Intra supplier', 'Sri Ayyappa Engineering Works', '7871652509', 'saenggworks2020@gmail.com', '4/348C,Kallipalayam Road', 'Chikarampalayam, Karamadai', 'Manikandan', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '0.00', NULL, '265500', NULL, '265500', NULL, '', NULL, '641104', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33AECFS3283F1Z6', '', '', '', '', '', '2026-02-10');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (12, '2026-02-12', 'Intra supplier', 'PKS Inspection Service', '9965223671', 'pkinspections@gmail.com', '83A Pudukadu 2nd Street,Sivanathapuram', 'Vellakovil-638111,Kangeyam Taluk', 'Prakash', 'Tamil Nadu', 'Tiruppur', '', '', NULL, '0.00', NULL, '7080', NULL, '4720', NULL, '', NULL, '638111', NULL, NULL, NULL, NULL, NULL, '1', 'PKS Inspection Service', 'Sulur', '33', '33BMHPP7661N1ZE', '', 'Bank of India', '824020110000850', '', 'BKID0008240', '2026-02-12');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (13, '2026-02-12', 'Intra customer', 'CKP LOI', '9790153461', '', 'SF NO.845B,D.NO.1J(4)', 'Annur,Rayarpalayam', 'Hema latha', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '0.00', NULL, NULL, NULL, '0.00', NULL, '', NULL, '641659', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33CGRPR4623R1ZI', '', '', '', '', '', '2026-02-12');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (14, '2026-02-13', 'Intra supplier', 'Shree Kumaran Alloys', '9952424271', 'ska@shreekumaranalloys.com', 'S/F No - 461, Telungupalayam Road,', 'Ellapalayam Post,Annur', 'M.Prakash', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '0.00', NULL, '217548', NULL, '217548', NULL, '', NULL, '641697', NULL, NULL, NULL, NULL, NULL, '1', '', 'Ganapathy', '33', '33ABFFS0702H1ZN', '', 'Indian Overseas Bank', '061302000010284', '', 'IOBA0000613', '2026-02-13');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (15, '2026-02-13', 'Intra customer', 'OM Industries', '9791321620', 'omdamu@gmail.com', 'No:230/2, 4Th Cross,', 'Vanapadi Road,Sipcot', 'Damotharan', 'Tamil Nadu', 'Ranipet', '', '', NULL, '0.00', NULL, '446901.40', NULL, '446901.4', NULL, '', NULL, '632403', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33ABKPL9684J1Z0', '', '', '', '', '', '2026-02-13');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (16, '2026-02-14', 'Intra supplier', 'TryMy Website', '9597236423', 'trymywebsites@gmail.com', '2nd Floor, SK Towers, Sathy Main Road, ', 'Saravanampatti', 'Kumar', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '0.00', NULL, NULL, NULL, '0.00', NULL, '', NULL, '641035', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33LSFPS9739E1Z3', '', '', '', '', '', '2026-02-14');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (17, '2026-03-04', 'Intra supplier', 'IDREAMDEVELOPERS', '7373333321', 'trymywebsites@gmail.com', 'No:91,Dr.Jaganathan Nagar,', 'Civil Aerodrome Post', 'JAYAPRAKASH', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '0.00', NULL, NULL, NULL, '0.00', NULL, '', NULL, '641014', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2026-03-04');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (18, '2026-03-05', 'Intra supplier', 'Coimbatore Metals', '9884424592', 'cbemetals1955@gmail.com', 'No.392-C.', ' Dr.Nanjappa Road,', '-', 'Tamil Nadu', 'coimbatore', '', '', NULL, '0.00', NULL, NULL, NULL, '0.00', NULL, '', NULL, '641018', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '', '', '', '', '', '', '2026-03-05');
INSERT INTO `customer_details` (`id`, `date`, `type`, `name`, `phoneno`, `email`, `address1`, `address2`, `contactperson`, `state`, `city`, `tinno`, `cstno`, `creditdays`, `openingbal`, `old_openingBal`, `salesamount`, `paidamount`, `balanceamount`, `returnamount`, `panno`, `location`, `pincode`, `eccno`, `range`, `division`, `commissionerate`, `remarks`, `status`, `accountname`, `printname`, `statecode`, `gstno`, `adharno`, `bankname`, `accountno`, `accountpay`, `chequeno`, `last_modified`) VALUES (19, '2026-03-06', 'Intra supplier', 'Praneeth Engineering', '', '', '93-D, Cosmafan Foundry Cluster Park-1,			', 'Arasur', 'Arivalagan', 'Tamil Nadu', 'Coimbatore', '', '', NULL, '0.00', NULL, NULL, NULL, '0.00', NULL, '', NULL, '641407', NULL, NULL, NULL, NULL, NULL, '1', '', '', '33', '33CHEPA3873J1ZG', '', '', '', '', '', '2026-03-06');


#
# TABLE STRUCTURE FOR: customerpo_details
#

DROP TABLE IF EXISTS `customerpo_details`;

CREATE TABLE `customerpo_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `cuspodate` date DEFAULT NULL,
  `invoicetype` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `cuspono` varchar(255) DEFAULT NULL,
  `transport` varchar(255) DEFAULT NULL,
  `customerpodate` date DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `cstname` varchar(255) DEFAULT NULL,
  `cstamount` varchar(255) DEFAULT NULL,
  `pf` varchar(255) DEFAULT NULL,
  `freight` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `pfadjus` varchar(255) DEFAULT NULL,
  `freightadjus` varchar(255) DEFAULT NULL,
  `roundoff` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: dc_delivery
#

DROP TABLE IF EXISTS `dc_delivery`;

CREATE TABLE `dc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(100) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `grade` varchar(100) NOT NULL,
  `weight` varchar(100) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: dcbill_details
#

DROP TABLE IF EXISTS `dcbill_details`;

CREATE TABLE `dcbill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` longtext DEFAULT NULL,
  `customerdcdate` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext DEFAULT NULL,
  `remarks` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `weight` varchar(100) DEFAULT NULL,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: dcbill_details_backup
#

DROP TABLE IF EXISTS `dcbill_details_backup`;

CREATE TABLE `dcbill_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` longtext DEFAULT NULL,
  `customerdcdate` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext DEFAULT NULL,
  `remarks` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `weight` varchar(100) NOT NULL,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: dpt_report
#

DROP TABLE IF EXISTS `dpt_report`;

CREATE TABLE `dpt_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `dpt_report_no` varchar(100) NOT NULL,
  `dpt_date` varchar(100) NOT NULL,
  `customername` varchar(100) DEFAULT NULL,
  `customerid` varchar(100) DEFAULT NULL,
  `report_no` varchar(100) DEFAULT NULL,
  `stage_of_test` varchar(100) DEFAULT NULL,
  `grade` varchar(100) DEFAULT NULL,
  `type_of_penetrant` varchar(100) DEFAULT NULL,
  `casting_temperature` varchar(100) DEFAULT NULL,
  `type_of_developer` varchar(100) DEFAULT NULL,
  `surface_condition` varchar(100) DEFAULT NULL,
  `testing_date` varchar(100) DEFAULT NULL,
  `acceptance_standard` varchar(100) DEFAULT NULL,
  `dwell_time` varchar(100) DEFAULT NULL,
  `procedure_ref` varchar(100) DEFAULT NULL,
  `fluosrecent` varchar(100) DEFAULT NULL,
  `area_method_of_test` varchar(100) DEFAULT NULL,
  `penetrant_apply_method` varchar(10) DEFAULT NULL,
  `precleaning_method` varchar(100) DEFAULT NULL,
  `post_of_test_cleaning` varchar(100) DEFAULT NULL,
  `light_indensity` varchar(100) DEFAULT NULL,
  `background` varchar(100) DEFAULT NULL,
  `result` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `drawing_no` text DEFAULT NULL,
  `heat_no` text DEFAULT NULL,
  `dp_no` text DEFAULT NULL,
  `qty` text DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: einvoicetoken
#

DROP TABLE IF EXISTS `einvoicetoken`;

CREATE TABLE `einvoicetoken` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tokenexpiry` varchar(255) NOT NULL,
  `authtoken` varchar(255) NOT NULL,
  `sek` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS `expenses`;

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: expenses_backup
#

DROP TABLE IF EXISTS `expenses_backup`;

CREATE TABLE `expenses_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `expensesid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `expensesdate` date DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `cardtype` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `headers` varchar(255) NOT NULL,
  `transactionid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: grade
#

DROP TABLE IF EXISTS `grade`;

CREATE TABLE `grade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `heat_treatment` varchar(255) DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `hsnno` varchar(100) NOT NULL,
  `element` text DEFAULT NULL,
  `min_value` text DEFAULT NULL,
  `max_value` text DEFAULT NULL,
  `mechanicalelement` text DEFAULT NULL,
  `mechanicalminvalue` text DEFAULT NULL,
  `mechanicalmaxvalue` text DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `grade` (`id`, `date`, `heat_treatment`, `grade`, `hsnno`, `element`, `min_value`, `max_value`, `mechanicalelement`, `mechanicalminvalue`, `mechanicalmaxvalue`, `remarks`, `status`) VALUES (1, '2026-02-09', 'SOLUTION ANNEALING : 1080 ° C / 3 HRS SOAKED / WATER QUENCHED', 'ASTM A351 CF3M', '73259930', 'C.%,Si.%,Mn.%,S.%,P.%,Cr.%,Ni.%,Mo.%,,,,,,,', '-,-,-,-,-,17.000,9.000,2.000,,,,,,,', '0.030,1.500,1.500,0.040,0.040,21.000,13.000,3.000,,,,,,,', 'Yield Strength,Tensile Strength,% Elongation,% Reduction of Area,Hardness,Bend Test,Impact Test in Joules', '205,485,30,-,-,,', '-,,,-,200,,', '<p><span style=\"font-size: 12px;\">﻿Separate test bar poured and the same bar tested for chemical and mechanical properties</span></p><p><span style=\"font-size: 12px;\"><br></span><br></p>', 1);
INSERT INTO `grade` (`id`, `date`, `heat_treatment`, `grade`, `hsnno`, `element`, `min_value`, `max_value`, `mechanicalelement`, `mechanicalminvalue`, `mechanicalmaxvalue`, `remarks`, `status`) VALUES (2, '2026-02-09', 'NORMALAZING : Heated  to  920°C soak for  3 Hrs and  then  air cooled.', 'ASTM A216 WCB', '73259999', 'C,Si,Mn,S,P,Cr,Ni,Mo,Cu,V,,,,,', ',,,,,,,,,,,,,,', '0.300,0.600,1.000,0.035,0.035,0.500,0.500,0.200,0.300,0.030,,,,,', 'Yield Strength,Tensile Strength,% Elongation,% Reduction of Area,Hardness,Bend Test,Impact Test in Joules', '250,485,22,35,,,', '-,-,-,-,235,,', '<p><span style=\"font-size: 12px;\">﻿Separate test bar poured and the same bar tested for chemical and mechanical properties</span></p><p><span style=\"font-size: 12px;\">Tensile Testing conducted on round specimen at room temperature</span><br>Visual inspection carried out at as per MSS SP-55, found satisfied<br></p>', 1);
INSERT INTO `grade` (`id`, `date`, `heat_treatment`, `grade`, `hsnno`, `element`, `min_value`, `max_value`, `mechanicalelement`, `mechanicalminvalue`, `mechanicalmaxvalue`, `remarks`, `status`) VALUES (3, '2026-02-09', '', 'ASTM A148 90-60', '73259920', 'C%,Si%,Mn%,P%,S%,Cr%,Ni%,Mo%,Cu,V,Al,TRE,CE,,', '0.180,-,0.950,-,-,,,,,,,,,,', '0.250,0.600,1.280,0.035,0.035,0.500,0.500,0.200,0.300,0.030,0.060,1.000,0.450,,', 'Yield Strength,Tensile Strength,% Elongation,% Reduction of Area,Hardness,Bend Test,Impact Test in Joules', '325,485,22,35,143,,', '-,-,,,237,,', '<p><span style=\"font-size: 12px;\">﻿1. Integral BlockIdentification ,Chemical, Mechnical, Impact Hardness Witnessed By TPI Sunshine Inspection and Certification Services.<br></span></p><p><span style=\"font-size: 12px;\">2. Visual inspection Carried out as per MSS SP 55</span></p><p><span style=\"font-size: 12px;\">3.Chemical &amp; Mechanical Test Carried out at NABL ISO 17025 Certified Laboratory and reports Found satisfied.</span></p><p><span style=\"font-size: 12px;\">5. Magnetic Particle Inspection of casting:100% Satisfactory According to ASME B16.34 Appendix II</span></p><p><span style=\"font-size: 12px;\">6.Ultrasonic Inspection of casting all accessible area found Satisfactory According to ASME B16.34 Appendix IV</span></p><p><span style=\"font-size: 12px;\">7.Casting meets customer requirement DMS -CAST-002 REV.0</span></p><p><span style=\"font-size: 12px;\">8.Visual inspection carried out as per ANSI/MSS SP 55 and meeting to Type II a to XII a</span><br>9.Radio active contamination not found in the castings<br></p>', 1);
INSERT INTO `grade` (`id`, `date`, `heat_treatment`, `grade`, `hsnno`, `element`, `min_value`, `max_value`, `mechanicalelement`, `mechanicalminvalue`, `mechanicalmaxvalue`, `remarks`, `status`) VALUES (4, '2026-02-09', 'Not Applicable', 'BS310 0 309C30', '73259930', 'C%,Si%,Mn%,S%,P%,Cr%,Ni%,Mo%,,,,,,,', '-,-,-,-,-,22.000,10.000,-,,,,,,,', '0.500,2.500,2.000,0.050,0.050,27.000,14.000,1.500,,,,,,,', 'Yield Strength,Tensile Strength,% Elongation,% Reduction of Area,Hardness,Bend Test,Impact Test in Joules', '-,-,-,-,-,-,', '-,-,-,-,-,-,', '<p><span style=\"font-size: 12px;\">﻿Visual inspection carried out at as per MSS SP-55, found satisfied</span></p><p><span style=\"font-size: 12px;\">Radio active contamination not found in the castings</span><br><br></p>', 1);
INSERT INTO `grade` (`id`, `date`, `heat_treatment`, `grade`, `hsnno`, `element`, `min_value`, `max_value`, `mechanicalelement`, `mechanicalminvalue`, `mechanicalmaxvalue`, `remarks`, `status`) VALUES (5, '2026-02-10', 'No', 'ASTM A297 Gr.HE', '73259930', ',,,,,,,,,,,,,,', ',,,,,,,,,,,,,,', ',,,,,,,,,,,,,,', 'Yield Strength,Tensile Strength,% Elongation,% Reduction of Area,Hardness,Bend Test,Impact Test in Joules', ',,,,,,', ',,,,,,', '<p><span style=\"font-size: 12px;\">﻿</span><br></p>', 1);
INSERT INTO `grade` (`id`, `date`, `heat_treatment`, `grade`, `hsnno`, `element`, `min_value`, `max_value`, `mechanicalelement`, `mechanicalminvalue`, `mechanicalmaxvalue`, `remarks`, `status`) VALUES (6, '2026-02-10', '', 'Pattern', '84803000', ',,,,,,,,,,,,,,', ',,,,,,,,,,,,,,', ',,,,,,,,,,,,,,', 'Yield Strength,Tensile Strength,% Elongation,% Reduction of Area,Hardness,Bend Test,Impact Test in Joules', ',,,,,,', ',,,,,,', '<p><span style=\"font-size: 12px;\">﻿</span><br></p>', 1);
INSERT INTO `grade` (`id`, `date`, `heat_treatment`, `grade`, `hsnno`, `element`, `min_value`, `max_value`, `mechanicalelement`, `mechanicalminvalue`, `mechanicalmaxvalue`, `remarks`, `status`) VALUES (7, '2026-02-13', '-', 'INSPECTION', '998898', ',,,,,,,,,,,,,,', ',,,,,,,,,,,,,,', ',,,,,,,,,,,,,,', 'Yield Strength,Tensile Strength,% Elongation,% Reduction of Area,Hardness,Bend Test,Impact Test in Joules', ',,,,,,', ',,,,,,', '<p><span style=\"font-size: 12px;\">﻿</span><br></p>', 1);
INSERT INTO `grade` (`id`, `date`, `heat_treatment`, `grade`, `hsnno`, `element`, `min_value`, `max_value`, `mechanicalelement`, `mechanicalminvalue`, `mechanicalmaxvalue`, `remarks`, `status`) VALUES (8, '2026-03-04', '-', 'EN 1.4409', '73259930', ',,,,,,,,,,,,,,', ',,,,,,,,,,,,,,', ',,,,,,,,,,,,,,', 'Yield Strength,Tensile Strength,% Elongation,% Reduction of Area,Hardness,Bend Test,Impact Test in Joules', ',,,,,,', ',,,,,,', '<p><span style=\"font-size: 12px;\">﻿</span><br></p>', 1);


#
# TABLE STRUCTURE FOR: headers
#

DROP TABLE IF EXISTS `headers`;

CREATE TABLE `headers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `status` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `headers` (`id`, `date`, `status`, `name`) VALUES (1, '2025-06-23', 1, 'Salary ');


#
# TABLE STRUCTURE FOR: hsnmaster
#

DROP TABLE IF EXISTS `hsnmaster`;

CREATE TABLE `hsnmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `party` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `hsnmaster` (`id`, `date`, `hsnno`, `party`, `status`) VALUES (2, '2025-08-11', '145311090', NULL, 1);


#
# TABLE STRUCTURE FOR: inspection_report
#

DROP TABLE IF EXISTS `inspection_report`;

CREATE TABLE `inspection_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `insno` varchar(100) NOT NULL,
  `inspection_date` varchar(100) NOT NULL,
  `customername` varchar(100) NOT NULL,
  `customerid` varchar(100) NOT NULL,
  `itemname` varchar(100) NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `dimension_in` varchar(100) NOT NULL,
  `heatno1` varchar(100) NOT NULL,
  `heatno2` varchar(100) NOT NULL,
  `heatno3` varchar(100) NOT NULL,
  `heatno4` varchar(100) NOT NULL,
  `sno` longtext NOT NULL,
  `view` longtext NOT NULL,
  `length` longtext NOT NULL,
  `inspection1` longtext NOT NULL,
  `inspection2` longtext NOT NULL,
  `inspection3` longtext NOT NULL,
  `inspection4` longtext NOT NULL,
  `remark` longtext NOT NULL,
  `ndt` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `result` varchar(255) NOT NULL,
  `ndt_remarks` text NOT NULL,
  `overall_remarks` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `inspection_report` (`id`, `date`, `insno`, `inspection_date`, `customername`, `customerid`, `itemname`, `drawingno`, `product_code`, `grade`, `dimension_in`, `heatno1`, `heatno2`, `heatno3`, `heatno4`, `sno`, `view`, `length`, `inspection1`, `inspection2`, `inspection3`, `inspection4`, `remark`, `ndt`, `qty`, `result`, `ndt_remarks`, `overall_remarks`, `status`, `created_at`) VALUES (1, '2026-02-13', 'CK/CIR/001', '05-05-2025', 'STAAN BIO MED PVT LTD', '9', 'EH Outer Box', 'ST-MSC-017', 'SBM08', '2', 'mm', 'P0464', 'P0471', 'P0482', 'P0497', '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40', 'TOTAL LENGTH,DEPTH,DISTANCE,WIDTH,WIDTH,DISTANCE,INNER DIS,INNER DIS,WIDTH,INNER DIS,LENGTH,LENGTH,DISTANCE,WIDTH,DISTANCE,INNER DIS,DISTANCE,WIDTH,DISTANCE,OUTER DIS,WIDTH,WIDTH,INNER DIS,DISTANCE,HEIGHT,INNER DIS,HEIGHT,HEIGHT,DISTANCE,DISTANCE,INNER DIS,HEIGHT,HEIGHT,HEIGHT,INNER DIS,LENGTH,LENGTH,HEIGHT,DISTANCE,DISTANCE', '531 ± 2,206 ± 2,30 ± 2,17 ± 2,50 ± 2,65 ± 2,51 ± 2,96 ± 2,17 ± 2,50 ± 2,527 ± 2,541 ± 2,36 ± 2,60 ± 2,37 ± 2,60 ± 2,58 ± 2,29,75 ± 2,17 ± 2,17 ± 2,581 ± 2,52 ± 2,60 ± 2,194 ± 2,36 ± 2,41 ± 2,66 ± 2,60 ± 2,50 ± 2,32 ± 2,40 ± 2,75 ± 2,52 ± 2,30 ± 2,40 ± 2,50 ± 2,51 ± 2,65 ± 2,130 ± 2', '529/530,206/207,30,18/19,48/49,66/67,52,95/96,18/19,54,526/527,542,36/37,60/61,40/41,62,56,29,74/75,18/19,18/19,581/581.5,52/54,59/60,193,36/37,43,64,62,54,30/31,39,74/75,52/54,27,38,48/49,52,67.5/68,135/136', '528/529,206/206,30.5,18.5/19,48/48,66/67,52,95/96,18/19,53,526/527,543,36/37,60/61,40/41,61/62,56,29,74/75,18/19,18/19,581.5/581,52/54,59/60,193,36/37,43.5,64,63,53,30/31,39,74/75,52/54,27,37.5,48/49,53,67.5/68,135/136', '528/529,206/206,30,18.5/19,48/48,66/67,52,95/96,18.5/19,54,526/527,542,36/37,60/61,40/41,61/62,56,29,74/75,18/19,18/19,581/581.5,52/54,58/59,193,36/37,43.5,64,62,54,30/31,39,74/75,52/54,27,38,48/49,53,67.5/68,135/136', '529/530,205/206,30.5,18/19,48/49,66/67,52,94.5/95,18.5/19,54,526/527,543,36/37,60/61,40/41,62,55,29,74/75,18/19,18/19,581.5/581,52/54,59/60,193,36/37,43,64,63,53,30/31,39,74/75,52/54,27,37.5,48/49,52,67.5/68,135/136', 'OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK', 'DP ,MP,RT,UT,VISUAL (As Per Mss SP-55),DIM.INSPECTION,DESPATCH QTY,OTHER REQUIRMENT', ',,,,40,4,40,-', ',,,,40,4,40,-', ',,,,,,,', '<p><span style=\"font-size: 12px;\">﻿</span><br></p>', 1, '2026-02-13 12:20:36');
INSERT INTO `inspection_report` (`id`, `date`, `insno`, `inspection_date`, `customername`, `customerid`, `itemname`, `drawingno`, `product_code`, `grade`, `dimension_in`, `heatno1`, `heatno2`, `heatno3`, `heatno4`, `sno`, `view`, `length`, `inspection1`, `inspection2`, `inspection3`, `inspection4`, `remark`, `ndt`, `qty`, `result`, `ndt_remarks`, `overall_remarks`, `status`, `created_at`) VALUES (2, '2026-03-03', 'CK/CIR/002', '20-06-2025', 'STAAN BIO MED PVT LTD', '9', 'LH Inner Box', 'ST-MSC-014-R1', 'SBM05', '2', 'mm', 'P0586', 'P0590', 'P0598', 'P0604', '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29', 'TOTAL LENGTH,LENGTH,WIDTH,HEIGHT,WIDTH,INNER WIDTH,DEPTH,DEPTH,WIDTH,WIDTH,HEIGHT,WIDTH,WIDTH,WIDTH,WIDTH,HEIGHT,WIDTH,INNER WIDTH,INNER WIDTH,INNER WIDTH,WIDTH,WIDTH,HEIGHT,WIDTH,WIDTH,WIDTH,WIDTH,INNER WIDTH,WIDTH', '502 ± 2,405 ± 2,20 ± 2,28 ± 2,100 ± 2,64 ± 0/1,18 ± 2,33 ± 2,18 ± 2,43 ± 2,71 ± 2,71 ± 0/1,28 ± 2,120 ± 2,28 ± 2,152 ± 2,176 ± 2,64 ± 1,18 ± 2,18 ± 2,26 ± 2,26 ± 2,97 ± 2,152 ± 2,41 ± 2,9 ± 2,45 ± 2,37 ± 2,73 ± 2', '505/506,408/409,19/20,28/28.5,102/103,63/64,18.5/19,33/34,18.5/19,42/43,71/72,70/71,28/28.5,123/124,28/28.5,151/152,180/179,63.5/63,18.5/19,18.5/19,25.5/26,25.5/26,98/99,151/152,40.5,10.5,44,38,71', '505/504,408/409,20/20,28/28.5,103/103,64/64,19/20,33.5/34,19/20,43/43,71/72,70/70,28/29,123/124,28/29,151/152,180/180,63.5/64,19/19,19/19,26/26,26/25.5,97/98.5,151/152,41,11,44,38,71.5', '505/504,408/409,19/20,28/29,102/103,63/64,19/20,33/33,19/20,43/43,71/72,71/71,28/28,124/124,28/28,151/152,180/179.5,63/63.5,19/19,19/19,25/26,25/26,97/98,151/152,41,11,43.5,39,71.5', '505/504,408/409,19/20,28/28,103/102,63/64,18.5/20,33/33,18.5/20,44/43,71/71,70/71,28/28,123/124,28/28,152/152,180/179.5,63.5/64,19/19.5,19/18.5,25/26,25/26,99/98,152/152,42,10.5,45,38,71', 'ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok,ok', 'DP ,MP,RT,UT,VISUAL (As Per Mss SP-55),DIM.INSPECTION,DESPATCH QTY,OTHER REQUIRMENT', ',,,,40,4,40,', ',,,,OK,OK,OK,', ',,,,,,,', '<p><span style=\"font-size: 12px;\">﻿</span><br></p>', 1, '2026-03-03 11:53:34');
INSERT INTO `inspection_report` (`id`, `date`, `insno`, `inspection_date`, `customername`, `customerid`, `itemname`, `drawingno`, `product_code`, `grade`, `dimension_in`, `heatno1`, `heatno2`, `heatno3`, `heatno4`, `sno`, `view`, `length`, `inspection1`, `inspection2`, `inspection3`, `inspection4`, `remark`, `ndt`, `qty`, `result`, `ndt_remarks`, `overall_remarks`, `status`, `created_at`) VALUES (3, '2026-03-03', 'CK/CIR/003', '20-06-2025', 'STAAN BIO MED PVT LTD', '9', '12FN Top Plate', 'STMSC022 R1', 'SBM10', '2', 'mm', 'P0580', 'P0584', 'P0589', 'P0608', '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46', 'LENGTH,LENGTH,WIDTH,LENGTH,HEIGHT,INNER WIDTH,DEGREE,DEPTH,INNER WIDTH,WIDTH,HEIGHT,HEIGHT,HEIGHT,INNER WIDTH,INNER WIDTH,WIDTH,WIDTH,DIM,DIM,DIM,DIM,DIM,DIM,INNER WIDTH,WIDTH,DIM,DIM,DIM,HEIGHT,DIM,DIM,DIM,HEIGHT,HEIGHT,INNER WIDTH,INNER WIDTH,WIDTH,HEIGHT,HEIGHT,HEIGHT,HEIGHT,HEIGHT,WIDTH,WIDTH,WIDTH,WIDTH', '364,98,331,364,22.5,30,45°,48,126.5,51.5,271,24,11,97,119.5,331,62,1.5°,1.5°,5°,2.5°,5°,1.5°,54.5,98,1.5°,1.5°,1°,32,5°,5°,1.5°,20,35,97,119.5,331,25,42,220,45,32,57,50,70,20', '367,100,331,367,22/21,29/30,45°,48/49,127/128,51.5/52,270,22/22.5,7.5/8,98,121,333,63,1.5°,1.5°,5°,2.5°,5°,1.5°,51.5/52,100,1.5°,1.5°,1°,33/34,5°,5°,1.5°,20,36,98,121,333,22.5,42,227,41,38,56,53,70,23', '367,100.5,333,367,22/22,29/30,45°,49/49,127/128,52/52,271,22/22,7.5/8,98.5,121,333,63,1.5°,1.5°,5°,2.5°,5°,1.5°,52/52,100.5,1.5°,1.5°,1°,33/33,5°,5°,1.5°,20.5,36.5,98.5,121,333,23,41.5,226.5,40.5,37,56.5,52,69.5,22.5', '366,100,334,366,21/22,30/30,45°,48/49,127/127,52/52,271,22/22.5,8.5/8,97,121,334,62.5,1.5°,1.5°,5°,2.5°,5°,1.5°,53/53,100,1.5°,1.5°,1°,33/33,5°,5°,1.5°,20,36,97,121,334,22.5,42,227,41,38,56,53,70,23', '367,100,333,367,22/22,30/30,45°,48/49,127/128,52/52,271,22/22.5,8.5/9,98,121.5,333,63,1.5°,1.5°,5°,2.5°,5°,1.5°,52/53,100,1.5°,1.5°,1°,33/34,5°,5°,1.5°,20,36,98,121.5,333,23,42.5,227,41,38,56,53,70,22.5', 'OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,EXCESS,EXCESS,EXCESS,OK,EXCESS,OK,OK', 'DP ,MP,RT,UT,VISUAL (As Per Mss SP-55),DIM.INSPECTION,DESPATCH QTY,OTHER REQUIRMENT', ',,,,50,4,50,', ',,,,OK,OK,OK,', ',,,,,,,', '<p><span style=\"font-size: 12px;\">﻿</span><br></p>', 1, '2026-03-03 16:11:45');
INSERT INTO `inspection_report` (`id`, `date`, `insno`, `inspection_date`, `customername`, `customerid`, `itemname`, `drawingno`, `product_code`, `grade`, `dimension_in`, `heatno1`, `heatno2`, `heatno3`, `heatno4`, `sno`, `view`, `length`, `inspection1`, `inspection2`, `inspection3`, `inspection4`, `remark`, `ndt`, `qty`, `result`, `ndt_remarks`, `overall_remarks`, `status`, `created_at`) VALUES (4, '2026-03-03', 'CK/CIR/004', '20-06-2025', 'STAAN BIO MED PVT LTD', '9', 'LH Outer Box', 'ST-MSC-016', 'SBM03', '2', 'mm', 'P0579', 'P0630', 'P0637', 'P0694', '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33', 'TOTAL LENGTH,LENGTH,WIDTH,WIDTH,WIDTH,DEPTH,DEPTH,DEPTH,LENGTH,LENGTH,WIDTH,LENGTH,INNER WIDTH,INNER LENGTH,LENGTH,INNER HEIGHT,INNER HEIGHT,HEIGHT,LENGTH,LENGTH,WIDTH,INNER WIDTH,INNER WIDTH,HEIGHT,HEIGHT,WIDTH,HEIGHT,LENGTH,INNER LENGTH,WIDTH,WIDTH,INNE WIDTH,WIDTH', '461 ± 2,411 ± 2,86 ± 2,55 ± 2,64 ± 2,96 ± 2,130 ± 2,35 ± 2,400 ± 2,431 ± 2,43 ± 2,25 ± 2,62 ± 2,50 ± 2,442 ± 2,34 ± 2,46 ± 2,30 ± 2,25 ± 2,60 ± 2,62 ± 2,53 ± 2,36 ± 2,75 ± 2,40 ± 2,23.5 ± 2,38.5 ± 2,53 ± 2,26 ± 2,39 ± 2,65 ± 2,65 ± 2,130 ± 2', '458/459,412/413,88,56/57,64/64.5,96/97/100,133/134,35,401/402,432/433,45,30,62/64,51/50,442,36,45/46,30/31,30/30.5,60/60,62/70,65/66,36/35.5,75/76,40/41,22/23,40/40.5,55/54,25,40/41,65/66,67,133/134', '459/460,413/412,88,57/58,64/65,96/98/99,132.5/134,36,401/401,432/433,46,29,62/64,50/49,443,35.5,45/46,30/30.5,30/30,60/60..5,62/69,65/65,36/36,75/75,40.5/41,24/24,40.5/41,54/55,26,40/41,65/65,67.5,133/134', '460/460,412/413,87,58/58,64/65,98/98/99,134/134,35,401/402,432/433,46,30,61/64,50/51,442,35.5,45/45,31/30,30/30,60/61,61/68,65/66,36/36,75/75,41/40.5,24/23.5,40/40,54/54.5,26,40/40,65/66,68,134/134', '460/461,413/412,88,58/57,64/64,98/99/100,132/133,36,401/401,432/433,45,29,62/64,50/50,442,36,45/44,31/31,30.5/30,60/60.5,62/69,65/66,35.5/36,75/76,40.5/41,24/24,40/40.5,54/54,26,40/41,65/65,68,133/134', 'OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,IN SIDE OPEN,MAT,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK,OK', 'DP ,MP,RT,UT,VISUAL (As Per Mss SP-55),DIM.INSPECTION,DESPATCH QTY,OTHER REQUIRMENT', ',,,,40,4,40,', ',,,,OK,OK,OK,', ',,,,,,,', '<p><span style=\"font-size: 12px;\">﻿</span><span style=\"font-size: 12px;\">﻿</span><br></p>', 1, '2026-03-03 16:39:11');
INSERT INTO `inspection_report` (`id`, `date`, `insno`, `inspection_date`, `customername`, `customerid`, `itemname`, `drawingno`, `product_code`, `grade`, `dimension_in`, `heatno1`, `heatno2`, `heatno3`, `heatno4`, `sno`, `view`, `length`, `inspection1`, `inspection2`, `inspection3`, `inspection4`, `remark`, `ndt`, `qty`, `result`, `ndt_remarks`, `overall_remarks`, `status`, `created_at`) VALUES (5, '2026-03-03', 'CK/CIR/005', '20-06-2025', 'OM Industries', '15', 'Retainer 2.0', '2.067398', 'OMI 01', '3', 'mm', 'P0690', '', '', '', '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30', 'WIDTH,RADIUS,ANGLE,WIDTH,INNER DIS,ANGLE,LENGTH,RADIUS,ANGLE,RADIUS,INNER DIS,LENGTH,LENGTH,WIDTH,INNER WIDTH,ANGLE,ANGLE,HEIGHT,HEIGHT,LENGTH,HEIGHT,RADIUS,WIDTH,WIDTH,INNER DIS,INNER DIS,WIDTH,INNER DIS,INNER DIS,INNER DIS', '275,R10,25,150,75,25,80,R20,48,R10,70,182,250,410,90,45,60,20,160,216,56,R3,ø139.5-0.2,115,ø11.5,11,80,ø95,75,90', '283/284,R10,25,158,78,25,85,R20,48,R10,69.5/70,185,249/250,412/415,89,45,60,24/23,171/172,235/236,62/63,R3,148/150,m/c,m/c,m/c,no step,71/72,78,71/74', ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,', ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,', ',,,,,,,,,,,,,,,,,,,,,,,,,,,,,', '8M/C OK,OK,OK,8M/C OK,OK,OK,5M/C OK, OK, OK, OK, OK, OK, OK, OK, OK,, OK, OK,10M/C OK,15M/C OK,EXCESS M/C OK, OK,10M/C OK, OK, OK,m/c,m/c,Pulling 4mm &20M/C , OK,20M/C OK', 'DP ,MP,RT,UT,VISUAL (As Per Mss SP-55),DIM.INSPECTION,DESPATCH QTY,OTHER REQUIRMENT', ',,,,12,1,12,', '-,-,-,-,12,1,12,', '-,-,-,-,OK,OK,OK,', '<p><span style=\"font-size: 12px;\">﻿</span><span style=\"font-size: 12px;\">﻿</span><br></p>', 1, '2026-03-03 16:41:38');
INSERT INTO `inspection_report` (`id`, `date`, `insno`, `inspection_date`, `customername`, `customerid`, `itemname`, `drawingno`, `product_code`, `grade`, `dimension_in`, `heatno1`, `heatno2`, `heatno3`, `heatno4`, `sno`, `view`, `length`, `inspection1`, `inspection2`, `inspection3`, `inspection4`, `remark`, `ndt`, `qty`, `result`, `ndt_remarks`, `overall_remarks`, `status`, `created_at`) VALUES (6, '2026-03-03', 'CK/CIR/006', '20-06-2025', 'OM Industries', '15', 'Retainer 3.0', '3.062269', 'OMI 02', '3', 'mm', 'P0674', '', '', '', '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21', 'DISTANCE,INNER DIS,RADIUS,INNER DIS,LENGTH,INNER DIS,LENGTH,DISTANCE,HEIGHT,DISTANCE,DISTANCE,RADIUS,DISTANCE,DIA,WIDTH,DISTANCE,HEIGHT,INNER DIS,RADIUS,OUTER DIS,HEIGHT', '130,5,R5,290,56,48,60,120,180,95,95,R12,60,80,70,60,45,175,R3,99 ± 0.1,60', '136/138,5,5,292/295,55/56,48.5/49,65/66,121.5/122,188/187,95,95,R12,-,66/66.5,70,64,56,190,3,134/136,65', ',,,,,,,,,,,,,,,,,,,,', ',,,,,,,,,,,,,,,,,,,,', ',,,,,,,,,,,,,,,,,,,,', '6M/C OK,OK,OK,OK,OK,OK,5M/C OK,OK,OK,OK,OK,OK,OK,Pulling 3mm&15M/C ,OK,OK,EXCESS M/C OK,OK,OK, excess material,OK', 'DP ,MP,RT,UT,VISUAL (As Per Mss SP-55),DIM.INSPECTION,DESPATCH QTY,OTHER REQUIRMENT', '-,-,-,-,4,1,4,', '-,-,-,-,OK,OK,OK,', ',,,,,,,', '<p><span style=\"font-size: 12px;\">﻿</span><span style=\"font-size: 12px;\">﻿</span><br></p>', 1, '2026-03-03 16:43:03');
INSERT INTO `inspection_report` (`id`, `date`, `insno`, `inspection_date`, `customername`, `customerid`, `itemname`, `drawingno`, `product_code`, `grade`, `dimension_in`, `heatno1`, `heatno2`, `heatno3`, `heatno4`, `sno`, `view`, `length`, `inspection1`, `inspection2`, `inspection3`, `inspection4`, `remark`, `ndt`, `qty`, `result`, `ndt_remarks`, `overall_remarks`, `status`, `created_at`) VALUES (11, '2026-03-03', 'CK/CIR/007', '26-06-2025', 'SIGMA POWER & ENERGY ENGINEERS', '2', 'Collector Casting 8557', '3-SPG-8557 ', 'SP03', '4', 'mm', '', '', '', '', '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25', 'TOTAL LENGTH,DISTANCE,DISTANCE,DISTANCE,WIDTH,DISTANCE,DEPTH,WIDTH,DEPTH,LENGTH,LENGTH,ANGLE,DISTANCE,DISTANCE BOSS,BOSS DIA,HEIGHT,RADIUS,INNER DISTANCE,WIDTH,CENTER TO,DISTANCE,DISTANCE,THICK,THICK,RADIUS', '500 ± 3,125 ± 2,250 ± 2,125,258,210,20,40,20,80,210,45°,130,10°,ø25,10,R427,128,3,R116,14,258,5,6,R6', ',,,,,,,,,,,,,,,,,,,,,,,,', ',,,,,,,,,,,,,,,,,,,,,,,,', ',,,,,,,,,,,,,,,,,,,,,,,,', ',,,,,,,,,,,,,,,,,,,,,,,,', ',,,,,,,,,,,,,,,,,,,,,,,,', 'DP ,MP,RT,UT,VISUAL (As Per Mss SP-55),DIM.INSPECTION,DESPATCH QTY,OTHER REQUIRMENT', ',,,,4,4,4,', ',,,,OK,OK,OK,', ',,,,,,,', '<p><span style=\"font-size: 12px;\">﻿</span><br></p>', 1, '2026-03-03 17:50:08');


#
# TABLE STRUCTURE FOR: inspectionmaster
#

DROP TABLE IF EXISTS `inspectionmaster`;

CREATE TABLE `inspectionmaster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `itemname` varchar(100) NOT NULL,
  `itemid` int(11) DEFAULT NULL,
  `sno` text NOT NULL,
  `view` text NOT NULL,
  `length` text NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `inspectionmaster` (`id`, `date`, `product_code`, `itemname`, `itemid`, `sno`, `view`, `length`, `status`, `created_at`) VALUES (1, '2026-02-11', 'SBM05', 'LH Inner Box', 6, '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50', 'TOTAL LENGTH,LENGTH,WIDTH,HEIGHT,WIDTH,INNER WIDTH,DEPTH,DEPTH,WIDTH,WIDTH,HEIGHT,WIDTH,WIDTH,WIDTH,WIDTH,HEIGHT,WIDTH,INNER WIDTH,INNER WIDTH,INNER WIDTH,WIDTH,WIDTH,HEIGHT,WIDTH,WIDTH,WIDTH,WIDTH,INNER WIDTH,WIDTH,,,,,,,,,,,,,,,,,,,,,', '502 ± 2,405 ± 2,20 ± 2,28 ± 2,100 ± 2,64 ± 0/1,18 ± 2,33 ± 2,18 ± 2,43 ± 2,71 ± 2,71 ± 0/1,28 ± 2,120 ± 2,28 ± 2,152 ± 2,176 ± 2,64 ± 1,18 ± 2,18 ± 2,26 ± 2,26 ± 2,97 ± 2,152 ± 2,41 ± 2,9 ± 2,45 ± 2,37 ± 2,73 ± 2,,,,,,,,,,,,,,,,,,,,,', 1, '2026-02-11 19:08:07');
INSERT INTO `inspectionmaster` (`id`, `date`, `product_code`, `itemname`, `itemid`, `sno`, `view`, `length`, `status`, `created_at`) VALUES (2, '2026-02-11', 'SBM10', '12FN Top Plate', 7, '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50', 'LENGTH,LENGTH,WIDTH,LENGTH,HEIGHT,INNER WIDTH,DEGREE,DEPTH,INNER WIDTH,WIDTH,HEIGHT,HEIGHT,HEIGHT,INNER WIDTH,INNER WIDTH,WIDTH,WIDTH,DIM,DIM,DIM,DIM,DIM,DIM,INNER WIDTH,WIDTH,DIM,DIM,DIM,HEIGHT,DIM,DIM,DIM,HEIGHT,HEIGHT,INNER WIDTH,INNER WIDTH,WIDTH,HEIGHT,HEIGHT,HEIGHT,HEIGHT,HEIGHT,WIDTH,WIDTH,WIDTH,WIDTH,,,,', '364,98,331,364,22.5,30,45°,48,126.5,51.5,271,24,11,97,119.5,331,62,1.5°,1.5°,5°,2.5°,5°,1.5°,54.5,98,1.5°,1.5°,1°,32,5°,5°,1.5°,20,35,97,119.5,331,25,42,220,45,32,57,50,70,20,,,,', 1, '2026-02-11 19:15:50');
INSERT INTO `inspectionmaster` (`id`, `date`, `product_code`, `itemname`, `itemid`, `sno`, `view`, `length`, `status`, `created_at`) VALUES (3, '2026-02-11', 'SP03', 'Collector Casting 8557', 13, '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50', 'TOTAL LENGTH,DISTANCE,DISTANCE,DISTANCE,WIDTH,DISTANCE,DEPTH,WIDTH,DEPTH,LENGTH,LENGTH,ANGLE,DISTANCE,DISTANCE BOSS,BOSS DIA,HEIGHT,RADIUS,INNER DISTANCE,WIDTH,CENTER TO ,DISTANCE,DISTANCE,THICK,THICK,RADIUS,,,,,,,,,,,,,,,,,,,,,,,,,', '500 ± 3,125 ± 2,250 ± 2,125,258,210,20,40,20,80,210,45°,130,10°,ø25,10,R427,128,3,R116,14,258,5,6,R6,,,,,,,,,,,,,,,,,,,,,,,,,', 1, '2026-02-11 19:25:33');
INSERT INTO `inspectionmaster` (`id`, `date`, `product_code`, `itemname`, `itemid`, `sno`, `view`, `length`, `status`, `created_at`) VALUES (4, '2026-02-11', 'SP02', 'Collector Casting', 12, '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50', 'TOTAL LENGTH,DISTANCE,DISTANCE,DISTANCE,WIDTH,DISTANCE,DEPTH,WIDTH,DEPTH,LENGTH,LENGTH,RADIUS,WALL THICK,DISTANCE BOSS,BOSS DIA,HEIGHT,ANGLE,ANGLE,WIDTH,CENTER TO,RADIUS,DISTANCE,THICK,THICK,RADIUS,,,,,,,,,,,,,,,,,,,,,,,,,', '500 ± 3,125 ± 2,250 ± 2,125 ± 2,231 + 0.0 - 1.0,210,20,40,20,80,210,R398,14 +1.5-0.0,10,Ø25,116,10°,45°,3,115,R102,231+0.0-1.0,5+0.0-1.0,6,R6,,,,,,,,,,,,,,,,,,,,,,,,,', 1, '2026-02-11 19:33:47');
INSERT INTO `inspectionmaster` (`id`, `date`, `product_code`, `itemname`, `itemid`, `sno`, `view`, `length`, `status`, `created_at`) VALUES (5, '2026-02-11', 'SBM15', 'EH Inner Box', 10, '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50', 'LENGTH,WIDTH,DISTANCE,WIDTH,WIDTH,DISTANCE,DISTANCE,DISTANCE,RADIUS,INNER DIS,LENGTH,DISTANCE,OUTER DIS,LENGTH,INNER DIS,RADIUS,RADIUS,DISTANCE,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,', '244 ± 2,133+2-0,112+2-0,26+0.2-0,45° ± 0°,108+2-0,135° ± 0°,69+2-0,R13,96+2-0,64 ± 2,204+2-0,554+2-0,23+2-0,69,R5,R13,44+1-0,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,', 1, '2026-02-11 19:40:19');
INSERT INTO `inspectionmaster` (`id`, `date`, `product_code`, `itemname`, `itemid`, `sno`, `view`, `length`, `status`, `created_at`) VALUES (6, '2026-02-11', 'SBM08', 'EH Outer Box', 4, '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50', 'TOTAL LENGTH,DEPTH,DISTANCE,WIDTH,WIDTH,DISTANCE,INNER DIS,INNER DIS,WIDTH,INNER DIS,LENGTH,LENGTH,DISTANCE,WIDTH,DISTANCE,INNER DIS,DISTANCE,WIDTH,DISTANCE,OUTER DIS,WIDTH,WIDTH,INNER DIS,DISTANCE,HEIGHT,INNER DIS,HEIGHT,HEIGHT,DISTANCE,DISTANCE,INNER DIS,HEIGHT,HEIGHT,HEIGHT,INNER DIS,LENGTH,LENGTH,HEIGHT,DISTANCE,DISTANCE,,,,,,,,,,', '531 ± 2,206 ± 2,30 ± 2,17 ± 2,50 ± 2,65 ± 2,51 ± 2,96 ± 2,17 ± 2,50 ± 2,527 ± 2,541 ± 2,36 ± 2,60 ± 2,37 ± 2,60 ± 2,58 ± 2,29,75 ± 2,17 ± 2,17 ± 2,581 ± 2,52 ± 2,60 ± 2,194 ± 2,36 ± 2,41 ± 2,66 ± 2,60 ± 2,50 ± 2,32 ± 2,40 ± 2,75 ± 2,52 ± 2,30 ± 2,40 ± 2,50 ± 2,51 ± 2,65 ± 2,130 ± 2,,,,,,,,,,', 1, '2026-02-11 19:47:15');
INSERT INTO `inspectionmaster` (`id`, `date`, `product_code`, `itemname`, `itemid`, `sno`, `view`, `length`, `status`, `created_at`) VALUES (7, '2026-02-17', 'SP04', 'Flame Holder Segment', 14, '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50', 'TOTAL LENGTH,LENGTH,WIDTH,RADIUS,WIDTH,WIDTH,RADIUS,RADIUS,RADIUS,THICKNESS,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,', '340,302,50,R3,50,98,453.5,403.5,473,20,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,', 1, '2026-02-11 19:49:10');
INSERT INTO `inspectionmaster` (`id`, `date`, `product_code`, `itemname`, `itemid`, `sno`, `view`, `length`, `status`, `created_at`) VALUES (8, '2026-02-16', 'SBM03', 'LH Outer Box', 5, '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50', 'TOTAL LENGTH,LENGTH,WIDTH,WIDTH,WIDTH,DEPTH,DEPTH,DEPTH,LENGTH,LENGTH,WIDTH,LENGTH,INNER WIDTH,INNER LENGTH,LENGTH,INNER HEIGHT,INNER HEIGHT,HEIGHT,LENGTH,LENGTH,WIDTH,INNER WIDTH,INNER WIDTH,HEIGHT,HEIGHT,WIDTH,HEIGHT,LENGTH,INNER LENGTH,WIDTH,WIDTH,INNE WIDTH,WIDTH,,,,,,,,,,,,,,,,,', '461 ± 2,411 ± 2,86 ± 2,55 ± 2,64 ± 2,96 ± 2,130 ± 2,35 ± 2,400 ± 2,431 ± 2,43 ± 2,25 ± 2,62 ± 2,50 ± 2,442 ± 2,34 ± 2,46 ± 2,30 ± 2,25 ± 2,60 ± 2,62 ± 2,53 ± 2,36 ± 2,75 ± 2,40 ± 2,23.5 ± 2,38.5 ± 2,53 ± 2,26 ± 2,39 ± 2,65 ± 2,65 ± 2,130 ± 2,,,,,,,,,,,,,,,,,', 1, '2026-02-16 17:41:26');
INSERT INTO `inspectionmaster` (`id`, `date`, `product_code`, `itemname`, `itemid`, `sno`, `view`, `length`, `status`, `created_at`) VALUES (10, '2026-02-18', 'SBM09', 'Moving Block', 11, '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50', 'TOTAL LENGTH,LENGTH,LENGTH,LENGTH,LENGTH,LENGTH,WIDTH,WIDTH,LENGTH,LENGTH,HEIGHT,WIDTH,ANGLE,ANGLE,HEIGHT,LENGTH,LENGTH,LENGTH,HEIGHT,LENGTH,ANGLE,ANGLE,ANGLE,HEIGHT,HEIGHT,HEIGHT,INNER LENGTH,HEIGHT,LENGTH,LENGTH,,,,,,,,,,,,,,,,,,,,', '555 + 2,383 + 2,285 + 2,70+ 2,230 ± 2,40 ± 2,30 ± 2,53 ± 2,40 ± 2,112 ± 2,44 ± 2,30 ± 2,124°,124°,102 ± 2,50.5,53,170 ± 2,53,50.5,54°,56°,124°,76 + 2,56 + 2,132 + 3,127  ± 2,35.5  ± 2,277.5,277.5,,,,,,,,,,,,,,,,,,,,', 1, '2026-02-18 12:50:43');
INSERT INTO `inspectionmaster` (`id`, `date`, `product_code`, `itemname`, `itemid`, `sno`, `view`, `length`, `status`, `created_at`) VALUES (11, '2026-02-18', 'SBM04', 'NH Inner Box', 9, '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50', 'TOTAL LENGTH,LENGTH,INNER WIDTH,WIDTH, INNER WIDTH,DEPTH,WIDTH, INNER WIDTH,DEPTH,WIDTH,HEIGHT,INNER HEIGHT,INNER WIDTH,WIDTH,WIDTH,WIDTH,HEIGHT,WIDTH,INNER WIDTH,INNER WIDTH,WIDTH,WIDTH,HEIGHT,WIDTH,WIDTH,WIDTH,WIDTH,INNER WIDTH,WIDTH,,,,,,,,,,,,,,,,,,,,,', '552± 2,455 ± 2,18 ± 2,33 ± 2,20 ± 2,28 ± 2,100 + 2,64 -1,18 ± 2,43 ± 2,82,71 ± 2,71+1,28 ± 2,120 ± 2,28 ± 2,152 ± 2,176 ± 2,18 ± 2,18 ± 2,26 ± 2,26 ± 2,97 ± 2,152 ± 2,41 ± 2,9 ± 2,45 ± 2,37 ± 2,73 ± 2,,,,,,,,,,,,,,,,,,,,,', 1, '2026-02-18 12:53:12');
INSERT INTO `inspectionmaster` (`id`, `date`, `product_code`, `itemname`, `itemid`, `sno`, `view`, `length`, `status`, `created_at`) VALUES (12, '2026-02-18', 'SBM02', 'NH Outer Box', 8, '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50', 'TOTAL LENGTH,WIDTH,INNER WIDTH,WIDTH,WIDTH,WIDTH,DEPTH,HEIGHT,HEIGHT,HEIGHT,INNER HEIGHT,HEIGHT,HEIGHT,INNER LENGTH,OUTER LENGTH,OUTER WIDTH,WIDTH,INNER WIDTH,OUTER LENGTH,HEIGHT,HEIGHT,INNER HEIGHT,INNER HEIGHT,HEIGHT,INNER WIDTH,LENGTH,INNER LENGTH,HEIGHT,HEIGHT,WIDTH,HEIGHT,HEIGHT,INNER HEIGHT,WIDTH,WIDTH,LENGHT ,LENGTH ,,,,,,,,,,,,,', '460± 2,86± 2,54 ± 2,65 ± 2,130 ± 2,96 ± 2,25,51± 2,448± 2,447 ± 2,33 ± 2,45 ± 2,47 ± 2,62 ± 2,65 ± 2,30  ± 2,56 ± 2,25 ± 2,75 ± 2,490 ± 2,505 ± 2,35 ± 2,45 ± 2,62 ± 2,62 ± 2,53  ± 2,36  ± 2,75  ± 2,40  ± 2,23.5  ± 2,38.5  ± 2,53 ± 2,25 ± 2,40 ± 2,65 ± 2,130 ± 2,65,,,,,,,,,,,,,', 1, '2026-02-18 13:17:56');
INSERT INTO `inspectionmaster` (`id`, `date`, `product_code`, `itemname`, `itemid`, `sno`, `view`, `length`, `status`, `created_at`) VALUES (13, '2026-02-18', 'OMI 01', 'Retainer 2.0', 15, '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50', 'WIDTH,RADIUS,ANGLE,WIDTH,INNER DIS,ANGLE,LENGTH,RADIUS,ANGLE,RADIUS,INNER DIS,LENGTH,LENGTH,WIDTH,INNER WIDTH,ANGLE,ANGLE,HEIGHT,HEIGHT,LENGTH,HEIGHT,RADIUS,WIDTH,WIDTH,INNER DIS,INNER DIS,WIDTH,INNER DIS,INNER DIS,INNER DIS,,,,,,,,,,,,,,,,,,,,', '275,R10,25,150,75,25,80,R20,48,R10,70,182,250,410,90,45,60,20,160,216,56,R3,ø139.5-0.2,115,ø11.5,11,80,ø95,75,90,,,,,,,,,,,,,,,,,,,,', 1, '2026-02-18 13:26:07');
INSERT INTO `inspectionmaster` (`id`, `date`, `product_code`, `itemname`, `itemid`, `sno`, `view`, `length`, `status`, `created_at`) VALUES (14, '2026-02-18', 'OMI 02', 'Retainer 3.0', 16, '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50', 'DISTANCE,INNER DIS,RADIUS,INNER DIS,LENGTH,INNER DIS,LENGTH,DISTANCE,HEIGHT,DISTANCE,DISTANCE,RADIUS,DISTANCE,DIA,WIDTH,DISTANCE,HEIGHT,INNER DIS,RADIUS,OUTER DIS,HEIGHT,,,,,,,,,,,,,,,,,,,,,,,,,,,,,', '130,5,R5,290,56,48,60,120,180,95,95,R12,60,80,70,60,45,175,R3,99 ± 0.1,60,,,,,,,,,,,,,,,,,,,,,,,,,,,,,', 1, '2026-02-18 13:31:45');


#
# TABLE STRUCTURE FOR: invoice_details
#

DROP TABLE IF EXISTS `invoice_details`;

CREATE TABLE `invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `pino` varchar(255) DEFAULT NULL,
  `purchaseordernos` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) NOT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerdcnos` varchar(100) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `removalDate` date NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToId` varchar(255) DEFAULT NULL,
  `shipToAddress` longtext DEFAULT NULL,
  `deliveryAddress1` longtext DEFAULT NULL,
  `deliveryAddress2` longtext DEFAULT NULL,
  `mobileNo` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `dcnos` longtext DEFAULT NULL,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext DEFAULT NULL,
  `workorderid` varchar(20) NOT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` longtext DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `weight` varchar(100) NOT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `totalqty` varchar(255) DEFAULT NULL,
  `acno` varchar(255) NOT NULL,
  `acdate` varchar(255) NOT NULL,
  `irn` varchar(255) NOT NULL,
  `signedinvoice` longtext NOT NULL,
  `signedqrcode` longtext NOT NULL,
  `status_ein` longtext NOT NULL,
  `ewayno` varchar(255) NOT NULL,
  `ewaydate` varchar(255) NOT NULL,
  `ewbvalidtill` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `status_cd` varchar(255) NOT NULL,
  `status_desc` varchar(255) NOT NULL,
  `einvoice_status` int(11) NOT NULL,
  `eway_status` int(11) NOT NULL,
  `invoice_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `purchaseorder`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `workorderid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`, `invoice_status`) VALUES (3, '2026-02-13', '2026-02-11', 'CAD2025361REV01', '2025-03-18', 'CK/INV/25-26/-001', '', 'CK/WO/25-26/-002', NULL, 'CK/WO/25-26/-002', '-', 'Tax Invoice', 'Against PO', '', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', NULL, NULL, '', '2026-02-11', '03:59 PM', 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '7', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '', '15', '73259930', 'CA16', '1/2\" CL 600 Body', '3', '', 'heatno : P0213-20', 'NOS', '1', '1250', '20', '3.5', '87500.00', '0', 'amount_wise', '', '87500.00', '9', '7875.00', '9', '7875.00', '18', '', '', '87500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '103250.00', '103250.00', 1, 'CK/INV/25-26/-110226', 'CK/INV/25-26/--2026', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `purchaseorder`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `workorderid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`, `invoice_status`) VALUES (4, '2026-02-13', '2025-04-09', '', '1970-01-01', 'CK/INV/25-26/-002', '', 'CK/WO/25-26/-001', NULL, 'CK/WO/25-26/-001', 'PO3704', 'Tax Invoice', 'Against PO', '', 2, 'SIGMA POWER & ENERGY ENGINEERS', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', NULL, NULL, '', '2026-02-13', '11:53 AM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '', '3', '84803000', 'SP01', 'Coal Nozzle ', '1', '', 'heatno : ', 'NOS', '6', '200000', '1', '1', '200000.00', '0', 'amount_wise', '', '200000.00', '9', '18000.00', '9', '18000.00', '18', '', '', '200000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '236000.00', '236000.00', 1, 'CK/INV/25-26/-002130226', 'CK/INV/25-26/-002-2026', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `purchaseorder`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `workorderid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`, `invoice_status`) VALUES (5, '2026-02-13', '2025-05-07', '', '1970-01-01', 'CK/INV/25-26/-003', '', 'CK/WO/25-26/-004', NULL, 'CK/WO/25-26/-004', 'PO-SC-2526-008', 'Tax Invoice', 'Against PO', '', 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', NULL, NULL, '', '2026-02-13', '12:25 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '', '17', '73259999', 'SBM08', 'EH Outer Box', '4', '', 'heatno : P0464-2 , P0470-2 , P0471-2 , P0472-2 , P0473-2 , P0474-2 , P0475-2 , P0476-2 , P0477-2 , P0478-2 , P0479-2 , P0481-2 , P0482-2 , P0483-2 , P0484-2 , P0485-2 , P0495-2 , P0496-2 , P0497-2 , P0498-2', 'NOS', '2', '167', '40', '34.1', '227788.00', '0', 'amount_wise', '', '227788.00', '9', '20500.92', '9', '20500.92', '18', '', '', '227788.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.16', NULL, '1', '268790.00', '268790.00', 1, 'CK/INV/25-26/-003130226', 'CK/INV/25-26/-003-2026', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `purchaseorder`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `workorderid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`, `invoice_status`) VALUES (6, '2026-02-14', '2025-05-07', '', '1970-01-01', 'CK/INV/25-26/-004', '', 'CK/WO/25-26/-003', NULL, 'CK/WO/25-26/-003', 'CAD2025405 REV 01', 'Tax Invoice', 'Against PO', '', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', NULL, NULL, '', '2026-02-13', '12:42 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '', '16', '73259999', 'CA16', '1/2\" CL 600 Body', '3', '', 'heatno : P0412-4 , P0424-5 , P0425-5 , P0426-2 , P0443-1', 'NOS', '2', '350', '17', '3.5', '20825.00', '0', 'amount_wise', '', '20825.00', '9', '1874.25', '9', '1874.25', '18', '', '', '20825.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.50', NULL, '1', '24574.00', '24574.00', 1, 'CK/INV/25-26/-004130226', 'CK/INV/25-26/-004-2026', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `purchaseorder`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `workorderid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`, `invoice_status`) VALUES (7, '2026-02-25', '2025-06-09', '', '1970-01-01', 'CK/INV/25-26/-005', '', 'CK/WO/25-26/-006||CK/WO/25-26/-017', NULL, 'CK/WO/25-26/-006||CK/WO/25-26/-017||CK/WO/25-26/-017||CK/WO/25-26/-017', 'CAD2025363 REV01||CAD2025363||CAD2025363||CAD2025363', 'Tax Invoice', 'Against PO', '', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', NULL, NULL, '', '2026-02-25', '12:25 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '', '21||48||49||50', '73259999||73259999||84803000', 'CA02||TB1||PR1', '4\" 1500 Body||TEST BAR(300mmX50mmX50mm)||Pattern Rework Cost', '18||23||24', '', 'heatno : 33801-3 , 33817-2||heatno : 33801||heatno : ', 'NOS||NOS||NOS', '2||2||6', '220||220||9500', '5||2||1', '212||6||1', '233200.00||2640.00||9500.00', '0||0||0', 'amount_wise', '||||0', '233200.00||2640.00||9500.00', '9', '22170.60', '9', '22170.60', '18', '', '', '245340.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1||1||1', '290681.20', '290681.20', 1, 'CK/INV/25-26/-005250226', 'CK/INV/25-26/-005-2026', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `purchaseorder`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `workorderid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`, `invoice_status`) VALUES (8, '2026-03-03', '2025-06-21', '', '1970-01-01', 'CK/INV/25-26/-006', '', 'CK/WO/25-26/-005', NULL, 'CK/WO/25-26/-005||CK/WO/25-26/-005', 'PO-SC-2526-020||PO-SC-2526-020', 'Tax Invoice', 'Against PO', '', 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', NULL, NULL, '', '2026-03-03', '12:04 PM', 'STAAN BIO MED PVT LTD', '9', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '', '19||20', '73259999||73259999', 'SBM05||SBM10', 'LH Inner Box||12FN Top Plate', '6||7', '', 'heatno : P0545-2 , P0585-3 , P0586-3 , P0587-3 , P0590-3 , P0596-3 , P0597-3 , P0598-3 , P0599-3 , P0601-1 , P0602-4 , P0603-4 , P0604-4 , P0607-1||heatno : P0546-4 , P0580-4 , P0582-4 , P0583-4 , P0584-4 , P0588-4 , P0589-4 , P0591-3 , P0592-3 , P0595-3 , P0600-3 , P0607-3 , P0608-4 , P0612-3', 'NOS||NOS', '2||2', '167||167', '40||50', '26.1||27.5', '174348.00||229625.00', '0||0', 'amount_wise', '', '174348.00||229625.00', '9', '36357.57', '9', '36357.57', '18', '', '', '403973.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '-0.14', NULL, '1||1', '476688.14', '476688.14', 1, 'CK/INV/25-26/-006030326', 'CK/INV/25-26/-006-2026', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `purchaseorder`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `workorderid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`, `invoice_status`) VALUES (9, '2026-03-03', '2025-06-28', '', '1970-01-01', 'CK/INV/25-26/-007', '', 'CK/WO/25-26/-005', NULL, 'CK/WO/25-26/-005', 'PO-SC-2526-020', 'Tax Invoice', 'Against PO', '', 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', NULL, NULL, '', '2026-03-03', '12:06 PM', 'STAAN BIO MED PVT LTD', '9', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '', '18', '73259999', 'SBM03', 'LH Outer Box', '5', '', 'heatno : P0579-3 , P0635-3 , P0641-3 , P0612-1 , P0636-3 , P0642-2 , P0613-4 , P0637-3 , P0660-2 , P0630-4 , P0638-3 , P0694-3 , P0634-3 , P0640-3', 'NOS', '2', '167', '40', '24.6', '164328.00', '0', 'amount_wise', '', '164328.00', '9', '14789.52', '9', '14789.52', '18', '', '', '164328.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '-0.04 ', NULL, '1', '193907.04', '193907.04', 1, 'CK/INV/25-26/-007030326', 'CK/INV/25-26/-007-2026', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `purchaseorder`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `workorderid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`, `invoice_status`) VALUES (10, '2026-03-03', '2025-06-28', 'PO-SC-2526-020', '2025-04-24', 'CK/INV/25-26/-008', '', '', NULL, '', '', 'Tax Invoice', 'Direct Invoice', '', 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', NULL, NULL, '', '2026-03-03', '12:11 PM', 'STAAN BIO MED PVT LTD', '9', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '', '', '73259999', 'SBM10', '12FN Top Plate', '', '', '', 'NOS', '2', '167', '1', '27', '4509.00', '0', 'amount_wise', '0', '4509.00', '9', '405.81', '9', '405.81', '18', '', '', '4509.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0.38', NULL, '1', '5321.00', '5321.00', 1, 'CK/INV/25-26/-008030326', 'CK/INV/25-26/-008-2026', 1, 1, '1.00', '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `purchaseorder`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `workorderid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`, `invoice_status`) VALUES (11, '2026-03-03', '2025-07-03', '', '1970-01-01', 'CK/INV/25-26/-009', '', 'CK/WO/25-26/-009', NULL, 'CK/WO/25-26/-009||CK/WO/25-26/-009||CK/WO/25-26/-009||CK/WO/25-26/-009', 'OM/PO/05-25-26/01||OM/PO/05-25-26/01||OM/PO/05-25-26/01||OM/PO/05-25-26/01', 'Tax Invoice', 'Against PO', '', 15, 'OM Industries', 'No:230/2, 4Th Cross,, Vanapadi Road,Sipcot, Ranipet, Tamil Nadu', NULL, NULL, '', '2026-03-03', '12:37 PM', 'OM Industries', '15', 'No:230/2, 4Th Cross,, Vanapadi Road,Sipcot, Ranipet, Tamil Nadu', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '', '28||27||29||30', '73259920||73259920||84803000||84803000', 'OMI 02||OMI 01||OMI 01||OMI 02', 'Retainer 3.0||Retainer 2.0||Retainer 2.0  Pattern||Retainer 3.0 Pattern', '16||15||19||20', '', 'heatno : P0674-4||heatno : P0662-2 , P0690-4 , P0693-2 , P0697-4||heatno : ||heatno : ', 'NOS||NOS||NOS||NOS', '3||3||6||6', '185||185||45500||35000', '4||12||1||1', '52||112.5||1||1', '38480.00||249750.00||45500.00||35000.00', '0||0||0||0', 'amount_wise', '', '38480.00||249750.00||45500.00||35000.00', '9', '34085.70', '9', '34085.70', '18', '', '', '368730.00', '10000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '-0.40', NULL, '1||1||1||1', '446901.40', '446901.40', 1, 'CK/INV/25-26/-009030326', 'CK/INV/25-26/-009-2026', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 0);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `purchaseorder`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `workorderid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`, `invoice_status`) VALUES (12, '2026-03-03', '2025-07-10', '', '1970-01-01', 'CK/INV/25-26/-010', '', 'CK/WO/25-26/-010', NULL, 'CK/WO/25-26/-010', 'PO 3742', 'Tax Invoice', 'Against PO', '', 2, 'SIGMA POWER & ENERGY ENGINEERS', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', NULL, NULL, '', '2026-03-03', '04:26 PM', '', '', '', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '', '31', '73259930', 'SP02', 'Collector Casting', '12', '', 'heatno : P0694 - 4', 'NOS', '4', '542', '4', '27.8', '60270.40', '0', 'amount_wise', '', '60270.40', '9', '5424.34', '9', '5424.34', '18', '', '', '60270.40', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '-0.08', NULL, '1', '71119.08', '71119.08', 1, 'CK/INV/25-26/-010030326', 'CK/INV/25-26/-010-2026', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 1);
INSERT INTO `invoice_details` (`id`, `date`, `invoicedate`, `orderno`, `orderdate`, `invoiceno`, `dcno`, `pono`, `pino`, `purchaseordernos`, `purchaseorder`, `bill_type`, `invoicetype`, `customerdcnos`, `customerId`, `customername`, `address`, `deliveryat`, `transportmode`, `vehicleno`, `removalDate`, `time`, `shipTo`, `shipToId`, `shipToAddress`, `deliveryAddress1`, `deliveryAddress2`, `mobileNo`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `dcnos`, `insertid`, `deliveryid`, `workorderid`, `hsnno`, `itemcode`, `itemname`, `itemid`, `heatno`, `item_desc`, `uom`, `grade`, `rate`, `qty`, `weight`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `roundOff`, `othercharges`, `return_status`, `grandtotal`, `balance`, `vou_status`, `invoicenodate`, `invoicenoyear`, `status`, `edit_status`, `totalqty`, `acno`, `acdate`, `irn`, `signedinvoice`, `signedqrcode`, `status_ein`, `ewayno`, `ewaydate`, `ewbvalidtill`, `remarks`, `status_cd`, `status_desc`, `einvoice_status`, `eway_status`, `invoice_status`) VALUES (13, '2026-03-03', '2025-07-10', '', '1970-01-01', 'CK/INV/25-26/-011', '', 'CK/WO/25-26/-012', NULL, 'CK/WO/25-26/-012', 'PO 3755', 'Tax Invoice', 'Against PO', '', 2, 'SIGMA POWER & ENERGY ENGINEERS', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', NULL, NULL, '', '2026-03-03', '04:29 PM', 'SIGMA POWER & ENERGY ENGINEERS', '2', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', NULL, NULL, NULL, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', NULL, '', '40', '73259930', 'SP02', 'Collector Casting', '12', '', 'heatno : P0593-1 , P0594-2 , P0691-3 , P0695-2 , P0696-3 , P0698-3 , P0699-4 , P0704-4 , P0706-3 , P0707-4 , P0713-2 , P0714-4 , P0715-3 , P0717-4 , P0719-3 , P0720-4 , P0721-4 , P0723-4 , P0724-4 , P0728-4 , P0729-3 , P0730-4 , P0731-3 , P0732-4 , P0733-4 , P0734-4 , P0740-3 , P0741-4 , P0742-2', 'NOS', '4', '539', '96', '28', '1448832.00', '0', 'amount_wise', '', '1448832.00', '9', '131249.16', '9', '131249.16', '18', '', '', '1448832.00', '9492', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, '1', '1720822.32', '1720822.32', 1, 'CK/INV/25-26/-011030326', 'CK/INV/25-26/-011-2026', 1, 1, NULL, '', '', '', '', '', '', '', '', '', '', '', '', 0, 0, 1);


#
# TABLE STRUCTURE FOR: invoice_details_backup
#

DROP TABLE IF EXISTS `invoice_details_backup`;

CREATE TABLE `invoice_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext DEFAULT NULL,
  `pono` varchar(255) DEFAULT NULL,
  `pino` varchar(255) DEFAULT NULL,
  `purchaseordernos` varchar(255) DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerdcnos` varchar(100) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `removalDate` date NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToId` varchar(255) DEFAULT NULL,
  `shipToAddress` longtext DEFAULT NULL,
  `deliveryAddress1` longtext DEFAULT NULL,
  `deliveryAddress2` longtext DEFAULT NULL,
  `mobileNo` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `dcnos` longtext DEFAULT NULL,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `heatno` varchar(100) NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `itemcode` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `weight` varchar(100) NOT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `totalqty` varchar(255) DEFAULT NULL,
  `acno` varchar(255) NOT NULL,
  `acdate` varchar(255) NOT NULL,
  `irn` varchar(255) NOT NULL,
  `signedinvoice` longtext NOT NULL,
  `signedqrcode` longtext NOT NULL,
  `status_ein` longtext NOT NULL,
  `ewayno` varchar(255) NOT NULL,
  `ewaydate` varchar(255) NOT NULL,
  `ewbvalidtill` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `status_cd` varchar(255) NOT NULL,
  `status_desc` varchar(255) NOT NULL,
  `einvoice_status` int(11) NOT NULL,
  `eway_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: invoice_party_statement
#

DROP TABLE IF EXISTS `invoice_party_statement`;

CREATE TABLE `invoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `weight` varchar(100) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (9, '-', '-', NULL, '2026-02-11', 'CK/INV/25-26/-001', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '', '', '', '1/2\" CL 600 Body', 'heatno : P0213-20', '', '', '', NULL, NULL, '', '', '1', '2026-02-11', '2026-02-11', '103250.00', '-', '-', '', '', '-', '-', NULL, '14487686.5', '-', '-', '-', '-', '103250.00', '-', '103250.00', NULL, NULL, 'CK/INV/25-26/-001-2026', 'CK/INV/25-26/-001130226', '3');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (5, '-', '-', NULL, '2025-04-09', 'CK/INV/25-26/-002', 2, 'SIGMA POWER & ENERGY ENGINEERS', '', '', '', 'Coal Nozzle ', 'heatno : ', '', '', '', NULL, NULL, '', '', '1', '2025-04-09', '2025-04-09', '236000.00', '-', '-', '', '', '-', '-', NULL, '1244706.92', '-', '-', '-', '-', '236000.00', '-', '236000.00', NULL, NULL, 'CK/INV/25-26/-002-2026', 'CK/INV/25-26/-002130226', '4');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (7, '-', '-', NULL, '2025-05-07', 'CK/INV/25-26/-003', 9, 'STAAN BIO MED PVT LTD', '', '', '', 'EH Outer Box', 'heatno : P0464-2 , P0470-2 , P0471-2 , P0472-2 , P0473-2 , P0474-2 , P0475-2 , P0476-2 , P0477-2 , P0478-2 , P0479-2 , P0481-2 , P0482-2 , P0483-2 , P0484-2 , P0485-2 , P0495-2 , P0496-2 , P0497-2 , P0498-2', '', '', '', NULL, NULL, '', '', '1', '2025-05-07', '2025-05-07', '268790.00', '-', '-', '', '', '-', '-', NULL, '976889.56', '-', '-', '-', '-', '268790.00', '-', '268790.00', NULL, NULL, 'CK/INV/25-26/-003-2026', 'CK/INV/25-26/-003130226', '5');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (10, '-', '-', NULL, '2025-05-07', 'CK/INV/25-26/-004', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '', '', '', '1/2\" CL 600 Body', 'heatno : P0412-4 , P0424-5 , P0425-5 , P0426-2 , P0443-1', '', '', '', NULL, NULL, '', '', '1', '2025-05-07', '2025-05-07', '24574.00', '-', '-', '', '', '-', '-', NULL, '14487686.5', '-', '-', '-', '-', '24574.00', '-', '24574.00', NULL, NULL, 'CK/INV/25-26/-004-2026', 'CK/INV/25-26/-004140226', '6');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (14, '-', '-', NULL, '2025-06-09', 'CK/INV/25-26/-005', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '', '', '', '4\" 1500 Body||TEST BAR(300mmX50mmX50mm)||Pattern Rework Cost', 'heatno : 33801-3 , 33817-2||heatno : 33801||heatno : ', '', '', '', NULL, NULL, '', '', '1', '2025-06-09', '2025-06-09', '290681.20', '-', '-', '', '', '-', '-', NULL, '14778367.7', '-', '-', '-', '-', '290681.20', '-', '290681.20', NULL, NULL, 'CK/INV/25-26/-005-2026', 'CK/INV/25-26/-005250226', '7');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (15, '-', '-', NULL, '2025-06-21', 'CK/INV/25-26/-006', 9, 'STAAN BIO MED PVT LTD', '', '', '', 'LH Inner Box||12FN Top Plate', 'heatno : P0545-2 , P0585-3 , P0586-3 , P0587-3 , P0590-3 , P0596-3 , P0597-3 , P0598-3 , P0599-3 , P0601-1 , P0602-4 , P0603-4 , P0604-4 , P0607-1||heatno : P0546-4 , P0580-4 , P0582-4 , P0583-4 , P0584-4 , P0588-4 , P0589-4 , P0591-3 , P0592-3 , P0595-3 , P0600-3 , P0607-3 , P0608-4 , P0612-3', '', '', '', NULL, NULL, '', '', '1', '2025-06-21', '2025-06-21', '476688.14', '-', '-', '', '', '-', '-', NULL, '1453577.7', '-', '-', '-', '-', '476688.14', '-', '476688.14', NULL, NULL, 'CK/INV/25-26/-006-2026', 'CK/INV/25-26/-006030326', '8');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (16, '-', '-', NULL, '2025-06-28', 'CK/INV/25-26/-007', 9, 'STAAN BIO MED PVT LTD', '', '', '', 'LH Outer Box', 'heatno : P0579-3 , P0635-3 , P0641-3 , P0612-1 , P0636-3 , P0642-2 , P0613-4 , P0637-3 , P0660-2 , P0630-4 , P0638-3 , P0694-3 , P0634-3 , P0640-3', '', '', '', NULL, NULL, '', '', '1', '2025-06-28', '2025-06-28', '193907.04', '-', '-', '', '', '-', '-', NULL, '1647484.74', '-', '-', '-', '-', '193907.04', '-', '193907.04', NULL, NULL, 'CK/INV/25-26/-007-2026', 'CK/INV/25-26/-007030326', '9');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (17, '-', '-', NULL, '2025-06-28', 'CK/INV/25-26/-008', 9, 'STAAN BIO MED PVT LTD', '', '', '', '12FN Top Plate', '', '', '', '', NULL, NULL, '', '', '1', '2025-06-28', '2025-06-28', '5321.00', '-', '-', '', '', '-', '-', NULL, '1652805.74', '-', '-', '-', '-', '5321.00', '-', '5321.00', NULL, NULL, 'CK/INV/25-26/-008-2026', 'CK/INV/25-26/-008030326', '10');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (18, '-', '-', NULL, '2025-07-03', 'CK/INV/25-26/-009', 15, 'OM Industries', '', '', '', 'Retainer 3.0||Retainer 2.0||Retainer 2.0  Pattern||Retainer 3.0 Pattern', 'heatno : P0674-4||heatno : P0662-2 , P0690-4 , P0693-2 , P0697-4||heatno : ||heatno : ', '', '', '', NULL, NULL, '', '', '1', '2025-07-03', '2025-07-03', '446901.40', '-', '-', '', '', '-', '-', NULL, '446901.4', '-', '-', '-', '-', '446901.40', '-', '446901.40', NULL, NULL, 'CK/INV/25-26/-009-2026', 'CK/INV/25-26/-009030326', '11');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (22, '-', '-', NULL, '2025-07-10', 'CK/INV/25-26/-011', 2, 'SIGMA POWER & ENERGY ENGINEERS', '', '', '', 'Collector Casting', 'heatno : P0593-1 , P0594-2 , P0691-3 , P0695-2 , P0696-3 , P0698-3 , P0699-4 , P0704-4 , P0706-3 , P0707-4 , P0713-2 , P0714-4 , P0715-3 , P0717-4 , P0719-3 , P0720-4 , P0721-4 , P0723-4 , P0724-4 , P0728-4 , P0729-3 , P0730-4 , P0731-3 , P0732-4 , P0733-4 , P0734-4 , P0740-3 , P0741-4 , P0742-2', '', '', '', NULL, NULL, '', '', '1', '2025-07-10', '2025-07-10', '1720822.32', '-', '-', '', '', '-', '-', NULL, '3036648.32', '-', '-', '-', '-', '1720822.32', '-', '1720822.32', NULL, NULL, 'CK/INV/25-26/-011-2026', 'CK/INV/25-26/-011030326', '13');
INSERT INTO `invoice_party_statement` (`id`, `receiptno`, `paid`, `receiptid`, `date`, `invoiceno`, `customerId`, `customername`, `cstno`, `phoneno`, `tinno`, `itemname`, `item_desc`, `rate`, `qty`, `weight`, `credit`, `debit`, `amount`, `total`, `status`, `receiptdate`, `invoicedate`, `totalamount`, `payment`, `throughcheck`, `balanceamount`, `payamount`, `paymentmode`, `chamount`, `paidamount`, `balance`, `banktransfer`, `bankamount`, `chequeno`, `paymentdetails`, `overallamount`, `receiptamt`, `invoiceamt`, `returnamount`, `formtype`, `invoicenoyear`, `invoicenodate`, `invoiceid`) VALUES (23, '-', '-', NULL, '2025-07-10', 'CK/INV/25-26/-010', 2, 'SIGMA POWER & ENERGY ENGINEERS', '', '', '', 'Collector Casting', 'heatno : P0694 - 4', '', '', '', NULL, NULL, '', '', '1', '2025-07-10', '2025-07-10', '71119.08', '-', '-', '', '', '-', '-', NULL, '3036648.32', '-', '-', '-', '-', '71119.08', '-', '71119.08', NULL, NULL, 'CK/INV/25-26/-010-2026', 'CK/INV/25-26/-010030326', '12');


#
# TABLE STRUCTURE FOR: invoice_party_statement_backup
#

DROP TABLE IF EXISTS `invoice_party_statement_backup`;

CREATE TABLE `invoice_party_statement_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `weight` varchar(100) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: invoice_reports
#

DROP TABLE IF EXISTS `invoice_reports`;

CREATE TABLE `invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseordernos` varchar(100) NOT NULL,
  `purchaseorder` varchar(100) NOT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `heatno` varchar(100) NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `uom` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `weight` varchar(100) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  `workorderid` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (9, '2026-02-13', 'CK/INV/25-26/-001', '', '', '2026-02-11', NULL, NULL, 0, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', NULL, NULL, NULL, 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '2025-03-18', 'CAD2025361REV01', NULL, '73259930', '', '3', 'CA16', NULL, '1/2\" CL 600 Body', 'heatno : P0213-20', '1250', '', '1', '20', '3.5', NULL, NULL, '87500.00', NULL, NULL, '103250.00', NULL, NULL, '1', 'CK/INV/25-26/-001-2026', 'CK/INV/25-26/-001130226', '3', '');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (5, '2026-02-13', 'CK/INV/25-26/-002', 'CK/WO/25-26/-001', 'PO3704', '2025-04-09', NULL, NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', NULL, NULL, NULL, 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '84803000', '', '1', 'SP01', NULL, 'Coal Nozzle ', 'heatno : ', '2', '', '6', '1', '1', '', NULL, '200000.00', NULL, NULL, '236000.00', NULL, NULL, '1', 'CK/INV/25-26/-002-2026', 'CK/INV/25-26/-002130226', '4', '3');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (7, '2026-02-13', 'CK/INV/25-26/-003', '', '', '2025-05-07', NULL, NULL, 0, 'STAAN BIO MED PVT LTD', NULL, NULL, NULL, '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '73259999', '', '4', 'SBM08', NULL, 'EH Outer Box', 'heatno : P0464-2 , P0470-2 , P0471-2 , P0472-2 , P0473-2 , P0474-2 , P0475-2 , P0476-2 , P0477-2 , P0478-2 , P0479-2 , P0481-2 , P0482-2 , P0483-2 , P0484-2 , P0485-2 , P0495-2 , P0496-2 , P0497-2 , P0498-2', '167', '', '2', '40', '34.1', NULL, NULL, '227788.00', NULL, NULL, '268790.00', NULL, NULL, '1', 'CK/INV/25-26/-003-2026', 'CK/INV/25-26/-003130226', '5', '');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (10, '2026-02-14', 'CK/INV/25-26/-004', '', '', '2025-05-07', NULL, NULL, 0, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', NULL, NULL, NULL, 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '73259999', '', '3', 'CA16', NULL, '1/2\" CL 600 Body', 'heatno : P0412-4 , P0424-5 , P0425-5 , P0426-2 , P0443-1', '350', '', '2', '17', '3.5', NULL, NULL, '20825.00', NULL, NULL, '24574.00', NULL, NULL, '1', 'CK/INV/25-26/-004-2026', 'CK/INV/25-26/-004140226', '6', '');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (24, '2026-02-25', 'CK/INV/25-26/-005', '', '', '2025-06-09', NULL, NULL, 0, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', NULL, NULL, NULL, 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '84803000', '', '24', 'PR1', NULL, 'Pattern Rework Cost', 'heatno : ', '9500', '', '6', '1', '1', NULL, NULL, '245340.00', NULL, NULL, '290681.20', NULL, NULL, '1', 'CK/INV/25-26/-005-2026', 'CK/INV/25-26/-005250226', '7', '');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (22, '2026-02-25', 'CK/INV/25-26/-005', '', '', '2025-06-09', NULL, NULL, 0, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', NULL, NULL, NULL, 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '73259999', '', '18', 'CA02', NULL, '4\" 1500 Body', 'heatno : 33801-3 , 33817-2', '220', '', '2', '5', '212', NULL, NULL, '245340.00', NULL, NULL, '290681.20', NULL, NULL, '1', 'CK/INV/25-26/-005-2026', 'CK/INV/25-26/-005250226', '7', '');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (23, '2026-02-25', 'CK/INV/25-26/-005', '', '', '2025-06-09', NULL, NULL, 0, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', NULL, NULL, NULL, 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '73259999', '', '23', 'TB1', NULL, 'TEST BAR(300mmX50mmX50mm)', 'heatno : 33801', '220', '', '2', '2', '6', NULL, NULL, '245340.00', NULL, NULL, '290681.20', NULL, NULL, '1', 'CK/INV/25-26/-005-2026', 'CK/INV/25-26/-005250226', '7', '');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (25, '2026-03-03', 'CK/INV/25-26/-006', 'CK/WO/25-26/-005||CK/WO/25-26/-005', 'PO-SC-2526-020||PO-SC-2526-020', '2025-06-21', NULL, NULL, 9, 'STAAN BIO MED PVT LTD', NULL, NULL, NULL, '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '73259999', '', '6', 'SBM05', NULL, 'LH Inner Box', 'heatno : P0545-2 , P0585-3 , P0586-3 , P0587-3 , P0590-3 , P0596-3 , P0597-3 , P0598-3 , P0599-3 , P0601-1 , P0602-4 , P0603-4 , P0604-4 , P0607-1', '1', '', '2', '40', '26.1', '', NULL, '403973.00', NULL, NULL, '476688.14', NULL, NULL, '1', 'CK/INV/25-26/-006-2026', 'CK/INV/25-26/-006030326', '8', '19');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (26, '2026-03-03', 'CK/INV/25-26/-006', 'CK/WO/25-26/-005||CK/WO/25-26/-005', 'PO-SC-2526-020||PO-SC-2526-020', '2025-06-21', NULL, NULL, 9, 'STAAN BIO MED PVT LTD', NULL, NULL, NULL, '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '73259999', '', '7', 'SBM10', NULL, '12FN Top Plate', 'heatno : P0546-4 , P0580-4 , P0582-4 , P0583-4 , P0584-4 , P0588-4 , P0589-4 , P0591-3 , P0592-3 , P0595-3 , P0600-3 , P0607-3 , P0608-4 , P0612-3', '6', '', '2', '50', '27.5', '', NULL, '403973.00', NULL, NULL, '476688.14', NULL, NULL, '1', 'CK/INV/25-26/-006-2026', 'CK/INV/25-26/-006030326', '8', '20');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (27, '2026-03-03', 'CK/INV/25-26/-007', 'CK/WO/25-26/-005', 'PO-SC-2526-020', '2025-06-28', NULL, NULL, 9, 'STAAN BIO MED PVT LTD', NULL, NULL, NULL, '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '73259999', '', '5', 'SBM03', NULL, 'LH Outer Box', 'heatno : P0579-3 , P0635-3 , P0641-3 , P0612-1 , P0636-3 , P0642-2 , P0613-4 , P0637-3 , P0660-2 , P0630-4 , P0638-3 , P0694-3 , P0634-3 , P0640-3', '1', '', '2', '40', '24.6', '', NULL, '164328.00', NULL, NULL, '193907.04', NULL, NULL, '1', 'CK/INV/25-26/-007-2026', 'CK/INV/25-26/-007030326', '9', '18');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (28, '2026-03-03', 'CK/INV/25-26/-008', '', '', '2025-06-28', NULL, NULL, 9, 'STAAN BIO MED PVT LTD', NULL, NULL, NULL, '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '2025-04-24', 'PO-SC-2526-020', NULL, '73259999', 'P0694', '', 'SBM10', NULL, '12FN Top Plate', '', '1', '', '2', '1', '27', '', NULL, '4509.00', NULL, NULL, '5321.00', NULL, NULL, '1', 'CK/INV/25-26/-008-2026', 'CK/INV/25-26/-008030326', '10', '');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (29, '2026-03-03', 'CK/INV/25-26/-009', 'CK/WO/25-26/-009||CK/WO/25-26/-009||CK/WO/25-26/-009||CK/WO/25-26/-009', 'OM/PO/05-25-26/01||OM/PO/05-25-26/01||OM/PO/05-25-26/01||OM/PO/05-25-26/01', '2025-07-03', NULL, NULL, 15, 'OM Industries', NULL, NULL, NULL, 'No:230/2, 4Th Cross,, Vanapadi Road,Sipcot, Ranipet, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '73259920', '', '16', 'OMI 02', NULL, 'Retainer 3.0', 'heatno : P0674-4', '1', '', '3', '4', '52', '', NULL, '368730.00', NULL, NULL, '446901.40', NULL, NULL, '1', 'CK/INV/25-26/-009-2026', 'CK/INV/25-26/-009030326', '11', '28');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (30, '2026-03-03', 'CK/INV/25-26/-009', 'CK/WO/25-26/-009||CK/WO/25-26/-009||CK/WO/25-26/-009||CK/WO/25-26/-009', 'OM/PO/05-25-26/01||OM/PO/05-25-26/01||OM/PO/05-25-26/01||OM/PO/05-25-26/01', '2025-07-03', NULL, NULL, 15, 'OM Industries', NULL, NULL, NULL, 'No:230/2, 4Th Cross,, Vanapadi Road,Sipcot, Ranipet, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '73259920', '', '15', 'OMI 01', NULL, 'Retainer 2.0', 'heatno : P0662-2 , P0690-4 , P0693-2 , P0697-4', '8', '', '3', '12', '112.5', '', NULL, '368730.00', NULL, NULL, '446901.40', NULL, NULL, '1', 'CK/INV/25-26/-009-2026', 'CK/INV/25-26/-009030326', '11', '27');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (31, '2026-03-03', 'CK/INV/25-26/-009', 'CK/WO/25-26/-009||CK/WO/25-26/-009||CK/WO/25-26/-009||CK/WO/25-26/-009', 'OM/PO/05-25-26/01||OM/PO/05-25-26/01||OM/PO/05-25-26/01||OM/PO/05-25-26/01', '2025-07-03', NULL, NULL, 15, 'OM Industries', NULL, NULL, NULL, 'No:230/2, 4Th Cross,, Vanapadi Road,Sipcot, Ranipet, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '84803000', '', '19', 'OMI 01', NULL, 'Retainer 2.0  Pattern', 'heatno : ', '5', '', '6', '1', '1', '', NULL, '368730.00', NULL, NULL, '446901.40', NULL, NULL, '1', 'CK/INV/25-26/-009-2026', 'CK/INV/25-26/-009030326', '11', '29');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (32, '2026-03-03', 'CK/INV/25-26/-009', 'CK/WO/25-26/-009||CK/WO/25-26/-009||CK/WO/25-26/-009||CK/WO/25-26/-009', 'OM/PO/05-25-26/01||OM/PO/05-25-26/01||OM/PO/05-25-26/01||OM/PO/05-25-26/01', '2025-07-03', NULL, NULL, 15, 'OM Industries', NULL, NULL, NULL, 'No:230/2, 4Th Cross,, Vanapadi Road,Sipcot, Ranipet, Tamil Nadu', 'intrastate', 'intrastate', '', '', NULL, '1970-01-01', '', NULL, '84803000', '', '20', 'OMI 02', NULL, 'Retainer 3.0 Pattern', 'heatno : ', '|', '', '6', '1', '1', '', NULL, '368730.00', NULL, NULL, '446901.40', NULL, NULL, '1', 'CK/INV/25-26/-009-2026', 'CK/INV/25-26/-009030326', '11', '30');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (37, '2026-03-03', 'CK/INV/25-26/-010', '', '', '2025-07-10', NULL, NULL, 0, 'SIGMA POWER & ENERGY ENGINEERS', NULL, NULL, NULL, 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '73259930', '', '12', 'SP02', NULL, 'Collector Casting', 'heatno : P0694 - 4', '542', '', '4', '4', '27.8', NULL, NULL, '60270.40', NULL, NULL, '71119.08', NULL, NULL, '1', 'CK/INV/25-26/-010-2026', 'CK/INV/25-26/-010030326', '12', '');
INSERT INTO `invoice_reports` (`id`, `date`, `invoiceno`, `purchaseordernos`, `purchaseorder`, `invoicedate`, `paymenttype`, `dcdate`, `customerId`, `customername`, `mobileno`, `tinno`, `cstno`, `address`, `gsttype`, `billtype`, `deliveryat`, `vehicleno`, `dcno`, `orderdate`, `orderno`, `despatch`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemno`, `itemname`, `item_desc`, `rate`, `uom`, `grade`, `qty`, `weight`, `total`, `totalamount`, `subtotal`, `discount`, `disamount`, `grandtotal`, `paid`, `balance`, `status`, `invoicenoyear`, `invoicenodate`, `invoiceid`, `workorderid`) VALUES (36, '2026-03-03', 'CK/INV/25-26/-011', '', '', '2025-07-10', NULL, NULL, 0, 'SIGMA POWER & ENERGY ENGINEERS', NULL, NULL, NULL, 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', 'intrastate', 'intrastate', NULL, '', NULL, '1970-01-01', '', NULL, '73259930', '', '12', 'SP02', NULL, 'Collector Casting', 'heatno : P0593-1 , P0594-2 , P0691-3 , P0695-2 , P0696-3 , P0698-3 , P0699-4 , P0704-4 , P0706-3 , P0707-4 , P0713-2 , P0714-4 , P0715-3 , P0717-4 , P0719-3 , P0720-4 , P0721-4 , P0723-4 , P0724-4 , P0728-4 , P0729-3 , P0730-4 , P0731-3 , P0732-4 , P0733-4 , P0734-4 , P0740-3 , P0741-4 , P0742-2', '539', '', '4', '96', '28', NULL, NULL, '1448832.00', NULL, NULL, '1720822.32', NULL, NULL, '1', 'CK/INV/25-26/-011-2026', 'CK/INV/25-26/-011030326', '13', '');


#
# TABLE STRUCTURE FOR: inward_delivery
#

DROP TABLE IF EXISTS `inward_delivery`;

CREATE TABLE `inward_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `insertid` int(11) NOT NULL,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(50) NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `lastupdatedqty` int(11) NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(50) NOT NULL,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `inward_status` int(11) DEFAULT NULL,
  `lastupdated` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (1, 1, '2026-03-03', 'CK/I/25-26/-001', '2025-05-07', 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy', 'SC-G-2526-0260', '2025-05-07', '6', '', 'LH Inner Box', 'Aluminium Corebox', '1', '1', 1, '', '84803000', 'SBM05', 'NOS', '6', 'CK/I/25-26/-001-26', 'CK/I/25-26/-001030326', 1, 1, '2026-03-04 10:29:44');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (2, 1, '2026-03-03', 'CK/I/25-26/-001', '2025-05-07', 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy', 'SC-G-2526-0260', '2025-05-07', '5', '', 'LH Outer Box', 'Aluminium CoreBox', '1', '1', 1, '', '84803000', 'SBM03', 'NOS', '6', 'CK/I/25-26/-001-26', 'CK/I/25-26/-001030326', 1, 1, '2026-03-04 10:29:44');
INSERT INTO `inward_delivery` (`id`, `insertid`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `balanceqty`, `lastupdatedqty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `inward_status`, `lastupdated`) VALUES (3, 1, '2026-03-03', 'CK/I/25-26/-001', '2025-05-07', 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy', 'SC-G-2526-0260', '2025-05-07', '7', '', '12FN Top Plate', '1 Set Pattern', '1', '1', 1, '', '73259999', 'SBM10', 'NOS', '2', 'CK/I/25-26/-001-26', 'CK/I/25-26/-001030326', 1, 1, '2026-03-04 10:29:44');


#
# TABLE STRUCTURE FOR: inward_details
#

DROP TABLE IF EXISTS `inward_details`;

CREATE TABLE `inward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(50) NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(50) NOT NULL,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `inward_details` (`id`, `date`, `inwardno`, `inwarddate`, `cusname`, `address`, `customerdcno`, `customerdcdate`, `itemid`, `heatno`, `itemname`, `item_desc`, `qty`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `inwardnoyear`, `inwardnodate`, `status`, `delete_status`, `inward_delivery_id`) VALUES (1, '2026-03-03', 'CK/I/25-26/-001', '2025-05-07', 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy', 'SC-G-2526-0260', '2025-05-07', '6||5||7', '', 'LH Inner Box||LH Outer Box||12FN Top Plate', 'Aluminium Corebox||Aluminium CoreBox||1 Set Pattern', '1||1||1', '', '84803000||84803000||73259999', 'SBM05||SBM03||SBM10', 'NOS||NOS||NOS', '6||6||2', 'CK/I/25-26/-001-26', 'CK/I/25-26/-001030326', 1, 1, '1,2,3');


#
# TABLE STRUCTURE FOR: inward_details_backup
#

DROP TABLE IF EXISTS `inward_details_backup`;

CREATE TABLE `inward_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `inwardno` varchar(255) NOT NULL,
  `inwarddate` date NOT NULL,
  `cusname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `customerdcno` varchar(255) NOT NULL,
  `customerdcdate` date NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `heatno` varchar(100) NOT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `inwardnoyear` varchar(225) DEFAULT NULL,
  `inwardnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `inward_delivery_id` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: job_data
#

DROP TABLE IF EXISTS `job_data`;

CREATE TABLE `job_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: job_details
#

DROP TABLE IF EXISTS `job_details`;

CREATE TABLE `job_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `joborderdate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext DEFAULT NULL,
  `category` longtext DEFAULT NULL,
  `jobdescription` longtext DEFAULT NULL,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: jobinward_data
#

DROP TABLE IF EXISTS `jobinward_data`;

CREATE TABLE `jobinward_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `insertid` int(11) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `itemname` varchar(225) DEFAULT NULL,
  `qty` varchar(225) DEFAULT NULL,
  `joborderqty` varchar(225) DEFAULT NULL,
  `hsnno` varchar(225) DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `returnitemname` varchar(225) DEFAULT NULL,
  `returnqty` varchar(225) DEFAULT NULL,
  `scrap` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `job_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobinward_details
#

DROP TABLE IF EXISTS `jobinward_details`;

CREATE TABLE `jobinward_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `jobtype` varchar(225) DEFAULT NULL,
  `jobinwardno` varchar(225) DEFAULT NULL,
  `jobinwarddate` date DEFAULT NULL,
  `dateofcompletion` date DEFAULT NULL,
  `operatorname` varchar(225) DEFAULT NULL,
  `vendors` varchar(225) DEFAULT NULL,
  `vendordetails` longtext DEFAULT NULL,
  `joborderno` varchar(225) DEFAULT NULL,
  `category` longtext DEFAULT NULL,
  `jobdescription` longtext DEFAULT NULL,
  `issueby` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: jobworkdc_delivery
#

DROP TABLE IF EXISTS `jobworkdc_delivery`;

CREATE TABLE `jobworkdc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `weight` varchar(100) NOT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `grade` varchar(100) NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `jobworkdc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `weight`, `remarks`, `hsnno`, `grade`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (1, '2026-03-03', 1, NULL, 'Direct DC', 'CK/PDC/25-26/-001', '2025-05-08', 8, 'PREMIER ALLOYS', '', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'LH Inner Box', '', '1 Set Pattern and Corebox', '1', '1', '-', '', '84803000', '6', 'SBM05', 'NOS', '', '', 1, 1);
INSERT INTO `jobworkdc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `weight`, `remarks`, `hsnno`, `grade`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (2, '2026-03-03', 1, NULL, 'Direct DC', 'CK/PDC/25-26/-001', '2025-05-08', 8, 'PREMIER ALLOYS', '', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'LH Outer Box', '', '1 Set Pattern and Corebox', '1', '1', '30', '', '84803000', '6', 'SBM03', 'NOS', '', '', 1, 1);
INSERT INTO `jobworkdc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `weight`, `remarks`, `hsnno`, `grade`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (3, '2026-03-03', 1, NULL, 'Direct DC', 'CK/PDC/25-26/-001', '2025-05-08', 8, 'PREMIER ALLOYS', '', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, NULL, '12FN Top Plate', '', '1 Set Pattern', '1', '1', '30', '', '84803000', '6', 'SBM10', 'NOS', '', '', 1, 1);
INSERT INTO `jobworkdc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `weight`, `remarks`, `hsnno`, `grade`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (5, '2026-03-05', 2, NULL, 'Direct DC', 'CK/PDC/25-26/-002', '2025-05-16', 8, 'PREMIER ALLOYS', '', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'Collector Casting', '', '1 Set Aluminium Pattern and Corebox. Teakwood Corebox with Mounting with Loose Pieces', '3', '3', '-', '', '84803000', '6', 'SP02', 'NOS', '', '', 1, 1);
INSERT INTO `jobworkdc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `weight`, `remarks`, `hsnno`, `grade`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (6, '2026-03-05', 3, NULL, 'Direct DC', 'CK/PDC/25-26/-003', '2025-05-16', 14, 'Shree Kumaran Alloys', '', 'S/F No - 461, Telungupalayam Road,, Ellapalayam Post,Annur, Coimbatore, Tamil Nadu', NULL, NULL, NULL, '4\" 1500 Body', '', '1 Set Aluminium Pattern & Corebox finishing. 1 Set Aluminium Corebox & matchplate Finishing. 1 Set Big Location Corebox', '1', '1', '200', '', '84803000', '6', 'CA02', 'NOS', '', '', 1, 1);
INSERT INTO `jobworkdc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `weight`, `remarks`, `hsnno`, `grade`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (8, '2026-03-05', 4, NULL, 'Direct DC', 'CK/PDC/25-26/-004', '2025-05-21', 8, 'PREMIER ALLOYS', '', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'EH Outer Box', '', '1 Set Pattern and Corebox', '1', '1', '40Kg', '', '84803000', '6', 'SBM08', 'NOS', '', '', 1, 1);
INSERT INTO `jobworkdc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `weight`, `remarks`, `hsnno`, `grade`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (9, '2026-03-05', 5, NULL, 'Direct DC', 'CK/PDC/25-26/-005', '2025-06-01', 10, 'Shristi Engineering Works', '', 'Door No.3,Ravathur Road,, Athappa Gounder Pudur,Irugur, Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'EH Outer Box', '', '1 Set Pattern and Corebox', '1', '1', '30Kg', '', '84803000', '6', 'SBM08', 'NOS', '', '', 1, 1);
INSERT INTO `jobworkdc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `weight`, `remarks`, `hsnno`, `grade`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (10, '2026-03-05', 5, NULL, 'Direct DC', 'CK/PDC/25-26/-005', '2025-06-01', 10, 'Shristi Engineering Works', '', 'Door No.3,Ravathur Road,, Athappa Gounder Pudur,Irugur, Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'NH Outer Box', '', '1 Set Pattern and Corebox', '1', '1', '40', '', '84803000', '6', 'SBM02', 'NOS', '', '', 1, 1);
INSERT INTO `jobworkdc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `weight`, `remarks`, `hsnno`, `grade`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (11, '2026-03-05', 5, NULL, 'Direct DC', 'CK/PDC/25-26/-005', '2025-06-01', 10, 'Shristi Engineering Works', '', 'Door No.3,Ravathur Road,, Athappa Gounder Pudur,Irugur, Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'NH Inner Box', '', '1 Set Pattern and Corebox', '1', '1', '35', '', '84803000', '6', 'SBM04', 'NOS', '', '', 1, 1);
INSERT INTO `jobworkdc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `weight`, `remarks`, `hsnno`, `grade`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (12, '2026-03-05', 5, NULL, 'Direct DC', 'CK/PDC/25-26/-005', '2025-06-01', 10, 'Shristi Engineering Works', '', 'Door No.3,Ravathur Road,, Athappa Gounder Pudur,Irugur, Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'EH Inner Box', '', '1 Set Pattern and Corebox', '1', '1', '40', '', '84803000', '6', 'SBM15', 'NOS', '', '', 1, 1);
INSERT INTO `jobworkdc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `weight`, `remarks`, `hsnno`, `grade`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (20, '2026-03-06', 6, NULL, 'Direct DC', 'CK/PDC/25-26/-006', '2025-06-16', 8, 'PREMIER ALLOYS', '', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'EH Inner Box', '', '1 Set Pattern and Correbox', '1', '1', '35', '', '84803000', '6', 'SBM15', 'NOS', '', '', 1, 1);
INSERT INTO `jobworkdc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `weight`, `remarks`, `hsnno`, `grade`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (19, '2026-03-06', 6, NULL, 'Direct DC', 'CK/PDC/25-26/-006', '2025-06-16', 8, 'PREMIER ALLOYS', '', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'NH Inner Box', '', '1 Set Pattern and Correbox', '1', '1', '40', '', '84803000', '6', 'SBM04', 'NOS', '', '', 1, 1);
INSERT INTO `jobworkdc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `weight`, `remarks`, `hsnno`, `grade`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (18, '2026-03-06', 6, NULL, 'Direct DC', 'CK/PDC/25-26/-006', '2025-06-16', 8, 'PREMIER ALLOYS', '', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'NH Outer Box', '', '1 Set Pattern and Correbox', '1', '1', '50', '', '84803000', '6', 'SBM02', 'NOS', '', '', 1, 1);
INSERT INTO `jobworkdc_delivery` (`id`, `date`, `insertid`, `inwardid`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `dispatchthrough`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `balanceqty`, `weight`, `remarks`, `hsnno`, `grade`, `itemcode`, `uom`, `dcnoyear`, `dcnodate`, `status`, `dc_status`) VALUES (17, '2026-03-06', 6, NULL, 'Direct DC', 'CK/PDC/25-26/-006', '2025-06-16', 8, 'PREMIER ALLOYS', '', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'EH Outer Box', '', '1 Set Pattern and Corebox', '1', '1', '30Kg', '', '84803000', '6', 'SBM08', 'NOS', '', '', 1, 1);


#
# TABLE STRUCTURE FOR: jobworkdc_delivery_backup
#

DROP TABLE IF EXISTS `jobworkdc_delivery_backup`;

CREATE TABLE `jobworkdc_delivery_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: jobworkdc_details
#

DROP TABLE IF EXISTS `jobworkdc_details`;

CREATE TABLE `jobworkdc_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `vehicleno` varchar(100) NOT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` longtext DEFAULT NULL,
  `customerdcdate` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `itemid` varchar(100) NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext DEFAULT NULL,
  `weight` varchar(100) NOT NULL,
  `remarks` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` tinyint(4) NOT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `jobworkdc_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `vehicleno`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `weight`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `dcnoyear`, `dcnodate`, `status`, `edit_status`, `delete_status`, `billtype`) VALUES (1, '2026-03-03', 'Direct DC', 'CK/PDC/25-26/-001', '2025-05-08', 8, 'PREMIER ALLOYS', 'TN37DD2067', NULL, '10.20AM', 'Material Sent for moulding Purpose', 'For Movement of inputs or partially processed goods from one factory to another factory for further ', '', '25000', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'LH Inner Box||LH Outer Box||12FN Top Plate', '6||5||7', '1 Set Pattern and Corebox||1 Set Pattern and Corebox||1 Set Pattern', '1||1||1', '-||30||30', '||||', '84803000||84803000||84803000', 'SBM05||SBM03||SBM10', 'NOS||NOS||NOS', '6||6||6', NULL, NULL, 1, 1, 1, '');
INSERT INTO `jobworkdc_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `vehicleno`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `weight`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `dcnoyear`, `dcnodate`, `status`, `edit_status`, `delete_status`, `billtype`) VALUES (2, '2026-03-05', 'Direct DC', 'CK/PDC/25-26/-002', '2025-05-16', 8, 'PREMIER ALLOYS', '', NULL, '10:41:PM', 'Materials sent for Moulding purpose only.', 'For Movement of inputs or partially processed goods from one factory to another factory for further ', '', '40000', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'Collector Casting', '12', '1 Set Aluminium Pattern and Corebox. Teakwood Corebox with Mounting with Loose Pieces', '3', '-', '', '84803000', 'SP02', 'NOS', '6', NULL, NULL, 1, 1, 1, '');
INSERT INTO `jobworkdc_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `vehicleno`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `weight`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `dcnoyear`, `dcnodate`, `status`, `edit_status`, `delete_status`, `billtype`) VALUES (3, '2026-03-05', 'Direct DC', 'CK/PDC/25-26/-003', '2025-05-16', 14, 'Shree Kumaran Alloys', 'TN37CK3568', NULL, '06.30:PM', 'Material Send for Moulding Purpose only', ' For Movement of inputs or partially processed goods from one factory to another factory for further processing/operation', '', '20000', 'S/F No - 461, Telungupalayam Road,, Ellapalayam Post,Annur, Coimbatore, Tamil Nadu', NULL, NULL, NULL, '4\" 1500 Body', '18', '1 Set Aluminium Pattern & Corebox finishing. 1 Set Aluminium Corebox & matchplate Finishing. 1 Set Big Location Corebox', '1', '200', '', '84803000', 'CA02', 'NOS', '6', NULL, NULL, 1, 1, 1, '');
INSERT INTO `jobworkdc_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `vehicleno`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `weight`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `dcnoyear`, `dcnodate`, `status`, `edit_status`, `delete_status`, `billtype`) VALUES (4, '2026-03-05', 'Direct DC', 'CK/PDC/25-26/-004', '2025-05-21', 8, 'PREMIER ALLOYS', '', NULL, '10:20 AM', 'Materials sent for Moulding purpose only', 'For Movement of inputs or partially processed goods from one factory to another factory for further ', '', '10000', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'EH Outer Box', '4', '1 Set Pattern and Corebox', '1', '40Kg', '', '84803000', 'SBM08', 'NOS', '6', NULL, NULL, 1, 1, 1, '');
INSERT INTO `jobworkdc_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `vehicleno`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `weight`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `dcnoyear`, `dcnodate`, `status`, `edit_status`, `delete_status`, `billtype`) VALUES (5, '2026-03-05', 'Direct DC', 'CK/PDC/25-26/-005', '2025-06-01', 10, 'Shristi Engineering Works', 'TN66AL4160', NULL, '10:20:AM', 'Material send for rework purpose only', 'For Movement of inputs or partially processed goods from one factory to another factory for further ', '', '79000', 'Door No.3,Ravathur Road,, Athappa Gounder Pudur,Irugur, Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'EH Outer Box||NH Outer Box||NH Inner Box||EH Inner Box', '4||8||9||10', '1 Set Pattern and Corebox||1 Set Pattern and Corebox||1 Set Pattern and Corebox||1 Set Pattern and Corebox', '1||1||1||1', '30Kg||40||35||40', '||||||', '84803000||84803000||84803000||84803000', 'SBM08||SBM02||SBM04||SBM15', 'NOS||NOS||NOS||NOS', '6||6||6||6', NULL, NULL, 1, 1, 1, '');
INSERT INTO `jobworkdc_details` (`id`, `date`, `dctype`, `dcno`, `dcdate`, `customerId`, `cusname`, `vehicleno`, `dispatchthrough`, `time`, `purpose`, `process`, `remarkss`, `approximate_value`, `address`, `inwardno`, `customerdcno`, `customerdcdate`, `itemname`, `itemid`, `item_desc`, `qty`, `weight`, `remarks`, `hsnno`, `itemcode`, `uom`, `grade`, `dcnoyear`, `dcnodate`, `status`, `edit_status`, `delete_status`, `billtype`) VALUES (6, '2026-03-06', 'Direct DC', 'CK/PDC/25-26/-006', '2025-06-16', 8, 'PREMIER ALLOYS', 'TN66AL4160aaa', NULL, '04:02:PM', 'Material Sent for moulding Purpose', 'For Movement of inputs or partially processed goods from one factory to another factory for further processing / operation.', '', '79000', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, NULL, 'EH Outer Box||NH Outer Box||NH Inner Box||EH Inner Box', '4||8||9||10', '1 Set Pattern and Corebox||1 Set Pattern and Correbox||1 Set Pattern and Correbox||1 Set Pattern and Correbox', '1||1||1||1', '30Kg||50||40||35', '||||||', '84803000||84803000||84803000||84803000', 'SBM08||SBM02||SBM04||SBM15', 'NOS||NOS||NOS||NOS', '6||6||6||6', NULL, NULL, 1, 1, 1, '');


#
# TABLE STRUCTURE FOR: jobworkdc_details_backup
#

DROP TABLE IF EXISTS `jobworkdc_details_backup`;

CREATE TABLE `jobworkdc_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` longtext DEFAULT NULL,
  `customerdcdate` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext DEFAULT NULL,
  `remarks` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: login_details
#

DROP TABLE IF EXISTS `login_details`;

CREATE TABLE `login_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userType` char(1) NOT NULL,
  `date` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `sub_menu_link` text DEFAULT NULL,
  `selectedMainMenu` text NOT NULL,
  `selectedSubMenu` text NOT NULL,
  `add_party` int(11) DEFAULT NULL,
  `add_expenses` int(11) DEFAULT NULL,
  `add_quotation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (1, 'A', '2017-01-26', 'admin', '', 'test@gmail.com', '876049652', '0000-00-00', 'admin', 'admin001', '1', '', '', '', NULL, NULL, NULL);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (5, 'U', '2018-05-02', 'purchase', 'Purchase Team', '', '', '1970-01-01', 'purchase', '123456', '1', 'purchase,inward,inward/view,inward/pending,stockmaster,daily_stockreports,customer/view', 'Purchase,Inward,Inward,Inward,Stock,Stock,Reports', 'Purchase Receipt,Add Inward,Inward Reports,Inward Pending,Add Stock,Daily Stock Reports,Party Reports', 1, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (6, 'U', '2018-05-02', 'Accounts', 'Accounts Team', '', '', '1970-01-01', 'Accounts', '123456', '1', 'invoice_statement/view,tax/view,cashbill/listing,purchase_statement/view,purchasetax/view,voucher,voucher/reports,stockmaster,daily_stockreports,itemwise_report,expenses/reports,quotation/view', 'Sales Invoice,Sales Invoice,Cash Bill,Purchase,Purchase,Voucher,Voucher,Stock,Stock,Stock,Reports,Reports', 'Invoice Party Statement,Invoice Tax Reports,Cash Bill Reports,Purchase Party Statement,Purchase Tax Reports,Add Voucher,Voucher Reports,Add Stock,Daily Stock Reports,Itemwise Reports,Expenses Reports,Quotation Reports', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (7, 'U', '2018-08-10', 'ramesh', 'developer', '', '', '1970-01-01', 'ramesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/reports,purchase_statement/view,purchasetax/view,stockmaster,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Stock,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Add Stock,Add Item', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (8, 'U', '2018-08-10', 'tester1', 'testing', '', '', '1970-01-01', 'tester1', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,purchase,purchase/view,purchase_statement/view,purchasetax/view,taxtype,uom,itemmaster', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Purchase,Purchase,Purchase,Purchase,Settings,Settings,Settings', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Purchase Receipt,Purchase Reports,Purchase Party Statement,Purchase Tax Reports,Tax Type,Add UOM,Add Item', 1, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (9, 'U', '2021-06-28', 'parmesh', 'developer', 'pshm956@gmail.com', '8344031191', '2021-06-28', 'parmesh', '123456', '1', 'dashboard,invoice,invoice/view,invoice_statement/view,tax/view,proforma_invoice,proforma_invoice/view', 'dashboard,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice,Sales Invoice', 'Dashboard,Add Invoice,Invoice Reports,Invoice Party Statement,Invoice Tax Reports,Add Proforma Invoice,Proforma Invoice Reports', 0, 0, 0);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (10, 'U', '2023-09-12', 'jp', 'quotation', 'jp@idreamdevelopers.com', '7810028222', '2023-09-12', 'jp', '123456', '1', 'taxtype,uom,itemmaster,headers,profile,backup,support,usermaster', 'Settings,Settings,Settings,Settings,Settings,Settings,Settings,Settings', 'Tax Type,Add UOM,Add Item,Account Headers,Company Profile,Backup Settings,Support,User Manager', 1, 1, 1);
INSERT INTO `login_details` (`id`, `userType`, `date`, `name`, `designation`, `email`, `phoneno`, `doj`, `username`, `password`, `status`, `sub_menu_link`, `selectedMainMenu`, `selectedSubMenu`, `add_party`, `add_expenses`, `add_quotation`) VALUES (12, 'U', '2025-06-20', 'Pradeepa ', 'Technical support', 'pradee@gmail.com', '9500995841', '2025-06-03', 'Pradeepa ', 'adminoo1', '1', '', '', '', 0, 0, 0);


#
# TABLE STRUCTURE FOR: materialdc_delivery
#

DROP TABLE IF EXISTS `materialdc_delivery`;

CREATE TABLE `materialdc_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `insertid` int(11) NOT NULL,
  `inwardid` int(11) DEFAULT NULL,
  `dctype` varchar(225) NOT NULL,
  `dcno` varchar(225) NOT NULL,
  `dcdate` varchar(225) NOT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) NOT NULL,
  `dispatchthrough` varchar(225) NOT NULL,
  `address` varchar(225) NOT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` varchar(225) DEFAULT NULL,
  `customerdcdate` varchar(225) DEFAULT NULL,
  `itemname` longtext NOT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext NOT NULL,
  `balanceqty` varchar(225) DEFAULT NULL,
  `remarks` longtext NOT NULL,
  `hsnno` longtext NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext NOT NULL,
  `dcnoyear` varchar(225) NOT NULL,
  `dcnodate` varchar(225) NOT NULL,
  `status` int(11) NOT NULL,
  `dc_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: materialdc_details
#

DROP TABLE IF EXISTS `materialdc_details`;

CREATE TABLE `materialdc_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` longtext DEFAULT NULL,
  `customerdcdate` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext DEFAULT NULL,
  `remarks` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: materialdc_details_backup
#

DROP TABLE IF EXISTS `materialdc_details_backup`;

CREATE TABLE `materialdc_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `dctype` varchar(225) DEFAULT NULL,
  `dcno` varchar(225) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `cusname` varchar(225) DEFAULT NULL,
  `dispatchthrough` varchar(225) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `process` varchar(255) DEFAULT NULL,
  `remarkss` varchar(255) DEFAULT NULL,
  `approximate_value` varchar(255) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `inwardno` longtext DEFAULT NULL,
  `customerdcno` longtext DEFAULT NULL,
  `customerdcdate` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `qty` longtext DEFAULT NULL,
  `remarks` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `dcnoyear` varchar(225) DEFAULT NULL,
  `dcnodate` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `delete_status` int(11) DEFAULT NULL,
  `billtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: mpt_report
#

DROP TABLE IF EXISTS `mpt_report`;

CREATE TABLE `mpt_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `mpt_report_no` varchar(100) NOT NULL,
  `mpt_date` varchar(100) NOT NULL,
  `customername` varchar(100) NOT NULL,
  `customerid` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `equipment_make` varchar(100) NOT NULL,
  `magnetic_powder_color` varchar(100) NOT NULL,
  `equipment_type` varchar(100) NOT NULL,
  `prod_spacing` varchar(100) NOT NULL,
  `procedure_ref` varchar(100) NOT NULL,
  `current_amps` varchar(100) NOT NULL,
  `stage_of_test` varchar(100) NOT NULL,
  `magnetisation` varchar(100) NOT NULL,
  `process` varchar(100) NOT NULL,
  `surface_condition` varchar(100) NOT NULL,
  `inspection_date` varchar(100) NOT NULL,
  `acceptance_standard` varchar(100) NOT NULL,
  `current` varchar(100) NOT NULL,
  `medium` varchar(100) NOT NULL,
  `light_indensity` varchar(100) NOT NULL,
  `fluosrecent` varchar(100) NOT NULL,
  `area_of_test` varchar(100) NOT NULL,
  `casting_temp` varchar(100) NOT NULL,
  `demagnetization` varchar(100) NOT NULL,
  `observation` varchar(100) NOT NULL,
  `po_no_dt` longtext NOT NULL,
  `description` longtext NOT NULL,
  `drawing_no` longtext NOT NULL,
  `heat_no` longtext NOT NULL,
  `mpi_no` longtext NOT NULL,
  `desp_qty` longtext NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_by` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: mtc_report
#

DROP TABLE IF EXISTS `mtc_report`;

CREATE TABLE `mtc_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `tcno` varchar(100) NOT NULL,
  `tcdate` varchar(100) NOT NULL,
  `heatno` varchar(100) NOT NULL,
  `customername` varchar(100) NOT NULL,
  `customerid` varchar(100) NOT NULL,
  `purchaseorderno` varchar(100) NOT NULL,
  `purchaseorder` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `heat_treatment` text NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `drawing_no` varchar(100) NOT NULL,
  `partno` varchar(100) NOT NULL,
  `poured_qty` varchar(100) NOT NULL,
  `chemical_element` text NOT NULL,
  `chemical_minvalue` text NOT NULL,
  `chemical_maxvalue` text NOT NULL,
  `chemical_actualvalue` text NOT NULL,
  `mechanical_element` longtext NOT NULL,
  `mechanical_minvalue` text NOT NULL,
  `mechanical_maxvalue` text NOT NULL,
  `mechanical_actualvalue` text NOT NULL,
  `remarks` longtext NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `mtc_report` (`id`, `date`, `tcno`, `tcdate`, `heatno`, `customername`, `customerid`, `purchaseorderno`, `purchaseorder`, `grade`, `heat_treatment`, `product_code`, `itemname`, `drawing_no`, `partno`, `poured_qty`, `chemical_element`, `chemical_minvalue`, `chemical_maxvalue`, `chemical_actualvalue`, `mechanical_element`, `mechanical_minvalue`, `mechanical_maxvalue`, `mechanical_actualvalue`, `remarks`, `status`) VALUES (1, '2026-02-13', 'MTC/25-26/001', '20-03-2025', 'P0213', 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '7', '-', 'CK/WO/25-26/-003', '1', 'SOLUTION ANNEALING : 1080 ° C / 3 HRS SOAKED / WATER QUENCHED', 'CA16', '1/2\" CL 600 Body', '-', '', 'CA16', 'C.%,Si.%,Mn.%,S.%,P.%,Cr.%,Ni.%,Mo.%,,,,,,,', '-,-,-,-,-,17.000,9.000,2.000,,,,,,,', '0.030,1.500,1.500,0.040,0.040,21.000,13.000,3.000,,,,,,,', '0.027,0.885,1.370,0.004,0.024,17.340,10.310,2.050,,,,,,,', 'Yield Strength,Tensile Strength,% Elongation,% Reduction of Area,Hardness,Bend Test,Impact Test in Joules', '205,485,30,-,-,,', '-,,,-,200,,', '370.15,574.35,63.30,,163,,', '<p><span style=\"font-size: 12px;\">﻿Separate test bar poured and the same bar tested for chemical and mechanical properties</span></p><p><span style=\"font-size: 12px;\"><br></span></p><p><span style=\"font-size: 12px;\"><br></span><br></p>', 1);


#
# TABLE STRUCTURE FOR: po_party_statements
#

DROP TABLE IF EXISTS `po_party_statements`;

CREATE TABLE `po_party_statements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `joborder_No` varchar(100) NOT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `joborder_No`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (3, '2025-03-20', '2025-03-20', '-', 'CK/P/25-26/.-001', '', 8, 'PREMIER ALLOYS', NULL, NULL, '1/2\" CL 600 Body', NULL, '48852.00', '-', '-', '-', '-', '-', '3135833.62', NULL, '-', '-', '-', '-', '-', '48852.00', '-', NULL, '-', NULL, '48852.00', NULL, '0290/24-25', '2025-03-20', '1', 'CK/P/25-26/.-001110226', 'CK/P/25-26/.-001-2026', '3');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `joborder_No`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (4, '2025-04-09', '2025-04-09', '-', 'CK/P/25-26/.-026', '', 11, 'Sri Ayyappa Engineering Works', NULL, NULL, 'Coal Nozzle ', NULL, '171100.00', '-', '-', '-', '-', '-', '171100', NULL, '-', '-', '-', '-', '-', '171100.00', '-', NULL, '-', NULL, '171100.00', NULL, 'SA003/25-26', '2025-04-09', '1', 'CK/P/25-26/.-026120226', 'CK/P/25-26/.-026-2026', '4');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `joborder_No`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (7, '2025-05-05', '2025-05-05', '-', 'CK/P/25-26/.-026', '', 0, 'PREMIER ALLOYS', NULL, NULL, '1/2\\\" CL 600 Body||1/2\\\" CL 600 Body||1/2\\\" CL 600 Body||1/2\\\" CL 600 Body||1/2\\\" CL 600 Body||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Out', NULL, '263518.00', '-', '-', '-', '-', '-', '3399351.62', NULL, '-', '-', '-', '-', '-', '3304.00||4130.00||4130.00||1652.00||826.00||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78', '-', NULL, '-', NULL, '263518.00', NULL, '0026/25-26', '2025-05-05', '1', 'CK/P/25-26/.-026180226', 'CK/P/25-26/.-026-2026', '5');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `joborder_No`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (8, '2025-05-05', '2025-05-05', '-', 'CK/P/25-26/.-026', '', 0, 'PKS Inspection Service', NULL, NULL, 'Inspection', NULL, '2360.00', '-', '-', '-', '-', '-', '2360', NULL, '-', '-', '-', '-', '-', '2360.00', '-', NULL, '-', NULL, '2360.00', NULL, 'PKS/09/25-26', '2025-05-05', '1', 'CK/P/25-26/.-026180226', 'CK/P/25-26/.-026-2026', '6');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `joborder_No`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (9, '2025-05-09', '2025-05-09', '-', 'CK/P/25-26/005', '', 11, 'Sri Ayyappa Engineering Works', NULL, NULL, '4\" 1500 Body', NULL, '9440.00', '-', '-', '-', '-', '-', '180540', NULL, '-', '-', '-', '-', '-', '9440.00', '-', NULL, '-', NULL, '9440.00', NULL, 'SA010/25-26', '2025-05-09', '1', 'CK/P/25-26/005180226', 'CK/P/25-26/005-2026', '7');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `joborder_No`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (10, '2025-05-29', '2025-05-29', '-', 'CK/P/25-26/006', '', 11, 'Sri Ayyappa Engineering Works', NULL, NULL, 'Retainer 3.0 Pattern||Retainer 2.0  Pattern', NULL, '84960.00', '-', '-', '-', '-', '-', '265500', NULL, '-', '-', '-', '-', '-', '37760.00||47200.00', '-', NULL, '-', NULL, '84960.00', NULL, 'SA012/25-26', '2025-05-29', '1', 'CK/P/25-26/006180226', 'CK/P/25-26/006-2026', '8');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `joborder_No`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (11, '2025-06-01', '2025-06-01', '-', 'CK/P/25-26/007', '', 12, 'PKS Inspection Service', NULL, NULL, 'Inspection', NULL, '2360.00', '-', '-', '-', '-', '-', '4720', NULL, '-', '-', '-', '-', '-', '2360.00', '-', NULL, '-', NULL, '2360.00', NULL, 'PKS/11/25-26', '2025-06-01', '1', 'CK/P/25-26/007180226', 'CK/P/25-26/007-2026', '9');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `joborder_No`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (18, '2025-06-07', '2025-06-07', '-', 'CK/P/25-26/008', '', 14, 'Shree Kumaran Alloys', NULL, NULL, '4\" 1500 Body||4\" 1500 Body', NULL, '215070.00', '-', '-', '-', '-', '-', '215070', NULL, '-', '-', '-', '-', '-', '129041.85||86027.90', '-', NULL, '-', NULL, '215070.00', NULL, 'D0138/25-26', '2025-06-07', '1', 'CK/P/25-26/008250226', 'CK/P/25-26/008-2026', '16');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `joborder_No`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (21, '2025-06-09', '2025-06-09', '-', 'CK/P/25-26/009', '', 14, 'Shree Kumaran Alloys', NULL, NULL, 'TEST BAR(300mmX50mmX50mm)', NULL, '2478.00', '-', '-', '-', '-', '-', '217548', NULL, '-', '-', '-', '-', '-', '2478.00', '-', NULL, '-', NULL, '2478.00', NULL, 'D0139/25-26', '2025-06-09', '1', 'CK/P/25-26/009250226', 'CK/P/25-26/009-2026', '19');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `joborder_No`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (22, '2025-06-21', '2025-06-21', '-', 'CK/P/25-26/010', '', 8, 'PREMIER ALLOYS', NULL, NULL, '12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||LH Inner Box||LH Inner Box||LH ', NULL, '434205.00', '-', '-', '-', '-', '-', '3833556.62', NULL, '-', '-', '-', '-', '-', '19753.20||19753.20||19753.20||19753.20||19753.20||19753.20||19753.20||14814.90||14814.90||14814.90||14814.90||14814.90||19753.20||14814.90||9364.48||14046.72||14046.72||14046.72||14046.72||14046.72||14046.72||14046.72||14046.72||4682.24||18728.96||18728.9', '-', NULL, '-', NULL, '434205.00', NULL, 'PA/0054/25-26', '2025-06-21', '1', 'CK/P/25-26/010020326', 'CK/P/25-26/010-2026', '20');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `joborder_No`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (23, '2025-06-27', '2025-06-27', '-', 'CK/P/25-26/011', '', 8, 'PREMIER ALLOYS', NULL, NULL, 'LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||12FN Top Plate', NULL, '183449.00', '-', '-', '-', '-', '-', '4017005.62', NULL, '-', '-', '-', '-', '-', '13388.28||13388.28||13388.28||4462.76||13388.28||8925.52||17851.04||13388.28||8925.52||17851.04||13388.28||13388.28||13388.28||13388.28||4938.30', '-', NULL, '-', NULL, '183449.00', NULL, 'PA/0063/25-26', '2025-06-27', '1', 'CK/P/25-26/011020326', 'CK/P/25-26/011-2026', '21');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `joborder_No`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (24, '2025-07-03', '2025-07-03', '-', 'CK/P/25-26/012', '', 8, 'PREMIER ALLOYS', NULL, NULL, 'Retainer 2.0||Retainer 2.0||Retainer 2.0||Retainer 2.0||Retainer 3.0', NULL, '304822.00', '-', '-', '-', '-', '-', '4321827.62', NULL, '-', '-', '-', '-', '-', '43924.32||87848.64||43924.32||87848.64||41276.40', '-', NULL, '-', NULL, '304822.00', NULL, 'PA/0074/25-26', '2025-07-03', '1', 'CK/P/25-26/012030326', 'CK/P/25-26/012-2026', '22');
INSERT INTO `po_party_statements` (`id`, `date`, `purchasedate`, `receiptno`, `purchaseno`, `joborder_No`, `supplierId`, `suppliername`, `mobileno`, `address`, `itemname`, `qty`, `total`, `currentpaid`, `purpose`, `payment`, `paid`, `paidamount`, `balance`, `paymentmode`, `throughcheck`, `chequeno`, `chamount`, `banktransfer`, `bankamount`, `amount`, `paymentdetails`, `openingbalance`, `receiptamt`, `returnamount`, `purchaseamt`, `formtype`, `invoiceno`, `invoicedate`, `status`, `purchasenodate`, `purchasenoyear`, `purchaseid`) VALUES (25, '2025-07-10', '2025-07-10', '-', 'CK/P/25-26/013', '', 8, 'PREMIER ALLOYS', NULL, NULL, 'Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collecto', NULL, '1417912.00', '-', '-', '-', '-', '-', '5739739.62', NULL, '-', '-', '-', '-', '-', '14179.12||28358.23||42537.35||56716.46||28358.23||42537.35||42537.35||56716.46||56716.46||42537.35||56716.46||28358.23||56716.46||42537.35||56716.46||42537.35||56716.46||56716.46||56716.46||56716.46||56716.46||42537.35||56716.46||42537.35||56716.46||56716', '-', NULL, '-', NULL, '1417912.00', NULL, 'PA/0081/25-26', '2025-07-10', '1', 'CK/P/25-26/013030326', 'CK/P/25-26/013-2026', '23');


#
# TABLE STRUCTURE FOR: po_party_statements_backup
#

DROP TABLE IF EXISTS `po_party_statements_backup`;

CREATE TABLE `po_party_statements_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `currentpaid` varchar(255) NOT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `openingbalance` varchar(225) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `purchaseamt` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: preference_details
#

DROP TABLE IF EXISTS `preference_details`;

CREATE TABLE `preference_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `sed` varchar(255) DEFAULT NULL,
  `edc` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: preference_settings
#

DROP TABLE IF EXISTS `preference_settings`;

CREATE TABLE `preference_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotationPrefix` varchar(255) NOT NULL,
  `quotation` varchar(255) NOT NULL,
  `expenses` varchar(255) NOT NULL,
  `expensePrefix` varchar(255) NOT NULL,
  `dc` varchar(255) NOT NULL,
  `voucherPrefix` varchar(255) NOT NULL,
  `voucher` varchar(255) NOT NULL,
  `debitPrefix` varchar(255) NOT NULL,
  `debit` varchar(255) NOT NULL,
  `creditPrefix` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `purchasePrefix` varchar(255) NOT NULL,
  `purchase` varchar(255) NOT NULL,
  `invoicePrefix` varchar(255) NOT NULL,
  `invoice` varchar(255) NOT NULL,
  `salesdcPrefix` varchar(255) NOT NULL,
  `materialdcPrefix` varchar(255) NOT NULL,
  `jobdcPrefix` varchar(255) NOT NULL,
  `proforma_invoicePrefix` varchar(255) NOT NULL,
  `proforma_invoice` varchar(255) NOT NULL,
  `inwardPrefix` varchar(255) NOT NULL,
  `inward` varchar(255) NOT NULL,
  `cashbillPrefix` varchar(255) NOT NULL,
  `cashbill_invoice` varchar(255) NOT NULL,
  `mtcPrefix` varchar(100) NOT NULL,
  `tcno` varchar(100) NOT NULL,
  `insPrefix` varchar(100) NOT NULL,
  `insno` varchar(100) NOT NULL,
  `utPrefix` varchar(100) NOT NULL,
  `utno` varchar(100) NOT NULL,
  `mptPrefix` varchar(100) NOT NULL,
  `mptno` varchar(100) NOT NULL,
  `dptPrefix` varchar(100) NOT NULL,
  `dptno` varchar(100) NOT NULL,
  `creditnote` varchar(255) DEFAULT NULL,
  `po_prefix` varchar(50) NOT NULL,
  `purchaseorder` varchar(255) NOT NULL,
  `spo_prefix` varchar(50) NOT NULL,
  `supplierpurchaseorder` varchar(100) NOT NULL,
  `jobworkdc` varchar(255) DEFAULT NULL,
  `materialdc` varchar(255) DEFAULT NULL,
  `cmp_companyname` varchar(255) NOT NULL,
  `cmp_phoneno` varchar(255) NOT NULL,
  `cmp_mobileno` varchar(255) NOT NULL,
  `cmp_address1` varchar(255) NOT NULL,
  `cmp_address2` varchar(255) NOT NULL,
  `cmp_city` varchar(255) NOT NULL,
  `cmp_pincode` varchar(255) NOT NULL,
  `cmp_stateCode` varchar(255) NOT NULL,
  `cmp_website` varchar(255) NOT NULL,
  `cmp_emailid` varchar(255) NOT NULL,
  `cmp_logo` varchar(255) NOT NULL,
  `cont_companyname` varchar(255) NOT NULL,
  `cont_phoneno` varchar(255) NOT NULL,
  `cont_mobileno` varchar(255) NOT NULL,
  `cont_address1` varchar(255) NOT NULL,
  `cont_address2` varchar(255) NOT NULL,
  `cont_city` varchar(255) NOT NULL,
  `cont_pincode` varchar(255) NOT NULL,
  `cont_stateCode` varchar(255) NOT NULL,
  `cont_website` varchar(255) NOT NULL,
  `cont_emailid` varchar(255) NOT NULL,
  `cont_logo` varchar(255) NOT NULL,
  `discountBy` varchar(255) NOT NULL,
  `invoiceBy` varchar(255) NOT NULL,
  `itemType` varchar(255) NOT NULL,
  `bill_type` varchar(255) DEFAULT NULL,
  `quot_bill_type` varchar(255) DEFAULT NULL,
  `voucher_receivable` varchar(255) DEFAULT NULL,
  `voucher_payable` varchar(255) DEFAULT NULL,
  `last_backup` date NOT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `inward_add` varchar(255) NOT NULL,
  `cashbill_add` varchar(255) NOT NULL,
  `cashbill_tax_type` varchar(255) NOT NULL,
  `priceType` varchar(255) DEFAULT NULL,
  `priceType1` varchar(255) DEFAULT NULL,
  `sales_dc` int(11) NOT NULL,
  `material_dc` int(11) NOT NULL,
  `jobwork_dc` int(11) NOT NULL,
  `cpo_type` varchar(255) NOT NULL,
  `spo_type` varchar(255) NOT NULL,
  `proforma_type` varchar(255) NOT NULL,
  `attendance` int(11) NOT NULL,
  `status` int(10) NOT NULL,
  `einvoice` int(11) NOT NULL,
  `eway` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `preference_settings` (`id`, `quotationPrefix`, `quotation`, `expenses`, `expensePrefix`, `dc`, `voucherPrefix`, `voucher`, `debitPrefix`, `debit`, `creditPrefix`, `credit`, `purchasePrefix`, `purchase`, `invoicePrefix`, `invoice`, `salesdcPrefix`, `materialdcPrefix`, `jobdcPrefix`, `proforma_invoicePrefix`, `proforma_invoice`, `inwardPrefix`, `inward`, `cashbillPrefix`, `cashbill_invoice`, `mtcPrefix`, `tcno`, `insPrefix`, `insno`, `utPrefix`, `utno`, `mptPrefix`, `mptno`, `dptPrefix`, `dptno`, `creditnote`, `po_prefix`, `purchaseorder`, `spo_prefix`, `supplierpurchaseorder`, `jobworkdc`, `materialdc`, `cmp_companyname`, `cmp_phoneno`, `cmp_mobileno`, `cmp_address1`, `cmp_address2`, `cmp_city`, `cmp_pincode`, `cmp_stateCode`, `cmp_website`, `cmp_emailid`, `cmp_logo`, `cont_companyname`, `cont_phoneno`, `cont_mobileno`, `cont_address1`, `cont_address2`, `cont_city`, `cont_pincode`, `cont_stateCode`, `cont_website`, `cont_emailid`, `cont_logo`, `discountBy`, `invoiceBy`, `itemType`, `bill_type`, `quot_bill_type`, `voucher_receivable`, `voucher_payable`, `last_backup`, `itemcode`, `inward_add`, `cashbill_add`, `cashbill_tax_type`, `priceType`, `priceType1`, `sales_dc`, `material_dc`, `jobwork_dc`, `cpo_type`, `spo_type`, `proforma_type`, `attendance`, `status`, `einvoice`, `eway`) VALUES (1, 'Q', '001', '001', 'E', '001', 'CK/V/25-26/-', '001', 'D', '001', 'C', '001', 'CK/P/25-26/', '', 'CK/INV/25-26/-', '', 'CK/DC/25-26/-', 'CK/MDC/25-26/-', 'CK/PDC/25-26/-', 'CK/PI/25-26/-', '001', 'CK/I/25-26/-', '', 'CB', '001', 'MTC/25-26/', '', 'CK/CIR/', '', 'CK/UT', '001', 'CK/MPT', '001', 'CK/DPT', '001', NULL, 'CK/WO/25-26/-', '', 'CK/PUR/25-26/-', '', '', '001', 'Myoffice Solutions', '7373333321', '8608701222', ' #91 Dr. Jaganathan Nagar', 'Civil Aerodrome Post, Coimbatore', 'Coimbatore', '641014', '33', 'www.idreamdevelopers.org', 'info@idreamdevelopers.com', '12832299_1579401915712151_5416626780361493206_n.png', 'IDREAMDEVELOPERS', '7373333321', '8608701333', ' #91 Dr. Jaganathan Nagar', 'Civil Aerodrome Post, Coimbatore', 'Coimbatore', '641014', '33', 'www.idreamdevelopers.com', 'info@idreamdevelopers.com', 'idream_logo.PNG', 'amount_wise', 'without_stock', 'with_item', 'Overall Tax', 'Overall Tax', 'Without Invoice', 'Without Purchase', '2025-03-01', '1', 'With Inward', 'Without Cashbill', 'Overall Tax', '1', '0', 1, 0, 3, 'Overall Tax', 'Overall Tax', 'Overall Tax', 0, 1, 0, 0);


#
# TABLE STRUCTURE FOR: profile
#

DROP TABLE IF EXISTS `profile`;

CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `companyname` varchar(255) DEFAULT NULL,
  `softwarename` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `stateCode` varchar(255) NOT NULL,
  `emailid` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `gstin` varchar(225) DEFAULT NULL,
  `aadharno` varchar(225) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `bankname` varchar(255) DEFAULT NULL,
  `accountno` varchar(255) DEFAULT NULL,
  `bankbranch` varchar(255) DEFAULT NULL,
  `ifsccode` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `profile` (`id`, `date`, `companyname`, `softwarename`, `mobileno`, `phoneno`, `address1`, `address2`, `city`, `pincode`, `stateCode`, `emailid`, `website`, `tinno`, `cstno`, `gstin`, `aadharno`, `status`, `username`, `password`, `bankname`, `accountno`, `bankbranch`, `ifsccode`, `state`) VALUES (1, NULL, 'CK PRIME ALLOYS', 'MYOFFICE ERP', '9790153461', '9159531600', 'SF.NO:845B, Door No:1J(4) Annur road, Rayarpalayam', ' Karumathampatti', 'Coimbatore', '641659', 'TamilNadu', 'ckprimealloys@gmail.com', 'www.ckprimealloys.com', '12345', '54321', '33CGRPR4623R1ZI', '', '1', 'admin', 'admin001', 'City Union Bank', '510909010332667 ', 'Somanur Branch', 'CIUB0000097', NULL);


#
# TABLE STRUCTURE FOR: proforma_invoice_details
#

DROP TABLE IF EXISTS `proforma_invoice_details`;

CREATE TABLE `proforma_invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `dcnos` longtext DEFAULT NULL,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: proforma_invoice_details_backup
#

DROP TABLE IF EXISTS `proforma_invoice_details_backup`;

CREATE TABLE `proforma_invoice_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `dcno` longtext DEFAULT NULL,
  `bill_type` varchar(255) NOT NULL,
  `invoicetype` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `deliveryat` varchar(225) DEFAULT NULL,
  `transportmode` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(225) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `dcnos` longtext DEFAULT NULL,
  `insertid` varchar(225) DEFAULT NULL,
  `deliveryid` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) NOT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `invoicenodate` varchar(225) DEFAULT NULL,
  `invoicenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: proforma_invoice_reports
#

DROP TABLE IF EXISTS `proforma_invoice_reports`;

CREATE TABLE `proforma_invoice_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `dcdate` date DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `billtype` varchar(255) DEFAULT NULL,
  `deliveryat` varchar(255) DEFAULT NULL,
  `vehicleno` varchar(255) DEFAULT NULL,
  `dcno` varchar(255) DEFAULT NULL,
  `orderdate` date DEFAULT NULL,
  `orderno` varchar(255) DEFAULT NULL,
  `despatch` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: proinvoice_party_statement
#

DROP TABLE IF EXISTS `proinvoice_party_statement`;

CREATE TABLE `proinvoice_party_statement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiptno` varchar(255) DEFAULT NULL,
  `paid` varchar(255) NOT NULL,
  `receiptid` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) NOT NULL,
  `cstno` varchar(255) NOT NULL,
  `phoneno` varchar(255) NOT NULL,
  `tinno` varchar(255) NOT NULL,
  `itemname` varchar(255) NOT NULL,
  `item_desc` text NOT NULL,
  `rate` varchar(255) NOT NULL,
  `qty` varchar(255) NOT NULL,
  `credit` varchar(255) DEFAULT NULL,
  `debit` varchar(255) DEFAULT NULL,
  `amount` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `receiptdate` date NOT NULL,
  `invoicedate` date NOT NULL,
  `totalamount` varchar(255) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `balanceamount` varchar(255) NOT NULL,
  `payamount` varchar(255) NOT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `paidamount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `returnamount` varchar(255) DEFAULT NULL,
  `formtype` varchar(255) DEFAULT NULL,
  `invoicenoyear` varchar(255) DEFAULT NULL,
  `invoicenodate` varchar(255) DEFAULT NULL,
  `invoiceid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: purchase_collection
#

DROP TABLE IF EXISTS `purchase_collection`;

CREATE TABLE `purchase_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `date_po` date NOT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` varchar(255) DEFAULT NULL,
  `receiptdate` date DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `receiptno` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `totalamount` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `alreadypaid` varchar(255) DEFAULT NULL,
  `alreadybalance` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `bankamount` varchar(255) NOT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `currentlypaid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `receiptamt` varchar(255) DEFAULT NULL,
  `payment` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `invoiceamt` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: purchase_details
#

DROP TABLE IF EXISTS `purchase_details`;

CREATE TABLE `purchase_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchasetype` varchar(100) NOT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `purchaseorderno` longtext NOT NULL,
  `purchaseorder` longtext NOT NULL,
  `poRecordId` varchar(100) NOT NULL,
  `joborder_No` varchar(100) NOT NULL,
  `JO_RecordId` int(11) NOT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `heatno` longtext DEFAULT NULL,
  `itemid` text DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `weight` longtext NOT NULL,
  `grade` longtext NOT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (3, '2026-02-11', '2025-03-20', '2025-03-20', 'purchase Order', 'CK/P/25-26/-001', 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0290/24-25', 'CK/PUR/25-26/-002', '-', '10', '', 0, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '73259930', 'CA16', 'P0213', '3', '1/2\" CL 600 Body', 'NOS', '3.45', '1', '600', '20', '41400.00', '0', 'amount_wise', '0.00', '41400.00', '9', '3726.00', '9', '3726.00', '18', '7452.00', '48852.00', '48852.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '48852.00', 'CK/P/25-26/.-001110226', 'CK/P/25-26/.-001-2026', 1, '48852.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (4, '2026-02-12', '2025-04-09', '2025-04-09', 'purchase Order', 'CK/P/25-26/002', 11, 'Sri Ayyappa Engineering Works', '4/348C,Kallipalayam Road, Chikarampalayam, Karamadai, Coimbatore, Tamil Nadu', 'SA003/25-26', 'CK/PUR/25-26/-001', '', '15', '', 0, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '84803000', 'SP01', '', '', 'Coal Nozzle ', 'NOS', '1', '1', '145000', '1', '145000.00', '0', 'amount_wise', '0.00', '145000.00', '9', '13050.00', '9', '13050.00', '18', '26100.00', '171100.00', '171100.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '171100.00', 'CK/P/25-26/.-026120226', 'CK/P/25-26/.-026-2026', 1, '171100.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (5, '2026-02-12', '2025-05-05', '2025-05-05', 'purchase Order', 'CK/P/25-26/003', 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', 'CK/PUR/25-26/-004||CK/PUR/25-26/-004||CK/PUR/25-26/-004||CK/PUR/25-26/-004||CK/PUR/25-26/-004||CK/PUR/25-26/-005||CK/PUR/25-26/-005||CK/PUR/25-26/-005||CK/PUR/25-26/-005||CK/PUR/25-26/-005||CK/PUR/25-', 'CAD2025405 REV 01||CAD2025405 REV 01||CAD2025405 REV 01||CAD2025405 REV 01||CAD2025405 REV 01||PO-SC-2526-008||PO-SC-2526-008||PO-SC-2526-008||PO-SC-2526-008||PO-SC-2526-008||PO-SC-2526-008||PO-SC-252', '12||12||12||12||12||14||14||14||14||14||14||14||14||14||14||14||14||14||14||14||14||14||14||14||14', '', 0, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999', 'CA16||CA16||CA16||CA16||CA16||CA16||CA16||CA16||CA16||CA16||CA16||CA16||CA16||CA16||CA16||CA16||CA16||CA16||CA16||CA16||SBM08||SBM08||SBM08||SBM08||SBM08||SBM08||SBM08||SBM08||SBM08||SBM08||SBM08||SBM08||SBM08||SBM08||SBM08||SBM08||SBM08||SBM08||SBM08||SB', 'P0412||P0424||P0425||P0426||P0443||P0464||P0470||P0471||P0472||P0473||P0474||P0475||P0476||P0477||P0478||P0479||P0481||P0482||P0483||P0484||P0485||P0495||P0496||P0497||P0498', '3||3||3||3||3||||||||||||||||||||||||||||||||||||||||', '1/2\\\" CL 600 Body||1/2\\\" CL 600 Body||1/2\\\" CL 600 Body||1/2\\\" CL 600 Body||1/2\\\" CL 600 Body||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box||EH Outer Box', 'NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS', '3.5||3.5||3.5||3.5||3.5||34.1||34.1||34.1||34.1||34.1||34.1||34.1||34.1||34.1||34.1||34.1||34.1||34.1||34.1||34.1||34.1||34.1||34.1||34.1||34.1', '2||2||2||2||2||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1', '200||200||200||200||200||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155', '4||5||5||2||1||2||2||2||2||2||2||2||2||2||2||2||2||2||2||2||2||2||2||2||2', '2800.00||3500.00||3500.00||1400.00||700.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00', '0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0', 'amount_wise', '||||||||||||||||||||||||||||||||||||||||||||||||', '2800.00||3500.00||3500.00||1400.00||700.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00||10571.00', '9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9', '252.00||315.00||315.00||126.00||63.00||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39', '9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9', '252.00||315.00||315.00||126.00||63.00||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39||951.39', '18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18', '504.00||630.00||630.00||252.00||126.00||1902.78||1902.78||1902.78||1902.78||1902.78||1902.78||1902.78||1902.78||1902.78||1902.78||1902.78||1902.78||1902.78||1902.78||1902.78||1902.78||1902.78||1902.78||1902.78||1902.78', '3304.00||4130.00||4130.00||1652.00||826.00||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78||12473.78', '263517.60', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0.40', '1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1', '263518.00', 'CK/P/25-26/.-026120226', 'CK/P/25-26/.-026-2026', 1, '263518.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (6, '2026-02-12', '2025-05-05', '2025-05-05', 'Direct Purchase', 'CK/P/25-26/004', 12, 'PKS Inspection Service', '83A Pudukadu 2nd Street,Sivanathapuram, Vellakovil-638111,Kangeyam Taluk, Tiruppur, Tamil Nadu', 'PKS/09/25-26', '', '', '', '', 0, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '', '001', '', '17', 'Inspection', 'NOS', '1', '', '2000', '1', '2000.00', '0', 'amount_wise', '', '2000.00', '9', '180.00', '9', '180.00', '18', '360.00', '2360.00', '2360.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '2360.00', 'CK/P/25-26/.-026120226', 'CK/P/25-26/.-026-2026', 1, '2360.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (7, '2026-02-18', '2025-05-09', '2025-05-09', 'purchase Order', 'CK/P/25-26/005', 11, 'Sri Ayyappa Engineering Works', '4/348C,Kallipalayam Road, Chikarampalayam, Karamadai, Coimbatore, Tamil Nadu', 'SA010/25-26', 'CK/PUR/25-26/-008', '', '62', '', 0, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '84803000', 'CA02', '', '', '4\" 1500 Body', 'NOS', '1', '1', '8000', '1', '8000.00', '0', 'amount_wise', '0.00', '8000.00', '9', '720.00', '9', '720.00', '18', '1440.00', '9440.00', '9440.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '9440.00', 'CK/P/25-26/005180226', 'CK/P/25-26/005-2026', 1, '9440.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (8, '2026-02-18', '2025-05-29', '2025-05-29', 'purchase Order', 'CK/P/25-26/006', 11, 'Sri Ayyappa Engineering Works', '4/348C,Kallipalayam Road, Chikarampalayam, Karamadai, Coimbatore, Tamil Nadu', 'SA012/25-26', 'CK/PUR/25-26/-010||CK/PUR/25-26/-010', '||', '58||57', '', 0, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '84803000||84803000', 'OMI 02||OMI 01', '||', '||', 'Retainer 3.0 Pattern||Retainer 2.0  Pattern', 'NOS||NOS', '1||1', '1||1', '32000||40000', '1||1', '32000.00||40000.00', '0||0', 'amount_wise', '0.00||0.00', '32000.00||40000.00', '9||9', '2880.00||3600.00', '9||9', '2880.00||3600.00', '18||18', '5760.00||7200.00', '37760.00||47200.00', '84960.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1||1', '84960.00', 'CK/P/25-26/006180226', 'CK/P/25-26/006-2026', 1, '84960.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (9, '2026-02-18', '2025-06-01', '2025-06-01', 'Direct Purchase', 'CK/P/25-26/007', 12, 'PKS Inspection Service', '83A Pudukadu 2nd Street,Sivanathapuram, Vellakovil-638111,Kangeyam Taluk, Tiruppur, Tamil Nadu', 'PKS/11/25-26', '', '', '', '', 0, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '998898', '001', '', '17', 'Inspection', 'NOS', '1', '7', '2000', '1', '2000.00', '0', 'amount_wise', '0', '2000.00', '9', '180.00', '9', '180.00', '18', '360.00', '2360.00', '2360.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '2360.00', 'CK/P/25-26/007180226', 'CK/P/25-26/007-2026', 1, '2360.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (16, '2026-02-25', '2025-06-07', '2025-06-07', 'purchase Order', 'CK/P/25-26/008', 14, 'Shree Kumaran Alloys', 'S/F No - 461, Telungupalayam Road,, Ellapalayam Post,Annur, Coimbatore, Tamil Nadu', 'D0138/25-26', 'CK/PUR/25-26/-009||CK/PUR/25-26/-009', 'CAD2025363 REV01||CAD2025363 REV01', '56||56', '', 0, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '73259999||73259999', 'CA02||CA02', '33801||33817', '||', '4\"1500 Body||4\"1500 Body', 'NOS||NOS', '208.3||208.3', '1||1', '175||175', '3||2', '109357.50||72905.00', '0||0', 'amount_wise', '0.00||0.00', '109357.50||72905.00', '9||9', '9842.18||6561.45', '9||9', '9842.18||6561.45', '18||18', '19684.35||13122.90', '129041.85||86027.90', '215069.75', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0.25', '1||1', '215070.00', 'CK/P/25-26/008250226', 'CK/P/25-26/008-2026', 1, '215070.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (19, '2026-02-25', '2025-06-09', '2025-06-09', 'Direct Purchase', 'CK/P/25-26/009', 14, 'Shree Kumaran Alloys', 'S/F No - 461, Telungupalayam Road,, Ellapalayam Post,Annur, Coimbatore, Tamil Nadu', 'D0139/25-26', '', '', '', '', 0, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '73259999', 'TB1', '33801', '23', 'TEST BAR(300mmX50mmX50mm)', 'NOS', '6', '2', '175', '2', '2100.00', '0', 'amount_wise', '0', '2100.00', '9', '189.00', '9', '189.00', '18', '378.00', '2478.00', '2478.00', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0', '1', '2478.00', 'CK/P/25-26/009250226', 'CK/P/25-26/009-2026', 1, '2478.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (20, '2026-03-02', '2025-06-21', '2025-06-21', 'purchase Order', 'CK/P/25-26/010', 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007||CK/PUR/25-26/-007||CK/PUR/25-26/-007||CK/PUR/25-26/-007||CK/PUR/25-26/-007||CK/PUR/25-26/-007||CK/PUR/25-26/-007||CK/PUR/25-26/-007||CK/PUR/25-26/-007||CK/PUR/25-26/-007||CK/PUR/25-', 'PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-25', '54||54||54||54||54||54||54||54||54||54||54||54||54||54||53||53||53||53||53||53||53||53||53||53||53||', '', 0, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999', 'SBM10||SBM10||SBM10||SBM10||SBM10||SBM10||SBM10||SBM10||SBM10||SBM10||SBM10||SBM10||SBM10||SBM10||SBM05||SBM05||SBM05||SBM05||SBM05||SBM05||SBM05||SBM05||SBM05||SBM05||SBM05||SBM05||SBM05||SBM05', 'P0546||P0580||P0582||P0583||P0584||P0588||P0589||P0591||P0592||P0595||P0600||P0607||P0608||P0612||P0545||P0585||P0586||P0587||P0590||P0596||P0597||P0598||P0599||P0601||P0602||P0603||P0604||P0607', '||||||||||||||||||||||||||||||||||||||||||||||||||||||', '12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||12FN Top Plate||LH Inner Box||LH Inner Box||LH Inner Box||LH Inner Box||LH Inner Box||LH Inner Box||LH Inner Box||LH Inner Box||LH Inner Box||LH Inner Box||LH Inner Box||LH Inner Box||LH Inner Box||LH Inner Box', 'NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS', '27||27||27||27||27||27||27||27||27||27||27||27||27||27||25.6||25.6||25.6||25.6||25.6||25.6||25.6||25.6||25.6||25.6||25.6||25.6||25.6||25.6', '1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1', '155||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155||155', '4||4||4||4||4||4||4||3||3||3||3||3||4||3||2||3||3||3||3||3||3||3||3||1||4||4||4||1', '16740.00||16740.00||16740.00||16740.00||16740.00||16740.00||16740.00||12555.00||12555.00||12555.00||12555.00||12555.00||16740.00||12555.00||7936.00||11904.00||11904.00||11904.00||11904.00||11904.00||11904.00||11904.00||11904.00||3968.00||15872.00||15872.00||15872.00||3968.00', '0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0', 'amount_wise', '0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00', '16740.00||16740.00||16740.00||16740.00||16740.00||16740.00||16740.00||12555.00||12555.00||12555.00||12555.00||12555.00||16740.00||12555.00||7936.00||11904.00||11904.00||11904.00||11904.00||11904.00||11904.00||11904.00||11904.00||3968.00||15872.00||15872.00||15872.00||3968.00', '9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9', '1506.60||1506.60||1506.60||1506.60||1506.60||1506.60||1506.60||1129.95||1129.95||1129.95||1129.95||1129.95||1506.60||1129.95||714.24||1071.36||1071.36||1071.36||1071.36||1071.36||1071.36||1071.36||1071.36||357.12||1428.48||1428.48||1428.48||357.12', '9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9', '1506.60||1506.60||1506.60||1506.60||1506.60||1506.60||1506.60||1129.95||1129.95||1129.95||1129.95||1129.95||1506.60||1129.95||714.24||1071.36||1071.36||1071.36||1071.36||1071.36||1071.36||1071.36||1071.36||357.12||1428.48||1428.48||1428.48||357.12', '18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18', '3013.20||3013.20||3013.20||3013.20||3013.20||3013.20||3013.20||2259.90||2259.90||2259.90||2259.90||2259.90||3013.20||2259.90||1428.48||2142.72||2142.72||2142.72||2142.72||2142.72||2142.72||2142.72||2142.72||714.24||2856.96||2856.96||2856.96||714.24', '19753.20||19753.20||19753.20||19753.20||19753.20||19753.20||19753.20||14814.90||14814.90||14814.90||14814.90||14814.90||19753.20||14814.90||9364.48||14046.72||14046.72||14046.72||14046.72||14046.72||14046.72||14046.72||14046.72||4682.24||18728.96||18728.96||18728.96||4682.24', '434204.60', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0.40', '1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1', '434205.00', 'CK/P/25-26/010020326', 'CK/P/25-26/010-2026', 1, '434205.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (21, '2026-03-02', '2025-06-27', '2025-06-27', 'purchase Order', 'CK/P/25-26/011', 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0063/25-26', 'CK/PUR/25-26/-007||CK/PUR/25-26/-007||CK/PUR/25-26/-007||CK/PUR/25-26/-007||CK/PUR/25-26/-007||CK/PUR/25-26/-007||CK/PUR/25-26/-007||CK/PUR/25-26/-007||CK/PUR/25-26/-007||CK/PUR/25-26/-007||CK/PUR/25-', 'PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-2526-020||PO-SC-25', '52||52||52||52||52||52||52||52||52||52||52||52||52||52||70', '', 0, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999||73259999', 'SBM03||SBM03||SBM03||SBM03||SBM03||SBM03||SBM03||SBM03||SBM03||SBM03||SBM03||SBM03||SBM03||SBM03||SBM10', 'P0579||P0635||P0641||P0612||P0636||P0642||P0613||P0637||P0660||P0630||P0638||P0694||P0634||P0640||P0694', '||||||||||||||||||||||||||||7', 'LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||LH Outer Box||12FN Top Plate', 'NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS', '24.4||24.4||24.4||24.4||24.4||24.4||24.4||24.4||24.4||24.4||24.4||24.4||24.4||24.4||27', '1||1||1||1||1||1||1||1||1||1||1||1||1||1||2', '155||155||155||155||155||155||155||155||155||155||155||155||155||155||155', '3||3||3||1||3||2||4||3||2||4||3||3||3||3||1', '11346.00||11346.00||11346.00||3782.00||11346.00||7564.00||15128.00||11346.00||7564.00||15128.00||11346.00||11346.00||11346.00||11346.00||4185.00', '0||0||0||0||0||0||0||0||0||0||0||0||0||0||0', 'amount_wise', '0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00', '11346.00||11346.00||11346.00||3782.00||11346.00||7564.00||15128.00||11346.00||7564.00||15128.00||11346.00||11346.00||11346.00||11346.00||4185.00', '9||9||9||9||9||9||9||9||9||9||9||9||9||9||9', '1021.14||1021.14||1021.14||340.38||1021.14||680.76||1361.52||1021.14||680.76||1361.52||1021.14||1021.14||1021.14||1021.14||376.65', '9||9||9||9||9||9||9||9||9||9||9||9||9||9||9', '1021.14||1021.14||1021.14||340.38||1021.14||680.76||1361.52||1021.14||680.76||1361.52||1021.14||1021.14||1021.14||1021.14||376.65', '18||18||18||18||18||18||18||18||18||18||18||18||18||18||18', '2042.28||2042.28||2042.28||680.76||2042.28||1361.52||2723.04||2042.28||1361.52||2723.04||2042.28||2042.28||2042.28||2042.28||753.30', '13388.28||13388.28||13388.28||4462.76||13388.28||8925.52||17851.04||13388.28||8925.52||17851.04||13388.28||13388.28||13388.28||13388.28||4938.30', '183448.70', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0.30', '1||1||1||1||1||1||1||1||1||1||1||1||1||1||1', '183449.00', 'CK/P/25-26/011020326', 'CK/P/25-26/011-2026', 1, '183449.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (22, '2026-03-03', '2025-07-03', '2025-07-03', 'purchase Order', 'CK/P/25-26/012', 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0074/25-26', 'CK/PUR/25-26/-012||CK/PUR/25-26/-012||CK/PUR/25-26/-012||CK/PUR/25-26/-012||CK/PUR/25-26/-012', 'OM/PO/05-25-26/01||OM/PO/05-25-26/01||OM/PO/05-25-26/01||OM/PO/05-25-26/01||OM/PO/05-25-26/01', '61||61||61||61||60', '', 0, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '73259920||73259920||73259920||73259920||73259920', 'OMI 01||OMI 01||OMI 01||OMI 01||OMI 02', 'P0662||P0690||P0693||P0697||P0674', '15||15||15||15||16', 'Retainer 2.0||Retainer 2.0||Retainer 2.0||Retainer 2.0||Retainer 3.0', 'NOS||NOS||NOS||NOS||NOS', '112.800||112.800||112.800||112.800||53', '1||1||1||1||1', '165||165||165||165||165', '2||4||2||4||4', '37224.00||74448.00||37224.00||74448.00||34980.00', '0||0||0||0||0', 'amount_wise', '0.00||0.00||0.00||0.00||0.00', '37224.00||74448.00||37224.00||74448.00||34980.00', '9||9||9||9||9', '3350.16||6700.32||3350.16||6700.32||3148.20', '9||9||9||9||9', '3350.16||6700.32||3350.16||6700.32||3148.20', '18||18||18||18||18', '6700.32||13400.64||6700.32||13400.64||6296.40', '43924.32||87848.64||43924.32||87848.64||41276.40', '304822.32', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '-0.32', '1||1||1||1||1', '304822.00', 'CK/P/25-26/012030326', 'CK/P/25-26/012-2026', 1, '304822.00', 1, 1);
INSERT INTO `purchase_details` (`id`, `date`, `purchasedate`, `invoicedate`, `purchasetype`, `purchaseno`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `heatno`, `itemid`, `itemname`, `uom`, `weight`, `grade`, `rate`, `qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `balance`, `vou_status`, `edit_status`) VALUES (23, '2026-03-03', '2025-07-10', '2025-07-10', 'purchase Order', 'CK/P/25-26/013', 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014||CK/PUR/25-26/-014', 'PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755||PO 3755', '64||64||64||64||64||64||64||64||64||64||64||64||64||64||64||64||64||64||64||64||64||64||64||64||64||', '', 0, 'intrastate', 'intrastate', 'sgst', 'cgst', '', '73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930||73259930', 'SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02||SP02', 'P0593||P0594||P0691||P0694||P0695||P0696||P0698||P0699||P0704||P0706||P0707||P0713||P0714||P0715||P0717||P0719||P0720||P0721||P0723||P0724||P0728||P0729||P0730||P0731||P0732||P0733||P0734||P0740||P0741||P0742', '12||12||12||12||12||12||12||12||12||12||12||12||12||12||12||12||12||12||12||12||12||12||12||12||12||12||12||12||12||12', 'Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting||Collector Casting', 'NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS||NOS', '28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61||28.61', '1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1', '420||420||420||420||420||420||420||420||420||420||420||420||420||420||420||420||420||420||420||420||420||420||420||420||420||420||420||420||420||420', '1||2||3||4||2||3||3||4||4||3||4||2||4||3||4||3||4||4||4||4||4||3||4||3||4||4||4||3||4||2', '12016.20||24032.40||36048.60||48064.80||24032.40||36048.60||36048.60||48064.80||48064.80||36048.60||48064.80||24032.40||48064.80||36048.60||48064.80||36048.60||48064.80||48064.80||48064.80||48064.80||48064.80||36048.60||48064.80||36048.60||48064.80||48064.80||48064.80||36048.60||48064.80||24032.40', '0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0||0', 'amount_wise', '0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00||0.00', '12016.20||24032.40||36048.60||48064.80||24032.40||36048.60||36048.60||48064.80||48064.80||36048.60||48064.80||24032.40||48064.80||36048.60||48064.80||36048.60||48064.80||48064.80||48064.80||48064.80||48064.80||36048.60||48064.80||36048.60||48064.80||48064.80||48064.80||36048.60||48064.80||24032.40', '9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9', '1081.46||2162.92||3244.37||4325.83||2162.92||3244.37||3244.37||4325.83||4325.83||3244.37||4325.83||2162.92||4325.83||3244.37||4325.83||3244.37||4325.83||4325.83||4325.83||4325.83||4325.83||3244.37||4325.83||3244.37||4325.83||4325.83||4325.83||3244.37||4325.83||2162.92', '9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9||9', '1081.46||2162.92||3244.37||4325.83||2162.92||3244.37||3244.37||4325.83||4325.83||3244.37||4325.83||2162.92||4325.83||3244.37||4325.83||3244.37||4325.83||4325.83||4325.83||4325.83||4325.83||3244.37||4325.83||3244.37||4325.83||4325.83||4325.83||3244.37||4325.83||2162.92', '18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18||18', '2162.92||4325.83||6488.75||8651.66||4325.83||6488.75||6488.75||8651.66||8651.66||6488.75||8651.66||4325.83||8651.66||6488.75||8651.66||6488.75||8651.66||8651.66||8651.66||8651.66||8651.66||6488.75||8651.66||6488.75||8651.66||8651.66||8651.66||6488.75||8651.66||4325.83', '14179.12||28358.23||42537.35||56716.46||28358.23||42537.35||42537.35||56716.46||56716.46||42537.35||56716.46||28358.23||56716.46||42537.35||56716.46||42537.35||56716.46||56716.46||56716.46||56716.46||56716.46||42537.35||56716.46||42537.35||56716.46||56716.46||56716.46||42537.35||56716.46||28358.23', '1417911.55', '', '0', '', '0', '', '0', '', '', '', '0', '', '0', '', '0', '', '', '0', '0.45', '1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1||1', '1417912.00', 'CK/P/25-26/013030326', 'CK/P/25-26/013-2026', 1, '1417912.00', 1, 1);


#
# TABLE STRUCTURE FOR: purchase_details_backup
#

DROP TABLE IF EXISTS `purchase_details_backup`;

CREATE TABLE `purchase_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `purchaseno` varchar(225) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `vou_status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: purchase_reports
#

DROP TABLE IF EXISTS `purchase_reports`;

CREATE TABLE `purchase_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseorderno` varchar(100) NOT NULL,
  `purchaseorder` varchar(100) NOT NULL,
  `poRecordId` varchar(50) NOT NULL,
  `joborder_No` varchar(100) NOT NULL,
  `JO_RecordId` int(11) NOT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `heatno` varchar(255) DEFAULT NULL,
  `weight` varchar(255) NOT NULL,
  `grade` varchar(255) NOT NULL,
  `itemid` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `create_mtc_status` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=191 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (3, '3', '2026-02-11', 'CK/P/25-26/001', '2025-03-20', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0290/24-25', 'CK/PUR/25-26/-002', '-', '10', '', 0, '2025-03-20', NULL, 'CA16', 'P0213', '3.45', '1', '3', '73259930', '1/2\" CL 600 Body', '600', '20', '48852.00', '48852.00', NULL, NULL, NULL, NULL, NULL, '48852.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-001-2026', 'CK/P/25-26/.-001110226', 2);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (4, '4', '2026-02-12', 'CK/P/25-26/002', '2025-04-09', NULL, 11, 'Sri Ayyappa Engineering Works', '4/348C,Kallipalayam Road, Chikarampalayam, Karamadai, Coimbatore, Tamil Nadu', 'SA003/25-26', 'CK/PUR/25-26/-001', '', '15', '', 0, '2025-04-09', NULL, 'SP01', '', '1', '1', '', '84803000', 'Coal Nozzle ', '145000', '1', '171100.00', '171100.00', NULL, NULL, NULL, NULL, NULL, '171100.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026120226', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (59, '8', '2026-02-18', 'CK/P/25-26/006', '2025-05-29', NULL, 11, 'Sri Ayyappa Engineering Works', '4/348C,Kallipalayam Road, Chikarampalayam, Karamadai, Coimbatore, Tamil Nadu', 'SA012/25-26', 'CK/PUR/25-26/-010', '', '57', '', 0, '2025-05-29', NULL, 'OMI 01', '', '1', '1', '', '84803000', 'Retainer 2.0  Pattern', '40000', '1', '47200.00', '84960.00', NULL, NULL, NULL, NULL, NULL, '84960.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/006-2026', 'CK/P/25-26/006180226', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (58, '8', '2026-02-18', 'CK/P/25-26/006', '2025-05-29', NULL, 11, 'Sri Ayyappa Engineering Works', '4/348C,Kallipalayam Road, Chikarampalayam, Karamadai, Coimbatore, Tamil Nadu', 'SA012/25-26', 'CK/PUR/25-26/-010', '', '58', '', 0, '2025-05-29', NULL, 'OMI 02', '', '1', '1', '', '84803000', 'Retainer 3.0 Pattern', '32000', '1', '37760.00', '84960.00', NULL, NULL, NULL, NULL, NULL, '84960.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/006-2026', 'CK/P/25-26/006180226', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (55, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'SBM08', 'P0412', '34.1', '1', '|', '73259999', 'EH Outer Box', '|', '2', '0', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (54, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'SBM08', 'P0424', '34.1', '1', '|', '73259999', 'EH Outer Box', '|', '2', '0', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (53, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'SBM08', 'P0425', '34.1', '1', '|', '73259999', 'EH Outer Box', '0', '2', '.', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (52, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'SBM08', 'P0426', '34.1', '1', '|', '73259999', 'EH Outer Box', '0', '2', '0', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (51, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'SBM08', 'P0443', '34.1', '1', '|', '73259999', 'EH Outer Box', '2', '2', '3', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (50, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0464', '34.1', '1', '|', '73259999', 'EH Outer Box', '|', '2', '1', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (49, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0470', '34.1', '1', '|', '73259999', 'EH Outer Box', '|', '2', '4', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (48, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0471', '34.1', '1', '|', '73259999', 'EH Outer Box', '0', '2', '|', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (47, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0472', '34.1', '1', '|', '73259999', 'EH Outer Box', '0', '2', '|', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (46, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0473', '34.1', '1', '|', '73259999', 'EH Outer Box', '2', '2', '0', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (45, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0474', '34.1', '1', '|', '73259999', 'EH Outer Box', '|', '2', '0', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (43, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0475', '34.1', '1', '|', '73259999', 'EH Outer Box', '0', '2', '0', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (42, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0476', '34.1', '1', '|', '73259999', 'EH Outer Box', '0', '2', '3', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (41, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0477', '34.1', '1', '|', '73259999', 'EH Outer Box', '2', '2', '1', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (40, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0478', '34.1', '1', '|', '73259999', 'EH Outer Box', '|', '2', '4', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (39, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0479', '34.1', '1', '|', '73259999', 'EH Outer Box', '|', '2', '|', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (38, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0481', '34.1', '1', '|', '73259999', 'EH Outer Box', '0', '2', '|', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (37, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0482', '34.1', '1', '|', '73259999', 'EH Outer Box', '0', '2', '0', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (36, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0483', '34.1', '1', '|', '73259999', 'EH Outer Box', '2', '2', '0', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (35, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0484', '3.5', '2', '|', '73259999', '1/2\" CL 600 Body', '|', '1', '.', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (34, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0485', '3.5', '2', '|', '73259999', '1/2\" CL 600 Body', '|', '2', '4', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (57, '7', '2026-02-18', 'CK/P/25-26/005', '2025-05-09', NULL, 11, 'Sri Ayyappa Engineering Works', '4/348C,Kallipalayam Road, Chikarampalayam, Karamadai, Coimbatore, Tamil Nadu', 'SA010/25-26', 'CK/PUR/25-26/-008', '', '62', '', 0, '2025-05-09', NULL, 'CA02', '', '1', '1', '', '84803000', '4\" 1500 Body', '8000', '1', '9440.00', '9440.00', NULL, NULL, NULL, NULL, NULL, '9440.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/005-2026', 'CK/P/25-26/005180226', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (33, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0495', '3.5', '2', '3', '73259999', '1/2\" CL 600 Body', '0', '5', '0', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (32, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0496', '3.5', '2', '3', '73259999', '1/2\" CL 600 Body', '0', '5', '3', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (56, '6', '2026-02-18', 'CK/P/25-26/004', '2025-05-05', NULL, 12, 'PKS Inspection Service', '83A Pudukadu 2nd Street,Sivanathapuram, Vellakovil-638111,Kangeyam Taluk, Tiruppur, Tamil Nadu', 'PKS/09/25-26', '', '', '', '', 0, '2025-05-05', NULL, '001', NULL, '1', '', '7', '', 'Inspection', '2', '1', '2', '2360.00', NULL, NULL, NULL, NULL, NULL, '2360.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (44, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', '', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0497', '34.1', '1', '|', '73259999', 'EH Outer Box', '|', '2', '.', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (31, '5', '2026-02-18', 'CK/P/25-26/003', '2025-05-05', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0026/25-26', '', 'CAD2025405 REV 01', '', '', 0, '2025-05-05', NULL, 'CA16', 'P0498', '3.5', '2', '3', '73259999', '1/2\" CL 600 Body', '2', '4', '3', '263517.60', NULL, NULL, NULL, NULL, NULL, '263518.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/.-026-2026', 'CK/P/25-26/.-026180226', NULL);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (60, '9', '2026-02-18', 'CK/P/25-26/007', '2025-06-01', NULL, 12, 'PKS Inspection Service', '83A Pudukadu 2nd Street,Sivanathapuram, Vellakovil-638111,Kangeyam Taluk, Tiruppur, Tamil Nadu', 'PKS/11/25-26', '', '', '', '', 0, '2025-06-01', NULL, '001', '', '1', '7', '17', '998898', 'Inspection', '2000', '1', '2360.00', '2360.00', NULL, NULL, NULL, NULL, NULL, '2360.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/007-2026', 'CK/P/25-26/007180226', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (108, '16', '2026-02-25', 'CK/P/25-26/008', '2025-06-07', NULL, 14, 'Shree Kumaran Alloys', 'S/F No - 461, Telungupalayam Road,, Ellapalayam Post,Annur, Coimbatore, Tamil Nadu', 'D0138/25-26', 'CK/PUR/25-26/-009', 'CAD2025363 REV01', '56', '', 0, '2025-06-07', NULL, 'CA02', '33801', '208.3', '1', '18', '73259999', '4\" 1500 Body', '175', '3', '129041.85', '215069.75', NULL, NULL, NULL, NULL, NULL, '215070.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/008-2026', 'CK/P/25-26/008250226', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (109, '16', '2026-02-25', 'CK/P/25-26/008', '2025-06-07', NULL, 14, 'Shree Kumaran Alloys', 'S/F No - 461, Telungupalayam Road,, Ellapalayam Post,Annur, Coimbatore, Tamil Nadu', 'D0138/25-26', 'CK/PUR/25-26/-009', 'CAD2025363 REV01', '56', '', 0, '2025-06-07', NULL, 'CA02', '33817', '208.3', '1', '18', '73259999', '4\" 1500 Body', '175', '2', '86027.90', '215069.75', NULL, NULL, NULL, NULL, NULL, '215070.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/008-2026', 'CK/P/25-26/008250226', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (112, '19', '2026-02-25', 'CK/P/25-26/009', '2025-06-09', NULL, 14, 'Shree Kumaran Alloys', 'S/F No - 461, Telungupalayam Road,, Ellapalayam Post,Annur, Coimbatore, Tamil Nadu', 'D0139/25-26', '', '', '', '', 0, '2025-06-09', NULL, 'TB1', '33801', '6', '2', '23', '73259999', 'TEST BAR(300mmX50mmX50mm)', '175', '2', '2478.00', '2478.00', NULL, NULL, NULL, NULL, NULL, '2478.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/009-2026', 'CK/P/25-26/009250226', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (113, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '54', '', 0, '2025-06-21', NULL, 'SBM10', 'P0546', '27', '1', '7', '73259999', '12FN Top Plate', '155', '4', '19753.20', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (114, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '54', '', 0, '2025-06-21', NULL, 'SBM10', 'P0580', '27', '1', '7', '73259999', '12FN Top Plate', '155', '4', '19753.20', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (115, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '54', '', 0, '2025-06-21', NULL, 'SBM10', 'P0582', '27', '1', '7', '73259999', '12FN Top Plate', '155', '4', '19753.20', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (116, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '54', '', 0, '2025-06-21', NULL, 'SBM10', 'P0583', '27', '1', '7', '73259999', '12FN Top Plate', '155', '4', '19753.20', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (117, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '54', '', 0, '2025-06-21', NULL, 'SBM10', 'P0584', '27', '1', '7', '73259999', '12FN Top Plate', '155', '4', '19753.20', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (118, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '54', '', 0, '2025-06-21', NULL, 'SBM10', 'P0588', '27', '1', '7', '73259999', '12FN Top Plate', '155', '4', '19753.20', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (119, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '54', '', 0, '2025-06-21', NULL, 'SBM10', 'P0589', '27', '1', '7', '73259999', '12FN Top Plate', '155', '4', '19753.20', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (120, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '54', '', 0, '2025-06-21', NULL, 'SBM10', 'P0591', '27', '1', '7', '73259999', '12FN Top Plate', '155', '3', '14814.90', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (121, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '54', '', 0, '2025-06-21', NULL, 'SBM10', 'P0592', '27', '1', '7', '73259999', '12FN Top Plate', '155', '3', '14814.90', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (122, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '54', '', 0, '2025-06-21', NULL, 'SBM10', 'P0595', '27', '1', '7', '73259999', '12FN Top Plate', '155', '3', '14814.90', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (123, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '54', '', 0, '2025-06-21', NULL, 'SBM10', 'P0600', '27', '1', '7', '73259999', '12FN Top Plate', '155', '3', '14814.90', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (124, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '54', '', 0, '2025-06-21', NULL, 'SBM10', 'P0607', '27', '1', '7', '73259999', '12FN Top Plate', '155', '3', '14814.90', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (125, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '54', '', 0, '2025-06-21', NULL, 'SBM10', 'P0608', '27', '1', '7', '73259999', '12FN Top Plate', '155', '4', '19753.20', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (126, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '54', '', 0, '2025-06-21', NULL, 'SBM10', 'P0612', '27', '1', '7', '73259999', '12FN Top Plate', '155', '3', '14814.90', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (127, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '53', '', 0, '2025-06-21', NULL, 'SBM05', 'P0545', '25.6', '1', '6', '73259999', 'LH Inner Box', '155', '2', '9364.48', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (128, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '53', '', 0, '2025-06-21', NULL, 'SBM05', 'P0585', '25.6', '1', '6', '73259999', 'LH Inner Box', '155', '3', '14046.72', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (129, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '53', '', 0, '2025-06-21', NULL, 'SBM05', 'P0586', '25.6', '1', '6', '73259999', 'LH Inner Box', '155', '3', '14046.72', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (130, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '53', '', 0, '2025-06-21', NULL, 'SBM05', 'P0587', '25.6', '1', '6', '73259999', 'LH Inner Box', '155', '3', '14046.72', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (131, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '53', '', 0, '2025-06-21', NULL, 'SBM05', 'P0590', '25.6', '1', '6', '73259999', 'LH Inner Box', '155', '3', '14046.72', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (132, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '53', '', 0, '2025-06-21', NULL, 'SBM05', 'P0596', '25.6', '1', '6', '73259999', 'LH Inner Box', '155', '3', '14046.72', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (133, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '53', '', 0, '2025-06-21', NULL, 'SBM05', 'P0597', '25.6', '1', '6', '73259999', 'LH Inner Box', '155', '3', '14046.72', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (134, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '53', '', 0, '2025-06-21', NULL, 'SBM05', 'P0598', '25.6', '1', '6', '73259999', 'LH Inner Box', '155', '3', '14046.72', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (135, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '53', '', 0, '2025-06-21', NULL, 'SBM05', 'P0599', '25.6', '1', '6', '73259999', 'LH Inner Box', '155', '3', '14046.72', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (136, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '53', '', 0, '2025-06-21', NULL, 'SBM05', 'P0601', '25.6', '1', '6', '73259999', 'LH Inner Box', '155', '1', '4682.24', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (137, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '53', '', 0, '2025-06-21', NULL, 'SBM05', 'P0602', '25.6', '1', '6', '73259999', 'LH Inner Box', '155', '4', '18728.96', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (138, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '53', '', 0, '2025-06-21', NULL, 'SBM05', 'P0603', '25.6', '1', '6', '73259999', 'LH Inner Box', '155', '4', '18728.96', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (139, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '53', '', 0, '2025-06-21', NULL, 'SBM05', 'P0604', '25.6', '1', '6', '73259999', 'LH Inner Box', '155', '4', '18728.96', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (140, '20', '2026-03-02', 'CK/P/25-26/010', '2025-06-21', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0054/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '53', '', 0, '2025-06-21', NULL, 'SBM05', 'P0607', '25.6', '1', '6', '73259999', 'LH Inner Box', '155', '1', '4682.24', '434204.60', NULL, NULL, NULL, NULL, NULL, '434205.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/010-2026', 'CK/P/25-26/010020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (141, '21', '2026-03-02', 'CK/P/25-26/011', '2025-06-27', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0063/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '52', '', 0, '2025-06-27', NULL, 'SBM03', 'P0579', '24.4', '1', '5', '73259999', 'LH Outer Box', '155', '3', '13388.28', '183448.70', NULL, NULL, NULL, NULL, NULL, '183449.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/011-2026', 'CK/P/25-26/011020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (142, '21', '2026-03-02', 'CK/P/25-26/011', '2025-06-27', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0063/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '52', '', 0, '2025-06-27', NULL, 'SBM03', 'P0635', '24.4', '1', '5', '73259999', 'LH Outer Box', '155', '3', '13388.28', '183448.70', NULL, NULL, NULL, NULL, NULL, '183449.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/011-2026', 'CK/P/25-26/011020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (143, '21', '2026-03-02', 'CK/P/25-26/011', '2025-06-27', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0063/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '52', '', 0, '2025-06-27', NULL, 'SBM03', 'P0641', '24.4', '1', '5', '73259999', 'LH Outer Box', '155', '3', '13388.28', '183448.70', NULL, NULL, NULL, NULL, NULL, '183449.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/011-2026', 'CK/P/25-26/011020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (144, '21', '2026-03-02', 'CK/P/25-26/011', '2025-06-27', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0063/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '52', '', 0, '2025-06-27', NULL, 'SBM03', 'P0612', '24.4', '1', '5', '73259999', 'LH Outer Box', '155', '1', '4462.76', '183448.70', NULL, NULL, NULL, NULL, NULL, '183449.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/011-2026', 'CK/P/25-26/011020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (145, '21', '2026-03-02', 'CK/P/25-26/011', '2025-06-27', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0063/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '52', '', 0, '2025-06-27', NULL, 'SBM03', 'P0636', '24.4', '1', '5', '73259999', 'LH Outer Box', '155', '3', '13388.28', '183448.70', NULL, NULL, NULL, NULL, NULL, '183449.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/011-2026', 'CK/P/25-26/011020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (146, '21', '2026-03-02', 'CK/P/25-26/011', '2025-06-27', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0063/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '52', '', 0, '2025-06-27', NULL, 'SBM03', 'P0642', '24.4', '1', '5', '73259999', 'LH Outer Box', '155', '2', '8925.52', '183448.70', NULL, NULL, NULL, NULL, NULL, '183449.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/011-2026', 'CK/P/25-26/011020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (147, '21', '2026-03-02', 'CK/P/25-26/011', '2025-06-27', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0063/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '52', '', 0, '2025-06-27', NULL, 'SBM03', 'P0613', '24.4', '1', '5', '73259999', 'LH Outer Box', '155', '4', '17851.04', '183448.70', NULL, NULL, NULL, NULL, NULL, '183449.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/011-2026', 'CK/P/25-26/011020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (148, '21', '2026-03-02', 'CK/P/25-26/011', '2025-06-27', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0063/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '52', '', 0, '2025-06-27', NULL, 'SBM03', 'P0637', '24.4', '1', '5', '73259999', 'LH Outer Box', '155', '3', '13388.28', '183448.70', NULL, NULL, NULL, NULL, NULL, '183449.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/011-2026', 'CK/P/25-26/011020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (149, '21', '2026-03-02', 'CK/P/25-26/011', '2025-06-27', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0063/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '52', '', 0, '2025-06-27', NULL, 'SBM03', 'P0660', '24.4', '1', '5', '73259999', 'LH Outer Box', '155', '2', '8925.52', '183448.70', NULL, NULL, NULL, NULL, NULL, '183449.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/011-2026', 'CK/P/25-26/011020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (150, '21', '2026-03-02', 'CK/P/25-26/011', '2025-06-27', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0063/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '52', '', 0, '2025-06-27', NULL, 'SBM03', 'P0630', '24.4', '1', '5', '73259999', 'LH Outer Box', '155', '4', '17851.04', '183448.70', NULL, NULL, NULL, NULL, NULL, '183449.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/011-2026', 'CK/P/25-26/011020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (151, '21', '2026-03-02', 'CK/P/25-26/011', '2025-06-27', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0063/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '52', '', 0, '2025-06-27', NULL, 'SBM03', 'P0638', '24.4', '1', '5', '73259999', 'LH Outer Box', '155', '3', '13388.28', '183448.70', NULL, NULL, NULL, NULL, NULL, '183449.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/011-2026', 'CK/P/25-26/011020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (152, '21', '2026-03-02', 'CK/P/25-26/011', '2025-06-27', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0063/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '52', '', 0, '2025-06-27', NULL, 'SBM03', 'P0694', '24.4', '1', '5', '73259999', 'LH Outer Box', '155', '3', '13388.28', '183448.70', NULL, NULL, NULL, NULL, NULL, '183449.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/011-2026', 'CK/P/25-26/011020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (153, '21', '2026-03-02', 'CK/P/25-26/011', '2025-06-27', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0063/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '52', '', 0, '2025-06-27', NULL, 'SBM03', 'P0634', '24.4', '1', '5', '73259999', 'LH Outer Box', '155', '3', '13388.28', '183448.70', NULL, NULL, NULL, NULL, NULL, '183449.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/011-2026', 'CK/P/25-26/011020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (154, '21', '2026-03-02', 'CK/P/25-26/011', '2025-06-27', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0063/25-26', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', '52', '', 0, '2025-06-27', NULL, 'SBM03', 'P0640', '24.4', '1', '5', '73259999', 'LH Outer Box', '155', '3', '13388.28', '183448.70', NULL, NULL, NULL, NULL, NULL, '183449.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/011-2026', 'CK/P/25-26/011020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (155, '21', '2026-03-02', 'CK/P/25-26/011', '2025-06-27', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0063/25-26', 'CK/PUR/25-26/-007', '5', '70', '', 0, '2025-06-27', NULL, 'SBM10', 'P0694', '27', '2', '7', '73259999', '12FN Top Plate', '155', '1', '4938.30', '183448.70', NULL, NULL, NULL, NULL, NULL, '183449.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/011-2026', 'CK/P/25-26/011020326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (156, '22', '2026-03-03', 'CK/P/25-26/012', '2025-07-03', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0074/25-26', 'CK/PUR/25-26/-012', 'OM/PO/05-25-26/01', '61', '', 0, '2025-07-03', NULL, 'OMI 01', 'P0662', '112.800', '1', '15', '73259920', 'Retainer 2.0', '165', '2', '43924.32', '304822.32', NULL, NULL, NULL, NULL, NULL, '304822.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/012-2026', 'CK/P/25-26/012030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (157, '22', '2026-03-03', 'CK/P/25-26/012', '2025-07-03', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0074/25-26', 'CK/PUR/25-26/-012', 'OM/PO/05-25-26/01', '61', '', 0, '2025-07-03', NULL, 'OMI 01', 'P0690', '112.800', '1', '15', '73259920', 'Retainer 2.0', '165', '4', '87848.64', '304822.32', NULL, NULL, NULL, NULL, NULL, '304822.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/012-2026', 'CK/P/25-26/012030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (158, '22', '2026-03-03', 'CK/P/25-26/012', '2025-07-03', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0074/25-26', 'CK/PUR/25-26/-012', 'OM/PO/05-25-26/01', '61', '', 0, '2025-07-03', NULL, 'OMI 01', 'P0693', '112.800', '1', '15', '73259920', 'Retainer 2.0', '165', '2', '43924.32', '304822.32', NULL, NULL, NULL, NULL, NULL, '304822.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/012-2026', 'CK/P/25-26/012030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (159, '22', '2026-03-03', 'CK/P/25-26/012', '2025-07-03', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0074/25-26', 'CK/PUR/25-26/-012', 'OM/PO/05-25-26/01', '61', '', 0, '2025-07-03', NULL, 'OMI 01', 'P0697', '112.800', '1', '15', '73259920', 'Retainer 2.0', '165', '4', '87848.64', '304822.32', NULL, NULL, NULL, NULL, NULL, '304822.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/012-2026', 'CK/P/25-26/012030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (160, '22', '2026-03-03', 'CK/P/25-26/012', '2025-07-03', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0074/25-26', 'CK/PUR/25-26/-012', 'OM/PO/05-25-26/01', '60', '', 0, '2025-07-03', NULL, 'OMI 02', 'P0674', '53', '1', '16', '73259920', 'Retainer 3.0', '165', '4', '41276.40', '304822.32', NULL, NULL, NULL, NULL, NULL, '304822.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/012-2026', 'CK/P/25-26/012030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (161, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0593', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '1', '14179.12', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (162, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0594', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '2', '28358.23', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (163, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0691', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '3', '42537.35', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (164, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0694', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '4', '56716.46', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (165, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0695', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '2', '28358.23', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (166, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0696', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '3', '42537.35', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (167, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0698', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '3', '42537.35', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (168, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0699', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '4', '56716.46', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (169, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0704', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '4', '56716.46', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (170, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0706', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '3', '42537.35', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (171, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0707', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '4', '56716.46', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (172, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0713', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '2', '28358.23', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (173, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0714', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '4', '56716.46', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (174, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0715', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '3', '42537.35', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (175, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0717', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '4', '56716.46', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (176, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0719', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '3', '42537.35', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (177, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0720', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '4', '56716.46', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (178, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0721', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '4', '56716.46', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (179, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0723', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '4', '56716.46', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (180, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0724', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '4', '56716.46', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (181, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0728', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '4', '56716.46', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (182, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0729', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '3', '42537.35', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (183, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0730', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '4', '56716.46', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (184, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0731', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '3', '42537.35', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (185, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0732', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '4', '56716.46', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (186, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0733', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '4', '56716.46', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (187, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0734', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '4', '56716.46', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (188, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0740', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '3', '42537.35', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (189, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0741', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '4', '56716.46', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);
INSERT INTO `purchase_reports` (`id`, `purchaseid`, `date`, `purchaseno`, `purchasedate`, `paymenttype`, `supplierId`, `suppliername`, `address`, `invoiceno`, `purchaseorderno`, `purchaseorder`, `poRecordId`, `joborder_No`, `JO_RecordId`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `weight`, `grade`, `itemid`, `hsnno`, `itemname`, `rate`, `qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `create_mtc_status`) VALUES (190, '23', '2026-03-03', 'CK/P/25-26/013', '2025-07-10', NULL, 8, 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', 'PA/0081/25-26', 'CK/PUR/25-26/-014', 'PO 3755', '64', '', 0, '2025-07-10', NULL, 'SP02', 'P0742', '28.61', '1', '12', '73259930', 'Collector Casting', '420', '2', '28358.23', '1417911.55', NULL, NULL, NULL, NULL, NULL, '1417912.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/P/25-26/013-2026', 'CK/P/25-26/013030326', 1);


#
# TABLE STRUCTURE FOR: purchaseorder_details
#

DROP TABLE IF EXISTS `purchaseorder_details`;

CREATE TABLE `purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `deliverydate` varchar(100) NOT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemid` varchar(255) DEFAULT NULL,
  `itemcode` longtext DEFAULT NULL,
  `heatno` text DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `item_desc` text NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `uom` longtext DEFAULT NULL,
  `weight` varchar(100) NOT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `balanceqty` longtext DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` longtext NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` longtext DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `oa_status` int(11) NOT NULL,
  `oa_deliverydate` varchar(255) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  `invoice_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=DYNAMIC;

INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (1, '2026-02-10', '2025-03-06', '2025-03-06', '30-04-2025', 'Direct PO', 'CK/WO/25-26/-001', 'PO3704', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '84803000||73259930', '1||2', 'SP01||SP01', NULL, 'Coal Nozzle ||Coal Nozzle(C)', '||', 'C-13-004||C-13-004', '6||5', 'NOS||NOS', '-||95.2', '200000||590', '1||4', '1||4', '', 'NaN||224672.00', '0||0', 'amount_wise', '||', 'NaN||224672.00', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1', NULL, 'CK/WO/25-26/-001100226', 'CK/WO/25-26/-001-2026', 1, 2, '30-04-2025||30-04-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (6, '2026-02-11', '2025-03-18', '2025-03-12', '30-04-2025', 'Direct PO', 'CK/WO/25-26/-002', '-', NULL, 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '73259930', '3', 'CA16', NULL, '1/2\" CL 600 Body', '', '-', '1', 'NOS', '3', '1250', '20', '20||20', '', '75000.00', '0', 'amount_wise', '0', '75000.00', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, 'CK/WO/25-26/-002110226', 'CK/WO/25-26/-002-2026', 1, 2, '30-03-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (7, '2026-02-11', '2025-03-18', '2025-03-18', '30-05-2025', 'Direct PO', 'CK/WO/25-26/-003', 'CAD2025405 REV 01', NULL, 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '73259999', '3', 'CA16', NULL, '1/2\" CL 600 Body', '', '-', '2', 'NOS', '3', '350', '20', '20', '', '21000.00', '0', 'amount_wise', '0', '21000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, 'CK/WO/25-26/-003110226', 'CK/WO/25-26/-003-2026', 1, 2, '30-05-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (8, '2026-02-12', '2025-04-10', '2025-04-10', '10-06-2025', 'Direct PO', 'CK/WO/25-26/-004', 'PO-SC-2526-008', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '73259999', '4', 'SBM08', NULL, 'EH Outer Box', '', 'ST-MSC-017', '2', 'NOS', '33.9', '167', '40', '40', '', '226452.00', '0', 'amount_wise', '0', '226452.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, 'CK/WO/25-26/-004120226', 'CK/WO/25-26/-004-2026', 1, 2, '10-06-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (9, '2026-02-12', '2025-04-24', '2025-04-25', '20-06-2025', 'Direct PO', 'CK/WO/25-26/-005', 'PO-SC-2526-020', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '73259999||73259999||73259999', '5||6||7', 'SBM03||SBM05||SBM10', NULL, 'LH Outer Box||LH Inner Box||12FN Top Plate', '||||', 'ST-MSC-016||ST-MSC-014-R1||STMSC022 R1', '2||2||2', 'NOS||NOS||NOS', '24.6||26.1||27', '167||167||167', '40||40||50', '40||40||50', '', '164328.00||174348.00||225450.00', '0||0||0', 'amount_wise', '0||0||0', '164328.00||174348.00||225450.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1||1', NULL, 'CK/WO/25-26/-005120226', 'CK/WO/25-26/-005-2026', 1, 2, '30-05-2025||04-06-2025||10-06-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (10, '2026-02-13', '2025-04-26', '2025-04-27', '15-06-2025', 'Direct PO', 'CK/WO/25-26/-006', 'CAD2025363 REV01', NULL, 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '73259999', '18', 'CA02', NULL, '4\" 1500 Body', '', 'CAD-SPS-YST-0001', '2', 'NOS', '212', '220', '5', '5', '', '233200.00', '0', 'amount_wise', '0', '233200.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, 'CK/WO/25-26/-006130226', 'CK/WO/25-26/-006-2026', 1, 2, '15-06-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (11, '2026-02-13', '2025-05-01', '2025-05-01', '30-05-2025', 'Direct PO', 'CK/WO/25-26/-007', '1', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '998898', '17', '001', NULL, 'Inspection', '', '-', '7', 'NOS', '1', '2000', '1', '1', '', '2000.00', '0', 'amount_wise', '0', '2000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, 'CK/WO/25-26/-007130226', 'CK/WO/25-26/-007-2026', 1, 2, '30-05-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (12, '2026-02-13', '2025-05-05', '2025-05-05', '30-05-2025', 'Direct PO', 'CK/WO/25-26/-008', '2', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '84803000', '18', 'CA02', NULL, '4\" 1500 Body', '', 'CAD-SPS-YST-0001', '6', 'NOS', '1', '8000', '1', '1', '', '8000.00', '0', 'amount_wise', '0', '8000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, 'CK/WO/25-26/-008130226', 'CK/WO/25-26/-008-2026', 1, 2, '30-05-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (13, '2026-02-13', '2025-05-12', '2025-05-12', '12-07-2025', 'Direct PO', 'CK/WO/25-26/-009', 'OM/PO/05-25-26/01', NULL, 15, 'OM Industries', 'No:230/2, 4Th Cross,, Vanapadi Road,Sipcot, Ranipet, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '73259920||73259920||84803000||84803000', '15||||||', 'OMI 01||OMI 02||OMI 01||OMI 02', NULL, 'Retainer 2.0||Retainer 3.0||Retainer 2.0  Pattern||Retainer 3.0 Pattern', '||||with Match Plate||with Match Plate', '2.067398||3.062269||2.067398||3.062269', '3||3||6||6', 'NOS||NOS||NOS||NOS', '103||49||1||1', '185||185||45500||35000', '12||4||1||1', '12', '', '228660.00||36260.00||45500.00||35000.00', '0||0||0||0', 'amount_wise', '0||||0||0', '228660.00||36260.00||45500.00||35000.00', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1||1||1', NULL, 'CK/WO/25-26/-009130226', 'CK/WO/25-26/-009-2026', 1, 2, '12-07-2025||12-07-2025||12-07-2025||12-07-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (14, '2026-02-14', '2025-05-13', '2025-05-13', '20-05-2025', 'Direct PO', 'CK/WO/25-26/-010', 'PO 3742', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '73259930', '12', 'SP02', NULL, 'Collector Casting', '', '3-SPG-9473', '4', 'NOS', '29.5', '542', '4', '4', '', '63956.00', '0', 'amount_wise', '0', '63956.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, 'CK/WO/25-26/-010140226', 'CK/WO/25-26/-010-2026', 1, 2, '24-06-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (16, '2026-02-14', '2025-05-20', '2025-05-20', '20-06-2025', 'Direct PO', 'CK/WO/25-26/-011', '3', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '84803000', '21', 'SP03', NULL, 'Collector Casting 3-SPG-8557', '1 Set Aluminium Pattern with Match Plate for Rework', '3-SPG-8557', '6', 'NOS', '1', '9500', '1', '1', '', '9500.00', '0', 'amount_wise', '0', '9500.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, 'CK/WO/25-26/-011140226', 'CK/WO/25-26/-011-2026', 1, 2, '20-06-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (19, '2026-02-14', '2025-06-05', '2025-06-05', '31-07-2025', 'Direct PO', 'CK/WO/25-26/-013', 'PO-2526-0333', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '73259999||73259999||73259999', '8||9||11', 'SBM02||SBM04||SBM09', NULL, 'NH Outer Box||NH Inner Box||Moving Block', '||||', 'ST-MSC-015||ST-MSC-013 R1||ST-MSC-012 R1', '2||2||2', 'NOS||NOS||NOS', '27.2||28.3||10.85', '167||167||167', '40||40||100', '40||40||100', '', '181696.00||189044.00||181195.00', '0||0||0', 'amount_wise', '0||0||0', '181696.00||189044.00||181195.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1||1', NULL, 'CK/WO/25-26/-013140226', 'CK/WO/25-26/-013-2026', 1, 2, '17-07-2025||25-07-2025||31-07-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (18, '2026-02-14', '2025-06-03', '2025-06-03', '30-07-2025', 'Direct PO', 'CK/WO/25-26/-012', 'PO 3755', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '73259930', '12', 'SP02', NULL, 'Collector Casting', '', '3-SPG-9473', '4', 'NOS', '27.8', '539', '348', '348', '', '5214501.60', '0', 'amount_wise', '0', '5214501.60', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, 'CK/WO/25-26/-012140226', 'CK/WO/25-26/-012-2026', 1, 2, '30-07-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (20, '2026-02-14', '2025-06-16', '2025-06-16', '10-07-2025', 'Direct PO', 'CK/WO/25-26/-014', '3757', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '73259930', '13', 'SP03', NULL, 'Collector Casting 8557', '', '3-SPG-8557 ', '4', 'NOS', '31', '542', '128', '128', '', '2150656.00', '0', 'amount_wise', '0', '2150656.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, 'CK/WO/25-26/-014140226', 'CK/WO/25-26/-014-2026', 1, 2, '30-07-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (21, '2026-02-14', '2025-06-23', '2025-06-23', '30-07-2025', 'Direct PO', 'CK/WO/25-26/-015', '4', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '998898', '22', 'WC1', NULL, 'Website Creation', 'Domain (1 year)         Hosting 1 GB(1 year)       6 Pages responsive Design        Watsapp Integration     Social Media Integration  Mobile Responsive Design', '-', '7', 'NOS', '1', '6000', '1', '1', '', '6000.00', '0', 'amount_wise', '0', '6000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, 'CK/WO/25-26/-015140226', 'CK/WO/25-26/-015-2026', 1, 2, '30-07-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (22, '2026-02-16', '2025-07-08', '2025-07-09', '02-09-2025', 'Direct PO', 'CK/WO/25-26/-016', 'PO-SC-2526-097', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '73259999||73259999', '5||6', 'SBM03||SBM05', NULL, 'LH Outer Box||LH Inner Box', '||', 'ST-MSC-016||ST-MSC-014-R1', '2||2', 'NOS||NOS', '24.6||26.1', '167||167', '40||40', '40||40', '', '164328.00||174348.00', '0||0', 'amount_wise', '0||0', '164328.00||174348.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1', NULL, 'CK/WO/25-26/-016160226', 'CK/WO/25-26/-016-2026', 1, 2, '19-08-2025||29-08-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (23, '2026-02-25', '2025-06-09', '2025-06-09', '09-06-2025', 'Direct PO', 'CK/WO/25-26/-017', 'CAD2025363', NULL, 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '73259999||84803000', '23||24', 'TB1||PR1', NULL, 'TEST BAR(300mmX50mmX50mm)||Pattern Rework Cost', '||||', '-||-||', '2||6', 'NOS||NOS', '6||1', '175||9500|', '2||1', '2||1', '', '2100.00||9500.00', '0||0', 'amount_wise', '0||0||0', '2100.00||9500.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1||1', NULL, 'CK/WO/25-26/-017250226', 'CK/WO/25-26/-017-2026', 1, 2, '09-06-2025||09-06-2025', 1, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (31, '2026-03-05', '2025-08-21', '2025-08-21', '21-08-2025', 'Direct PO', 'CK/WO/25-26/-025', '10', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '84803000||84803000||84803000||84803000||84803000', '4||8||9||10||11', 'SBM08||SBM02||SBM04||SBM15||SBM09', NULL, 'EH Outer Box||NH Outer Box||NH Inner Box||EH Inner Box||Moving Block', '1 Set Aluminium Pattern Finishing||1 Set Aluminium Pattern Finishing||1 Set Aluminium Pattern Finishing||1 Set Aluminium Pattern Finishing||1 Nos Aluminium Corebox(New)', 'ST-MSC-017||ST-MSC-015||ST-MSC-013 R1||ST-MSC-027 R0||ST-MSC-012 R1', '6||6||6||6||6', 'NOS||NOS||NOS||NOS||NOS', '1||1||1||1||1', '5000||5000||5000||5000||12000', '1||1||1||1||1', '1||1||1||1||1', '', '5000.00||5000.00||5000.00||5000.00||12000.00', '0||0||0||0||0', 'amount_wise', '0||0||0||0||0', '5000.00||5000.00||5000.00||5000.00||12000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1||1||1||1', NULL, 'CK/WO/25-26/-025050326', 'CK/WO/25-26/-025-2026', 1, 2, '10-09-2025||10-09-2025||10-09-2025||10-09-2025||10-09-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (25, '2026-03-04', '2025-08-05', '2025-08-05', '06-10-2025', 'Direct PO', 'CK/WO/25-26/-019', 'PO-2526-0628', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '73259999||73259999||73259999||73259999||73259999', '8||9||6||5||11', 'SBM02||SBM04||SBM05||SBM03||SBM09', NULL, 'NH Outer Box||NH Inner Box||LH Inner Box||LH Outer Box||Moving Block', '||||||||', 'ST-MSC-015||ST-MSC-013 R1||ST-MSC-014-R1||ST-MSC-016||ST-MSC-012 R1', '2||2||2||2||2', 'NOS||NOS||NOS||NOS||NOS', '27.2||28.3||26.1||24.6||10.85', '167||167||167||167||167', '40||40||45||30||60', '40||40||45||30||60', '', '181696.00||189044.00||196141.50||123246.00||108717.00', '0||0||0||0||0', 'amount_wise', '0||0||0||0||0', '181696.00||189044.00||196141.50||123246.00||108717.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1||1||1||1', NULL, 'CK/WO/25-26/-019040326', 'CK/WO/25-26/-019-2026', 1, 2, '16-09-2025||20-09-2025||23-09-2025||26-09-2025||30-09-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (26, '2026-03-04', '2025-07-17', '2025-07-17', '04-03-2026', 'Direct PO', 'CK/WO/25-26/-020', '6', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '998898', '26', 'SW1', NULL, 'Customized ERP Software ', 'Cloud/Online Version Including 1st Year Server AMC', '-', '7', 'NOS', '1', '30000', '1', '1', '', '30000.00', '0', 'amount_wise', '0', '30000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, 'CK/WO/25-26/-020040326', 'CK/WO/25-26/-020-2026', 1, 2, '30-03-2026', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (27, '2026-03-04', '2025-07-20', '2025-07-20', '05-08-2025', 'Direct PO', 'CK/WO/25-26/-021', '7', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '84803000||84803000', '27||21', 'SP02||SP03', NULL, 'Collector Casting 3-SPG-9473||Collector Casting 3-SPG-8557', '1 Set Aluminium Pattern With Match Plate For Rework & finishing. MatchPlate Remounting Putty Finishing||1 Set Aluminium Pattern With Match Plate For Rework & finishing. MatchPlate Remounting Putty Finishing', '3-SPG-9473||3-SPG-8557', '6||6', 'NOS||NOS', '1||1', '30000||30000', '1||1', '1||1', '', '30000.00||30000.00', '0||0', 'amount_wise', '0||0', '30000.00||30000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1', NULL, 'CK/WO/25-26/-021040326', 'CK/WO/25-26/-021-2026', 1, 2, '10-08-2025||10-08-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (28, '2026-03-05', '2025-08-05', '2025-08-05', '10-09-2025', 'Direct PO', 'CK/WO/25-26/-022', '8', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '73259930', '28', 'EP01', NULL, 'Casing EO8-250', '', '005.01.2086-0', '8', 'NOS', '250', '600', '3', '3', '', '450000.00', '0', 'amount_wise', '0', '450000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, 'CK/WO/25-26/-022050326', 'CK/WO/25-26/-022-2026', 1, 2, '10-09-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (29, '2026-03-05', '2025-08-11', '2025-08-11', '30-09-2025', 'Direct PO', 'CK/WO/25-26/-023', '3801', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '73259930', '13', 'SP03', NULL, 'Collector Casting 8557', '', '3-SPG-8557 REV01', '4', 'NOS', '31', '542', '60', '60', '', '1008120.00', '0', 'amount_wise', '0', '1008120.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, 'CK/WO/25-26/-023050326', 'CK/WO/25-26/-023-2026', 1, 2, '30-09-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (30, '2026-03-05', '2025-08-20', '2025-08-20', '20-08-2025', 'Direct PO', 'CK/WO/25-26/-024', '9', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '84803000||84803000', '29||30', '-||-', NULL, 'Aluminium Plate Alloy 20mmX1160X575mm||115mmX260X150mm', '||', '-||-', '6||6', 'KGS||KGS', '37.5||28', '475||500', '1||1', '1||1', '', '17812.50||14000.00', '0||0', 'amount_wise', '0||0', '17812.50||14000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1', NULL, 'CK/WO/25-26/-024050326', 'CK/WO/25-26/-024-2026', 1, 2, '25-08-2025||25-08-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (32, '2026-03-05', '2025-08-30', '2025-08-30', '31-10-2025', 'Direct PO', 'CK/WO/25-26/-026', '3811', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '73259930', '13', 'SP03', NULL, 'Collector Casting 8557', '', '3-SPG-8557 Rev-01', '4', 'NOS', '31', '542', '240', '240', '', '4032480.00', '0', 'amount_wise', '0', '4032480.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', NULL, 'CK/WO/25-26/-026050326', 'CK/WO/25-26/-026-2026', 1, 2, '30-10-2025', 2, 1);
INSERT INTO `purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `customerId`, `customername`, `address`, `invoiceno`, `billtype`, `gsttype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemid`, `itemcode`, `heatno`, `itemname`, `item_desc`, `drawingno`, `grade`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `oa_status`, `oa_deliverydate`, `edit_status`, `invoice_status`) VALUES (33, '2026-03-06', '2026-03-06', '2026-03-06', '06-03-2026', 'Direct PO', 'CK/WO/25-26/-027', '0027', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', 'intrastate', 'intrastate', NULL, NULL, NULL, '73259930||', '29||26', '-||SW1', NULL, 'Aluminium Plate Alloy 20mmX1160X575mm||Customized ERP Software ', 'a||b', '0027||-', '1||', 'KGS||NOS', '20||10', '475||30000', '20||20', '20||20', '', '190000.00||6000000.00', '0||0', 'amount_wise', '0||0', '190000.00||6000000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1||1', NULL, 'CK/WO/25-26/-027060326', 'CK/WO/25-26/-027-2026', 1, 2, '31-03-2026||31-03-2026', 2, 1);


#
# TABLE STRUCTURE FOR: purchaseorder_details_backup
#

DROP TABLE IF EXISTS `purchaseorder_details_backup`;

CREATE TABLE `purchaseorder_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: purchaseorder_reports
#

DROP TABLE IF EXISTS `purchaseorder_reports`;

CREATE TABLE `purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `heatno` text DEFAULT NULL,
  `itemid` text DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `weight` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `workorderbalance` varchar(100) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `oa_status` int(11) NOT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (4, '1', '2026-02-10', '', 'CK/WO/25-26/-001', 'PO3704', NULL, '2025-03-06', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', NULL, '2025-03-06', NULL, 'SP01', NULL, '2', '73259930', 'Coal Nozzle(C)', '', 'NOS', '95.2', '5', 'C-13-004', '590', '4', '4', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-001-2026', 'CK/WO/25-26/-001100226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (3, '1', '2026-02-10', '', 'CK/WO/25-26/-001', 'PO3704', NULL, '2025-03-06', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', NULL, '2025-03-06', NULL, 'SP01', NULL, '1', '84803000', 'Coal Nozzle ', '', 'NOS', '-', '6', 'C-13-004', '200000', '1', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-001-2026', 'CK/WO/25-26/-001100226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (15, '6', '2026-02-11', '', 'CK/WO/25-26/-002', '-', NULL, '2015-09-17', NULL, 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', NULL, '2025-03-12', NULL, 'CA16', NULL, '3', '73259930', '1/2\" CL 600 Body', '', 'NOS', '3', '1', '-', '1250', '20', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-002-2026', 'CK/WO/25-26/-002110226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (16, '7', '2026-02-11', 'Direct PO', 'CK/WO/25-26/-003', 'CAD2025405 REV 01', NULL, '2025-03-18', NULL, 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', '0', '2025-03-18', NULL, 'CA16', NULL, '3', '73259999', '1/2\" CL 600 Body', '', 'NOS', '3', '2', '-', '350', '20', '3', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-003-2026', 'CK/WO/25-26/-003110226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (17, '8', '2026-02-12', 'Direct PO', 'CK/WO/25-26/-004', 'PO-SC-2526-008', NULL, '2025-04-10', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', '2025-04-10', NULL, 'SBM08', NULL, '4', '73259999', 'EH Outer Box', '', 'NOS', '33.9', '2', 'ST-MSC-017', '167', '40', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-004-2026', 'CK/WO/25-26/-004120226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (18, '9', '2026-02-12', 'Direct PO', 'CK/WO/25-26/-005', 'PO-SC-2526-020', NULL, '2025-04-24', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', '2025-04-25', NULL, 'SBM03', NULL, '5', '73259999', 'LH Outer Box', '', 'NOS', '24.6', '2', 'ST-MSC-016', '167', '40', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-005-2026', 'CK/WO/25-26/-005120226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (19, '9', '2026-02-12', 'Direct PO', 'CK/WO/25-26/-005', 'PO-SC-2526-020', NULL, '2025-04-24', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', '2025-04-25', NULL, 'SBM05', NULL, '6', '73259999', 'LH Inner Box', '', 'NOS', '26.1', '2', 'ST-MSC-014-R1', '167', '40', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-005-2026', 'CK/WO/25-26/-005120226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (20, '9', '2026-02-12', 'Direct PO', 'CK/WO/25-26/-005', 'PO-SC-2526-020', NULL, '2025-04-24', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', '2025-04-25', NULL, 'SBM10', NULL, '7', '73259999', '12FN Top Plate', '', 'NOS', '27', '2', 'STMSC022 R1', '167', '50', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-005-2026', 'CK/WO/25-26/-005120226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (21, '10', '2026-02-13', 'Direct PO', 'CK/WO/25-26/-006', 'CAD2025363 REV01', NULL, '2025-04-26', NULL, 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', '0', '2025-04-27', NULL, 'CA02', NULL, '18', '73259999', '4\" 1500 Body', '', 'NOS', '212', '2', 'CAD-SPS-YST-0001', '220', '5', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-006-2026', 'CK/WO/25-26/-006130226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (22, '11', '2026-02-13', 'Direct PO', 'CK/WO/25-26/-007', '1', NULL, '2025-05-01', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', '2025-05-01', NULL, '001', NULL, '17', '998898', 'Inspection', '', 'NOS', '1', '7', '-', '2000', '1', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-007-2026', 'CK/WO/25-26/-007130226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (23, '12', '2026-02-13', 'Direct PO', 'CK/WO/25-26/-008', '2', NULL, '2025-05-05', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', '2025-05-05', NULL, 'CA02', NULL, '18', '84803000', '4\" 1500 Body', '', 'NOS', '1', '6', 'CAD-SPS-YST-0001', '8000', '1', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-008-2026', 'CK/WO/25-26/-008130226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (28, '13', '2026-02-13', '', 'CK/WO/25-26/-009', 'OM/PO/05-25-26/01', NULL, '2025-05-12', NULL, 15, 'OM Industries', 'No:230/2, 4Th Cross,, Vanapadi Road,Sipcot, Ranipet, Tamil Nadu', NULL, '2025-05-12', NULL, 'OMI 02', NULL, '16', '73259920', 'Retainer 3.0', '', 'NOS', '49', '3', '3.062269', '185', '4', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-009-2026', 'CK/WO/25-26/-009130226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (27, '13', '2026-02-13', '', 'CK/WO/25-26/-009', 'OM/PO/05-25-26/01', NULL, '2025-05-12', NULL, 15, 'OM Industries', 'No:230/2, 4Th Cross,, Vanapadi Road,Sipcot, Ranipet, Tamil Nadu', NULL, '2025-05-12', NULL, 'OMI 01', NULL, '15', '73259920', 'Retainer 2.0', '', 'NOS', '103', '3', '2.067398', '185', '12', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-009-2026', 'CK/WO/25-26/-009130226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (29, '13', '2026-02-13', '', 'CK/WO/25-26/-009', 'OM/PO/05-25-26/01', NULL, '2025-05-12', NULL, 15, 'OM Industries', 'No:230/2, 4Th Cross,, Vanapadi Road,Sipcot, Ranipet, Tamil Nadu', NULL, '2025-05-12', NULL, 'OMI 01', NULL, '19', '84803000', 'Retainer 2.0  Pattern', '', 'NOS', '1', '6', '2.067398', '45500', '1', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-009-2026', 'CK/WO/25-26/-009130226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (30, '13', '2026-02-13', '', 'CK/WO/25-26/-009', 'OM/PO/05-25-26/01', NULL, '2025-05-12', NULL, 15, 'OM Industries', 'No:230/2, 4Th Cross,, Vanapadi Road,Sipcot, Ranipet, Tamil Nadu', NULL, '2025-05-12', NULL, 'OMI 02', NULL, '20', '84803000', 'Retainer 3.0 Pattern', '', 'NOS', '1', '6', '3.062269', '35000', '1', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-009-2026', 'CK/WO/25-26/-009130226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (31, '14', '2026-02-14', 'Direct PO', 'CK/WO/25-26/-010', 'PO 3742', NULL, '2025-05-13', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', '0', '2025-05-13', NULL, 'SP02', NULL, '12', '73259930', 'Collector Casting', '', 'NOS', '29.5', '4', '3-SPG-9473', '542', '4', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '0', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-010-2026', 'CK/WO/25-26/-010140226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (40, '18', '2026-02-14', 'Direct PO', 'CK/WO/25-26/-012', 'PO 3755', NULL, '2025-06-03', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', '0', '2025-06-03', NULL, 'SP02', NULL, '12', '73259930', 'Collector Casting', '', 'NOS', '27.8', '4', '3-SPG-9473', '539', '348', '252', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-012-2026', 'CK/WO/25-26/-012140226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (42, '19', '2026-02-14', 'Direct PO', 'CK/WO/25-26/-013', 'PO-2526-0333', NULL, '2025-06-05', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', '2025-06-05', NULL, 'SBM04', NULL, '9', '73259999', 'NH Inner Box', '', 'NOS', '28.3', '2', 'ST-MSC-013 R1', '167', '40', '40', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-013-2026', 'CK/WO/25-26/-013140226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (41, '19', '2026-02-14', 'Direct PO', 'CK/WO/25-26/-013', 'PO-2526-0333', NULL, '2025-06-05', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', '2025-06-05', NULL, 'SBM02', NULL, '8', '73259999', 'NH Outer Box', '', 'NOS', '27.2', '2', 'ST-MSC-015', '167', '40', '40', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-013-2026', 'CK/WO/25-26/-013140226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (36, '16', '2026-02-14', 'Direct PO', 'CK/WO/25-26/-011', '3', NULL, '2025-05-20', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', '2025-05-20', NULL, 'SP03', NULL, '21', '84803000', 'Collector Casting 3-SPG-8557', '1 Set Aluminium Pattern with Match Plate for Rework', 'NOS', '1', '6', '3-SPG-8557', '9500', '1', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-011-2026', 'CK/WO/25-26/-011140226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (43, '19', '2026-02-14', 'Direct PO', 'CK/WO/25-26/-013', 'PO-2526-0333', NULL, '2025-06-05', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', '2025-06-05', NULL, 'SBM09', NULL, '11', '73259999', 'Moving Block', '', 'NOS', '10.85', '2', 'ST-MSC-012 R1', '167', '100', '100', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-013-2026', 'CK/WO/25-26/-013140226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (44, '20', '2026-02-14', 'Direct PO', 'CK/WO/25-26/-014', '3757', NULL, '2025-06-16', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', '0', '2025-06-16', NULL, 'SP03', NULL, '13', '73259930', 'Collector Casting 8557', '', 'NOS', '31', '4', '3-SPG-8557 ', '542', '128', '128', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-014-2026', 'CK/WO/25-26/-014140226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (45, '21', '2026-02-14', 'Direct PO', 'CK/WO/25-26/-015', '4', NULL, '2025-06-23', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', '2025-06-23', NULL, 'WC1', NULL, '22', '998898', 'Website Creation', 'Domain (1 year)         Hosting 1 GB(1 year)       6 Pages responsive Design        Watsapp Integration     Social Media Integration  Mobile Responsive Design', 'NOS', '1', '7', '-', '6000', '1', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-015-2026', 'CK/WO/25-26/-015140226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (46, '22', '2026-02-16', 'Direct PO', 'CK/WO/25-26/-016', 'PO-SC-2526-097', NULL, '2025-07-08', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', '2025-07-09', NULL, 'SBM03', NULL, '5', '73259999', 'LH Outer Box', '', 'NOS', '24.6', '2', 'ST-MSC-016', '167', '40', '40', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-016-2026', 'CK/WO/25-26/-016160226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (47, '22', '2026-02-16', 'Direct PO', 'CK/WO/25-26/-016', 'PO-SC-2526-097', NULL, '2025-07-08', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', '2025-07-09', NULL, 'SBM05', NULL, '6', '73259999', 'LH Inner Box', '', 'NOS', '26.1', '2', 'ST-MSC-014-R1', '167', '40', '40', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-016-2026', 'CK/WO/25-26/-016160226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (48, '23', '2026-02-25', 'Direct PO', 'CK/WO/25-26/-017', 'CAD2025363', NULL, '2025-06-09', NULL, 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', '0', '2025-06-09', NULL, 'TB1', NULL, '23', '73259999', 'TEST BAR(300mmX50mmX50mm)', '', 'NOS', '6', '2', '-', '175', '2', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2', '0', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-017-2026', 'CK/WO/25-26/-017250226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (49, '23', '2026-02-25', 'Direct PO', 'CK/WO/25-26/-017', 'CAD2025363', NULL, '2025-06-09', NULL, 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'No:54 SRI VIGNESHWAR ILLAM, MGR NAGAR, GOLDWINS, Coimbatore, Tamil Nadu', '0', '2025-06-09', NULL, 'PR1', NULL, '24', '84803000', 'Pattern Rework Cost', '', 'NOS', '1', '6', '-', '9500', '1', '0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1', '0', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-017-2026', 'CK/WO/25-26/-017250226');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (64, '31', '2026-03-05', 'Direct PO', 'CK/WO/25-26/-025', '10', NULL, '2025-08-21', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', '2025-08-21', NULL, 'SBM08', NULL, '4', '84803000', 'EH Outer Box', '1 Set Aluminium Pattern Finishing', 'NOS', '1', '6', 'ST-MSC-017', '5000', '1', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-025-2026', 'CK/WO/25-26/-025050326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (52, '25', '2026-03-04', 'Direct PO', 'CK/WO/25-26/-019', 'PO-2526-0628', NULL, '2025-08-05', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', '2025-08-05', NULL, 'SBM02', NULL, '8', '73259999', 'NH Outer Box', '', 'NOS', '27.2', '2', 'ST-MSC-015', '167', '40', '40', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-019-2026', 'CK/WO/25-26/-019040326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (53, '25', '2026-03-04', 'Direct PO', 'CK/WO/25-26/-019', 'PO-2526-0628', NULL, '2025-08-05', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', '2025-08-05', NULL, 'SBM04', NULL, '9', '73259999', 'NH Inner Box', '', 'NOS', '28.3', '2', 'ST-MSC-013 R1', '167', '40', '40', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-019-2026', 'CK/WO/25-26/-019040326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (54, '25', '2026-03-04', 'Direct PO', 'CK/WO/25-26/-019', 'PO-2526-0628', NULL, '2025-08-05', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', '2025-08-05', NULL, 'SBM05', NULL, '6', '73259999', 'LH Inner Box', '', 'NOS', '26.1', '2', 'ST-MSC-014-R1', '167', '45', '45', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-019-2026', 'CK/WO/25-26/-019040326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (55, '25', '2026-03-04', 'Direct PO', 'CK/WO/25-26/-019', 'PO-2526-0628', NULL, '2025-08-05', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', '2025-08-05', NULL, 'SBM03', NULL, '5', '73259999', 'LH Outer Box', '', 'NOS', '24.6', '2', 'ST-MSC-016', '167', '30', '30', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-019-2026', 'CK/WO/25-26/-019040326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (56, '25', '2026-03-04', 'Direct PO', 'CK/WO/25-26/-019', 'PO-2526-0628', NULL, '2025-08-05', NULL, 9, 'STAAN BIO MED PVT LTD', '190-A, Bharathiar Road, Ganapathy, Coimbatore, Tamil Nadu', '0', '2025-08-05', NULL, 'SBM09', NULL, '11', '73259999', 'Moving Block', '', 'NOS', '10.85', '2', 'ST-MSC-012 R1', '167', '60', '60', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-019-2026', 'CK/WO/25-26/-019040326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (57, '26', '2026-03-04', 'Direct PO', 'CK/WO/25-26/-020', '6', NULL, '2025-07-17', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', '2025-07-17', NULL, 'SW1', NULL, '26', '998898', 'Customized ERP Software ', 'Cloud/Online Version Including 1st Year Server AMC', 'NOS', '1', '7', '-', '30000', '1', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-020-2026', 'CK/WO/25-26/-020040326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (58, '27', '2026-03-04', 'Direct PO', 'CK/WO/25-26/-021', '7', NULL, '2025-07-20', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', '2025-07-20', NULL, 'SP02', NULL, '27', '84803000', 'Collector Casting 3-SPG-9473', '1 Set Aluminium Pattern With Match Plate For Rework & finishing. MatchPlate Remounting Putty Finishing', 'NOS', '1', '6', '3-SPG-9473', '30000', '1', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-021-2026', 'CK/WO/25-26/-021040326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (59, '27', '2026-03-04', 'Direct PO', 'CK/WO/25-26/-021', '7', NULL, '2025-07-20', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', '2025-07-20', NULL, 'SP03', NULL, '21', '84803000', 'Collector Casting 3-SPG-8557', '1 Set Aluminium Pattern With Match Plate For Rework & finishing. MatchPlate Remounting Putty Finishing', 'NOS', '1', '6', '3-SPG-8557', '30000', '1', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-021-2026', 'CK/WO/25-26/-021040326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (60, '28', '2026-03-05', 'Direct PO', 'CK/WO/25-26/-022', '8', NULL, '2025-08-05', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', '2025-08-05', NULL, 'EP01', NULL, '28', '73259930', 'Casing EO8-250', '', 'NOS', '250', '8', '005.01.2086-0', '600', '3', '3', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-022-2026', 'CK/WO/25-26/-022050326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (61, '29', '2026-03-05', 'Direct PO', 'CK/WO/25-26/-023', '3801', NULL, '2025-08-11', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', '0', '2025-08-11', NULL, 'SP03', NULL, '13', '73259930', 'Collector Casting 8557', '', 'NOS', '31', '4', '3-SPG-8557 REV01', '542', '60', '60', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-023-2026', 'CK/WO/25-26/-023050326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (62, '30', '2026-03-05', 'Direct PO', 'CK/WO/25-26/-024', '9', NULL, '2025-08-20', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', '2025-08-20', NULL, '-', NULL, '29', '84803000', 'Aluminium Plate Alloy 20mmX1160X575mm', '', 'KGS', '37.5', '6', '-', '475', '1', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-024-2026', 'CK/WO/25-26/-024050326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (63, '30', '2026-03-05', 'Direct PO', 'CK/WO/25-26/-024', '9', NULL, '2025-08-20', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', '2025-08-20', NULL, '-', NULL, '30', '84803000', '115mmX260X150mm', '', 'KGS', '28', '6', '-', '500', '1', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-024-2026', 'CK/WO/25-26/-024050326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (65, '31', '2026-03-05', 'Direct PO', 'CK/WO/25-26/-025', '10', NULL, '2025-08-21', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', '2025-08-21', NULL, 'SBM02', NULL, '8', '84803000', 'NH Outer Box', '1 Set Aluminium Pattern Finishing', 'NOS', '1', '6', 'ST-MSC-015', '5000', '1', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-025-2026', 'CK/WO/25-26/-025050326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (66, '31', '2026-03-05', 'Direct PO', 'CK/WO/25-26/-025', '10', NULL, '2025-08-21', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', '2025-08-21', NULL, 'SBM04', NULL, '9', '84803000', 'NH Inner Box', '1 Set Aluminium Pattern Finishing', 'NOS', '1', '6', 'ST-MSC-013 R1', '5000', '1', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-025-2026', 'CK/WO/25-26/-025050326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (67, '31', '2026-03-05', 'Direct PO', 'CK/WO/25-26/-025', '10', NULL, '2025-08-21', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', '2025-08-21', NULL, 'SBM15', NULL, '10', '84803000', 'EH Inner Box', '1 Set Aluminium Pattern Finishing', 'NOS', '1', '6', 'ST-MSC-027 R0', '5000', '1', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-025-2026', 'CK/WO/25-26/-025050326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (68, '31', '2026-03-05', 'Direct PO', 'CK/WO/25-26/-025', '10', NULL, '2025-08-21', NULL, 13, 'CKP LOI', 'SF NO.845B,D.NO.1J(4), Annur,Rayarpalayam, Coimbatore, Tamil Nadu', '0', '2025-08-21', NULL, 'SBM09', NULL, '11', '84803000', 'Moving Block', '1 Nos Aluminium Corebox(New)', 'NOS', '1', '6', 'ST-MSC-012 R1', '12000', '1', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-025-2026', 'CK/WO/25-26/-025050326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (69, '32', '2026-03-05', 'Direct PO', 'CK/WO/25-26/-026', '3811', NULL, '2025-08-30', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', 'PLOT No.E-5 SIDCO INDUSTRIES ESTATE, Phase II, VALAVANTHAN KOTTAI, THUVAKUDI, TRICHY, Tamil Nadu', '0', '2025-08-30', NULL, 'SP03', NULL, '13', '73259930', 'Collector Casting 8557', '', 'NOS', '31', '4', '3-SPG-8557 Rev-01', '542', '240', '240', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-026-2026', 'CK/WO/25-26/-026050326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (70, '33', '2026-03-06', 'Direct PO', 'CK/WO/25-26/-027', '0027', NULL, '2026-03-06', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', '2026-03-06', NULL, '-', NULL, '29', '73259930', 'Aluminium Plate Alloy 20mmX1160X575mm', 'a', 'KGS', '20', '1', '0027', '475', '20', '20', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '10', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-027-2026', 'CK/WO/25-26/-027060326');
INSERT INTO `purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `address`, `invoiceno`, `invoicedate`, `batchno`, `itemcode`, `heatno`, `itemid`, `hsnno`, `itemname`, `item_desc`, `uom`, `weight`, `grade`, `drawingno`, `rate`, `qty`, `balaceqty`, `bom_qty`, `total`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `workorderbalance`, `status`, `oa_status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`) VALUES (71, '33', '2026-03-06', 'Direct PO', 'CK/WO/25-26/-027', '0027', NULL, '2026-03-06', NULL, 1, 'jack', 'gandhipuram, singanallur, karaikudi, Tamil Nadu', '0', '2026-03-06', NULL, 'SW1', NULL, '26', '', 'Customized ERP Software ', 'b', 'NOS', '10', '', '-', '30000', '20', '20', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '10', '1', 2, NULL, NULL, NULL, NULL, NULL, 'CK/WO/25-26/-027-2026', 'CK/WO/25-26/-027060326');


#
# TABLE STRUCTURE FOR: quotation_details
#

DROP TABLE IF EXISTS `quotation_details`;

CREATE TABLE `quotation_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: quotation_details_backup
#

DROP TABLE IF EXISTS `quotation_details_backup`;

CREATE TABLE `quotation_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `quotationdate` date DEFAULT NULL,
  `gstinno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `quotationno` varchar(225) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightcharges` varchar(225) DEFAULT NULL,
  `packingcharges` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: sales_return
#

DROP TABLE IF EXISTS `sales_return`;

CREATE TABLE `sales_return` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `discountamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: sales_return_backup
#

DROP TABLE IF EXISTS `sales_return_backup`;

CREATE TABLE `sales_return_backup` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) DEFAULT NULL,
  `returndate` varchar(255) DEFAULT NULL,
  `types` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `dateofissue` date DEFAULT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `customerid` varchar(255) DEFAULT NULL,
  `supplierid` varchar(255) DEFAULT NULL,
  `gsttype` varchar(255) DEFAULT NULL,
  `suppliername` varchar(255) DEFAULT NULL,
  `openingbal` varchar(255) DEFAULT NULL,
  `outstandingamount` int(255) DEFAULT NULL,
  `returnno` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `discountamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `freightamount` varchar(255) NOT NULL,
  `freightcgst` varchar(255) NOT NULL,
  `freightcgstamount` varchar(255) NOT NULL,
  `freightsgst` varchar(255) NOT NULL,
  `freightsgstamount` varchar(255) NOT NULL,
  `freightigst` varchar(255) NOT NULL,
  `freightigstamount` varchar(255) NOT NULL,
  `freighttotal` varchar(255) NOT NULL,
  `loadingamount` varchar(255) NOT NULL,
  `loadingcgst` varchar(255) NOT NULL,
  `loadingcgstamount` varchar(255) NOT NULL,
  `loadingsgst` varchar(255) NOT NULL,
  `loadingsgstamount` varchar(255) NOT NULL,
  `loadingigst` varchar(255) NOT NULL,
  `loadingigstamount` varchar(255) NOT NULL,
  `loadingtotal` varchar(255) NOT NULL,
  `othercharges` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: statecode
#

DROP TABLE IF EXISTS `statecode`;

CREATE TABLE `statecode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(255) NOT NULL,
  `stateCode` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (1, 'Jammu & Kashmir', '01', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (2, 'Himachal Pradesh', '02', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (3, 'Punjab', '03', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (4, 'Chandigarh', '04', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (5, 'Uttarakhand', '05', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (6, 'Haryana', '06', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (7, 'Delhi', '07', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (8, 'Rajasthan', '08', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (9, 'Uttar Pradesh', '09', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (10, 'Bihar', '10', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (11, 'Sikkim', '11', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (12, 'Arunachal Pradesh', '12', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (13, 'Nagaland', '13', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (14, 'Manipur', '14', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (15, 'Mizoram', '15', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (16, 'Tripura', '16', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (17, 'Meghalaya', '17', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (18, 'Assam', '18', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (19, 'West Bengal', '19', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (20, 'Jharkhand', '20', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (21, 'odisha', '21', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (22, 'Chattisgarh', '22', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (23, 'Madhya Pradesh', '23', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (24, 'Daman & Diu', '25', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (25, 'Gujarat', '24', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (26, 'Dadra & Nagar Haveli', '26', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (27, 'Maharashtra', '27', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (28, 'Andhra Pradesh', '28', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (29, 'Karnataka', '29', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (30, 'Goa', '30', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (31, 'Lakshadweep', '31', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (32, 'Kerala', '32', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (33, 'Tamil Nadu', '33', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (34, 'Puducherry', '34', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (35, 'Andaman & Nicobar Islands', '35', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (36, 'Telengana', '36', 1);
INSERT INTO `statecode` (`id`, `state`, `stateCode`, `status`) VALUES (37, 'Andrapradesh(New)', '37', 1);


#
# TABLE STRUCTURE FOR: stock
#

DROP TABLE IF EXISTS `stock`;

CREATE TABLE `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `heatno` varchar(255) DEFAULT NULL,
  `itemid` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `sgst` varchar(255) DEFAULT NULL,
  `cgst` varchar(255) DEFAULT NULL,
  `igst` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `rate` varchar(255) NOT NULL,
  `updatestock` varchar(255) NOT NULL,
  `weight` varchar(100) DEFAULT NULL,
  `total` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `balance` varchar(255) NOT NULL,
  `oldqty` varchar(255) DEFAULT NULL,
  `currentstock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=133 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (1, '2026-02-13', '73259930', 'P0213', '3', 'CA16', '9', '9', '18', '1/2\" CL 600 Body', '20', '600', '20', NULL, '', '', '80', NULL, NULL, '', '2025-03-20', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (2, '2026-02-13', '84803000', '', '', 'SP01', '9', '9', '18', 'Coal Nozzle ', '1', '145000', '1', NULL, '', '', '0', NULL, NULL, '', '2025-04-09', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (3, '2026-02-18', '73259999', 'P0412', '3', 'CA16', '9', '9', '18', '1/2\" CL 600 Body', '4', '200', '4', NULL, '', '', '17', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (4, '2026-02-18', '73259999', 'P0424', '3', 'CA16', '9', '9', '18', '1/2\" CL 600 Body', '5', '200', '5', NULL, '', '', '21', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (5, '2026-02-18', '73259999', 'P0425', '3', 'CA16', '9', '9', '18', '1/2\" CL 600 Body', '5', '200', '5', NULL, '', '', '21', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (6, '2026-02-18', '73259999', 'P0426', '3', 'CA16', '9', '9', '18', '1/2\" CL 600 Body', '2', '200', '2', NULL, '', '', '9', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (7, '2026-02-18', '73259999', 'P0443', '3', 'CA16', '9', '9', '18', '1/2\" CL 600 Body', '1', '200', '1', NULL, '', '', '5', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (8, '2026-02-13', '73259999', 'P0464', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-70', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (9, '2026-02-13', '73259999', 'P0470', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-70', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (10, '2026-02-13', '73259999', 'P0471', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-70', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (11, '2026-02-13', '73259999', 'P0472', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-70', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (12, '2026-02-13', '73259999', 'P0473', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-70', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (13, '2026-02-13', '73259999', 'P0474', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-70', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (14, '2026-02-13', '73259999', 'P0475', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-70', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (15, '2026-02-13', '73259999', 'P0476', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-70', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (16, '2026-02-13', '73259999', 'P0477', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-70', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (17, '2026-02-13', '73259999', 'P0478', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-70', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (18, '2026-02-13', '73259999', 'P0479', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-70', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (19, '2026-02-13', '73259999', 'P0481', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-70', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (20, '2026-02-13', '73259999', 'P0482', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-70', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (21, '2026-02-13', '73259999', 'P0483', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-70', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (22, '2026-02-13', '73259999', 'P0484', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-70', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (23, '2026-02-18', '73259999', 'P0485', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-68', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (24, '2026-02-18', '73259999', 'P0495', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-68', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (25, '2026-02-18', '73259999', 'P0496', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-68', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (26, '2026-02-18', '73259999', 'P0497', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-68', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (27, '2026-02-18', '73259999', 'P0498', '', 'SBM08', '9', '9', '18', 'EH Outer Box', '2', '155', '2', NULL, '', '', '-68', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (28, '2026-02-12', '', '', '17', '001', '9', '9', '18', 'Inspection', '1', '2000', '1', NULL, '', '', '0', NULL, NULL, '', '2025-05-05', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (29, '2026-02-18', '73259999', 'P0464', '|', 'CA16', '9', '9', '18', 'EH Outer Box', '2', '155', '2', '34.1', '', '', '2', NULL, NULL, '', '2025-05-05', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (30, '2026-02-18', '73259999', 'P0470', '3', 'CA16', '9', '9', '18', 'EH Outer Box', '2', '155', '2', '34.1', '', '', '2', NULL, NULL, '', '2025-05-05', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (31, '2026-02-18', '73259999', 'P0471', '|', 'CA16', '9', '9', '18', 'EH Outer Box', '2', '155', '2', '34.1', '', '', '2', NULL, NULL, '', '2025-05-05', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (32, '2026-02-18', '73259999', 'P0472', '|', 'CA16', '9', '9', '18', 'EH Outer Box', '2', '155', '2', '34.1', '', '', '2', NULL, NULL, '', '2025-05-05', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (33, '2026-02-18', '73259999', 'P0473', '3', 'CA16', '9', '9', '18', 'EH Outer Box', '2', '155', '2', '34.1', '', '', '2', NULL, NULL, '', '2025-05-05', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (34, '2026-02-18', '73259999', 'P0474', '|', 'CA16', '9', '9', '18', 'EH Outer Box', '2', '155', '2', '34.1', '', '', '2', NULL, NULL, '', '2025-05-05', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (35, '2026-02-18', '73259999', 'P0475', '|', 'CA16', '9', '9', '18', 'EH Outer Box', '2', '155', '2', '34.1', '', '', '2', NULL, NULL, '', '2025-05-05', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (36, '2026-02-18', '73259999', 'P0476', '3', 'CA16', '9', '9', '18', 'EH Outer Box', '2', '155', '2', '34.1', '', '', '2', NULL, NULL, '', '2025-05-05', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (37, '2026-02-18', '73259999', 'P0477', '|', 'CA16', '9', '9', '18', 'EH Outer Box', '2', '155', '2', '34.1', '', '', '2', NULL, NULL, '', '2025-05-05', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (38, '2026-02-18', '73259999', 'P0478', '|', 'CA16', '9', '9', '18', 'EH Outer Box', '2', '155', '2', '34.1', '', '', '2', NULL, NULL, '', '2025-05-05', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (39, '2026-02-18', '73259999', 'P0479', '|', 'CA16', '9', '9', '18', 'EH Outer Box', '2', '155', '2', '34.1', '', '', '2', NULL, NULL, '', '2025-05-05', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (40, '2026-02-18', '73259999', 'P0481', '|', 'CA16', '9', '9', '18', 'EH Outer Box', '2', '155', '2', '34.1', '', '', '2', NULL, NULL, '', '2025-05-05', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (41, '2026-02-18', '73259999', 'P0482', '|', 'CA16', '9', '9', '18', 'EH Outer Box', '2', '155', '2', '34.1', '', '', '2', NULL, NULL, '', '2025-05-05', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (42, '2026-02-18', '73259999', 'P0483', '|', 'CA16', '9', '9', '18', 'EH Outer Box', '2', '155', '2', '34.1', '', '', '2', NULL, NULL, '', '2025-05-05', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (43, '2026-02-18', '73259999', 'P0484', '|', 'CA16', '9', '9', '18', 'EH Outer Box', '2', '155', '2', '34.1', '', '', '2', NULL, NULL, '', '2025-05-05', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (44, '2026-02-18', '', NULL, '1', '001', '9', '9', '18', 'Inspection', '1', '2000', '1', '1', '', '', '1', NULL, NULL, '', '2025-05-05', '');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (45, '2026-02-18', '84803000', '', '', 'CA02', '9', '9', '18', '4\" 1500 Body', '1', '8000', '1', NULL, '', '', '1', NULL, NULL, '', '2025-05-09', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (46, '2026-03-03', '84803000', '', '', 'OMI 02', '9', '9', '18', 'Retainer 3.0 Pattern', '1', '32000', '1', NULL, '', '', '0', NULL, NULL, '', '2025-05-29', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (47, '2026-03-03', '84803000', '', '', 'OMI 01', '9', '9', '18', 'Retainer 2.0  Pattern', '1', '40000', '1', NULL, '', '', '0', NULL, NULL, '', '2025-05-29', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (48, '2026-02-18', '998898', '', '17', '001', '9', '9', '18', 'Inspection', '1', '2000', '1', NULL, '', '', '1', NULL, NULL, '', '2025-06-01', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (49, '2026-02-25', '73259999', '33801', '', 'CA02', '9', '9', '18', '4\" 1500 Body', '3', '175', '3', NULL, '', '', '15', NULL, NULL, '', '2025-06-07', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (50, '2026-02-25', '73259999', '33817', '', 'CA02', '9', '9', '18', '4\" 1500 Body', '2', '175', '2', NULL, '', '', '15', NULL, NULL, '', '2025-06-07', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (51, '2026-02-25', '73259999', '', '23', 'TB1', '9', '9', '18', 'TEST BAR(300mmX50mmX50mm)', '2', '175', '2', NULL, '', '', '0', NULL, NULL, '', '2025-06-09', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (52, '2026-03-03', '73259999', 'P0546', '', 'SBM10', '9', '9', '18', '12FN Top Plate', '4', '155', '4', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (53, '2026-03-03', '73259999', 'P0580', '', 'SBM10', '9', '9', '18', '12FN Top Plate', '4', '155', '4', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (54, '2026-03-03', '73259999', 'P0582', '', 'SBM10', '9', '9', '18', '12FN Top Plate', '4', '155', '4', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (55, '2026-03-03', '73259999', 'P0583', '', 'SBM10', '9', '9', '18', '12FN Top Plate', '4', '155', '4', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (56, '2026-03-03', '73259999', 'P0584', '', 'SBM10', '9', '9', '18', '12FN Top Plate', '4', '155', '4', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (57, '2026-03-03', '73259999', 'P0588', '', 'SBM10', '9', '9', '18', '12FN Top Plate', '4', '155', '4', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (58, '2026-03-03', '73259999', 'P0589', '', 'SBM10', '9', '9', '18', '12FN Top Plate', '4', '155', '4', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (59, '2026-03-03', '73259999', 'P0591', '', 'SBM10', '9', '9', '18', '12FN Top Plate', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (60, '2026-03-03', '73259999', 'P0592', '', 'SBM10', '9', '9', '18', '12FN Top Plate', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (61, '2026-03-03', '73259999', 'P0595', '', 'SBM10', '9', '9', '18', '12FN Top Plate', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (62, '2026-03-03', '73259999', 'P0600', '', 'SBM10', '9', '9', '18', '12FN Top Plate', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (63, '2026-03-03', '73259999', 'P0607', '', 'SBM10', '9', '9', '18', '12FN Top Plate', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (64, '2026-03-03', '73259999', 'P6-0608', '', 'SBM10', '9', '9', '18', '12FN Top Plate', '4', '155', '4', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (65, '2026-03-03', '73259999', 'P0612', '', 'SBM10', '9', '9', '18', '12FN Top Plate', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (66, '2026-03-03', '73259999', 'P0545', '', 'SBM05', '9', '9', '18', 'LH Inner Box', '2', '155', '2', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (67, '2026-03-03', '73259999', 'P0585', '', 'SBM05', '9', '9', '18', 'LH Inner Box', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (68, '2026-03-03', '73259999', 'P0586', '', 'SBM05', '9', '9', '18', 'LH Inner Box', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (69, '2026-03-03', '73259999', 'P0587', '', 'SBM05', '9', '9', '18', 'LH Inner Box', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (70, '2026-03-03', '73259999', 'P0590', '', 'SBM05', '9', '9', '18', 'LH Inner Box', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (71, '2026-03-03', '73259999', 'P0596', '', 'SBM05', '9', '9', '18', 'LH Inner Box', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (72, '2026-03-03', '73259999', 'P0597', '', 'SBM05', '9', '9', '18', 'LH Inner Box', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (73, '2026-03-03', '73259999', 'P0598', '', 'SBM05', '9', '9', '18', 'LH Inner Box', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (74, '2026-03-03', '73259999', 'P0599', '', 'SBM05', '9', '9', '18', 'LH Inner Box', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (75, '2026-03-03', '73259999', 'P0601', '', 'SBM05', '9', '9', '18', 'LH Inner Box', '1', '155', '1', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (76, '2026-03-03', '73259999', 'P0602', '', 'SBM05', '9', '9', '18', 'LH Inner Box', '4', '155', '4', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (77, '2026-03-03', '73259999', 'P0603', '', 'SBM05', '9', '9', '18', 'LH Inner Box', '4', '155', '4', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (78, '2026-03-03', '73259999', 'P0604', '', 'SBM05', '9', '9', '18', 'LH Inner Box', '4', '155', '4', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (79, '2026-03-03', '73259999', 'P0607', '', 'SBM05', '9', '9', '18', 'LH Inner Box', '1', '155', '1', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (80, '2026-03-03', '73259999', 'P0579', '', 'SBM03', '9', '9', '18', 'LH Outer Box', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-27', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (81, '2026-03-03', '73259999', 'P0612', '', 'SBM03', '9', '9', '18', 'LH Outer Box', '1', '155', '1', NULL, '', '', '0', NULL, NULL, '', '2025-06-27', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (82, '2026-03-03', '73259999', 'P0613', '', 'SBM03', '9', '9', '18', 'LH Outer Box', '4', '155', '4', NULL, '', '', '0', NULL, NULL, '', '2025-06-27', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (83, '2026-03-03', '73259999', 'P0630', '', 'SBM03', '9', '9', '18', 'LH Outer Box', '4', '155', '4', NULL, '', '', '0', NULL, NULL, '', '2025-06-27', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (84, '2026-03-03', '73259999', 'P0635', '', 'SBM03', '9', '9', '18', 'LH Outer Box', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-27', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (85, '2026-03-03', '73259999', 'P0636', '', 'SBM03', '9', '9', '18', 'LH Outer Box', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-27', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (86, '2026-03-03', '73259999', 'P0637', '', 'SBM03', '9', '9', '18', 'LH Outer Box', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-27', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (87, '2026-03-03', '73259999', 'P0638', '', 'SBM03', '9', '9', '18', 'LH Outer Box', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-27', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (88, '2026-03-03', '73259999', 'P0640', '', 'SBM03', '9', '9', '18', 'LH Outer Box', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-27', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (89, '2026-03-03', '73259999', 'P0641', '', 'SBM03', '9', '9', '18', 'LH Outer Box', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-27', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (90, '2026-03-03', '73259999', 'P0642', '', 'SBM03', '9', '9', '18', 'LH Outer Box', '2', '155', '2', NULL, '', '', '0', NULL, NULL, '', '2025-06-27', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (91, '2026-03-03', '73259999', 'P0634', '', 'SBM03', '9', '9', '18', 'LH Outer Box', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-27', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (92, '2026-03-03', '73259999', 'P0660', '', 'SBM03', '9', '9', '18', 'LH Outer Box', '2', '155', '2', NULL, '', '', '0', NULL, NULL, '', '2025-06-27', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (93, '2026-03-03', '73259999', 'P0694', '', 'SBM03', '9', '9', '18', 'LH Outer Box', '3', '155', '3', NULL, '', '', '0', NULL, NULL, '', '2025-06-27', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (94, '2026-03-03', '73259999', '', '7', 'SBM10', '9', '9', '18', '12FN Top Plate', '1', '155', '1', NULL, '', '', '0', NULL, NULL, '', '2025-06-27', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (95, '2026-02-25', '73259999', '33801', '23', 'TB1', '9', '9', '18', 'TEST BAR(300mmX50mmX50mm)', '2', '175', '2', NULL, '', '', '0', NULL, NULL, '', '2025-06-09', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (96, '2026-03-03', '73259999', 'P0608', '', 'SBM10', '9', '9', '18', '12FN Top Plate', '4', '155', '4', NULL, '', '', '0', NULL, NULL, '', '2025-06-21', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (97, '2026-03-03', '73259999', 'P0694', '7', 'SBM10', '9', '9', '18', '12FN Top Plate', '1', '155', '1', NULL, '', '', '0', NULL, NULL, '', '2025-06-27', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (98, '2026-03-03', '73259920', 'P0662', '15', 'OMI 01', '9', '9', '18', 'Retainer 2.0', '2', '165', '2', NULL, '', '', '0', NULL, NULL, '', '2025-07-03', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (99, '2026-03-03', '73259920', 'P0690', '15', 'OMI 01', '9', '9', '18', 'Retainer 2.0', '4', '165', '4', NULL, '', '', '0', NULL, NULL, '', '2025-07-03', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (100, '2026-03-03', '73259920', 'P0693', '15', 'OMI 01', '9', '9', '18', 'Retainer 2.0', '2', '165', '2', NULL, '', '', '0', NULL, NULL, '', '2025-07-03', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (101, '2026-03-03', '73259920', 'P0697', '15', 'OMI 01', '9', '9', '18', 'Retainer 2.0', '4', '165', '4', NULL, '', '', '0', NULL, NULL, '', '2025-07-03', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (102, '2026-03-03', '73259920', 'P0674', '16', 'OMI 02', '9', '9', '18', 'Retainer 3.0', '4', '165', '4', NULL, '', '', '0', NULL, NULL, '', '2025-07-03', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (103, '2026-03-03', '73259930', 'P0593', '12', 'SP02', '9', '9', '18', 'Collector Casting', '1', '420', '1', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (104, '2026-03-03', '73259930', 'P0594', '12', 'SP02', '9', '9', '18', 'Collector Casting', '2', '420', '2', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (105, '2026-03-03', '73259930', 'P0691', '12', 'SP02', '9', '9', '18', 'Collector Casting', '3', '420', '3', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (106, '2026-03-03', '73259930', 'P0694', '12', 'SP02', '9', '9', '18', 'Collector Casting', '4', '420', '4', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (107, '2026-03-03', '73259930', 'P0695', '12', 'SP02', '9', '9', '18', 'Collector Casting', '2', '420', '2', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (108, '2026-03-03', '73259930', 'P0696', '12', 'SP02', '9', '9', '18', 'Collector Casting', '3', '420', '3', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (109, '2026-03-03', '73259930', 'P0698', '12', 'SP02', '9', '9', '18', 'Collector Casting', '3', '420', '3', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (110, '2026-03-03', '73259930', 'P0699', '12', 'SP02', '9', '9', '18', 'Collector Casting', '4', '420', '4', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (111, '2026-03-03', '73259930', 'P0704', '12', 'SP02', '9', '9', '18', 'Collector Casting', '4', '420', '4', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (112, '2026-03-03', '73259930', 'P0706', '12', 'SP02', '9', '9', '18', 'Collector Casting', '3', '420', '3', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (113, '2026-03-03', '73259930', 'P0707', '12', 'SP02', '9', '9', '18', 'Collector Casting', '4', '420', '4', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (114, '2026-03-03', '73259930', 'P0713', '12', 'SP02', '9', '9', '18', 'Collector Casting', '2', '420', '2', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (115, '2026-03-03', '73259930', 'P0714', '12', 'SP02', '9', '9', '18', 'Collector Casting', '4', '420', '4', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (116, '2026-03-03', '73259930', 'P0715', '12', 'SP02', '9', '9', '18', 'Collector Casting', '3', '420', '3', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (117, '2026-03-03', '73259930', 'P0717', '12', 'SP02', '9', '9', '18', 'Collector Casting', '4', '420', '4', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (118, '2026-03-03', '73259930', 'P0719', '12', 'SP02', '9', '9', '18', 'Collector Casting', '3', '420', '3', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (119, '2026-03-03', '73259930', 'P0720', '12', 'SP02', '9', '9', '18', 'Collector Casting', '4', '420', '4', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (120, '2026-03-03', '73259930', 'P0721', '12', 'SP02', '9', '9', '18', 'Collector Casting', '4', '420', '4', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (121, '2026-03-03', '73259930', 'P0723', '12', 'SP02', '9', '9', '18', 'Collector Casting', '4', '420', '4', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (122, '2026-03-03', '73259930', 'P0724', '12', 'SP02', '9', '9', '18', 'Collector Casting', '4', '420', '4', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (123, '2026-03-03', '73259930', 'P0728', '12', 'SP02', '9', '9', '18', 'Collector Casting', '4', '420', '4', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (124, '2026-03-03', '73259930', 'P0729', '12', 'SP02', '9', '9', '18', 'Collector Casting', '3', '420', '3', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (125, '2026-03-03', '73259930', 'P0730', '12', 'SP02', '9', '9', '18', 'Collector Casting', '4', '420', '4', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (126, '2026-03-03', '73259930', 'P0731', '12', 'SP02', '9', '9', '18', 'Collector Casting', '3', '420', '3', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (127, '2026-03-03', '73259930', 'P0732', '12', 'SP02', '9', '9', '18', 'Collector Casting', '4', '420', '4', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (128, '2026-03-03', '73259930', 'P0733', '12', 'SP02', '9', '9', '18', 'Collector Casting', '4', '420', '4', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (129, '2026-03-03', '73259930', 'P0734', '12', 'SP02', '9', '9', '18', 'Collector Casting', '4', '420', '4', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (130, '2026-03-03', '73259930', 'P0740', '12', 'SP02', '9', '9', '18', 'Collector Casting', '3', '420', '3', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (131, '2026-03-03', '73259930', 'P0741', '12', 'SP02', '9', '9', '18', 'Collector Casting', '4', '420', '4', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');
INSERT INTO `stock` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `sgst`, `cgst`, `igst`, `itemname`, `quantity`, `rate`, `updatestock`, `weight`, `total`, `status`, `balance`, `oldqty`, `currentstock`, `stat`, `stockdate`, `priceType`) VALUES (132, '2026-03-03', '73259930', 'P0742', '12', 'SP02', '9', '9', '18', 'Collector Casting', '2', '420', '2', NULL, '', '', '104', NULL, NULL, '', '2025-07-10', 'Exclusive');


#
# TABLE STRUCTURE FOR: stock_reports
#

DROP TABLE IF EXISTS `stock_reports`;

CREATE TABLE `stock_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `heatno` varchar(255) DEFAULT NULL,
  `itemid` varchar(255) DEFAULT NULL,
  `itemcode` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `updatestock` varchar(255) DEFAULT NULL,
  `stat` varchar(255) NOT NULL,
  `stockdate` date DEFAULT NULL,
  `purchaseid` varchar(255) DEFAULT NULL,
  `balance` varchar(225) DEFAULT NULL,
  `priceType` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=206 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (3, '2026-02-11', '73259930', 'P0213', '3', 'CA16', '1/2\" CL 600 Body', NULL, '20', '', NULL, '3', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (4, '2026-02-12', '84803000', '', '', 'SP01', 'Coal Nozzle ', NULL, '1', '', NULL, '4', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (70, '2026-02-18', '73259999', 'P0498', '|', 'SBM08', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (69, '2026-02-18', '73259999', 'P0497', '|', 'SBM08', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (68, '2026-02-18', '73259999', 'P0496', '|', 'SBM08', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (67, '2026-02-18', '73259999', 'P0495', '|', 'SBM08', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (66, '2026-02-18', '73259999', 'P0485', '|', 'SBM08', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (65, '2026-02-18', '73259999', 'P0484', '|', 'CA16', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (64, '2026-02-18', '73259999', 'P0483', '|', 'CA16', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (63, '2026-02-18', '73259999', 'P0482', '|', 'CA16', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (62, '2026-02-18', '73259999', 'P0481', '|', 'CA16', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (61, '2026-02-18', '73259999', 'P0479', '|', 'CA16', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (60, '2026-02-18', '73259999', 'P0478', '|', 'CA16', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (59, '2026-02-18', '73259999', 'P0477', '|', 'CA16', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (58, '2026-02-18', '73259999', 'P0476', '3', 'CA16', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (57, '2026-02-18', '73259999', 'P0475', '|', 'CA16', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (56, '2026-02-18', '73259999', 'P0474', '|', 'CA16', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (55, '2026-02-18', '73259999', 'P0473', '3', 'CA16', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (54, '2026-02-18', '73259999', 'P0472', '|', 'CA16', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (53, '2026-02-18', '73259999', 'P0471', '|', 'CA16', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (52, '2026-02-18', '73259999', 'P0470', '3', 'CA16', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (51, '2026-02-18', '73259999', 'P0464', '|', 'CA16', 'EH Outer Box', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (50, '2026-02-18', '73259999', 'P0443', '|', 'CA16', '1/2\" CL 600 Body', NULL, '1', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (49, '2026-02-18', '73259999', 'P0426', '3', 'CA16', '1/2\" CL 600 Body', NULL, '2', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (48, '2026-02-18', '73259999', 'P0425', '|', 'CA16', '1/2\" CL 600 Body', NULL, '5', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (47, '2026-02-18', '73259999', 'P0424', '|', 'CA16', '1/2\" CL 600 Body', NULL, '5', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (46, '2026-02-18', '73259999', 'P0412', '3', 'CA16', '1/2\" CL 600 Body', NULL, '4', '', '2025-05-05', '5', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (71, '2026-02-18', '', NULL, '1', '001', 'Inspection', NULL, '1', '', '2025-05-05', '6', NULL, '');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (72, '2026-02-18', '84803000', '', '', 'CA02', '4\" 1500 Body', NULL, '1', '', '2025-05-09', '7', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (73, '2026-02-18', '84803000', '', '', 'OMI 02', 'Retainer 3.0 Pattern', NULL, '1', '', '2025-05-29', '8', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (74, '2026-02-18', '84803000', '', '', 'OMI 01', 'Retainer 2.0  Pattern', NULL, '1', '', '2025-05-29', '8', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (75, '2026-02-18', '998898', '', '17', '001', 'Inspection', NULL, '1', '', '2025-06-01', '9', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (123, '2026-02-25', '73259999', '33801', '', 'CA02', '4\" 1500 Body', NULL, '3', '', NULL, '16', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (124, '2026-02-25', '73259999', '33817', '', 'CA02', '4\" 1500 Body', NULL, '2', '', NULL, '16', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (127, '2026-02-25', '73259999', '33801', '23', 'TB1', 'TEST BAR(300mmX50mmX50mm)', NULL, '2', '', NULL, '19', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (128, '2026-03-02', '73259999', 'P0546', '', 'SBM10', '12FN Top Plate', NULL, '4', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (129, '2026-03-02', '73259999', 'P0580', '', 'SBM10', '12FN Top Plate', NULL, '4', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (130, '2026-03-02', '73259999', 'P0582', '', 'SBM10', '12FN Top Plate', NULL, '4', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (131, '2026-03-02', '73259999', 'P0583', '', 'SBM10', '12FN Top Plate', NULL, '4', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (132, '2026-03-02', '73259999', 'P0584', '', 'SBM10', '12FN Top Plate', NULL, '4', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (133, '2026-03-02', '73259999', 'P0588', '', 'SBM10', '12FN Top Plate', NULL, '4', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (134, '2026-03-02', '73259999', 'P0589', '', 'SBM10', '12FN Top Plate', NULL, '4', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (135, '2026-03-02', '73259999', 'P0591', '', 'SBM10', '12FN Top Plate', NULL, '3', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (136, '2026-03-02', '73259999', 'P0592', '', 'SBM10', '12FN Top Plate', NULL, '3', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (137, '2026-03-02', '73259999', 'P0595', '', 'SBM10', '12FN Top Plate', NULL, '3', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (138, '2026-03-02', '73259999', 'P0600', '', 'SBM10', '12FN Top Plate', NULL, '3', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (139, '2026-03-02', '73259999', 'P0607', '', 'SBM10', '12FN Top Plate', NULL, '3', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (140, '2026-03-02', '73259999', 'P0608', '', 'SBM10', '12FN Top Plate', NULL, '4', '', '2025-06-21', '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (141, '2026-03-02', '73259999', 'P0612', '', 'SBM10', '12FN Top Plate', NULL, '3', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (142, '2026-03-02', '73259999', 'P0545', '', 'SBM05', 'LH Inner Box', NULL, '2', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (143, '2026-03-02', '73259999', 'P0585', '', 'SBM05', 'LH Inner Box', NULL, '3', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (144, '2026-03-02', '73259999', 'P0586', '', 'SBM05', 'LH Inner Box', NULL, '3', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (145, '2026-03-02', '73259999', 'P0587', '', 'SBM05', 'LH Inner Box', NULL, '3', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (146, '2026-03-02', '73259999', 'P0590', '', 'SBM05', 'LH Inner Box', NULL, '3', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (147, '2026-03-02', '73259999', 'P0596', '', 'SBM05', 'LH Inner Box', NULL, '3', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (148, '2026-03-02', '73259999', 'P0597', '', 'SBM05', 'LH Inner Box', NULL, '3', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (149, '2026-03-02', '73259999', 'P0598', '', 'SBM05', 'LH Inner Box', NULL, '3', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (150, '2026-03-02', '73259999', 'P0599', '', 'SBM05', 'LH Inner Box', NULL, '3', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (151, '2026-03-02', '73259999', 'P0601', '', 'SBM05', 'LH Inner Box', NULL, '1', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (152, '2026-03-02', '73259999', 'P0602', '', 'SBM05', 'LH Inner Box', NULL, '4', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (153, '2026-03-02', '73259999', 'P0603', '', 'SBM05', 'LH Inner Box', NULL, '4', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (154, '2026-03-02', '73259999', 'P0604', '', 'SBM05', 'LH Inner Box', NULL, '4', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (155, '2026-03-02', '73259999', 'P0607', '', 'SBM05', 'LH Inner Box', NULL, '1', '', NULL, '20', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (156, '2026-03-02', '73259999', 'P0579', '', 'SBM03', 'LH Outer Box', NULL, '3', '', NULL, '21', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (157, '2026-03-02', '73259999', 'P0635', '', 'SBM03', 'LH Outer Box', NULL, '3', '', NULL, '21', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (158, '2026-03-02', '73259999', 'P0641', '', 'SBM03', 'LH Outer Box', NULL, '3', '', NULL, '21', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (159, '2026-03-02', '73259999', 'P0612', '', 'SBM03', 'LH Outer Box', NULL, '1', '', NULL, '21', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (160, '2026-03-02', '73259999', 'P0636', '', 'SBM03', 'LH Outer Box', NULL, '3', '', NULL, '21', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (161, '2026-03-02', '73259999', 'P0642', '', 'SBM03', 'LH Outer Box', NULL, '2', '', NULL, '21', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (162, '2026-03-02', '73259999', 'P0613', '', 'SBM03', 'LH Outer Box', NULL, '4', '', NULL, '21', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (163, '2026-03-02', '73259999', 'P0637', '', 'SBM03', 'LH Outer Box', NULL, '3', '', NULL, '21', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (164, '2026-03-02', '73259999', 'P0660', '', 'SBM03', 'LH Outer Box', NULL, '2', '', NULL, '21', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (165, '2026-03-02', '73259999', 'P0630', '', 'SBM03', 'LH Outer Box', NULL, '4', '', NULL, '21', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (166, '2026-03-02', '73259999', 'P0638', '', 'SBM03', 'LH Outer Box', NULL, '3', '', NULL, '21', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (167, '2026-03-02', '73259999', 'P0694', '', 'SBM03', 'LH Outer Box', NULL, '3', '', NULL, '21', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (168, '2026-03-02', '73259999', 'P0634', '', 'SBM03', 'LH Outer Box', NULL, '3', '', NULL, '21', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (169, '2026-03-02', '73259999', 'P0640', '', 'SBM03', 'LH Outer Box', NULL, '3', '', NULL, '21', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (170, '2026-03-02', '73259999', 'P0694', '7', 'SBM10', '12FN Top Plate', NULL, '1', '', '2025-06-27', '21', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (171, '2026-03-03', '73259920', 'P0662', '15', 'OMI 01', 'Retainer 2.0', NULL, '2', '', '2025-07-03', '22', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (172, '2026-03-03', '73259920', 'P0690', '15', 'OMI 01', 'Retainer 2.0', NULL, '4', '', '2025-07-03', '22', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (173, '2026-03-03', '73259920', 'P0693', '15', 'OMI 01', 'Retainer 2.0', NULL, '2', '', '2025-07-03', '22', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (174, '2026-03-03', '73259920', 'P0697', '15', 'OMI 01', 'Retainer 2.0', NULL, '4', '', '2025-07-03', '22', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (175, '2026-03-03', '73259920', 'P0674', '16', 'OMI 02', 'Retainer 3.0', NULL, '4', '', '2025-07-03', '22', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (176, '2026-03-03', '73259930', 'P0593', '12', 'SP02', 'Collector Casting', NULL, '1', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (177, '2026-03-03', '73259930', 'P0594', '12', 'SP02', 'Collector Casting', NULL, '2', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (178, '2026-03-03', '73259930', 'P0691', '12', 'SP02', 'Collector Casting', NULL, '3', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (179, '2026-03-03', '73259930', 'P0694', '12', 'SP02', 'Collector Casting', NULL, '4', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (180, '2026-03-03', '73259930', 'P0695', '12', 'SP02', 'Collector Casting', NULL, '2', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (181, '2026-03-03', '73259930', 'P0696', '12', 'SP02', 'Collector Casting', NULL, '3', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (182, '2026-03-03', '73259930', 'P0698', '12', 'SP02', 'Collector Casting', NULL, '3', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (183, '2026-03-03', '73259930', 'P0699', '12', 'SP02', 'Collector Casting', NULL, '4', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (184, '2026-03-03', '73259930', 'P0704', '12', 'SP02', 'Collector Casting', NULL, '4', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (185, '2026-03-03', '73259930', 'P0706', '12', 'SP02', 'Collector Casting', NULL, '3', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (186, '2026-03-03', '73259930', 'P0707', '12', 'SP02', 'Collector Casting', NULL, '4', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (187, '2026-03-03', '73259930', 'P0713', '12', 'SP02', 'Collector Casting', NULL, '2', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (188, '2026-03-03', '73259930', 'P0714', '12', 'SP02', 'Collector Casting', NULL, '4', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (189, '2026-03-03', '73259930', 'P0715', '12', 'SP02', 'Collector Casting', NULL, '3', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (190, '2026-03-03', '73259930', 'P0717', '12', 'SP02', 'Collector Casting', NULL, '4', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (191, '2026-03-03', '73259930', 'P0719', '12', 'SP02', 'Collector Casting', NULL, '3', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (192, '2026-03-03', '73259930', 'P0720', '12', 'SP02', 'Collector Casting', NULL, '4', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (193, '2026-03-03', '73259930', 'P0721', '12', 'SP02', 'Collector Casting', NULL, '4', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (194, '2026-03-03', '73259930', 'P0723', '12', 'SP02', 'Collector Casting', NULL, '4', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (195, '2026-03-03', '73259930', 'P0724', '12', 'SP02', 'Collector Casting', NULL, '4', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (196, '2026-03-03', '73259930', 'P0728', '12', 'SP02', 'Collector Casting', NULL, '4', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (197, '2026-03-03', '73259930', 'P0729', '12', 'SP02', 'Collector Casting', NULL, '3', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (198, '2026-03-03', '73259930', 'P0730', '12', 'SP02', 'Collector Casting', NULL, '4', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (199, '2026-03-03', '73259930', 'P0731', '12', 'SP02', 'Collector Casting', NULL, '3', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (200, '2026-03-03', '73259930', 'P0732', '12', 'SP02', 'Collector Casting', NULL, '4', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (201, '2026-03-03', '73259930', 'P0733', '12', 'SP02', 'Collector Casting', NULL, '4', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (202, '2026-03-03', '73259930', 'P0734', '12', 'SP02', 'Collector Casting', NULL, '4', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (203, '2026-03-03', '73259930', 'P0740', '12', 'SP02', 'Collector Casting', NULL, '3', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (204, '2026-03-03', '73259930', 'P0741', '12', 'SP02', 'Collector Casting', NULL, '4', '', '2025-07-10', '23', NULL, 'Exclusive');
INSERT INTO `stock_reports` (`id`, `date`, `hsnno`, `heatno`, `itemid`, `itemcode`, `itemname`, `status`, `updatestock`, `stat`, `stockdate`, `purchaseid`, `balance`, `priceType`) VALUES (205, '2026-03-03', '73259930', 'P0742', '12', 'SP02', 'Collector Casting', NULL, '2', '', '2025-07-10', '23', NULL, 'Exclusive');


#
# TABLE STRUCTURE FOR: sup_purchaseorder_details
#

DROP TABLE IF EXISTS `sup_purchaseorder_details`;

CREATE TABLE `sup_purchaseorder_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `deliverydate` varchar(100) NOT NULL,
  `potype` varchar(255) NOT NULL,
  `tctype` varchar(255) DEFAULT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `supplierid` varchar(100) NOT NULL,
  `suppliername` varchar(100) NOT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `shipTo` varchar(255) DEFAULT NULL,
  `shipToAddress` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `requirements` text DEFAULT NULL,
  `vendor_quot` varchar(100) DEFAULT NULL,
  `quot_date` varchar(100) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `tcctype` int(11) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemcode` varchar(100) NOT NULL,
  `itemid` varchar(255) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `grade` varchar(100) NOT NULL,
  `workorderno` varchar(100) NOT NULL,
  `workorderid` varchar(100) NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `uom` longtext DEFAULT NULL,
  `weight` varchar(100) DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `deliverydates` varchar(100) DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (1, '2026-02-10', '2025-03-12', NULL, '10-02-2026', 'workorder', '2', 'CK/PUR/25-26/-001', NULL, NULL, '11', 'Sri Ayyappa Engineering Works', 2, 'SIGMA POWER & ENERGY ENGINEERS', '4/348C,Kallipalayam Road, Chikarampalayam, Karamadai, Coimbatore, Tamil Nadu', NULL, NULL, '0', NULL, NULL, NULL, 'intrastate', 'intrastate', NULL, 'sgst', 'cgst', '', '84803000', 'SP01', NULL, 'Coal Nozzle ', '', '1', 'CK/WO/25-26/-001', '3', 'C-13-004', 'NOS', '1', '142000', '1', '1', '', '142000.00', '', 'amount_wise', '', '142000.00', '9', '12780.00', '9', '12780.00', '0', '0', NULL, '', '142000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1', '167560.00', 'CK/PUR/25-26/-001100226', 'CK/PUR/25-26/-001-2026', 1, 2);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (7, '2026-02-11', '2025-03-12', NULL, '30-03-2025', 'workorder', '1', 'CK/PUR/25-26/-002', '-', NULL, '8', 'PREMIER ALLOYS', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', 'Note:\r\nTest Certificate Required', NULL, NULL, 'intrastate', 'intrastate', NULL, 'sgst', 'cgst', '', '73259930', 'CA16', '3', '1/2\" CL 600 Body', '', '1', 'CK/WO/25-26/-002', '15', '-', 'NOS', '3', '600', '20', '20', '', '36000.00', NULL, 'amount_wise', '', '36000.00', '9', '3240.00', '9', '3240.00', '0', '0', NULL, '30-03-2025', '36000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', '42480.00', 'CK/PUR/25-26/-002110226', 'CK/PUR/25-26/-002-2026', 1, 2);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (8, '2026-02-11', '2025-03-12', NULL, '30-05-2025', 'workorder', '', 'CK/PUR/25-26/-003', 'PO3704', NULL, '8', 'PREMIER ALLOYS', 2, 'SIGMA POWER & ENERGY ENGINEERS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', NULL, 'ORAL', '17-02-2025', 'intrastate', 'intrastate', NULL, 'sgst', 'cgst', '', '73259930', 'SP01', NULL, 'Coal Nozzle(C)', '', '1', 'CK/WO/25-26/-001', '4', 'C-13-004', 'NOS', '120', '450', '4', '4', '', '216000.00', '', 'amount_wise', '', '216000.00', '9', '19440.00', '9', '19440.00', '0', '0', NULL, '', '216000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1', '254880.00', 'CK/PUR/25-26/-003110226', 'CK/PUR/25-26/-003-2026', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (9, '2026-02-11', '2025-03-23', NULL, '30-05-2025', 'workorder', '1', 'CK/PUR/25-26/-004', 'CAD2025405 REV 01', NULL, '8', 'PREMIER ALLOYS', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', 'Note:\r\nTest Certificate Required', NULL, NULL, 'intrastate', 'intrastate', NULL, 'sgst', 'cgst', '', '73259999', 'CA16', '3', '1/2\" CL 600 Body', '', '2', 'CK/WO/25-26/-003', '16', '-', 'NOS', '3.5', '200', '20', '20', '', '14000.00', NULL, 'amount_wise', '', '14000.00', '9', '1260.00', '9', '1260.00', '0', '0', NULL, '', '14000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', '16520.00', 'CK/PUR/25-26/-004110226', 'CK/PUR/25-26/-004-2026', 1, 2);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (10, '2026-02-12', '2025-04-18', NULL, '12-02-2026', 'workorder', '1', 'CK/PUR/25-26/-005', 'PO-SC-2526-008', NULL, '8', 'PREMIER ALLOYS', 9, 'STAAN BIO MED PVT LTD', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', NULL, NULL, NULL, 'intrastate', 'intrastate', NULL, 'sgst', 'cgst', '', '73259999', 'SBM08', NULL, 'EH Outer Box', '', '1', 'CK/WO/25-26/-004', '17', 'ST-MSC-017', 'NOS', '33.9', '150', '40', '40', '', '203400.00', '', 'amount_wise', '', '203400.00', '9', '18306.00', '9', '18306.00', '0', '0', NULL, '28-04-2025', '203400.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1', '240012.00', 'CK/PUR/25-26/-005120226', 'CK/PUR/25-26/-005-2026', 1, 2);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (11, '2026-02-13', '2025-05-05', NULL, '13-02-2026', 'workorder', '', 'CK/PUR/25-26/-006', '1', NULL, '12', 'PKS Inspection Service', 13, 'CKP LOI', '83A Pudukadu 2nd Street,Sivanathapuram, Vellakovil-638111,Kangeyam Taluk, Tiruppur, Tamil Nadu', NULL, NULL, '0', NULL, '1', '01-05-2025', 'intrastate', 'intrastate', NULL, 'sgst', 'cgst', '', '998898', '001', NULL, 'Inspection', '', '1', 'CK/WO/25-26/-007', '22', '-', 'NOS', '1', '2000', '1', '1', '', '2000.00', '', 'amount_wise', '', '2000.00', '9', '180.00', '9', '180.00', '0', '0', NULL, '30-05-2025', '2000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1', '2360.00', 'CK/PUR/25-26/-006130226', 'CK/PUR/25-26/-006-2026', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (12, '2026-02-13', '2025-05-06', NULL, '13-02-2026', 'workorder', '', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', NULL, '8', 'PREMIER ALLOYS', 9, 'STAAN BIO MED PVT LTD', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', NULL, 'ORAL', '18-02-2025', 'intrastate', 'intrastate', NULL, 'sgst', 'cgst', '', '73259999||73259999||73259999', 'SBM03||SBM05||SBM10', NULL, 'LH Outer Box||LH Inner Box||12FN Top Plate', '||||', '1||1||1', 'CK/WO/25-26/-005', '18||19||20', 'ST-MSC-016||ST-MSC-014-R1||STMSC022 R1', 'NOS||NOS||NOS', '24.6||26.1||27', '155||155||155', '40||40||51', '40||40||50', '', '152520.00||161820.00||209250.00', '', 'amount_wise', '||||', '152520.00||161820.00||209250.00', '9', '47123.10', '9', '47123.10', '0||0||0', '0||0||0', NULL, '||||', '523590.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1||1||1', '617836.20', 'CK/PUR/25-26/-007130226', 'CK/PUR/25-26/-007-2026', 1, 2);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (13, '2026-02-13', '2025-05-07', NULL, '13-02-2026', 'workorder', '', 'CK/PUR/25-26/-008', '', NULL, '11', 'Sri Ayyappa Engineering Works', 13, 'CKP LOI', '4/348C,Kallipalayam Road, Chikarampalayam, Karamadai, Coimbatore, Tamil Nadu', NULL, NULL, '0', NULL, 'SA/25-26/15', '09-05-2025', 'intrastate', 'intrastate', NULL, 'sgst', 'cgst', '', '84803000', 'CA02', NULL, '4\" 1500 Body', 'Pattern & CoreBox for Dimension rework', '1', 'CK/WO/25-26/-008', '23', 'CAD-SPS-YST-0001', 'NOS', '1', '8000', '1', '1', '', '8000.00', '', 'amount_wise', '', '8000.00', '9', '720.00', '9', '720.00', '0', '0', NULL, '', '8000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1', '9440.00', 'CK/PUR/25-26/-008130226', 'CK/PUR/25-26/-008-2026', 1, 2);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (14, '2026-02-13', '2025-05-08', NULL, '08-06-2025', 'workorder', '', 'CK/PUR/25-26/-009', 'CAD2025363 REV01', NULL, '14', 'Shree Kumaran Alloys', 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', 'S/F No - 461, Telungupalayam Road,, Ellapalayam Post,Annur, Coimbatore, Tamil Nadu', NULL, NULL, '0', NULL, 'ORAL', '07-05-2025', 'intrastate', 'intrastate', NULL, 'sgst', 'cgst', '', '73259999', 'CA02', NULL, '4\" 1500 Body', '', '1', 'CK/WO/25-26/-006', '21', 'CAD-SPS-YST-0001', 'NOS', '212', '175', '5', '5', '', '185500.00', '', 'amount_wise', '', '185500.00', '9', '16695.00', '9', '16695.00', '0', '0', NULL, '08-06-2025', '185500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1', '218890.00', 'CK/PUR/25-26/-009130226', 'CK/PUR/25-26/-009-2026', 1, 2);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (15, '2026-02-14', '2025-05-12', NULL, '25-06-2025', 'workorder', '', 'CK/PUR/25-26/-010', '', NULL, '8', 'Sri Ayyappa Engineering Works', 15, 'OM Industries', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', NULL, 'SA/25-25/096', '28-02-2025', 'intrastate', 'intrastate', NULL, 'sgst', 'cgst', '', '84803000||84803000', 'OMI 01||OMI 02', NULL, 'Retainer 2.0  Pattern||Retainer 3.0 Pattern', '||', '1||1', 'CK/WO/25-26/-009', '29||30', '2.067398||3.062269', 'NOS||NOS', '1||1', '40000||32000', '1||1', '1||1', '', '40000.00||32000.00', '', 'amount_wise', '||', '40000.00||32000.00', '9', '6480.00', '9', '6480.00', '0||0', '0||0', NULL, '30-05-2025||30-05-2025', '72000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1||1', '84960.00', 'CK/PUR/25-26/-010140226', 'CK/PUR/25-26/-010-2026', 1, 2);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (16, '2026-02-14', '2025-05-16', NULL, '20-05-2026', 'workorder', '', 'CK/PUR/25-26/-011', 'PO 3742', NULL, '8', 'PREMIER ALLOYS', 2, 'SIGMA POWER & ENERGY ENGINEERS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', NULL, 'ORAL', '16-05-2025', 'intrastate', 'intrastate', NULL, 'sgst', 'cgst', '', '73259930', 'SP02', NULL, 'Collector Casting', '', '1', 'CK/WO/25-26/-010', '31', '3-SPG-9473', 'NOS', '28.7', '410', '4', '4', '', '47068.00', '', 'amount_wise', '', '47068.00', '9', '4236.12', '9', '4236.12', '0', '0', NULL, '', '47068.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1', '55540.24', 'CK/PUR/25-26/-011140226', 'CK/PUR/25-26/-011-2026', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (17, '2026-02-14', '2025-05-19', NULL, '20-06-2025', 'workorder', '', 'CK/PUR/25-26/-012', 'OM/PO/05-25-26/01', NULL, '8', 'PREMIER ALLOYS', 15, 'OM Industries', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', NULL, 'ORAL', '19-04-2025', 'intrastate', 'intrastate', NULL, 'sgst', 'cgst', '', '73259920||73259920', 'OMI 02||OMI 01', NULL, 'Retainer 3.0||Retainer 2.0', '||', '1||1', 'CK/WO/25-26/-009', '28||27', '3.062269||2.067398', 'NOS||NOS', '49||103', '165||165', '4||12', '4||12', '', '32340.00||203940.00', '', 'amount_wise', '||', '32340.00||203940.00', '9', '21265.20', '9', '21265.20', '0||0', '0||0', NULL, '||', '236280.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1||1', '278810.40', 'CK/PUR/25-26/-012140226', 'CK/PUR/25-26/-012-2026', 1, 2);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (18, '2026-02-14', '2026-05-20', NULL, '10-06-2025', 'workorder', '', 'CK/PUR/25-26/-013', '3', NULL, '11', 'Sri Ayyappa Engineering Works', 13, 'CKP LOI', '4/348C,Kallipalayam Road, Chikarampalayam, Karamadai, Coimbatore, Tamil Nadu', NULL, NULL, '0', NULL, 'SA/24-25/096', '28-02-2025', 'intrastate', 'intrastate', NULL, 'sgst', 'cgst', '', '84803000', 'SP03', NULL, 'Collector Casting 3-SPG-8557', '1 Set Aluminium Pattern with Match Plate for Rework', '1', 'CK/WO/25-26/-011', '36', '3-SPG-8557', 'NOS', '1', '9500', '1', '1', '', '9500.00', '', 'amount_wise', '', '9500.00', '9', '855.00', '9', '855.00', '0', '0', NULL, '20-06-2025', '9500.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1', '11210.00', 'CK/PUR/25-26/-013140226', 'CK/PUR/25-26/-013-2026', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (19, '2026-02-14', '2025-06-10', NULL, '30-07-2025', 'workorder', '', 'CK/PUR/25-26/-014', 'PO 3755', NULL, '8', 'PREMIER ALLOYS', 2, 'SIGMA POWER & ENERGY ENGINEERS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', NULL, 'ORAL', '09-06-2025', 'intrastate', 'intrastate', NULL, 'sgst', 'cgst', '', '73259930', 'SP02', NULL, 'Collector Casting', '', '1', 'CK/WO/25-26/-012', '40', '3-SPG-9473', 'NOS', '27.5', '420', '348', '348', '', '4019400.00', '', 'amount_wise', '', '4019400.00', '9', '361746.00', '9', '361746.00', '0', '0', NULL, '', '4019400.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1', '4742892.00', 'CK/PUR/25-26/-014140226', 'CK/PUR/25-26/-014-2026', 1, 2);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (20, '2026-02-14', '2025-06-11', NULL, '15-07-2025', 'workorder', '', 'CK/PUR/25-26/-015', 'PO-2526-0333', NULL, '8', 'PREMIER ALLOYS', 9, 'STAAN BIO MED PVT LTD', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', 'Test Certificate Required\r\nDelivery Date 15.07.2025', 'ORAL', '18-02-2025', 'intrastate', 'intrastate', 1, 'sgst', 'cgst', '', '73259999||73259999||73259999', 'SBM04||SBM02||SBM09', NULL, 'NH Inner Box||NH Outer Box||Moving Block', '||||', '2||2||2', 'CK/WO/25-26/-013', '42||41||43', 'ST-MSC-013 R1||ST-MSC-015||ST-MSC-012 R1', 'NOS||NOS||NOS', '28||27||10', '155||155||155', '40||40||100', '40||40||100', '', '173600.00||167400.00||155000.00', '', 'amount_wise', '||||', '173600.00||167400.00||155000.00', '9', '44640.00', '9', '44640.00', '0||0||0', '0||0||0', NULL, '15-07-2025||15-07-2025||15-07-2025', '496000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1||1||1', '585280.00', 'CK/PUR/25-26/-015140226', 'CK/PUR/25-26/-015-2026', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (21, '2026-02-14', '2025-06-16', NULL, '16-06-2025', 'workorder', '', 'CK/PUR/25-26/-016', '3757', NULL, '8', 'PREMIER ALLOYS', 2, 'SIGMA POWER & ENERGY ENGINEERS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', '1.Test Certificate required\r\n2.Dimension Report Required\r\n3. Acid Pickling to be done.', 'ORAL', '09-06-2025', 'intrastate', 'intrastate', 1, 'sgst', 'cgst', '', '73259930', 'SP03', NULL, 'Collector Casting 8557', '', '1', 'CK/WO/25-26/-014', '44', '3-SPG-8557 ', 'NOS', '30.5', '420', '4', '4', '', '51240.00', '', 'amount_wise', '', '51240.00', '9', '4611.60', '9', '4611.60', '0', '0', NULL, '30-06-2025', '51240.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1', '60463.20', 'CK/PUR/25-26/-016140226', 'CK/PUR/25-26/-016-2026', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (22, '2026-02-14', '2025-06-23', NULL, '30-07-2025', 'workorder', '', 'CK/PUR/25-26/-017', '4', NULL, '16', 'TryMy Website', 13, 'CKP LOI', '2nd Floor, SK Towers, Sathy Main Road, , Saravanampatti, Coimbatore, Tamil Nadu', NULL, NULL, '0', NULL, '132', '03-05-2025', 'intrastate', 'intrastate', NULL, 'sgst', 'cgst', '', '998898', 'WC1', NULL, 'Website Creation', 'Domain (1 year)         Hosting 1 GB(1 year)       6 Pages responsive Design        Watsapp Integration     Social Media Integration  Mobile Responsive Design', '1', 'CK/WO/25-26/-015', '45', '-', 'NOS', '1', '6000', '1', '1', '', '6000.00', '', 'amount_wise', '', '6000.00', '9', '540.00', '9', '540.00', '0', '0', NULL, '30-07-2025', '6000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1', '7080.00', 'CK/PUR/25-26/-017140226', 'CK/PUR/25-26/-017-2026', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (23, '2026-02-14', '2025-06-28', NULL, '14-02-2026', 'workorder', '1', 'CK/PUR/25-26/-018', '', NULL, '8', 'PREMIER ALLOYS', 2, 'SIGMA POWER & ENERGY ENGINEERS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', '1. Test Certificate required.\r\n2. Dimension Report Required.\r\n3. Acid pickling to be done.', 'ORAL', '09-06-2025', 'intrastate', 'intrastate', 1, 'sgst', 'cgst', '', '73259930', 'SP03', NULL, 'Collector Casting 8557', '', '1', 'CK/WO/25-26/-014', '44', '3-SPG-8557 ', 'NOS', '30.5', '420', '4', '4', '', '51240.00', '', 'amount_wise', '', '51240.00', '9', '4611.60', '9', '4611.60', '0', '0', NULL, '30-07-2025', '51240.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1', '60463.20', 'CK/PUR/25-26/-018140226', 'CK/PUR/25-26/-018-2026', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (24, '2026-02-14', '2025-07-16', NULL, '25-07-2025', 'workorder', '1', 'CK/PUR/25-26/-019', '3757', NULL, '8', 'PREMIER ALLOYS', 2, 'SIGMA POWER & ENERGY ENGINEERS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', '1. test Certificate required.\r\n2. Dimension Report Required.\r\n3. Acid pickling to be done.\r\n4.Delivery Date 25.07.2025', 'ORAL', '09-06-2025', 'intrastate', 'intrastate', 1, 'sgst', 'cgst', '', '73259930', 'SP03', NULL, 'Collector Casting 8557', '', '1', 'CK/WO/25-26/-014', '44', '3-SPG-8557 ', 'NOS', '30', '420', '120', '120', '', '1512000.00', '', 'amount_wise', '', '1512000.00', '9', '136080.00', '9', '136080.00', '0', '0', NULL, '25-07-2025', '1512000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1', '1784160.00', 'CK/PUR/25-26/-019140226', 'CK/PUR/25-26/-019-2026', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (25, '2026-02-16', '2025-07-17', NULL, '25-08-2025', 'workorder', '', 'CK/PUR/25-26/-020', 'PO-SC-2526-097', NULL, '8', 'PREMIER ALLOYS', 9, 'STAAN BIO MED PVT LTD', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', '1. Test Certificate required.\r\n2. Delivery Date:25.08.2025', 'ORAL', '18-02-2025', 'intrastate', 'intrastate', 1, 'sgst', 'cgst', '', '73259999||73259999', 'SBM03||SBM05', NULL, 'LH Outer Box||LH Inner Box', '||', '2||2', 'CK/WO/25-26/-016', '46||47', 'ST-MSC-016||ST-MSC-014-R1', 'NOS||NOS', '24.4||25.6', '155||155', '40||40', '40||40', '', '151280.00||158720.00', '', 'amount_wise', '||', '151280.00||158720.00', '9', '27900.00', '9', '27900.00', '0||0', '0||0', NULL, '18-08-2025||25-08-2025', '310000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1||1', '365800.00', 'CK/PUR/25-26/-020160226', 'CK/PUR/25-26/-020-2026', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (27, '2026-03-04', '2025-07-17', NULL, '30-03-2026', 'workorder', '2', 'CK/PUR/25-26/-021', '6', NULL, '17', 'IDREAMDEVELOPERS', 13, 'CKP LOI', 'No:91,Dr.Jaganathan Nagar,, Civil Aerodrome Post, Coimbatore, Tamil Nadu', NULL, NULL, '0', '', '20250725048', '23-06-2025', 'intrastate', 'intrastate', 3, 'sgst', 'cgst', '', '998898', 'SW1', NULL, 'Customized ERP Software ', 'Cloud/Online Version Including 1st Year Server AMC', '7', 'CK/WO/25-26/-020', '57', '-', 'NOS', '1', '30000', '1', '1', '', '30000.00', '', 'amount_wise', '', '30000.00', '9', '2700.00', '9', '2700.00', '0', '0', NULL, '', '30000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1', '35400.00', 'CK/PUR/25-26/-021040326', 'CK/PUR/25-26/-021-2026', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (28, '2026-03-04', '2025-07-20', NULL, '05-08-2025', 'workorder', '2', 'CK/PUR/25-26/-022', '7', NULL, '11', 'Sri Ayyappa Engineering Works', 13, 'CKP LOI', '4/348C,Kallipalayam Road, Chikarampalayam, Karamadai, Coimbatore, Tamil Nadu', NULL, NULL, '0', '', 'SA/2025-26/43', '12-07-2025', 'intrastate', 'intrastate', 2, 'sgst', 'cgst', '', '84803000||84803000', 'SP02||SP03', NULL, 'Collector Casting 3-SPG-9473||Collector Casting 3-SPG-8557', '1 Set Aluminium Pattern With Match Plate For Rework & finishing. MatchPlate Remounting Putty Finishing||1 Set Aluminium Pattern With Match Plate For Rework & finishing. MatchPlate Remounting Putty Finishing', '6||6', 'CK/WO/25-26/-021', '58||59', '3-SPG-9473||3-SPG-8557', 'NOS||NOS', '1||1', '30000||30000', '1||1', '1||1', '', '30000.00||30000.00', '', 'amount_wise', '||', '30000.00||30000.00', '9', '5400.00', '9', '5400.00', '0||0', '0||0', NULL, '||', '60000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1||1', '70800.00', 'CK/PUR/25-26/-022040326', 'CK/PUR/25-26/-022-2026', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (29, '2026-03-05', '2025-08-05', NULL, '10-09-2025', 'workorder', '1', 'CK/PUR/25-26/-023', '8', NULL, '14', 'Shree Kumaran Alloys', 13, 'CKP LOI', 'S/F No - 461, Telungupalayam Road,, Ellapalayam Post,Annur, Coimbatore, Tamil Nadu', NULL, NULL, '0', '1.DPI Required', 'SKA/CKP/0021/2025-26', '05-08-2025', 'intrastate', 'intrastate', 1, 'sgst', 'cgst', '', '73259930', 'EP01', NULL, 'Casing EO8-250', '', '8', 'CK/WO/25-26/-022', '60', '005.01.2086-0', 'NOS', '250', '600', '3', '3', '', '450000.00', '', 'amount_wise', '', '450000.00', '9', '40500.00', '9', '40500.00', '0', '0', NULL, '', '450000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1', '531000.00', 'CK/PUR/25-26/-023050326', 'CK/PUR/25-26/-023-2026', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (30, '2026-03-05', '2025-08-07', NULL, '06-09-2025', 'workorder', '1', 'CK/PUR/25-26/-024', 'PO-2526-0628', NULL, '8', 'PREMIER ALLOYS', 9, 'STAAN BIO MED PVT LTD', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', 'Test Certificate Required\r\nDelivery Date:06.09.2025', 'ORAL', '18-02-2025', 'intrastate', 'intrastate', 1, 'sgst', 'cgst', '', '73259999||73259999||73259999||73259999||73259999', 'SBM02||SBM04||SBM05||SBM03||SBM09', NULL, 'NH Outer Box||NH Inner Box||LH Inner Box||LH Outer Box||Moving Block', '||||||||', '2||2||2||2||2', 'CK/WO/25-26/-019', '52||53||54||55||56', 'ST-MSC-015||ST-MSC-013 R1||ST-MSC-014-R1||ST-MSC-016||ST-MSC-012 R1', 'NOS||NOS||NOS||NOS||NOS', '28||28.4||25.6||24.4||10.00', '155||155||155||155||155', '40||40||45||30||60', '40||40||45||30||60', '', '173600.00||176080.00||178560.00||113460.00||93000.00', '', 'amount_wise', '||||||||', '173600.00||176080.00||178560.00||113460.00||93000.00', '9', '66123.00', '9', '66123.00', '0||0||0||0||0', '0||0||0||0||0', NULL, '||||||||', '734700.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1||1||1||1||1', '866946.00', 'CK/PUR/25-26/-024050326', 'CK/PUR/25-26/-024-2026', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (31, '2026-03-05', '2025-08-18', NULL, '10-09-2025', 'workorder', '1', 'CK/PUR/25-26/-025', '3801', NULL, '8', 'PREMIER ALLOYS', 2, 'SIGMA POWER & ENERGY ENGINEERS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', '1. Test Certificate required.\r\n2.Dimension Report Required\r\n3.Acid pickling to be done.\r\n4. Delivery Date 10.09.2025', 'ORAL', '09-06-2025', 'intrastate', 'intrastate', 1, 'sgst', 'cgst', '', '73259930', 'SP03', NULL, 'Collector Casting 8557', '', '4', 'CK/WO/25-26/-023', '61', '3-SPG-8557 REV01', 'NOS', '30', '420', '60', '60', '', '756000.00', '', 'amount_wise', '', '756000.00', '9', '68040.00', '9', '68040.00', '0', '0', NULL, '10-09-2025', '756000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1', '892080.00', 'CK/PUR/25-26/-025050326', 'CK/PUR/25-26/-025-2026', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (33, '2026-03-05', '2025-08-21', NULL, '10-09-2025', 'workorder', NULL, 'CK/PUR/25-26/-027', '10', NULL, '10', 'Shristi Engineering Works', 13, 'CKP LOI', 'Door No.3,Ravathur Road,, Athappa Gounder Pudur,Irugur, Coimbatore, Tamil Nadu', NULL, NULL, '0', '', '056/CKP-01/25-26', '20-08-2025', 'intrastate', 'intrastate', 2, 'sgst', 'cgst', '', '84803000||84803000||84803000||84803000||84803000', 'SBM08||SBM02||SBM04||SBM15||SBM09', NULL, 'EH Outer Box||NH Outer Box||NH Inner Box||EH Inner Box||Moving Block', '1 Set Aluminium Pattern Finishing||1 Set Aluminium Pattern Finishing||1 Set Aluminium Pattern Finishing||1 Set Aluminium Pattern Finishing||1 Nos Aluminium Corebox(New)', '6||6||6||6||6', 'CK/WO/25-26/-025', '64||65||66||67||68', 'ST-MSC-017||ST-MSC-015||ST-MSC-013 R1||ST-MSC-027 R0||ST-MSC-012 R1', 'NOS||NOS||NOS||NOS||NOS', '1||1||1||1||1', '5000||5000||5000||5000||12000', '1||1||1||1||1', '1||1||1||1||1', '', '5000.00||5000.00||5000.00||5000.00||12000.00', '', 'amount_wise', '||||||||', '5000.00||5000.00||5000.00||5000.00||12000.00', '9', '2880.00', '9', '2880.00', '0||0||0||0||0', '0||0||0||0||0', NULL, '||||||||', '32000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1||1||1||1||1', '37760.00', 'CK/PUR/25-26/-027050326', 'CK/PUR/25-26/-027-2026', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (32, '2026-03-05', '2025-08-20', NULL, '25-08-2025', 'workorder', '2', 'CK/PUR/25-26/-026', '9', NULL, '18', 'Coimbatore Metals', 13, 'CKP LOI', 'No.392-C.,  Dr.Nanjappa Road,, coimbatore, Tamil Nadu', NULL, NULL, '0', '1.Test Certificate required', '056-CKP-01/25-26', '20-08-2025', 'intrastate', 'intrastate', 2, 'sgst', 'cgst', '', '84803000||84803000', '-||-', NULL, 'Aluminium Plate Alloy 20mmX1160X575mm||115mmX260X150mm', '||', '6||6', 'CK/WO/25-26/-024', '62||63', '-||-', 'KGS||KGS', '37.5||28', '475||500', '1||1', '1||1', '', '17812.50||14000.00', '', 'amount_wise', '||', '17812.50||14000.00', '9', '2863.13', '9', '2863.13', '0||0', '0||0', NULL, '28-05-2025||28-05-2025', '31812.50', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '0', '1||1', '37538.76', 'CK/PUR/25-26/-026050326', 'CK/PUR/25-26/-026-2026', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (34, '2026-03-05', '2025-09-03', NULL, '20-10-2025', 'workorder', NULL, 'CK/PUR/25-26/-028', '3811', NULL, '8', 'PREMIER ALLOYS', 2, 'SIGMA POWER & ENERGY ENGINEERS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', '1. test Certificate required.\r\n2. Dimension Report Required.\r\n3. Acid pickling to be done.\r\n4. Last Delivery Date 20.10.2025', 'ORAL', '09-06-2025', 'intrastate', 'intrastate', NULL, 'sgst', 'cgst', '', '73259930', 'SP03', '13', 'Collector Casting 8557', '', '4', 'CK/WO/25-26/-026', '69', '3-SPG-8557 Rev-0', 'NOS', '30', '420', '240', '240', '', '3024000.00', NULL, 'amount_wise', '', '3024000.00', '9', '272160.00', '9', '272160.00', '0', '0', NULL, '', '3024000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', '3568320.00', 'CK/PUR/25-26/-028050326', 'CK/PUR/25-26/-028-2026', 1, 1);
INSERT INTO `sup_purchaseorder_details` (`id`, `date`, `purchasedate`, `invoicedate`, `deliverydate`, `potype`, `tctype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `supplierid`, `suppliername`, `customerId`, `customername`, `address`, `shipTo`, `shipToAddress`, `invoiceno`, `requirements`, `vendor_quot`, `quot_date`, `billtype`, `gsttype`, `tcctype`, `typesgst`, `typecgst`, `typeigst`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `grade`, `workorderno`, `workorderid`, `drawingno`, `uom`, `weight`, `rate`, `qty`, `balanceqty`, `bom_qty`, `amount`, `discount`, `discountBy`, `discountamount`, `taxableamount`, `sgst`, `sgstamount`, `cgst`, `cgstamount`, `igst`, `igstamount`, `total`, `deliverydates`, `subtotal`, `freightamount`, `freightcgst`, `freightcgstamount`, `freightsgst`, `freightsgstamount`, `freightigst`, `freightigstamount`, `freighttotal`, `loadingamount`, `loadingcgst`, `loadingcgstamount`, `loadingsgst`, `loadingsgstamount`, `loadingigst`, `loadingigstamount`, `loadingtotal`, `othercharges`, `roundOff`, `return_status`, `grandtotal`, `purchasenodate`, `purchasenoyear`, `status`, `edit_status`) VALUES (35, '2026-03-06', '2026-03-06', NULL, '06-03-2026', 'workorder', '1', 'CK/PUR/25-26/-029', '0027', NULL, '8', 'PREMIER ALLOYS', 1, 'jack', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, NULL, '0', 'aaaaaaaaa', '000', '06-03-2026', 'intrastate', 'intrastate', NULL, 'sgst', 'cgst', '', '73259930||', '-||SW1', '29||26', 'Aluminium Plate Alloy 20mmX1160X575mm||Customized ERP Software ', 'a||b', '1||1', 'CK/WO/25-26/-027', '70||71', '0027||-', 'KGS||NOS', '20||10', '475||30000', '10||10', '10||10', '', '95000.00||3000000.00', NULL, 'amount_wise', '||', '95000.00||3000000.00', '9', '278550.00', '9', '278550.00', '0||0', '0||0', NULL, '31-03-2026||19-03-2026', '3095000.00', '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1||1', '3652100.00', 'CK/PUR/25-26/-029060326', 'CK/PUR/25-26/-029-2026', 1, 1);


#
# TABLE STRUCTURE FOR: sup_purchaseorder_details_backup
#

DROP TABLE IF EXISTS `sup_purchaseorder_details_backup`;

CREATE TABLE `sup_purchaseorder_details_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `purchasedate` date DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(225) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(225) DEFAULT NULL,
  `address` varchar(225) DEFAULT NULL,
  `invoiceno` varchar(225) DEFAULT NULL,
  `billtype` varchar(225) DEFAULT NULL,
  `gsttype` varchar(225) DEFAULT NULL,
  `typesgst` longtext DEFAULT NULL,
  `typecgst` longtext DEFAULT NULL,
  `typeigst` longtext DEFAULT NULL,
  `hsnno` longtext DEFAULT NULL,
  `itemname` longtext DEFAULT NULL,
  `uom` longtext DEFAULT NULL,
  `rate` longtext DEFAULT NULL,
  `qty` longtext DEFAULT NULL,
  `balanceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `amount` longtext DEFAULT NULL,
  `discount` longtext DEFAULT NULL,
  `discountBy` varchar(255) NOT NULL,
  `discountamount` longtext DEFAULT NULL,
  `taxableamount` longtext DEFAULT NULL,
  `sgst` longtext DEFAULT NULL,
  `sgstamount` longtext DEFAULT NULL,
  `cgst` longtext DEFAULT NULL,
  `cgstamount` longtext DEFAULT NULL,
  `igst` longtext DEFAULT NULL,
  `igstamount` longtext DEFAULT NULL,
  `total` longtext DEFAULT NULL,
  `subtotal` varchar(225) DEFAULT NULL,
  `freightamount` varchar(225) DEFAULT NULL,
  `freightcgst` varchar(225) DEFAULT NULL,
  `freightcgstamount` varchar(225) DEFAULT NULL,
  `freightsgst` varchar(225) DEFAULT NULL,
  `freightsgstamount` varchar(225) DEFAULT NULL,
  `freightigst` varchar(225) DEFAULT NULL,
  `freightigstamount` varchar(225) DEFAULT NULL,
  `freighttotal` varchar(225) DEFAULT NULL,
  `loadingamount` varchar(225) DEFAULT NULL,
  `loadingcgst` varchar(225) DEFAULT NULL,
  `loadingcgstamount` varchar(225) DEFAULT NULL,
  `loadingsgst` varchar(225) DEFAULT NULL,
  `loadingsgstamount` varchar(225) DEFAULT NULL,
  `loadingigst` varchar(225) DEFAULT NULL,
  `loadingigstamount` varchar(225) DEFAULT NULL,
  `loadingtotal` varchar(225) DEFAULT NULL,
  `othercharges` varchar(225) DEFAULT NULL,
  `roundOff` varchar(255) NOT NULL,
  `return_status` longtext DEFAULT NULL,
  `grandtotal` varchar(225) DEFAULT NULL,
  `purchasenodate` varchar(225) DEFAULT NULL,
  `purchasenoyear` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `edit_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: sup_purchaseorder_reports
#

DROP TABLE IF EXISTS `sup_purchaseorder_reports`;

CREATE TABLE `sup_purchaseorder_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseid` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `potype` varchar(255) NOT NULL,
  `purchaseorderno` varchar(255) DEFAULT NULL,
  `purchaseorder` varchar(255) DEFAULT NULL,
  `selected_bom` varchar(255) DEFAULT NULL,
  `purchasedate` varchar(255) DEFAULT NULL,
  `paymenttype` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `customername` varchar(255) DEFAULT NULL,
  `supplierid` varchar(100) NOT NULL,
  `suppliername` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `invoicedate` date DEFAULT NULL,
  `deliverydate` varchar(100) NOT NULL,
  `batchno` varchar(255) DEFAULT NULL,
  `itemno` varchar(255) DEFAULT NULL,
  `hsnno` varchar(255) DEFAULT NULL,
  `itemcode` varchar(100) NOT NULL,
  `itemid` varchar(100) DEFAULT NULL,
  `itemname` varchar(255) DEFAULT NULL,
  `item_desc` text NOT NULL,
  `uom` varchar(255) DEFAULT NULL,
  `weight` varchar(100) DEFAULT NULL,
  `rate` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `grade` varchar(100) NOT NULL,
  `drawingno` varchar(100) NOT NULL,
  `workorderid` varchar(100) NOT NULL,
  `workorderno` varchar(100) NOT NULL,
  `balaceqty` varchar(255) DEFAULT NULL,
  `bom_qty` varchar(255) NOT NULL,
  `total` varchar(255) DEFAULT NULL,
  `deliverydates` varchar(100) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `disamount` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `adjustment` varchar(255) DEFAULT NULL,
  `grandtotal` varchar(255) DEFAULT NULL,
  `taxtotal` varchar(255) DEFAULT NULL,
  `adjus` varchar(255) DEFAULT NULL,
  `vatadjus` varchar(255) DEFAULT NULL,
  `paid` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `bedadjs` varchar(200) DEFAULT NULL,
  `edcadjus` varchar(255) DEFAULT NULL,
  `sedadjus` varchar(255) DEFAULT NULL,
  `cstadjus` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `purchasenoyear` varchar(255) DEFAULT NULL,
  `purchasenodate` varchar(255) DEFAULT NULL,
  `requirements` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=139 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (15, '1', '2026-02-12', 'workorder', 'CK/PUR/25-26/-001', NULL, NULL, '2025-03-12', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', '11', 'Sri Ayyappa Engineering Works', '4/348C,Kallipalayam Road, Chikarampalayam, Karamadai, Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '84803000', 'SP01', '1', 'Coal Nozzle ', '', 'NOS', '1', '142000', '1', '1', 'C-13-004', '3', 'CK/WO/25-26/-001', '0', '', NULL, '', '142000.00', NULL, NULL, NULL, NULL, NULL, '167560.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-001-2026', 'CK/PUR/25-26/-001120226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (10, '7', '2026-02-11', 'workorder', 'CK/PUR/25-26/-002', '-', NULL, '2025-03-12', NULL, 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0', NULL, '30-03-2025', NULL, NULL, '73259930', 'CA16', '3', '1/2\" CL 600 Body', '', 'NOS', '3', '600', '20', '1', '-', '15', 'CK/WO/25-26/-002', '0', '', NULL, '30-03-2025', '36000.00', NULL, NULL, NULL, NULL, NULL, '42480.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-002-2026', 'CK/PUR/25-26/-002110226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (50, '8', '2026-02-17', 'workorder', 'CK/PUR/25-26/-003', 'PO3704', NULL, '2025-03-12', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259930', 'SP01', '2', 'Coal Nozzle(C)', '', 'NOS', '120', '450', '4', '1', 'C-13-004', '4', 'CK/WO/25-26/-001', '4', '', NULL, '', '216000.00', NULL, NULL, NULL, NULL, NULL, '254880.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-003-2026', 'CK/PUR/25-26/-003170226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (12, '9', '2026-02-11', 'workorder', 'CK/PUR/25-26/-004', 'CAD2025405 REV 01', NULL, '2025-03-23', NULL, 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0', NULL, '30-05-2025', NULL, NULL, '73259999', 'CA16', '3', '1/2\" CL 600 Body', '', 'NOS', '3.5', '200', '20', '2', '-', '16', 'CK/WO/25-26/-003', '3', '', NULL, '', '14000.00', NULL, NULL, NULL, NULL, NULL, '16520.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-004-2026', 'CK/PUR/25-26/-004110226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (14, '10', '2026-02-12', 'workorder', 'CK/PUR/25-26/-005', 'PO-SC-2526-008', NULL, '2025-04-18', NULL, 9, 'STAAN BIO MED PVT LTD', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259999', 'SBM08', '4', 'EH Outer Box', '', 'NOS', '33.9', '150', '40', '1', 'ST-MSC-017', '17', 'CK/WO/25-26/-004', '0', '', NULL, '28-04-2025', '203400.00', NULL, NULL, NULL, NULL, NULL, '240012.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-005-2026', 'CK/PUR/25-26/-005120226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (51, '11', '2026-02-17', 'workorder', 'CK/PUR/25-26/-006', '1', NULL, '2025-05-05', NULL, 13, 'CKP LOI', '12', 'PKS Inspection Service', '83A Pudukadu 2nd Street,Sivanathapuram, Vellakovil-638111,Kangeyam Taluk, Tiruppur, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '998898', '001', '17', 'Inspection', '', 'NOS', '1', '2000', '1', '1', '-', '22', 'CK/WO/25-26/-007', '1', '', NULL, '30-05-2025', '2000.00', NULL, NULL, NULL, NULL, NULL, '2360.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-006-2026', 'CK/PUR/25-26/-006170226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (54, '12', '2026-02-17', 'workorder', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', NULL, '2025-05-06', NULL, 9, 'STAAN BIO MED PVT LTD', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259999', 'SBM10', '7', '12FN Top Plate', '', 'NOS', '27', '155', '51', '1', 'STMSC022 R1', '20', 'CK/WO/25-26/-005', '0', '', NULL, '', '523590.00', NULL, NULL, NULL, NULL, NULL, '617836.20', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-007-2026', 'CK/PUR/25-26/-007170226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (53, '12', '2026-02-17', 'workorder', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', NULL, '2025-05-06', NULL, 9, 'STAAN BIO MED PVT LTD', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259999', 'SBM05', '6', 'LH Inner Box', '', 'NOS', '26.1', '155', '40', '1', 'ST-MSC-014-R1', '19', 'CK/WO/25-26/-005', '0', '', NULL, '', '523590.00', NULL, NULL, NULL, NULL, NULL, '617836.20', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-007-2026', 'CK/PUR/25-26/-007170226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (52, '12', '2026-02-17', 'workorder', 'CK/PUR/25-26/-007', 'PO-SC-2526-020', NULL, '2025-05-06', NULL, 9, 'STAAN BIO MED PVT LTD', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259999', 'SBM03', '5', 'LH Outer Box', '', 'NOS', '24.6', '155', '40', '1', 'ST-MSC-016', '18', 'CK/WO/25-26/-005', '0', '', NULL, '', '523590.00', NULL, NULL, NULL, NULL, NULL, '617836.20', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-007-2026', 'CK/PUR/25-26/-007170226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (62, '13', '2026-02-17', 'workorder', 'CK/PUR/25-26/-008', '', NULL, '2025-05-07', NULL, 13, 'CKP LOI', '11', 'Sri Ayyappa Engineering Works', '4/348C,Kallipalayam Road, Chikarampalayam, Karamadai, Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '84803000', 'CA02', '18', '4\" 1500 Body', 'Pattern & CoreBox for Dimension rework', 'NOS', '1', '8000', '1', '1', 'CAD-SPS-YST-0001', '23', 'CK/WO/25-26/-008', '0', '', NULL, '', '8000.00', NULL, NULL, NULL, NULL, NULL, '9440.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-008-2026', 'CK/PUR/25-26/-008170226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (56, '14', '2026-02-17', 'workorder', 'CK/PUR/25-26/-009', 'CAD2025363 REV01', NULL, '2025-05-08', NULL, 7, 'M/S CADALAN OFFSHORE PRIVATE LIMITED', '14', 'Shree Kumaran Alloys', 'S/F No - 461, Telungupalayam Road,, Ellapalayam Post,Annur, Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259999', 'CA02', '18', '4\" 1500 Body', '', 'NOS', '212', '175', '5', '1', 'CAD-SPS-YST-0001', '21', 'CK/WO/25-26/-006', '0', '', NULL, '08-06-2025', '185500.00', NULL, NULL, NULL, NULL, NULL, '218890.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-009-2026', 'CK/PUR/25-26/-009170226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (58, '15', '2026-02-17', 'workorder', 'CK/PUR/25-26/-010', '', NULL, '2025-05-12', NULL, 15, 'OM Industries', '8', 'Sri Ayyappa Engineering Works', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '84803000', 'OMI 02', '20', 'Retainer 3.0 Pattern', '', 'NOS', '1', '32000', '1', '1', '3.062269', '30', 'CK/WO/25-26/-009', '0', '', NULL, '30-05-2025', '72000.00', NULL, NULL, NULL, NULL, NULL, '84960.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-010-2026', 'CK/PUR/25-26/-010170226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (57, '15', '2026-02-17', 'workorder', 'CK/PUR/25-26/-010', '', NULL, '2025-05-12', NULL, 15, 'OM Industries', '8', 'Sri Ayyappa Engineering Works', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '84803000', 'OMI 01', '19', 'Retainer 2.0  Pattern', '', 'NOS', '1', '40000', '1', '1', '2.067398', '29', 'CK/WO/25-26/-009', '0', '', NULL, '30-05-2025', '72000.00', NULL, NULL, NULL, NULL, NULL, '84960.00', NULL, NULL, NULL, NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-010-2026', 'CK/PUR/25-26/-010170226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (59, '16', '2026-02-17', 'workorder', 'CK/PUR/25-26/-011', 'PO 3742', NULL, '2025-05-16', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259930', 'SP02', '12', 'Collector Casting', '', 'NOS', '28.7', '410', '4', '1', '3-SPG-9473', '31', 'CK/WO/25-26/-010', '4', '', NULL, '', '47068.00', NULL, NULL, NULL, NULL, NULL, '55540.24', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-011-2026', 'CK/PUR/25-26/-011170226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (61, '17', '2026-02-17', 'workorder', 'CK/PUR/25-26/-012', 'OM/PO/05-25-26/01', NULL, '2025-05-19', NULL, 15, 'OM Industries', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259920', 'OMI 01', '15', 'Retainer 2.0', '', 'NOS', '103', '165', '12', '1', '2.067398', '27', 'CK/WO/25-26/-009', '0', '', NULL, '', '236280.00', NULL, NULL, NULL, NULL, NULL, '278810.40', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-012-2026', 'CK/PUR/25-26/-012170226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (60, '17', '2026-02-17', 'workorder', 'CK/PUR/25-26/-012', 'OM/PO/05-25-26/01', NULL, '2025-05-19', NULL, 15, 'OM Industries', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259920', 'OMI 02', '16', 'Retainer 3.0', '', 'NOS', '49', '165', '4', '1', '3.062269', '28', 'CK/WO/25-26/-009', '0', '', NULL, '', '236280.00', NULL, NULL, NULL, NULL, NULL, '278810.40', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-012-2026', 'CK/PUR/25-26/-012170226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (63, '18', '2026-02-17', 'workorder', 'CK/PUR/25-26/-013', '3', NULL, '2026-05-20', NULL, 13, 'CKP LOI', '11', 'Sri Ayyappa Engineering Works', '4/348C,Kallipalayam Road, Chikarampalayam, Karamadai, Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '84803000', 'SP03', '21', 'Collector Casting 3-SPG-8557', '1 Set Aluminium Pattern with Match Plate for Rework', 'NOS', '1', '9500', '1', '1', '3-SPG-8557', '36', 'CK/WO/25-26/-011', '1', '', NULL, '20-06-2025', '9500.00', NULL, NULL, NULL, NULL, NULL, '11210.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-013-2026', 'CK/PUR/25-26/-013170226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (64, '19', '2026-02-17', 'workorder', 'CK/PUR/25-26/-014', 'PO 3755', NULL, '2025-06-10', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259930', 'SP02', '12', 'Collector Casting', '', 'NOS', '27.5', '420', '348', '1', '3-SPG-9473', '40', 'CK/WO/25-26/-012', '248', '', NULL, '', '4019400.00', NULL, NULL, NULL, NULL, NULL, '4742892.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-014-2026', 'CK/PUR/25-26/-014170226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (111, '20', '2026-03-05', 'workorder', 'CK/PUR/25-26/-015', 'PO-2526-0333', NULL, '2025-06-11', NULL, 9, 'STAAN BIO MED PVT LTD', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259999', 'SBM09', NULL, 'Moving Block', '', 'NOS', '10', '155', '100', '2', 'ST-MSC-012 R1', '43', 'CK/WO/25-26/-013', '100', '', NULL, '15-07-2025', '496000.00', NULL, NULL, NULL, NULL, NULL, '585280.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-015-2026', 'CK/PUR/25-26/-015050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (110, '20', '2026-03-05', 'workorder', 'CK/PUR/25-26/-015', 'PO-2526-0333', NULL, '2025-06-11', NULL, 9, 'STAAN BIO MED PVT LTD', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259999', 'SBM02', NULL, 'NH Outer Box', '', 'NOS', '27', '155', '40', '2', 'ST-MSC-015', '41', 'CK/WO/25-26/-013', '40', '', NULL, '15-07-2025', '496000.00', NULL, NULL, NULL, NULL, NULL, '585280.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-015-2026', 'CK/PUR/25-26/-015050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (112, '21', '2026-03-05', 'workorder', 'CK/PUR/25-26/-016', '3757', NULL, '2025-06-16', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259930', 'SP03', NULL, 'Collector Casting 8557', '', 'NOS', '30.5', '420', '4', '1', '3-SPG-8557 ', '44', 'CK/WO/25-26/-014', '4', '', NULL, '30-06-2025', '51240.00', NULL, NULL, NULL, NULL, NULL, '60463.20', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-016-2026', 'CK/PUR/25-26/-016050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (69, '22', '2026-02-17', 'workorder', 'CK/PUR/25-26/-017', '4', NULL, '2025-06-23', NULL, 13, 'CKP LOI', '16', 'TryMy Website', '2nd Floor, SK Towers, Sathy Main Road, , Saravanampatti, Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '998898', 'WC1', '22', 'Website Creation', 'Domain (1 year)         Hosting 1 GB(1 year)       6 Pages responsive Design        Watsapp Integration     Social Media Integration  Mobile Responsive Design', 'NOS', '1', '6000', '1', '1', '-', '45', 'CK/WO/25-26/-015', '1', '', NULL, '30-07-2025', '6000.00', NULL, NULL, NULL, NULL, NULL, '7080.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-017-2026', 'CK/PUR/25-26/-017170226', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (115, '24', '2026-03-05', 'workorder', 'CK/PUR/25-26/-019', '3757', NULL, '2025-07-16', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259930', 'SP03', NULL, 'Collector Casting 8557', '', 'NOS', '30', '420', '120', '1', '3-SPG-8557 ', '44', 'CK/WO/25-26/-014', '120', '', NULL, '25-07-2025', '1512000.00', NULL, NULL, NULL, NULL, NULL, '1784160.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-019-2026', 'CK/PUR/25-26/-019050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (117, '25', '2026-03-05', 'workorder', 'CK/PUR/25-26/-020', 'PO-SC-2526-097', NULL, '2025-07-17', NULL, 9, 'STAAN BIO MED PVT LTD', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259999', 'SBM05', NULL, 'LH Inner Box', '', 'NOS', '25.6', '155', '40', '2', 'ST-MSC-014-R1', '47', 'CK/WO/25-26/-016', '40', '', NULL, '25-08-2025', '310000.00', NULL, NULL, NULL, NULL, NULL, '365800.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-020-2026', 'CK/PUR/25-26/-020050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (116, '25', '2026-03-05', 'workorder', 'CK/PUR/25-26/-020', 'PO-SC-2526-097', NULL, '2025-07-17', NULL, 9, 'STAAN BIO MED PVT LTD', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259999', 'SBM03', NULL, 'LH Outer Box', '', 'NOS', '24.4', '155', '40', '2', 'ST-MSC-016', '46', 'CK/WO/25-26/-016', '40', '', NULL, '18-08-2025', '310000.00', NULL, NULL, NULL, NULL, NULL, '365800.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-020-2026', 'CK/PUR/25-26/-020050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (118, '27', '2026-03-05', 'workorder', 'CK/PUR/25-26/-021', '6', NULL, '2025-07-17', NULL, 13, 'CKP LOI', '17', 'IDREAMDEVELOPERS', 'No:91,Dr.Jaganathan Nagar,, Civil Aerodrome Post, Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '998898', 'SW1', NULL, 'Customized ERP Software ', 'Cloud/Online Version Including 1st Year Server AMC', 'NOS', '1', '30000', '1', '7', '-', '57', 'CK/WO/25-26/-020', '1', '', NULL, '', '30000.00', NULL, NULL, NULL, NULL, NULL, '35400.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-021-2026', 'CK/PUR/25-26/-021050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (109, '20', '2026-03-05', 'workorder', 'CK/PUR/25-26/-015', 'PO-2526-0333', NULL, '2025-06-11', NULL, 9, 'STAAN BIO MED PVT LTD', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259999', 'SBM04', NULL, 'NH Inner Box', '', 'NOS', '28', '155', '40', '2', 'ST-MSC-013 R1', '42', 'CK/WO/25-26/-013', '40', '', NULL, '15-07-2025', '496000.00', NULL, NULL, NULL, NULL, NULL, '585280.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-015-2026', 'CK/PUR/25-26/-015050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (120, '28', '2026-03-05', 'workorder', 'CK/PUR/25-26/-022', '7', NULL, '2025-07-20', NULL, 13, 'CKP LOI', '11', 'Sri Ayyappa Engineering Works', '4/348C,Kallipalayam Road, Chikarampalayam, Karamadai, Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '84803000', 'SP03', NULL, 'Collector Casting 3-SPG-8557', '1 Set Aluminium Pattern With Match Plate For Rework & finishing. MatchPlate Remounting Putty Finishing', 'NOS', '1', '30000', '1', '6', '3-SPG-8557', '59', 'CK/WO/25-26/-021', '1', '', NULL, '', '60000.00', NULL, NULL, NULL, NULL, NULL, '70800.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-022-2026', 'CK/PUR/25-26/-022050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (119, '28', '2026-03-05', 'workorder', 'CK/PUR/25-26/-022', '7', NULL, '2025-07-20', NULL, 13, 'CKP LOI', '11', 'Sri Ayyappa Engineering Works', '4/348C,Kallipalayam Road, Chikarampalayam, Karamadai, Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '84803000', 'SP02', NULL, 'Collector Casting 3-SPG-9473', '1 Set Aluminium Pattern With Match Plate For Rework & finishing. MatchPlate Remounting Putty Finishing', 'NOS', '1', '30000', '1', '6', '3-SPG-9473', '58', 'CK/WO/25-26/-021', '1', '', NULL, '', '60000.00', NULL, NULL, NULL, NULL, NULL, '70800.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-022-2026', 'CK/PUR/25-26/-022050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (121, '29', '2026-03-05', 'workorder', 'CK/PUR/25-26/-023', '8', NULL, '2025-08-05', NULL, 13, 'CKP LOI', '14', 'Shree Kumaran Alloys', 'S/F No - 461, Telungupalayam Road,, Ellapalayam Post,Annur, Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259930', 'EP01', NULL, 'Casing EO8-250', '', 'NOS', '250', '600', '3', '8', '005.01.2086-0', '60', 'CK/WO/25-26/-022', '3', '', NULL, '', '450000.00', NULL, NULL, NULL, NULL, NULL, '531000.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-023-2026', 'CK/PUR/25-26/-023050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (126, '30', '2026-03-05', 'workorder', 'CK/PUR/25-26/-024', 'PO-2526-0628', NULL, '2025-08-07', NULL, 9, 'STAAN BIO MED PVT LTD', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259999', 'SBM09', NULL, 'Moving Block', '', 'NOS', '10.00', '155', '60', '2', 'ST-MSC-012 R1', '56', 'CK/WO/25-26/-019', '60', '', NULL, '', '734700.00', NULL, NULL, NULL, NULL, NULL, '866946.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-024-2026', 'CK/PUR/25-26/-024050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (125, '30', '2026-03-05', 'workorder', 'CK/PUR/25-26/-024', 'PO-2526-0628', NULL, '2025-08-07', NULL, 9, 'STAAN BIO MED PVT LTD', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259999', 'SBM03', NULL, 'LH Outer Box', '', 'NOS', '24.4', '155', '30', '2', 'ST-MSC-016', '55', 'CK/WO/25-26/-019', '30', '', NULL, '', '734700.00', NULL, NULL, NULL, NULL, NULL, '866946.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-024-2026', 'CK/PUR/25-26/-024050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (124, '30', '2026-03-05', 'workorder', 'CK/PUR/25-26/-024', 'PO-2526-0628', NULL, '2025-08-07', NULL, 9, 'STAAN BIO MED PVT LTD', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259999', 'SBM05', NULL, 'LH Inner Box', '', 'NOS', '25.6', '155', '45', '2', 'ST-MSC-014-R1', '54', 'CK/WO/25-26/-019', '45', '', NULL, '', '734700.00', NULL, NULL, NULL, NULL, NULL, '866946.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-024-2026', 'CK/PUR/25-26/-024050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (123, '30', '2026-03-05', 'workorder', 'CK/PUR/25-26/-024', 'PO-2526-0628', NULL, '2025-08-07', NULL, 9, 'STAAN BIO MED PVT LTD', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259999', 'SBM04', NULL, 'NH Inner Box', '', 'NOS', '28.4', '155', '40', '2', 'ST-MSC-013 R1', '53', 'CK/WO/25-26/-019', '40', '', NULL, '', '734700.00', NULL, NULL, NULL, NULL, NULL, '866946.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-024-2026', 'CK/PUR/25-26/-024050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (122, '30', '2026-03-05', 'workorder', 'CK/PUR/25-26/-024', 'PO-2526-0628', NULL, '2025-08-07', NULL, 9, 'STAAN BIO MED PVT LTD', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259999', 'SBM02', NULL, 'NH Outer Box', '', 'NOS', '28', '155', '40', '2', 'ST-MSC-015', '52', 'CK/WO/25-26/-019', '40', '', NULL, '', '734700.00', NULL, NULL, NULL, NULL, NULL, '866946.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-024-2026', 'CK/PUR/25-26/-024050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (108, '31', '2026-03-05', 'workorder', 'CK/PUR/25-26/-025', '3801', NULL, '2025-08-18', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259930', 'SP03', NULL, 'Collector Casting 8557', '', 'NOS', '30', '420', '60', '4', '3-SPG-8557 REV01', '61', 'CK/WO/25-26/-023', '60', '', NULL, '10-09-2025', '756000.00', NULL, NULL, NULL, NULL, NULL, '892080.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-025-2026', 'CK/PUR/25-26/-025050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (130, '32', '2026-03-05', 'workorder', 'CK/PUR/25-26/-026', '9', NULL, '2025-08-20', NULL, 13, 'CKP LOI', '18', 'Coimbatore Metals', 'No.392-C.,  Dr.Nanjappa Road,, coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '84803000', '-', NULL, '115mmX260X150mm', '', 'KGS', '28', '500', '1', '6', '-', '63', 'CK/WO/25-26/-024', '1', '', NULL, '28-05-2025', '31812.50', NULL, NULL, NULL, NULL, NULL, '37538.76', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-026-2026', 'CK/PUR/25-26/-026050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (129, '32', '2026-03-05', 'workorder', 'CK/PUR/25-26/-026', '9', NULL, '2025-08-20', NULL, 13, 'CKP LOI', '18', 'Coimbatore Metals', 'No.392-C.,  Dr.Nanjappa Road,, coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '84803000', '-', NULL, 'Aluminium Plate Alloy 20mmX1160X575mm', '', 'KGS', '37.5', '475', '1', '6', '-', '62', 'CK/WO/25-26/-024', '1', '', NULL, '28-05-2025', '31812.50', NULL, NULL, NULL, NULL, NULL, '37538.76', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-026-2026', 'CK/PUR/25-26/-026050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (135, '33', '2026-03-05', 'workorder', 'CK/PUR/25-26/-027', '10', NULL, '2025-08-21', NULL, 13, 'CKP LOI', '10', 'Shristi Engineering Works', 'Door No.3,Ravathur Road,, Athappa Gounder Pudur,Irugur, Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '84803000', 'SBM09', NULL, 'Moving Block', '1 Nos Aluminium Corebox(New)', 'NOS', '1', '12000', '1', '6', 'ST-MSC-012 R1', '68', 'CK/WO/25-26/-025', '1', '', NULL, '', '32000.00', NULL, NULL, NULL, NULL, NULL, '37760.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-027-2026', 'CK/PUR/25-26/-027050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (134, '33', '2026-03-05', 'workorder', 'CK/PUR/25-26/-027', '10', NULL, '2025-08-21', NULL, 13, 'CKP LOI', '10', 'Shristi Engineering Works', 'Door No.3,Ravathur Road,, Athappa Gounder Pudur,Irugur, Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '84803000', 'SBM15', NULL, 'EH Inner Box', '1 Set Aluminium Pattern Finishing', 'NOS', '1', '5000', '1', '6', 'ST-MSC-027 R0', '67', 'CK/WO/25-26/-025', '1', '', NULL, '', '32000.00', NULL, NULL, NULL, NULL, NULL, '37760.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-027-2026', 'CK/PUR/25-26/-027050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (133, '33', '2026-03-05', 'workorder', 'CK/PUR/25-26/-027', '10', NULL, '2025-08-21', NULL, 13, 'CKP LOI', '10', 'Shristi Engineering Works', 'Door No.3,Ravathur Road,, Athappa Gounder Pudur,Irugur, Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '84803000', 'SBM04', NULL, 'NH Inner Box', '1 Set Aluminium Pattern Finishing', 'NOS', '1', '5000', '1', '6', 'ST-MSC-013 R1', '66', 'CK/WO/25-26/-025', '1', '', NULL, '', '32000.00', NULL, NULL, NULL, NULL, NULL, '37760.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-027-2026', 'CK/PUR/25-26/-027050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (132, '33', '2026-03-05', 'workorder', 'CK/PUR/25-26/-027', '10', NULL, '2025-08-21', NULL, 13, 'CKP LOI', '10', 'Shristi Engineering Works', 'Door No.3,Ravathur Road,, Athappa Gounder Pudur,Irugur, Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '84803000', 'SBM02', NULL, 'NH Outer Box', '1 Set Aluminium Pattern Finishing', 'NOS', '1', '5000', '1', '6', 'ST-MSC-015', '65', 'CK/WO/25-26/-025', '1', '', NULL, '', '32000.00', NULL, NULL, NULL, NULL, NULL, '37760.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-027-2026', 'CK/PUR/25-26/-027050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (131, '33', '2026-03-05', 'workorder', 'CK/PUR/25-26/-027', '10', NULL, '2025-08-21', NULL, 13, 'CKP LOI', '10', 'Shristi Engineering Works', 'Door No.3,Ravathur Road,, Athappa Gounder Pudur,Irugur, Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '84803000', 'SBM08', NULL, 'EH Outer Box', '1 Set Aluminium Pattern Finishing', 'NOS', '1', '5000', '1', '6', 'ST-MSC-017', '64', 'CK/WO/25-26/-025', '1', '', NULL, '', '32000.00', NULL, NULL, NULL, NULL, NULL, '37760.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-027-2026', 'CK/PUR/25-26/-027050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (114, '23', '2026-03-05', 'workorder', 'CK/PUR/25-26/-018', '', NULL, '2025-06-28', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', NULL, '1970-01-01', '', NULL, NULL, '73259930', 'SP03', NULL, 'Collector Casting 8557', '', 'NOS', '30.5', '420', '4', '1', '3-SPG-8557 ', '44', 'CK/WO/25-26/-014', '4', '', NULL, '30-07-2025', '51240.00', NULL, NULL, NULL, NULL, NULL, '60463.20', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-018-2026', 'CK/PUR/25-26/-018050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (136, '34', '2026-03-05', 'workorder', 'CK/PUR/25-26/-028', '3811', NULL, '2025-09-03', NULL, 2, 'SIGMA POWER & ENERGY ENGINEERS', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0', NULL, '20-10-2025', NULL, NULL, '73259930', 'SP03', '13', 'Collector Casting 8557', '', 'NOS', '30', '420', '240', '4', '3-SPG-8557 Rev-0', '69', 'CK/WO/25-26/-026', '240', '', NULL, '', '3024000.00', NULL, NULL, NULL, NULL, NULL, '3568320.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-028-2026', 'CK/PUR/25-26/-028050326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (137, '35', '2026-03-06', 'workorder', 'CK/PUR/25-26/-029', '0027', NULL, '2026-03-06', NULL, 1, 'jack', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0', NULL, '06-03-2026', NULL, NULL, '73259930', '-', '29', 'Aluminium Plate Alloy 20mmX1160X575mm', 'a', 'KGS', '20', '475', '10', '1', '0027', '70', 'CK/WO/25-26/-027', '10', '', NULL, '31-03-2026', '3095000.00', NULL, NULL, NULL, NULL, NULL, '3652100.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-029-2026', 'CK/PUR/25-26/-029060326', NULL);
INSERT INTO `sup_purchaseorder_reports` (`id`, `purchaseid`, `date`, `potype`, `purchaseorderno`, `purchaseorder`, `selected_bom`, `purchasedate`, `paymenttype`, `customerId`, `customername`, `supplierid`, `suppliername`, `address`, `invoiceno`, `invoicedate`, `deliverydate`, `batchno`, `itemno`, `hsnno`, `itemcode`, `itemid`, `itemname`, `item_desc`, `uom`, `weight`, `rate`, `qty`, `grade`, `drawingno`, `workorderid`, `workorderno`, `balaceqty`, `bom_qty`, `total`, `deliverydates`, `subtotal`, `discount`, `disamount`, `taxname`, `taxamount`, `adjustment`, `grandtotal`, `taxtotal`, `adjus`, `vatadjus`, `paid`, `balance`, `status`, `bedadjs`, `edcadjus`, `sedadjus`, `cstadjus`, `taxpercentage`, `purchasenoyear`, `purchasenodate`, `requirements`) VALUES (138, '35', '2026-03-06', 'workorder', 'CK/PUR/25-26/-029', '0027', NULL, '2026-03-06', NULL, 1, 'jack', '8', 'PREMIER ALLOYS', 'No 2, Goldwins,Avinashi Road, , Civil Aerodrome(po), Coimbatore, Tamil Nadu', '0', NULL, '06-03-2026', NULL, NULL, '', 'SW1', '26', 'Customized ERP Software ', 'b', 'NOS', '10', '30000', '10', '1', '-', '71', 'CK/WO/25-26/-027', '10', '', NULL, '19-03-2026', '3095000.00', NULL, NULL, NULL, NULL, NULL, '3652100.00', NULL, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL, 'CK/PUR/25-26/-029-2026', 'CK/PUR/25-26/-029060326', NULL);


#
# TABLE STRUCTURE FOR: tbl_person
#

DROP TABLE IF EXISTS `tbl_person`;

CREATE TABLE `tbl_person` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: uom
#

DROP TABLE IF EXISTS `uom`;

CREATE TABLE `uom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `uom` varchar(225) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (1, '2025-06-20', 'KGS', 1);
INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (2, '2025-06-21', 'NOS', 1);
INSERT INTO `uom` (`id`, `date`, `uom`, `status`) VALUES (3, '2025-06-23', 'PACK', 1);


#
# TABLE STRUCTURE FOR: user_menu
#

DROP TABLE IF EXISTS `user_menu`;

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) NOT NULL,
  `main_menu` varchar(255) NOT NULL,
  `sub_menu` varchar(255) NOT NULL,
  `sub_menu_link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: ut_report
#

DROP TABLE IF EXISTS `ut_report`;

CREATE TABLE `ut_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `ut_report_no` varchar(100) NOT NULL,
  `ut_date` varchar(100) NOT NULL,
  `customername` varchar(100) NOT NULL,
  `customerid` varchar(100) NOT NULL,
  `stage_of_test` varchar(100) NOT NULL,
  `test_date` varchar(100) NOT NULL,
  `surface_condition` varchar(100) NOT NULL,
  `calibration_block` varchar(100) NOT NULL,
  `equipment` varchar(100) NOT NULL,
  `couplant` varchar(100) NOT NULL,
  `probe` varchar(100) NOT NULL,
  `range_of_crt` varchar(100) NOT NULL,
  `frequency` varchar(100) NOT NULL,
  `gain` varchar(100) NOT NULL,
  `area_coverage` varchar(100) NOT NULL,
  `procedure_ref` varchar(100) NOT NULL,
  `acceptance_standard` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `itemid` varchar(100) NOT NULL,
  `drawing` varchar(100) NOT NULL,
  `grade` varchar(100) NOT NULL,
  `heat_no` varchar(100) NOT NULL,
  `ut_no` varchar(100) NOT NULL,
  `result` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

#
# TABLE STRUCTURE FOR: vat_details
#

DROP TABLE IF EXISTS `vat_details`;

CREATE TABLE `vat_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `taxtype` varchar(255) DEFAULT NULL,
  `taxname` varchar(255) DEFAULT NULL,
  `taxpercentage` varchar(255) DEFAULT NULL,
  `sgst` varchar(225) DEFAULT NULL,
  `cgst` varchar(225) DEFAULT NULL,
  `igst` varchar(225) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO `vat_details` (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (1, '2025-06-20', 'gst', '18', 'gst @ 18 %', '9', '9', '18', '1');
INSERT INTO `vat_details` (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (2, '2025-06-21', 'GSt', '12', 'GSt @ 12 %', '6', '6', '12', '1');
INSERT INTO `vat_details` (`id`, `date`, `taxtype`, `taxname`, `taxpercentage`, `sgst`, `cgst`, `igst`, `status`) VALUES (3, '2025-06-23', 'GST', '15', 'GST @ 15 %', '7.5', '7.5', '15', '1');


#
# TABLE STRUCTURE FOR: vendor_details
#

DROP TABLE IF EXISTS `vendor_details`;

CREATE TABLE `vendor_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `vendorname` varchar(255) DEFAULT NULL,
  `phoneno` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `tinno` varchar(255) DEFAULT NULL,
  `cstno` varchar(255) DEFAULT NULL,
  `creditdays` varchar(255) DEFAULT NULL,
  `panno` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `eccno` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `commissionerate` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `accountname` varchar(100) NOT NULL,
  `printname` varchar(100) NOT NULL,
  `statecode` varchar(255) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `adharno` varchar(255) NOT NULL,
  `bankname` varchar(100) NOT NULL,
  `accountno` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

#
# TABLE STRUCTURE FOR: voucher
#

DROP TABLE IF EXISTS `voucher`;

CREATE TABLE `voucher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `tdsamount` varchar(100) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) DEFAULT NULL,
  `purchaseno` varchar(255) DEFAULT NULL,
  `balance_amt` varchar(255) DEFAULT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

#
# TABLE STRUCTURE FOR: voucher_backup
#

DROP TABLE IF EXISTS `voucher_backup`;

CREATE TABLE `voucher_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `voucherid` varchar(255) DEFAULT NULL,
  `cus_suppId` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `voucherdate` date DEFAULT NULL,
  `vouchertype` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `paymentmode` varchar(255) DEFAULT NULL,
  `throughcheck` varchar(255) DEFAULT NULL,
  `chequeno` varchar(255) DEFAULT NULL,
  `chamount` varchar(255) DEFAULT NULL,
  `banktransfer` varchar(255) DEFAULT NULL,
  `bamount` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `paymentdetails` varchar(255) DEFAULT NULL,
  `transactionid` varchar(225) DEFAULT NULL,
  `chequedate` varchar(225) DEFAULT NULL,
  `overallamount` varchar(255) DEFAULT NULL,
  `voucheramount` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `invoiceno` varchar(255) NOT NULL,
  `purchaseno` varchar(255) NOT NULL,
  `balance_amt` varchar(255) NOT NULL,
  `otherBank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

