<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
ob_start();
error_reporting(0);
class Purchase extends CI_Controller {

public function __construct()
{
parent::__construct();
$this->load->model('purchase_model');
if($this->session->userdata('rcbio_login')=='')
{

$this->session->set_flashdata('msg','Please Login to continue!');
redirect('login');
} 
date_default_timezone_set('Asia/Kolkata');    
}

public function index()
{
$query_update1 =$this->db->where('status',1)->order_by('id','desc')->limit(1)->get('purchase_details')->result_array();
foreach($query_update1 as $row)
{
@$quotationnos=$row['purchaseno'];
}
if(date('m')=='04')
{

$month=date('m');
$year=date('Y');
$old=$this->db->where('month(date)', $month)->where('year(date) ', $year)->where('status',1)->get('purchase_details')->result_array();
if($old)
{
@$bond_no = $quotationnos;

if(is_null($bond_no))
{
$default_bond=$this->db->where('id',1)->get('preference_settings')->row();
$new_bond_prefix = $default_bond->purchasePrefix;
$new_bond_noo = $new_bond_prefix.$default_bond->purchase;
//$new_bond_noo = 'P00001'; 
} 
else 
{
$default_bond=$this->db->where('id',1)->where('purchase !=','')->get('preference_settings')->row();
if($default_bond)
{
$bond_no=$default_bond->purchase;
$bondLen = strlen($bond_no);
$bondOnlyNum = filter_var($bond_no, FILTER_SANITIZE_NUMBER_INT);
$new_bond_prefix = $default_bond->purchasePrefix;
$new_bond_noo = $new_bond_prefix.sprintf('%0'.$bondLen.'d', $bondOnlyNum);
}
else
{
$bondLen = strlen($bond_no);
$bondOnlyNum = filter_var($bond_no, FILTER_SANITIZE_NUMBER_INT);
$default_bond=$this->db->where('id',1)->where('purchase !=','')->get('preference_settings')->row();
$new_bond_prefix = $default_bond->purchasePrefix;
$new_bond_noo = $new_bond_prefix.sprintf('%0'.$bondLen.'d', (float)$bondOnlyNum + 1);
}

}
}
else
{
$default_bond=$this->db->where('id',1)->get('preference_settings')->row();
$new_bond_prefix = $default_bond->purchasePrefix;
$new_bond_noo = $new_bond_prefix.$default_bond->purchase;
//$new_bond_noo = 'P00001';
}
}
else
{
@$bond_no = $quotationnos;
if(is_null($bond_no))
{
$default_bond=$this->db->where('id',1)->get('preference_settings')->row();
$new_bond_prefix = $default_bond->purchasePrefix;
$new_bond_noo = $new_bond_prefix.$default_bond->purchase;
//$new_bond_noo = 'P00001'; 
} 
else
{
$default_bond=$this->db->where('id',1)->where('purchase !=','')->get('preference_settings')->row();
if($default_bond)
{
@$bond_no=$default_bond->purchase;
$new_bond_prefix = $default_bond->purchasePrefix;
$bondLen = strlen($bond_no);
$bondOnlyNum = filter_var($bond_no, FILTER_SANITIZE_NUMBER_INT);
$new_bond_noo = $new_bond_prefix.sprintf('%0'.$bondLen.'d', $bondOnlyNum);
}
else
{
$bondLen = strlen($bond_no);
$default_bond=$this->db->where('id',1)->get('preference_settings')->row();
$new_bond_prefix = $default_bond->purchasePrefix;
$bondOnlyNum = filter_var($bond_no, FILTER_SANITIZE_NUMBER_INT);
$new_bond_noo = $new_bond_prefix.sprintf('%0'.$bondLen.'d', $bondOnlyNum + 1);
}

}
}

$data['invoiceno']=$new_bond_noo;
$this->load->view('header');
$this->load->view('add_purchase',$data);
$this->load->view('footer');
}

public function insert()
{

	$balanceqty = implode('||',$this->input->post('balaceqty'));
	print_r($balanceqty);die;

$query_update1 =$this->db->where('status',1)->order_by('id','desc')->limit(1)->get('purchase_details')->result_array();
foreach($query_update1 as $row)

{
@$quotationnos=$row['purchaseno'];
}
if(date('m')=='04')
{

$month=date('m');
$year=date('Y');
$old=$this->db->where('month(date)', $month)->where('year(date) ', $year)->where('status',1)->get('purchase_details')->result_array();
if($old)
{
@$bond_no = $quotationnos;

if(is_null($bond_no))
{
$default_bond=$this->db->where('id',1)->get('preference_settings')->row();
$new_bond_noo = 'P'.$default_bond->purchase;
//$new_bond_noo = 'P00001'; 
} 
else 
{
$default_bond=$this->db->where('id',1)->where('purchase !=','')->get('preference_settings')->row();
if($default_bond)
{
$bond_no='P'.$default_bond->purchase;
$bondLen = strlen($bond_no)-1;
$bondOnlyNum = filter_var($bond_no, FILTER_SANITIZE_NUMBER_INT);
$new_bond_noo = 'P'.sprintf('%0'.$bondLen.'d', $bondOnlyNum);
}
else
{
$bondLen = strlen($bond_no)-1;
$bondOnlyNum = filter_var($bond_no, FILTER_SANITIZE_NUMBER_INT);
$new_bond_noo = 'P'.sprintf('%0'.$bondLen.'d', $bondOnlyNum + 1);
}

}
}
else
{
$default_bond=$this->db->where('id',1)->get('preference_settings')->row();
$new_bond_noo = 'P'.$default_bond->purchase;
//$new_bond_noo = 'P00001';
}
}
else
{
@$bond_no = $quotationnos;
if(is_null($bond_no))
{
$default_bond=$this->db->where('id',1)->get('preference_settings')->row();
$new_bond_noo = 'P'.$default_bond->purchase;
//$new_bond_noo = 'P00001'; 
} 
else
{
$default_bond=$this->db->where('id',1)->where('purchase !=','')->get('preference_settings')->row();
if($default_bond)
{
@$bond_no='P'.$default_bond->purchase;
$bondLen = strlen($bond_no)-1;
$bondOnlyNum = filter_var($bond_no, FILTER_SANITIZE_NUMBER_INT);
$new_bond_noo = 'P'.sprintf('%0'.$bondLen.'d', $bondOnlyNum);
}
else
{
$bondLen = strlen($bond_no)-1;
$bondOnlyNum = filter_var($bond_no, FILTER_SANITIZE_NUMBER_INT);
$new_bond_noo = 'P'.sprintf('%0'.$bondLen.'d', $bondOnlyNum + 1);
}

}
}

$invoiceno=$new_bond_noo;

// echo '<pre>';
// print_r($_POST);die;


$grandtotal = $_POST['grandtotal'];
$customerid = $_POST['supplierid'];


$data1=$this->db->where('id',$customerid)->get('customer_details')->result_array();

foreach ($data1 as $a) 
{
$openingbalance=$a['openingbal'];
$balance=$a['balanceamount'];
$salesamounts=$a['salesamount'];  
$paidamounts=$a['paidamount'];  
}

if($balance)
{
$balanceamount=$balance + $grandtotal;
}
else
{
$balanceamount=($openingbalance+$grandtotal)-$paidamounts;
}
if($salesamounts=='')
{
$salesamount=$grandtotal;
}
else
{
$salesamount=$salesamounts+$grandtotal;
}


$datass = array('salesamount'=>$salesamount,'balanceamount'=>$balanceamount);
$this->db->where('id',$customerid)->update('customer_details',$datass);

$hsnno=implode('||',$_POST['hsnno']);
$heatno=implode('||',$_POST['heatno']);
$itemid=implode('||',$_POST['itemid']);
$itemcode=implode('||',$_POST['itemcode']);
$itemname=implode('||',$_POST['itemname']);
$qty=implode('||',$_POST['qty']);
$uom=implode('||',$_POST['uom']);
$rate=implode('||',$_POST['rate']);
$amount=implode('||',$_POST['amount']);
@$discount=implode('||',$_POST['discount']);
@$discountamount=implode('||',$_POST['discountamount']);
$taxableamount=implode('||',$_POST['taxableamount']);
$cgst=implode('||',$_POST['cgst']);
$cgstamount=implode('||',$_POST['cgstamount']);
$sgst=implode('||',$_POST['sgst']);
$sgstamount=implode('||',$_POST['sgstamount']);
$igst=implode('||',$_POST['igst']);
$igstamount=implode('||',$_POST['igstamount']);
$total=implode('||',$_POST['total']);
$subtotal=$this->input->post('subtotal');
$freightamount=$this->input->post('freightamount');
$freightcgst=$this->input->post('freightcgst');
$freightcgstamount=$this->input->post('freightcgstamount');
$freightsgst=$this->input->post('freightsgst');
$freightsgstamount=$this->input->post('freightsgstamount');
$freightigst=$this->input->post('freightigst');
$freightigstamount=$this->input->post('freightigstamount');
$freighttotal=$this->input->post('freighttotal');
$loadingamount=$this->input->post('loadingamount');
$loadingcgst=$this->input->post('loadingcgst');
$loadingcgstamount=$this->input->post('loadingcgstamount');
$loadingsgst=$this->input->post('loadingsgst');
$loadingsgstamount=$this->input->post('loadingsgstamount');
$loadingigst=$this->input->post('loadingigst');
$loadingigstamount=$this->input->post('loadingigstamount');
$loadingtotal=$this->input->post('loadingtotal');
$othercharges=$this->input->post('othercharges');
$hiddenDiscountBy=$this->input->post('hiddenDiscountBy');
$roundOff=$this->input->post('roundOff');
$grandtotal=$this->input->post('grandtotal');
$purchasenoyear=$_POST['purchaseno'].''.date('-Y').'';
$purchasenodate=$_POST['purchaseno'].''.date('dmy').'';


$pcode=$_POST['hsnno'];
$count7=count($pcode);
for ($i=0; $i < $count7; $i++) 
{
$res[]="0";
$ret[]="1";
}

$billtype=$_POST['gsttype'];
if($billtype=='intrastate')
{
$sgst = implode('||',$_POST['sgst']);
$cgst = implode('||',$_POST['cgst']);
$igst = implode('||',$_POST['igst']);
//$igst = implode('||',$res);
$sgstamount = implode('||',$_POST['sgstamount']);
$cgstamount = implode('||',$_POST['cgstamount']);
$igstamount = implode('||',$_POST['igstamount']);
//$igstamount = implode('||',$res);
$sgsts='sgst';
$cgsts='cgst';
$igsts='';
}

if($billtype=='interstate')
{
//$sgst =implode('||',$res);
//$cgst = implode('||',$res);
$sgst = implode('||',$_POST['sgst']);
$cgst = implode('||',$_POST['cgst']);
$igst = implode('||',$_POST['igst']);
//$sgstamount = implode('||',$res);
//$cgstamount = implode('||',$res);
$sgstamount = implode('||',$_POST['sgstamount']);
$cgstamount = implode('||',$_POST['cgstamount']);
$igstamount = implode('||',$_POST['igstamount']);
$igsts='igst';
$sgsts='';
$cgsts='';
}


$data=array(
'date'=>date('Y-m-d'),
'purchasedate' =>date('Y-m-d',strtotime($_POST['purchasedate'])), 
'invoicedate' =>date('Y-m-d',strtotime($_POST['invoicedate'])), 
'purchaseno' =>$invoiceno, 
'supplierId' => $customerid,
'suppliername' =>$_POST['suppliername'], 
'address' =>$_POST['address'], 
'invoiceno' =>$_POST['invoiceno'], 
'billtype' =>$_POST['gsttype'], 
'gsttype' =>$_POST['gsttype'], 
'purchasetype'=>$_POST['purchasetype'],
'typesgst'=>$sgsts,
'typecgst'=>$cgsts,
'typeigst'=>$igsts,
'hsnno'=>$hsnno,
'heatno'=>$heatno,
'itemid'=>$itemid,
'itemcode'=>$itemcode,
'itemname'=>$itemname,
'uom'=>$uom,
'rate'=>$rate,
'qty'=>$qty,
'amount'=>$amount,
'discount'=>$discount,
'discountamount'=>$discountamount,
'taxableamount'=>$taxableamount,
'sgst'=>$sgst,
'sgstamount'=>$sgstamount,
'cgst'=>$cgst,
'cgstamount'=>$cgstamount,
'igst'=>$igst,
'igstamount'=>$igstamount,
'total'=>$total,
'subtotal' =>$_POST['subtotal'], 
'freightamount'=>$freightamount,
'freightcgst'=>$freightcgst,
'freightcgstamount'=>$freightcgstamount,
'freightsgst'=>$freightsgst,
'freightsgstamount'=>$freightsgstamount,
'freightigst'=>$freightigst,
'freightigstamount'=>$freightigstamount,
'freighttotal'=>$freighttotal,
'loadingamount'=>$loadingamount,
'loadingcgst'=>$loadingcgst,
'loadingcgstamount'=>$loadingcgstamount,
'loadingsgst'=>$loadingsgst,
'loadingsgstamount'=>$loadingsgstamount,
'loadingigst'=>$loadingigst,
'loadingigstamount'=>$loadingigstamount,
'loadingtotal'=>$loadingtotal,
'roundOff' =>$roundOff,
'othercharges' =>$othercharges,
'discountBy' =>$hiddenDiscountBy,
'return_status'=>implode('||',$ret),
'grandtotal' =>$grandtotal, 
'purchasenodate' =>$purchasenodate, 
'purchasenoyear' =>$purchasenoyear, 
'status'=>1,
'balance'=>$grandtotal, 
'vou_status'=>1,
'edit_status'=>1);
$result=$this->db->insert('purchase_details',$data);
if($result==true)
{ 

$purchaseid = $this->db->insert_id();
$this->db->query("UPDATE preference_settings SET purchase='' WHERE id=1");
$sparename=$_POST['itemname'];
$qty=$_POST['qty'];
$hsnnos=$_POST['hsnno'];
$itemcodes=$_POST['itemcode'];
$heatnos=$_POST['heatno'];
$itemids=$_POST['itemid'];
$sgsts=$_POST['sgst'];
$cgsts=$_POST['cgst'];
$igsts=$_POST['igst'];
$priceTypes=$_POST['priceType'];
$rates=$_POST['rate'];
$count=count($sparename);

for ($i=0; $i <  $count; $i++) 
{ 
$data=$this->db->where('itemcode',$itemcodes[$i])->where('hsnno',$hsnnos[$i])->where('heatno',$heatnos[$i])->get('stock')->result();
foreach($data as $v)
{
$bal=$v->balance;
}
if($data)
{
$this->db->where('itemcode',$itemcodes[$i])->where('hsnno',$hsnnos[$i])->where('heatno',$heatnos[$i])->update('stock',
array(
'updatestock'=>$qty[$i],
'stockdate' =>date('Y-m-d',strtotime($_POST['purchasedate'])), 
'quantity'=>$qty[$i],
'heatno'=>$heatnos[$i],
'itemid'=>$itemid[$i],
'hsnno' =>$hsnnos[$i],
'itemcode' =>$itemcodes[$i],
'sgst' =>$sgsts[$i],
'cgst' =>$cgsts[$i],
'igst' =>$igsts[$i],
'date'=>date('Y-m-d'),
'balance'=>$bal+$qty[$i]
));

$this->db->insert('stock_reports',
array( 
'hsnno' =>$hsnnos[$i],
'itemcode' =>$itemcodes[$i],
'heatno'=>$heatnos[$i],
'itemid'=>$itemid[$i],
'date' =>date('Y-m-d'),
'itemname' =>$sparename[$i], 
'purchaseid' =>$purchaseid, 
'updatestock' =>$qty[$i],
'priceType'	=> $priceTypes[$i]));        
}
else
{
$this->db->insert('stock',
array( 
'hsnno' =>$hsnnos[$i],
'heatno'=>$heatnos[$i],
'itemid'=>$itemid[$i],
'itemcode' =>$itemcodes[$i],
'stockdate' =>date('Y-m-d',strtotime($_POST['purchasedate'])), 
'date' =>date('Y-m-d'),
'itemname' =>$sparename[$i],
'sgst' =>$sgsts[$i],
'cgst' =>$cgsts[$i],
'igst' =>$igsts[$i],
'quantity'=>$qty[$i],
'rate'	=> $rates[$i],
'priceType'	=> $priceTypes[$i],
'updatestock' =>$qty[$i], 
'balance' =>$_POST['qty'][$i])); 

$this->db->insert('stock_reports',
array(
'stockdate' =>date('Y-m-d',strtotime($_POST['purchasedate'])), 
'purchaseid' =>$purchaseid, 
'date' =>date('Y-m-d'),
'itemname' =>$sparename[$i],
'hsnno' =>$hsnnos[$i],
'heatno'=>$heatnos[$i],
'itemid'=>$itemid[$i],
'itemcode' =>$itemcodes[$i],
'updatestock' =>$qty[$i],
'priceType'	=> $priceTypes[$i]));        
}

}


$itemnames=$_POST['itemname'];
$heatnos = $_POST['heatno'];
$itemids = $_POST['itemid'];
$qtys=$_POST['qty'];
$hsnnoss=$_POST['hsnno'];
$itemcodess=$_POST['itemcode'];
$count=count($sparename);



for ($j=0; $j <  $count; $j++) 
{
$podatass=array(
'date'=>date('Y-m-d'),
'purchasedate' =>date('Y-m-d',strtotime($_POST['purchasedate'])), 
'invoicedate' =>date('Y-m-d',strtotime($_POST['invoicedate'])), 
'purchaseno' =>$_POST['purchaseno'], 
'supplierId' => $customerid,
'suppliername' =>$_POST['suppliername'], 
'invoiceno' =>$_POST['invoiceno'], 
'itemname'=>$itemnames[$j],
'rate'=>$rate[$j],
'qty'=>$qty[$j],
'total'=>$total[$j],
'hsnno'=>$hsnnoss[$j],
'heatno'=>$heatnos[$j],
'itemid'=>$itemids[$j],
'itemcode'=>$itemcodess[$j],
'address' =>$_POST['address'],  
'subtotal' =>$_POST['subtotal'], 
'grandtotal' =>$_POST['grandtotal'], 
'purchasenodate' =>$purchasenodate, 
'purchasenoyear' =>$purchasenoyear,
'purchaseid' =>$purchaseid,
'status'=>1);
$this->db->insert('purchase_reports',$podatass);
}






@$receiptno='-';
@$paymentdetails='-';
@$paymentmodes='-';
@$throughchecks='-';
@$banktransfers='-';
@$chamounts='-';
@$bankamounts='-';
@$purpose='-';
@$amount='-';
@$chequeno='-';


$dd=array(
'date'=>date('Y-m-d',strtotime($_POST['invoicedate'])),
'receiptno'=>$receiptno,
'purchaseno'=>$_POST['purchaseno'],
'supplierId' => $customerid,
'suppliername'=>$_POST['suppliername'],
'payment'=>$paymentdetails, 
'purchasedate'=>date('Y-m-d',strtotime($_POST['purchasedate'])),
'itemname'=>$itemname, 
'amount'=>$total, 
'purpose'=>$purpose,
'chamount'=>$chamounts,
'banktransfer'=>$banktransfers,
'bankamount'=>$bankamounts, 
'chequeno'=>$chequeno, 
'throughcheck'=>$throughchecks, 
'paymentdetails'=>$paymentdetails,
'total'=>$_POST['grandtotal'],
'paid'=>$pay,
'paidamount'=>$paymentdetails,
'currentpaid'=>$paymentdetails,
'receiptamt'=>$paymentdetails,
'balance'=>$balanceamount,
'purchaseamt'=>$_POST['grandtotal'],
'invoiceno' =>$_POST['invoiceno'],
'purchasenodate' =>$purchasenodate, 
'purchasenoyear' =>$purchasenoyear,
'purchaseid' =>$purchaseid, 
'invoicedate' =>date('Y-m-d',strtotime($_POST['invoicedate'])), 
'status'=>1);

$this->db->insert('po_party_statements',$dd);


$purchasetype=$this->input->post('purchasetype');
if($purchasetype=='purchase Order')
{
	$itemname = $this->input->post('itemname');
	$itemcode = $this->input->post('itemcode');
	$qty = $this->input->post('qty');
	$balanceqty=$this->input->post('balaceqty');
	$id=$this->input->post('purchaseOrder');
	$count=count($itemname);
	// 	

for ($j=0; $j < $count; $j++) 
{ 
 $balanceQtys=$balanceqty[$j]-$qty[$j];

 

if($balanceQtys==0)
{
$status=0;
}
else
{
$status=1;
}
$datas=array('balaceqty'=>$balanceQtys,'status'=>$status);
$this->db->where('purchaseorderno',$id[$j]);
$this->db->update('sup_purchaseorder_reports',$datas);
}

}








$this->session->set_flashdata('msg','Purchase Added Successfully');
redirect('purchase');
}
else
{
$this->session->set_flashdata('msg1','Purchase Added Unsuccessfully');
redirect('purchase');
}

}

public function view()
{
$data['purchase']=$this->purchase_model->select();
$data['vat']=$this->db->get('vat_details')->result_array(); 
$this->load->view('header');
$this->load->view('purchase_view',$data);
$this->load->view('footer1');
}

public function views()
{
$id=base64_decode($this->uri->segment(3));
$data['result']=$this->db->where('id',$id)->get('purchase_details')->result_array(); 
$this->load->view('header');
$this->load->view('view_purchase',$data);
$this->load->view('footer');
}


public function ajax_list()
{
$list = $this->purchase_model->get_datatables();
$data = array();
$no = $_POST['start'];
$i=1;
foreach ($list as $person) {
$startTimeStamp = strtotime($person->invoicedate);
$endTimeStamp = strtotime(date('Y-m-d'));
$timeDiff = abs($endTimeStamp - $startTimeStamp);
$numberDays = $timeDiff/86400;  // 86400 seconds in one day
$numberDays = intval($numberDays);

$no++;
$row = array();
$row[] = $i++;
$row[] =date('d-m-Y',strtotime($person->invoicedate));
$row[] = $person->invoiceno;
$row[] = $person->suppliername;
$row[] = $numberDays.' Days';
$row[] = $person->grandtotal;
$code=base64_encode($person->id);
//add html for action
$return_status=explode("||",$person->return_status);
if(in_array(0,$return_status))
{
$deleteOptn='<a class="" style="color:white; font-weight: bold;background-color: #23BDCF;" href="javascript:alert(\'Sorry! You cannot able to delete!\');" title="Hapus" >Delete</a>';

}
else
{
$deleteOptn='<a class="" style="color:white; font-weight: bold;background-color: #23BDCF;" href="javascript:void()" title="Hapus" onclick="delete_person('."'".$code."'".')">Delete</a>';
}
if($person->edit_status=='0')
{
$row[] = '
<div class="btn-group">
<button type="button" class="btn
btn-info dropdown-toggle waves-effect waves-light"
data-toggle="dropdown" aria-expanded="false">Manage <span
class="caret"></span></button>
<ul class="dropdown-menu"
role="menu" style="background: #23BDCF none repeat scroll
0% 0%;width:14px;min-width: 100%;">


<li><a class="" style="color:white; font-weight: bold;background-color: #23BDCF;" href="'.base_url('purchase/views/'.$code).'" title="View" >View</a></li>
<li><a class="" style="color:white; font-weight: bold;background-color: #23BDCF;" href="'.base_url('purchase/edit/'.$code).'" title="Edit" >Edit</a></li>

<li>'.$deleteOptn.'</li>
</ul>
</div>

'; 
}

else
{

$row[] = '


<div class="btn-group">
<button type="button" class="btn
btn-info dropdown-toggle waves-effect waves-light"
data-toggle="dropdown" aria-expanded="false">Manage <span
class="caret"></span></button>
<ul class="dropdown-menu"
role="menu" style="background: #23BDCF none repeat scroll
0% 0%;width:14px;min-width: 100%;">


<li><a class="" style="color:white; font-weight: bold;background-color: #23BDCF;" href="'.base_url('purchase/views/'.$code).'" title="View" >View</a></li>



<li><a class="" style="color:white; font-weight: bold;background-color: #23BDCF;" href="'.base_url('purchase/edit/'.$code).'" title="Edit" >Edit</a></li>

<li>'.$deleteOptn.'</li>
</ul>
</div>

';
}

$data[] = $row;
}

$output = array(
"draw" => $_POST['draw'],
"recordsTotal" => $this->purchase_model->count_all(),
"recordsFiltered" => $this->purchase_model->count_filtered(),
"data" => $data,
);
//output to json format
echo json_encode($output);
}



public function ajax_delete($id)
{
$this->purchase_model->delete_by_id($id);
echo json_encode(array("status" => TRUE));
}


public function autocomplete_customername()
{
$orderno=$this->input->post('keyword');
$this->db->select('*');
$this->db->from('customer_details');
$this->db->where("(type = 'Intra supplier' OR type = 'Inter supplier')");
$this->db->like('name',$orderno);
$query = $this->db->get();
$result = $query->result();
$name       =  array();
foreach ($result as $d){
$json_array             = array();
$json_array['label']    = $d->name;
$json_array['value']    = $d->name;
$json_array['address']    = $d->address1.', '.$d->address2.', '.$d->city.', '.$d->state;
$json_array['supplierid'] = $d->id;
$json_array['type']    = $d->type;
$name[]             = $json_array;
}
echo json_encode($name);
}



public function get_itemcode()
{
$itemcode=$this->input->post('name');
$this->db->select('*');
$this->db->from('additem');
$this->db->where('itemno',$itemcode);
$query = $this->db->get();
$result = $query->result();
foreach($result as $h)
{   
$vob['itemname']=$h->itemname;
$vob['price']=$h->price;
$vob['hsnno']=$h->hsnno;

}
echo json_encode($vob);
}

public function get_hsnno()
{
$itemcode=$this->input->post('name');
$this->db->select('*');
$this->db->from('additem');
$this->db->where('hsnno',$itemcode);
$query = $this->db->get();
$result = $query->result();
foreach($result as $h)
{   
$vob['itemname']=$h->itemname;
$vob['price']=$h->price;
$vob['sgst']=$h->sgst;
$vob['cgst']=$h->cgst;
$vob['igst']=$h->igst;

}
echo json_encode($vob);
}


public function get_itemnames()
{
$itemcode=$this->input->post('name');
$this->db->select('*');
$this->db->from('additem');
$this->db->where('itemname',$itemcode);
$query = $this->db->get();
$result = $query->result();
foreach($result as $h)
{   
$uom=$this->db->select('uom')->where('id',$h->uom)->get('uom')->row()->uom;

$vob['itemcode']=$h->itemcode;
$vob['price']=$h->price;
$vob['priceType']=$h->priceType;
$vob['sgst']=$h->sgst;
$vob['cgst']=$h->cgst;
$vob['igst']=$h->igst;
$vob['uom']=$uom;
$vob['drawingno'] = $h->drawingno;
$vob['weight'] = $h->casting_weight;

}
echo json_encode($vob);
}

public function get_itemcodes()
{
$itemcode=$this->input->post('name');
$this->db->select('*');
$this->db->from('additem');
$this->db->where('itemcode',$itemcode);
$query = $this->db->get();
$result = $query->result();
foreach($result as $h)
{   
$uom=$this->db->select('uom')->where('id',$h->uom)->get('uom')->row()->uom;

$vob['itemname']=$h->itemname;
$vob['price']=$h->price;
$vob['priceType']=$h->priceType;
$vob['sgst']=$h->sgst;
$vob['cgst']=$h->cgst;
$vob['igst']=$h->igst;
$vob['uom']=$uom;
$vob['drawingno'] = $h->drawingno;
$vob['weight'] = $h->casting_weight;

}
echo json_encode($vob);
}



public function autocomplete_itemname()
{
$orderno=$this->input->post('keyword');
$this->db->select('*');
$this->db->from('additem');
$this->db->like('itemname',$orderno);
$query = $this->db->get();
$result = $query->result();
$name       =  array();
foreach ($result as $d){
$json_array             = array();
$json_array['label']    = $d->itemname;
$json_array['value']    = $d->itemname;
$json_array['price']    = $d->price;
$json_array['sgst']    = $d->sgst;
$json_array['cgst']    = $d->cgst;
$json_array['igst']    = $d->igst;



// $json_array['advanceamount'] = $d->voucheramount;
$name[]             = $json_array;
}
echo json_encode($name);
}


public function autocomplete_itemcode()
{
$orderno=$this->input->post('keyword');
$this->db->select('*');
$this->db->from('additem');
$this->db->like('itemcode',$orderno);
$query = $this->db->get();
$result = $query->result();
$name       =  array();
foreach ($result as $d){
$json_array             = array();
$json_array['label']    = $d->itemcode;
$json_array['value']    = $d->itemcode;
$json_array['price']    = $d->price;
$json_array['sgst']    = $d->sgst;
$json_array['cgst']    = $d->cgst;
$json_array['igst']    = $d->igst;


// $json_array['advanceamount'] = $d->voucheramount;
$name[]             = $json_array;
}
echo json_encode($name);
}

public function autocomplete_hsnno()
{
$orderno=$this->input->post('keyword');
$this->db->select('*');
$this->db->from('additem');
$this->db->like('hsnno',$orderno);
$query = $this->db->get();
$result = $query->result();
$name       =  array();
foreach ($result as $d){
$json_array             = array();
$json_array['label']    = $d->hsnno;
$json_array['value']    = $d->hsnno;


// $json_array['advanceamount'] = $d->voucheramount;
$name[]             = $json_array;
}
echo json_encode($name);
}


public function edit()

{

$id=base64_decode($this->uri->segment(3));
$data['result']=$this->db->where('id',$id)->get('purchase_details')->result_array(); 
// echo"<prE>";
// print_r($data['result']);
$this->load->view('header');
$this->load->view('purchase_edit',$data);
$this->load->view('footer');

}

public function getsupplier()
{
$name=$_POST['name'];
$data=$this->db->where('name',$name)->where("(type = 'Intra supplier' OR type = 'Inter supplier')")->get('customer_details')->result();
echo $count=count($data);

}


public function autocomplete_invoiceno()
{
$name=$this->input->post('keyword');
$this->db->select('*');
$this->db->from('purchase_details');
$this->db->like('purchaseno',$name);
$query = $this->db->get();
$result = $query->result();
$name       =  array();
foreach ($result as $d) 
{
$json_array             = array();
$json_array['value']    = $d->purchaseno;
$json_array['label']    = $d->purchaseno;
$name[]             = $json_array;
}
echo json_encode($name);
}
public function autocomplete_invoiceno1()
{
$name=$this->input->post('keyword');
$this->db->select('*');
$this->db->from('purchase_details');
$this->db->like('invoiceno',$name);
$query = $this->db->get();
$result = $query->result();
$name       =  array();
foreach ($result as $d) 
{
$json_array             = array();
$json_array['value']    = $d->invoiceno;
$json_array['label']    = $d->invoiceno;
$name[]             = $json_array;
}
echo json_encode($name);
}


public function autocomplete_no()
{
$name=$this->input->post('keyword');
$this->db->select('*');
$this->db->from('additem');
$this->db->like('itemno',$name);
$query = $this->db->get();
$result = $query->result();
$name       =  array();
foreach ($result as $d) 
{
$json_array             = array();
$json_array['value']    = $d->itemno;
$json_array['label']    = $d->itemno;
$name[]             = $json_array;
}
echo json_encode($name);
}


public function autocomplete_item()
{
$itemname=$this->input->post('keyword');
//$cusname='ram';
$this->db->select('*');
$this->db->from('additem');
$this->db->like('itemname',$itemname);
$query = $this->db->get();
$result = $query->result();
$name       =  array();
foreach ($result as $d) 
{
$json_array             = array();
$json_array['value']    = $d->itemname;
$json_array['label']    = $d->itemname;
$name[]             = $json_array;
}
echo json_encode($name);
}
public function get_itemno()
{
$itemno=$this->input->post('itemno');
$this->db->select('*');
$this->db->from('additem');
$this->db->where('itemno',$itemno);
$query = $this->db->get();
$result = $query->result();
foreach($result as $s)
{   
$vob['itemname']=$s->itemname;
$vob['price']=$s->price;
}
echo json_encode($vob);
}
public function get_itemname()
{
$itemname=$this->input->post('itemname');
$this->db->select('*');
$this->db->from('additem');
$this->db->where('itemname',$itemname);
$query = $this->db->get();
$result = $query->result();
foreach($result as $s)
{   
$vob['itemno']=$s->itemno;
$vob['price']=$s->price;
}
echo json_encode($vob);
}




// public function edit()
// {


//       $data['vat']=$this->db->get('vat_details')->result_array(); 

//   $id=base64_decode($this->uri->segment(3));

//     $data['edit']=$this->purchase_model->invoice_edit($id);
//     $this->load->view('header');
//     $this->load->view('edit_invoice',$data);
//        $this->load->view('footer');


// }

public function update()
{

$id=$this->input->post('id');
$getpurchase=$this->db->where('id',$id)->get('purchase_details')->result();
foreach($getpurchase as $getp)
$grandtotals=$getp->grandtotal;  

$ite=explode('||',$getp->itemname);
$qtyss=explode('||',$getp->qty);
$hsnnos=explode('||',$getp->hsnno);
$itemcodes=explode('||',$getp->itemcode);
/*$updatableitemName = $_POST['itemname'];
$updatableitemNo = $_POST['hsnno'];
$updatableQty = $_POST['hsnno'];
print_r($updatableitemName);
echo '<hr>';
print_r($updatableitemNo);
exit;
Array ( [0] => let us c [1] => Let Us C++ )
Array ( [0] => 0001 [1] => 0002 )*/
//

$count=count($ite);
for ($i=0; $i < $count; $i++) 
{ 
$stock=$this->db->where('itemname',$ite[$i])->where('itemcode',$itemcodes[$i])->where('hsnno',$hsnnos[$i])->get('stock')->result_array();
foreach ($stock as $s) 
{
$ite[$i];
$cur=$s['balance']; 
$tot=$cur-$qtyss[$i]; 
$this->db->where('itemname',$ite[$i])->where('itemcode',$itemcodes[$i])->where('hsnno',$hsnnos[$i])->update('stock',array('balance'=>$tot));   
}
}
//$grandtotal = $_POST['grandtotal'];

$this->db->where("(type = 'Intra supplier' OR type = 'Inter supplier')");
$data1=$this->db->where('name',$_POST['suppliername'])->get('customer_details')->result_array();
foreach ($data1 as $a) 
{
$openingbalance=$a['openingbal'];
$balance=$a['balanceamount'];
$salesamounts=$a['salesamount'];  
} 

if($balance)
{
$balanceamount=$balance -$grandtotals;
}
else
{
$balanceamount='0.00';
}
$this->db->where('id',$a['id'])->update('customer_details',array('balanceamount'=>$balanceamount));
$data11=$this->db->where('id',$a['id'])->get('customer_details')->result_array();
$grandtotal = $_POST['grandtotal'];

foreach ($data11 as $a1) 
{
$openingbalance=$a1['openingbal'];
$balance=$a1['balanceamount'];
$salesamounts=$a1['salesamount'];  
}


if($balance)
{
$balanceamount=$balance + $grandtotal;
}
else
{
$balanceamount=$openingbalance+$grandtotal;
}
if($salesamounts=='')
{
$salesamount=$grandtotal;
}
else
{
$salesamount=$salesamounts+$grandtotal;
}
$datass = array('salesamount'=>$salesamount,'balanceamount'=>$balanceamount);
$this->db->where('id',$a1['id'])->update('customer_details',$datass);



$hsnno=implode('||',$_POST['hsnno']);
$heatno=implode('||',$_POST['heatno']);
$itemid=implode('||',$_POST['itemid']);
$itemcode=implode('||',$_POST['itemcode']);
$itemname=implode('||',$this->db->escape_str($_POST['itemname']));
$qty=implode('||',$_POST['qty']);
$uom=implode('||',$_POST['uom']);
$rate=implode('||',$_POST['rate']);
$amount=implode('||',$_POST['amount']);
@$discount=implode('||',$_POST['discount']);
@$discountamount=implode('||',$_POST['discountamount']);
$taxableamount=implode('||',$_POST['taxableamount']);
$cgst=implode('||',$_POST['cgst']);
$cgstamount=implode('||',$_POST['cgstamount']);
$sgst=implode('||',$_POST['sgst']);
$sgstamount=implode('||',$_POST['sgstamount']);
@$igst=implode('||',$_POST['igst']);
@$igstamount=implode('||',$_POST['igstamount']);
$total=implode('||',$_POST['total']);
$subtotal=$this->input->post('subtotal');
$freightamount=$this->input->post('freightamount');
$freightcgst=$this->input->post('freightcgst');
$freightcgstamount=$this->input->post('freightcgstamount');
$freightsgst=$this->input->post('freightsgst');
$freightsgstamount=$this->input->post('freightsgstamount');
$freightigst=$this->input->post('freightigst');
$freightigstamount=$this->input->post('freightigstamount');
$freighttotal=$this->input->post('freighttotal');
$loadingamount=$this->input->post('loadingamount');
$loadingcgst=$this->input->post('loadingcgst');
$loadingcgstamount=$this->input->post('loadingcgstamount');
$loadingsgst=$this->input->post('loadingsgst');
$loadingsgstamount=$this->input->post('loadingsgstamount');
$loadingigst=$this->input->post('loadingigst');
$loadingigstamount=$this->input->post('loadingigstamount');
$loadingtotal=$this->input->post('loadingtotal');
$roundOff=$this->input->post('roundOff');
$othercharges=$this->input->post('othercharges');
$hiddenDiscountBy=$this->input->post('hiddenDiscountBy');
$grandtotal=$this->input->post('grandtotal');


$pcode=$_POST['hsnno'];
$count7=count($pcode);
for ($i=0; $i < $count7; $i++) 
{
$res[]="0";
$ret[]="1";
}

$billtype=$_POST['gsttype'];
if($billtype=='intrastate')
{
$sgst = implode('||',$_POST['sgst']);
$cgst = implode('||',$_POST['cgst']);
$igst = implode('||',$_POST['igst']);
//$igst = implode('||',$res);
$sgstamount = implode('||',$_POST['sgstamount']);
$cgstamount = implode('||',$_POST['cgstamount']);
$igstamount = implode('||',$_POST['igstamount']);
//$igstamount = implode('||',$res);
$sgsts='sgst';
$cgsts='cgst';
$igsts='';
}
if($billtype=='interstate')
{
//$sgst =implode('||',$res);
//$cgst = implode('||',$res);
$sgst = implode('||',$_POST['sgst']);
$cgst = implode('||',$_POST['cgst']);
$igst = implode('||',$_POST['igst']);
//$sgstamount = implode('||',$res);
//$cgstamount = implode('||',$res);
$sgstamount = implode('||',$_POST['sgstamount']);
$cgstamount = implode('||',$_POST['cgstamount']);
$igstamount = implode('||',$_POST['igstamount']);
$igsts='igst';
$sgsts='';
$cgsts='';
}

$data=array(
'invoicedate' =>date('Y-m-d',strtotime($_POST['invoicedate'])), 
'suppliername' =>$_POST['suppliername'], 
'address' =>$_POST['address'], 
'invoiceno' =>$_POST['invoiceno'], 
'billtype' =>$_POST['gsttype'], 
'gsttype' =>$_POST['gsttype'], 
'typesgst'=>$sgsts,
'typecgst'=>$cgsts,
'typeigst'=>$igsts,
'hsnno'=>$hsnno,
'heatno'=>$heatno,
'itemid'=>$itemid,
'itemcode'=>$itemcode,
'itemname'=>$itemname,
'uom'=>$uom,
'rate'=>$rate,
'qty'=>$qty,
'amount'=>$amount,
'discount'=>$discount,
'discountamount'=>$discountamount,
'taxableamount'=>$taxableamount,
'sgst'=>$sgst,
'sgstamount'=>$sgstamount,
'cgst'=>$cgst,
'cgstamount'=>$cgstamount,
'igst'=>$igst,
'igstamount'=>$igstamount,
'total'=>$total,
'subtotal' =>$_POST['subtotal'], 
'freightamount'=>$freightamount,
'freightcgst'=>$freightcgst,
'freightcgstamount'=>$freightcgstamount,
'freightsgst'=>$freightsgst,
'freightsgstamount'=>$freightsgstamount,
'freightigst'=>$freightigst,
'freightigstamount'=>$freightigstamount,
'freighttotal'=>$freighttotal,
'loadingamount'=>$loadingamount,
'loadingcgst'=>$loadingcgst,
'loadingcgstamount'=>$loadingcgstamount,
'loadingsgst'=>$loadingsgst,
'loadingsgstamount'=>$loadingsgstamount,
'loadingigst'=>$loadingigst,
'loadingigstamount'=>$loadingigstamount,
'loadingtotal'=>$loadingtotal,
'roundOff' =>$roundOff,
'othercharges' =>$othercharges,
'discountBy' =>$hiddenDiscountBy,
'return_status'=>implode('||',$ret),
'grandtotal' =>$grandtotal, 
'edit_status'=>1
);
$this->db->where('id',$id);
$result=$this->db->update('purchase_details',$data);
// $results=$this->purchase_model->update_invoice($data,$id);
if($result)
{


$this->db->where('purchaseid',$id)->delete('purchase_collection');
$this->db->where('purchaseid',$id)->delete('po_party_statements');//ok
$this->db->where('purchaseid',$id)->delete('purchase_reports');
$this->db->where('purchaseid',$id)->delete('stock_reports');
//UPDATING STOCK INTO STOCK TABLE AND STOCK_REPORT TABLE
$purchaseid = $_POST['id'];
$sparename=$_POST['itemname'];
$qty=$_POST['qty'];
$pocode=$_POST['hsnno'];
$itemcodess=$_POST['itemcode'];
$heatnos=$_POST['heatno'];
$sgsts=$_POST['sgst'];
$cgsts=$_POST['cgst'];
$igsts=$_POST['igst'];
$priceTypes=$_POST['priceType'];
$rates=$_POST['rate'];
$count=count($sparename);
for ($i=0; $i <  $count; $i++) 
{ 
@$dt=$this->db->where('itemname',$sparename[$i])->where('itemcode',$itemcodess[$i])->where('hsnno',$pocode[$i])->where('heatno',$heatnos[$i])->get('stock')->result();
foreach($dt as $v)
{
$bal=$v->balance;
}
if($dt)
{ 
$this->db->where('itemname',$sparename[$i])->where('itemcode',$itemcodess[$i])->where('hsnno',$pocode[$i])->where('heatno',$heatnos[$i])->update('stock',array('updatestock'=>$qty[$i],'hsnno'=>$pocode[$i],'date'=>date('Y-m-d'),'balance'=>$bal+$qty[$i]));
}
else
{
$this->db->insert('stock',
array( 
'hsnno' =>$pocode[$i],
'itemcode' =>$itemcodess[$i],
'stockdate' =>date('Y-m-d',strtotime($_POST['purchasedate'])), 
'date' =>date('Y-m-d'),
'itemname' =>$sparename[$i],
'heatno'=>$heatnos[$i],
'itemid'=>$itemid[$i],
'sgst' =>$sgsts[$i],
'cgst' =>$cgsts[$i],
'igst' =>$igsts[$i],
'quantity'=>$qty[$i],
'rate'	=> $rates[$i],
'priceType'	=> $priceTypes[$i],
'updatestock' =>$qty[$i], 
'balance' =>$qty[$i])
); 
}
$this->db->insert('stock_reports',
array(
'stockdate' =>date('Y-m-d',strtotime($_POST['purchasedate'])), 
'purchaseid' =>$purchaseid, 
'heatno'=>$heatnos[$i],
'itemid'=>$itemid[$i],
'date' =>date('Y-m-d'),
'itemname' =>$sparename[$i],
'hsnno' =>$pocode[$i],
'itemcode' =>$itemcodess[$i],
'updatestock' =>$qty[$i],
'priceType'	=> $priceTypes[$i])
);

}




$itemnames=$_POST['itemname'];
$qtys=$_POST['qty'];
$hsnnoss=$_POST['hsnno'];
$pscode=$_POST['itemcode'];
$postItemName = $_POST['itemname'];
$count=count($postItemName);

for ($j=0; $j <  $count; $j++) 
{

$podatass=array(
'date'=>date('Y-m-d'),
'purchasedate' =>date('Y-m-d',strtotime($_POST['purchasedate'])), 
'invoicedate' =>date('Y-m-d',strtotime($_POST['invoicedate'])), 
'purchaseno' =>$_POST['purchaseno'], 
'suppliername' =>$_POST['suppliername'], 
'invoiceno' =>$_POST['invoiceno'], 
'itemname'=>$postItemName[$j],
'heatno'=>$heatnos[$i],
'itemid'=>$itemid[$i],
'rate'=>$rate[$j],
'qty'=>$qty[$j],
'total'=>$total[$j],
'hsnno'=>$hsnnoss[$j],
'itemcode'=>$pscode[$j],
'address' =>$_POST['address'],  
'subtotal' =>$_POST['subtotal'], 
'grandtotal' =>$_POST['grandtotal'], 
'purchasenodate' =>$purchasenodate, 
'purchasenoyear' =>$purchasenoyear,
'purchaseid' =>$purchaseid,
'status'=>1);
$this->db->insert('purchase_reports',$podatass);
}






@$receiptno='-';
@$paymentdetails='-';
@$paymentmodes='-';
@$throughchecks='-';
@$banktransfers='-';
@$chamounts='-';
@$bankamounts='-';
@$purpose='-';
@$amount='-';
@$chequeno='-';


$dd=array(
'date'=>date('Y-m-d',strtotime($_POST['invoicedate'])),
'receiptno'=>$receiptno,
'purchaseno'=>$_POST['purchaseno'],
'suppliername'=>$_POST['suppliername'],
'payment'=>$paymentdetails, 
'purchasedate'=>date('Y-m-d',strtotime($_POST['purchasedate'])),
'itemname'=>$itemname, 
'amount'=>$total, 
'purpose'=>$purpose,
'chamount'=>$chamounts,
'banktransfer'=>$banktransfers,
'bankamount'=>$bankamounts, 
'chequeno'=>$chequeno, 
'throughcheck'=>$throughchecks, 
'paymentdetails'=>$paymentdetails,
'total'=>$_POST['grandtotal'],
'paid'=>$pay,
'paidamount'=>$paymentdetails,
'currentpaid'=>$paymentdetails,
'receiptamt'=>$paymentdetails,
'balance'=>$balanceamount,
'purchaseamt'=>$_POST['grandtotal'],
'invoiceno' =>$_POST['invoiceno'],
'purchasenodate' =>$purchasenodate, 
'purchasenoyear' =>$purchasenoyear,
'purchaseid' =>$purchaseid, 
'invoicedate' =>date('Y-m-d',strtotime($_POST['invoicedate'])), 
'status'=>1);

$this->db->insert('po_party_statements',$dd);

$this->session->set_flashdata('msg','Purchase Updated Successfully');
redirect('purchase/view');
}
else
{
$this->session->set_flashdata('msg1','No Changes');
redirect('purchase/view');
}

}





public function search()
{ 
$fromdate=$this->input->post('fromdate');
$todate=$this->input->post('todate');
$suppliername=$this->input->post('suppliername');
$invoiceno=$this->input->post('invoiceno');

$data=array(
'rcbio_fromdate' => $fromdate,
'rcbio_todate' => $todate,
'rcbio_suppliername' => $suppliername,
'rcbio_invoiceno' => $invoiceno,
'rcbio_bill_format' =>'Print',
);
$this->session->set_userdata($data);
}


public function search_reports()
{   
$bill_format=$this->session->userdata('rcbio_bill_format');                
$data['purchase']=$this->purchase_model->search_billing();
$data['fromdate']=$this->session->userdata('rcbio_fromdate');
$data['todate']=$this->session->userdata('rcbio_todate');
$data['suppliername']=$this->session->userdata('rcbio_suppliername');
$data['invoiceno']=$this->session->userdata('rcbio_invoiceno');
$this->load->view('purchase_reports2',$data);
}  

public function download()
{
$fromdate=$this->input->post('fromdate');
$todate=$this->input->post('todate');
$cusname=$this->input->post('cusname');
$invoiceno=$this->input->post('invoiceno');
$gsttype=$this->input->post('gsttype');

$data=array(
'rcbio_fromdate' => $fromdate,
'rcbio_todate' => $todate,
'rcbio_cusname' => $cusname,
'rcbio_invoiceno' => $invoiceno,
'rcbio_gsttype' => $gsttype,
'rcbio_bill_format' =>'Excel',
);
$this->session->set_userdata($data);
}
public function excel_download(){
    
     $bill_format=$this->session->userdata('rcbio_bill_format'); 
     if($bill_format=='Excel'){
    $val=$this->purchase_model->search_billing();
$this->load->library('excel');
$this->excel->setActiveSheetIndex(0);
//name the worksheet
$this->excel->getActiveSheet()->setTitle('Purchase Reports');
//set cell A1 content with some text
$this->excel->getActiveSheet()->setCellValue('A1', 'INVOICE DETAILS');
$this->excel->getActiveSheet()->setCellValue('A2', 'DATE');
$this->excel->getActiveSheet()->setCellValue('B2', 'INVOICE NO');
$this->excel->getActiveSheet()->setCellValue('C2', 'COMPANY NAME');
$this->excel->getActiveSheet()->setCellValue('D2', 'BILL AGE');
$this->excel->getActiveSheet()->setCellValue('E2', 'TOTAL');



//merge cell A1 until C1
$this->excel->getActiveSheet()->mergeCells('A1:E1');
//set aligment to center for that merged cell (A1 to C1)
$this->excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
//make the font become bold
$this->excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
$this->excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(16);
$this->excel->getActiveSheet()->getStyle('A1')->getFill()->getStartColor()->setARGB('#333');

for($col = ord('A'); $col <= ord('E'); $col++){
//set column dimension
$this->excel->getActiveSheet()->getColumnDimension(chr($col))->setAutoSize(true);
//change the font size
$this->excel->getActiveSheet()->getStyle(chr($col))->getFont()->setSize(12);

$this->excel->getActiveSheet()->getStyle(chr($col))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
}
//retrive contries table data

//$rs = $this->db->get('countries');

$exceldata="";
foreach ($val as $row)
{

$startTimeStamp = strtotime($row['invoicedate']);
$endTimeStamp = strtotime(date('Y-m-d'));
$timeDiff = abs($endTimeStamp - $startTimeStamp);
$numberDays = $timeDiff/86400;  // 86400 seconds in one day
$numberDays = intval($numberDays);

$data['date']=date('d-m-Y',strtotime($row['date']));
$data['invoiceno']=$row['invoiceno'];
$data['suppliername']=$row['suppliername'];
$data['billage']=$numberDays.'Days';
$data['grandtotal']=$row['grandtotal'];
 $datas[] = $data;
 $gtotal[]=$row['grandtotal'];
}
//Fill data 
$overalltotal=array_sum($gtotal);
if(count($datas) > 0)
{
    $data['date']="";
$data['invoiceno']="";
$data['suppliername']="";
$data['billage']="";
$data['grandtotal']=number_format($overalltotal,2);

@$datas[] = $data;
$this->excel->getActiveSheet()->fromArray($datas, null, 'A3');
}


$this->excel->getActiveSheet()->getStyle('A3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$this->excel->getActiveSheet()->getStyle('B3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$this->excel->getActiveSheet()->getStyle('C3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$this->excel->getActiveSheet()->getStyle('D3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$this->excel->getActiveSheet()->getStyle('E3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$filename='Purchase Reports-'.date('d/m/y').'.xls'; //save our workbook as this file name
header('Content-Type: application/vnd.ms-excel'); //mime type
header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
header('Cache-Control: max-age=0'); //no cache

//save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
//if you want to save it as .XLSX Excel 2007 format
$objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');  
//force user to download the Excel file without writing it to server's HD
$objWriter->save('php://output');
}
}

public function delete()
{
$del=base64_decode($this->input->post('id'));
//$del=$this->input->post('id');  
$getdetails=$this->db->where('id',$del)->get('purchase_details')->result();
foreach($getdetails as $row)

// $getsuppliers='Intra supplier';
// $getsuppliers1='Inter supplier';

$customer_details=$this->db->where("(type = 'Intra supplier' OR type = 'Inter supplier')")->where('name',$row->suppliername)->get('customer_details')->result();
foreach($customer_details as $c)
$updates=$c->balanceamount-$row->grandtotal;
$salesamt = $c->salesamount-$row->grandtotal;
$this->db->where("(type = 'Intra supplier' OR type = 'Inter supplier')")->where('name',$row->suppliername)->update('customer_details',array('balanceamount'=>$updates,'salesamount'=>$salesamt));
$itemname =explode('||',$row->itemname);
$rate =explode('||',$row->rate);
$qty =explode('||',$row->qty);
$hsnno =explode('||',$row->hsnno);
$invcount=count($itemname);
for ($j=0; $j < $invcount; $j++)
{ 
$invwq=$this->db->where('itemname',$itemname[$j])->where('hsnno',$hsnno[$j])->get('stock')->result();
foreach($invwq as $w)
$old=$w->balance;  
//$qty[$j];
$bal=$old-$qty[$j];
$this->db->where('itemname',$itemname[$j])->where('hsnno',$hsnno[$j])->update('stock',array('balance'=>$bal));

$invwq1=$this->db->where('itemname',$itemname[$j])->where('hsnno',$hsnno[$j])->get('stock_reports')->result();
foreach($invwq1 as $w1)
$old1=$w1->updatestock;
$ba1l=$old1-$qty[$j];
$this->db->where('itemname',$itemname[$j])->where('hsnno',$hsnno[$j])->update('stock_reports',array('updatestock'=>$ba1l));		
} 
$data=$this->db->where('id',$del)->delete('purchase_details');
if($data)
{
//$this->db->where('purchaseid',$del)->delete('purchase_collection');
$this->db->where('purchaseid',$del)->delete('po_party_statements');
//$this->session->set_flashdata('msg','Purchase  Deleted successfully!');
echo'yes';
}
else
{
//$this->session->set_flashdata('msg1','Purchase  Deleted unsuccessfully');
echo'no';   

}
}



public function pending()
{

$data['pending']=$this->purchase_model->pending_select();


$this->load->view('header');
$this->load->view('purchase_pending_view',$data);
$this->load->view('footer1');
}


public function pending_search()
{
$data['pending']=$this->purchase_model->search_reports();


$this->load->view('header');
$this->load->view('purchase_pending_view',$data);
$this->load->view('footer1');
}


public function purchase_reports()
{
@$suppliername=$_POST['suppliername'];
@$fromdate=$_POST['fromdate'];
@$todate=$_POST['todate'];
$data['pending']=$this->purchase_model->search_pending();

// echo"<pre>";
// print_r($data);
$this->load->view('purchase_reports',$data,$fromdate,$todate,$suppliername);

}

public function reports()
{
@$suppliername=$_POST['suppliername'];
@$fromdate=$_POST['fromdate'];
@$todate=$_POST['todate'];
$data['pending']=$this->purchase_model->search_reports();


$this->load->view('purchase_reports2',$data,$fromdate,$todate);

}


public function reports1()
{
@$suppliername=$_POST['suppliername'];
@$fromdate=$_POST['fromdate'];
@$todate=$_POST['todate'];
$data['pending']=$this->purchase_model->search_pending();


$this->load->view('purchase_reports1',$data,$fromdate,$todate);

}

public function get_supplier()
{
$name=$_POST['name'];
$data=$this->db->where('name',$name)->get('customer_details')->result();
echo $count=count($data);

}

public function check_hsnno()
{
$name=$_POST['name'];
$data=$this->db->where('hsnno',$name)->get('additem')->result();

echo $count=count($data);

}

public function get_purchaseorderno()
{
    $suppliers=$_POST['supplier'];
    
    
    			
    $query=$this->db->where('status',1)->where('suppliername',$suppliers)->group_by('purchaseorderno')->get('sup_purchaseorder_reports');

    $result= $query->result();
    $data=array(); 
    if($result)
    {
        foreach($result as $r)
        {
                 $data['value']=$r->purchaseorderno;
                $data['label']=$r->purchaseorderno;
                $json[]=$data;
           
        }
    }
    echo json_encode($json);
}

public function getaddpurchasedetails()
		{
			$discountBy=$this->db->select('discountBy')->where('id', '1')->get('preference_settings')->row()->discountBy;
			if($discountBy=='percent_wise') { $discType= '%'; } else { $discType=''; }
			$html ='
			<div class="table-responsive myform directPurchaseDet1" >
				<table class="table two">
					<thead> 
						<tr>
							<th style="width:70px">HSN Code</th>
							
							
						  
							<th style="width:150px">Items Name</th>
							
							<th style="width:50px">UOM</th>
							<th style="width:50px">weight</th>
							<th style="width:50px">Qty</th>
							<th style="width:70px">Rate</th>
							<th style="width:100px">Amount</th>
							<th style="width:40px">Disc '.$discType.'</th>
							<th style="width:100px">&nbsp;&nbsp;&nbsp;Taxable <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Amount</th>
							<th class="sgst" style="width:45px">&nbsp;&nbsp;&nbsp;CGST</th>
							<th class="sgst" style="width:80px">&nbsp;&nbsp;&nbsp;CGST <br> &nbsp;&nbsp;&nbsp;Amount</th>
							<th class="sgst" style="width:45px">&nbsp;&nbsp;&nbsp;SGST</th>
							<th class="sgst" style="width:80px">&nbsp;&nbsp;&nbsp;SGST <br>&nbsp;&nbsp;&nbsp;Amount</th>
							<th style="display:none;" class="igst">&nbsp;&nbsp;&nbsp;IGST</th>
							<th style="display:none;" class="igst">&nbsp;&nbsp;&nbsp;IGST <br> &nbsp;&nbsp;&nbsp;Amount</th>
							<th style="width:110px">Total</th>
							<th style="width:10px;">&nbsp;</th>
						</tr>  
					</thead>
					<tbody>
						<tr>
							<td><input class="" id="hsnno0" parsley-trigger="change"  readonly type="text" name="hsnno[]" value="" ><div id="hsnno_valid0"></div><input type="hidden" name="priceType[]" id="priceType0" /></td>
							
					
							
							<td><input class="itemname_class" data-id="0" id="itemname0" parsley-trigger="change" required  type="text" name="itemname[]" value="" ><div id="itemname_valid0"></div></td>

							<td><input class="" id="uom0" parsley-trigger="change"  readonly  type="text" name="uom[]"  autocomplete="off"><div id="uom_valid0"></div></td>
							
							<td><input class="" id="weight0" parsley-trigger="change"   type="text" name="weight[]"  autocomplete="off"></td>
							
							<td><input class="qty_class decimals" id="qty0" data-id="0" parsley-trigger="change" required type="text" name="qty[]"  autocomplete="off" ><div id="qty_valid0"></div></td>  

							<td><input class="rate_class decimals" data-id="0" parsley-trigger="change"  id="rate0" required type="text" name="rate[]"   autocomplete="off"><div id="rate_valid0"></div></td>

							<td><input class="decimals" id="amount0" parsley-trigger="change"  readonly type="text" name="amount[]" value=""  autocomplete="off"><div id="amount_valid0"></div></td>

							<td><input class="discount_class decimals" id="discount0" data-id="0"  type="text" name="discount[]" onkeypress="return isNumberKey_With_Dot(event)" value="0"  autocomplete="off"><div id="discount_valid0"></div></td>

							<td><input class="decimals" id="taxableamount0" readonly type="text" name="taxableamount[]" value=""  autocomplete="off"><input type="hidden" name="discountamount[]" id="discountamount0"><div id="taxableamount_valid0"></div></td>

							<td class="sgst"><input class="decimals" readonly id="cgst0"  type="text" name="cgst[]" value="" onkeypress="return isNumberKey(event)" autocomplete="off" ><div id="cgst_valid0"></div></td>

							<td class="sgst"><input class="decimals" readonly id="cgstamount0"  type="text" name="cgstamount[]"   onkeypress="return isNumberKey(event)" autocomplete="off" readonly value=""></td>

							<td class="sgst"><input class="decimals" id="sgst0" readonly  type="text" name="sgst[]" value="" onkeypress="return isNumberKey(event)" autocomplete="off" ><div id="sgst_valid0"></div></td>

							<td class="sgst"><input class="decimals" id="sgstamount0"  type="text" name="sgstamount[]" readonly  onkeypress="return isNumberKey(event)" autocomplete="off" readonly value=""></td>

							<td class="igst" style="display:none;"><input class="decimals" id="igst0"  type="text" name="igst[]" readonly  onkeypress="return isNumberKey(event)" autocomplete="off" ><div id="igst_valid0"></div></td>

							<td class="igst" style="display:none;"><input class="decimals" id="igstamount0"  type="text" name="igstamount[]"   onkeypress="return isNumberKey(event)" autocomplete="off" readonly value=""></td>

							<td><input class="" id="total0" type="text" name="total[]" value=""  readonly ></td>
							<td style="width:10px;">&nbsp;</td>
						</tr>
				</tbody>
				<tbody id="append"></tbody> 
			</table> 
			</div>
			
			
			';
			echo $html;
		}


		// public function getpodetails()
		// {
		// 	$gsttype=$this->input->post('gsttype');
        //     $supplierid=$this->input->post('supplierid');
		// 	$purchaseOrder=$this->input->post('purchaseOrder');
		// 	// print_r($purchaseOrder);die;
		// 	if($purchaseOrder=='')
		// 	{$html='<div class="text-center" style="color:red;font-weight:bold;"><span>Please Select PO No</span></div>';}
		// 	else
		// 	{
		// 		$count=count($purchaseOrder);
		// 		for ($i=0; $i < $count; $i++) { 
		// 			$data[]=$this->db->where('purchaseorderno',$purchaseOrder[$i])->where('balaceqty >',0)->get('sup_purchaseorder_reports')->result_array();//
		// 		}
		// 		$discountBy=$this->db->select('discountBy')->where('id', '1')->get('preference_settings')->row()->discountBy;
		// 		if($discountBy=='percent_wise') { $discType= '%'; } else { $discType=''; }
			
		// 		$html='
		// 		<div class="table-responsive myform" >
		// 		<table class="responsive table" width="100%">
		// 			<thead> 
		// 				<tr>
		// 					<th -style="width:70px">HSN Code</th>
		// 					<th -style="width:70px">Item Code</th>
		// 					<th -style="width:150px">Item Name</th>
		// 					<th -style="width:150px">Heat No</th>
		// 					<th -style="width:50px">Qty</th>
		// 					<th -style="width:50px">UOM</th>
		// 					<th -style="width:50px">weight</th>
		// 					<th -style="width:70px">Rate</th>
		// 					<th -style="width:100px">Amount</th>
		// 					<th -style="width:40px">Disc '.$discType.'</th>
		// 					<th -style="width:100px">&nbsp;&nbsp;&nbsp;Taxable <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Amount</th>
		// 					<th class="sgst" -style="width:45px">&nbsp;&nbsp;&nbsp;CGST</th>
		// 					<th class="sgst" -style="width:80px">&nbsp;&nbsp;&nbsp;CGST <br> &nbsp;&nbsp;&nbsp;Amount</th>
		// 					<th class="sgst" -style="width:45px">&nbsp;&nbsp;&nbsp;SGST</th>
		// 					<th class="sgst" -style="width:80px">&nbsp;&nbsp;&nbsp;SGST <br>&nbsp;&nbsp;&nbsp;Amount</th>
		// 					<th style="display:none;" class="igst">&nbsp;&nbsp;&nbsp;IGST</th>
		// 					<th style="display:none;" class="igst">&nbsp;&nbsp;&nbsp;IGST <br> &nbsp;&nbsp;&nbsp;Amount</th>
		// 					<th -style="width:110px">Total</th>
		// 					<th -style="width:10px;">&nbsp;</th>
		// 				</tr>  
		// 			</thead>
		// 			<tbody>';
		// 		$k=0;
		// 		foreach ($data as $datas) 
		// 		{foreach ($datas as $rows) 
		// 			{$itemDet=$this->db->select('*')->where('itemcode',$rows['itemcode'])->get('additem')->row();
		// 			$html.='
		// 				<tr>
		// 					<td><input class="" id="hsnno'.$k.'" parsley-trigger="change"  readonly type="text" name="hsnno[]" value="'.$rows['hsnno'].'" ><div id="hsnno_valid'.$k.'"></div><input type="hidden" name="priceType[]" id="priceType'.$k.'" value="'.$itemDet->priceType.'"/><input type="hidden" name="inwNo[]" value="'.$rows['purchaseorderno'].'" /></td>				
		// 					<td><input class="itemcode_class" data-id="'.$k.'" id="itemcode'.$k.'" parsley-trigger="change" required  type="text" name="itemcode[]" value="'.$rows['itemcode'].'" ><div id="itemcode_valid'.$k.'"></div></td>
		// 					<td><input class="itemname_class" data-id="'.$k.'" id="itemname'.$k.'" parsley-trigger="change" required  type="text" name="itemname[]" value="'.htmlentities($rows['itemname']).'" ><div id="itemname_valid'.$k.'"></div></td>
		// 					<td><input class="" data-id="'.$k.'" id="heatno'.$k.'" parsley-trigger="change" required  type="text" name="heatno[]" value="" ><input type="hidden" name="itemid[]" id="itemid'.$k.'" value="'.$itemDet->id.'"></td>
		// 					<td><input class="qty_class decimals" id="qty'.$k.'" data-id="'.$k.'" parsley-trigger="change" required type="text" name="qty[]"  autocomplete="off" value=""><div id="qty_valid'.$k.'"></div><div style="color:green;">Purchase Order Qty : '.$rows['balaceqty'].'</div><input type="hidden" name="balaceqty[]" id="balaceqty'.$k.'" value="'.$rows['balaceqty'].'"/></td>  
		// 					<td><input class="" id="uom'.$k.'" parsley-trigger="change"  readonly  type="text" name="uom[]"  autocomplete="off" value="'.$rows['uom'].'"><div id="uom_valid'.$k.'"></div></td>	
		// 					<td><input class="" id="weight'.$k.'" parsley-trigger="change"  readonly  type="text" name="weight[]"  autocomplete="off" value="'.$rows['weight'].'"></td>
		// 					<td><input class="rate_class decimals" data-id="'.$k.'" parsley-trigger="change"  id="rate'.$k.'"  type="text" name="rate[]"   autocomplete="off" value="'.$itemDet->price.'"><div id="rate_valid'.$k.'"></div></td>
		// 					<td><input class="decimals" id="amount'.$k.'" parsley-trigger="change"  readonly type="text" name="amount[]" value=""  autocomplete="off"><div id="amount_valid'.$k.'"></div></td>
		// 					<td><input class="discount_class decimals" id="discount'.$k.'" data-id="'.$k.'"  type="text" name="discount[]" onkeypress="return isNumberKey_With_Dot(event)" value="0"  autocomplete="off"><div id="discount_valid'.$k.'"></div></td>
		// 					<td><input class="decimals" id="taxableamount'.$k.'" readonly type="text" name="taxableamount[]" value=""  autocomplete="off"><input type="hidden" name="discountamount[]" id="discountamount'.$k.'"><div id="taxableamount_valid'.$k.'"></div></td>
		// 					<td class="sgst"><input class="decimals" readonly id="cgst'.$k.'"  type="text" name="cgst[]" onkeypress="return isNumberKey(event)" autocomplete="off" value="'.$itemDet->cgst.'"><div id="cgst_valid'.$k.'"></div></td>
		// 					<td class="sgst"><input class="decimals" readonly id="cgstamount'.$k.'"  type="text" name="cgstamount[]"   onkeypress="return isNumberKey(event)" autocomplete="off" readonly value=""></td>
		// 					<td class="sgst"><input class="decimals" id="sgst'.$k.'" readonly  type="text" name="sgst[]" value="'.$itemDet->sgst.'" onkeypress="return isNumberKey(event)" autocomplete="off" ><div id="sgst_valid'.$k.'"></div></td>
		// 					<td class="sgst"><input class="decimals" id="sgstamount'.$k.'"  type="text" name="sgstamount[]" readonly  onkeypress="return isNumberKey(event)" autocomplete="off" readonly value=""></td>
		// 					<td class="igst" style="display:none;"><input class="decimals" id="igst'.$k.'"  type="text" name="igst[]" readonly  onkeypress="return isNumberKey(event)" autocomplete="off" value="'.$itemDet->sgst.'"><div id="igst_valid'.$k.'"></div></td>
		// 					<td class="igst" style="display:none;"><input class="decimals" id="igstamount'.$k.'"  type="text" name="igstamount[]"   onkeypress="return isNumberKey(event)" autocomplete="off" readonly value=""></td>
		// 					<td><input class="" id="total'.$k.'" type="text" name="total[]" value=""  readonly ></td>	
		// 					<td><input  data-id="'.$k.'" id="stockType'.$k.'" parsley-trigger="change"   type="hidden" name="stockType[]" value="" >
		// 					<td style="width:10px;">&nbsp;<input class="form-control" parsley-trigger="change" readonly id="purchaseid" type="hidden" name="purchaseid" value="'.$rows['purchaseid'].'"><input class="form-control" parsley-trigger="change" readonly id="id" type="hidden" name="id[]" value="'.$rows['id'].'"> </td>
		// 					';
		// 					if($k==0)
		// 					{$html .= '<td>&nbsp;</td>';}
		// 					else
		// 					{$html .='<td><button type="button" class="btn btn-danger remove"><i class="fa fa-remove"></i></button></td>';}
		// 				$html .='</tr>';$k++;
		// 			}
		// 		}
		// 		$html.='
		// 			</tbody>
		// 		</table>
		// 		<script>
		// 		$(".remove").click(function(){
		// 			$(this).parents("tr").remove();
		// 		});
		// 		</script>';
		// 	}
		// 	echo $html;
		// }



public function getpodetails()
{
    $gsttype = $this->input->post('gsttype');
    $supplierid = $this->input->post('supplierid');
    $purchaseOrder = $this->input->post('purchaseOrder');

    if ($purchaseOrder == '') {
        $html = '<div class="text-center" style="color:red;font-weight:bold;"><span>Please Select PO No</span></div>';
    } else {
        $count = count($purchaseOrder);
        $data = [];
        for ($i = 0; $i < $count; $i++) { 
            $data[] = $this->db->where('purchaseorderno', $purchaseOrder[$i])
                               ->where('balaceqty >', 0)
                               ->get('sup_purchaseorder_reports')
                               ->result_array();
        }

        $discountBy = $this->db->select('discountBy')
                               ->where('id', '1')
                               ->get('preference_settings')
                               ->row()->discountBy;
        $discType = ($discountBy == 'percent_wise') ? '%' : '';

        $html = '
        <div class="table-responsive myform">
        <table class="responsive table" width="100%">
            <thead> 
                <tr>
                    <th>HSN Code</th>
                    <th>Item Code</th>
                    <th>Item Name</th>
                    <th>Heat No</th>
                    <th>Qty</th>
                    <th>UOM</th>
                    <th>Weight</th>
                    <th>Rate</th>
                    <th>Amount</th>
                    <th>Disc '.$discType.'</th>
                    <th>Taxable Amount</th>
                    <th class="sgst">CGST</th>
                    <th class="sgst">CGST Amount</th>
                    <th class="sgst">SGST</th>
                    <th class="sgst">SGST Amount</th>
                    <th class="igst" style="display:none;">IGST</th>
                    <th class="igst" style="display:none;">IGST Amount</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>  
            </thead>
            <tbody>';

        $k = 0;
        foreach ($data as $datas) {
            foreach ($datas as $rows) {
                $itemDet = $this->db->select('*')
                                    ->where('itemcode', $rows['itemcode'])
                                    ->get('additem')->row();

                $html .= '
                <tr data-original="1">
                    <td>
                        <input id="hsnno'.$k.'" readonly type="text" name="hsnno[]" value="'.$rows['hsnno'].'">
                        <input type="hidden" name="priceType[]" id="priceType'.$k.'" value="'.$itemDet->priceType.'"/>
                        <input type="hidden" name="inwNo[]" value="'.$rows['purchaseorderno'].'" />
                    </td>				
                    <td><input class="itemcode_class" data-id="'.$k.'" id="itemcode'.$k.'" required type="text" name="itemcode[]" value="'.$rows['itemcode'].'"></td>
                    <td><input class="itemname_class" data-id="'.$k.'" id="itemname'.$k.'" required type="text" name="itemname[]" value="'.htmlentities($rows['itemname']).'"></td>
                    <td><input id="heatno'.$k.'" data-id="'.$k.'" required type="text" name="heatno[]" value=""><input type="hidden" name="itemid[]" id="itemid'.$k.'" value="'.$itemDet->id.'"></td>
                    <td>
                        <input class="qty_class decimals" id="qty'.$k.'" data-id="'.$k.'" required type="text" name="qty[]" autocomplete="off" value="">
                        <div style="color:green;">Purchase Order Qty : <span class="balLabel">'.$rows['balaceqty'].'</span></div>
                        <input type="hidden" name="balaceqty[]" id="balaceqty'.$k.'" value="'.$rows['balaceqty'].'"/>
                    </td>  
                    <td><input id="uom'.$k.'" readonly type="text" name="uom[]" value="'.$rows['uom'].'"></td>	
                    <td><input id="weight'.$k.'" readonly type="text" name="weight[]" value="'.$rows['weight'].'"></td>
                    <td><input class="rate_class decimals" data-id="'.$k.'" id="rate'.$k.'" type="text" name="rate[]" value="'.$itemDet->price.'"></td>
                    <td><input class="decimals" id="amount'.$k.'" readonly type="text" name="amount[]" value=""></td>
                    <td><input class="discount_class decimals" id="discount'.$k.'" data-id="'.$k.'" type="text" name="discount[]" value="0"></td>
                    <td><input class="decimals" id="taxableamount'.$k.'" readonly type="text" name="taxableamount[]" value=""><input type="hidden" name="discountamount[]" id="discountamount'.$k.'"></td>
                    <td class="sgst"><input class="decimals" readonly id="cgst'.$k.'" type="text" name="cgst[]" value="'.$itemDet->cgst.'"></td>
                    <td class="sgst"><input class="decimals" readonly id="cgstamount'.$k.'" type="text" name="cgstamount[]" value=""></td>
                    <td class="sgst"><input class="decimals" readonly id="sgst'.$k.'" type="text" name="sgst[]" value="'.$itemDet->sgst.'"></td>
                    <td class="sgst"><input class="decimals" readonly id="sgstamount'.$k.'" type="text" name="sgstamount[]" value=""></td>
                    <td class="igst" style="display:none;"><input class="decimals" readonly id="igst'.$k.'" type="text" name="igst[]" value="'.$itemDet->igst.'"></td>
                    <td class="igst" style="display:none;"><input class="decimals" readonly id="igstamount'.$k.'" type="text" name="igstamount[]" value=""></td>
                    <td><input id="total'.$k.'" type="text" name="total[]" value="" readonly></td>
                    <td>
                        <button type="button" class="btn btn-success addRow"><i class="fa fa-plus"></i></button>
                        <button type="button" class="btn btn-danger remove"><i class="fa fa-remove"></i></button>
                    </td>
                </tr>';
                $k++;
            }
        }

        $html .= "</tbody></table></div>

<script>
$(document).ready(function() {

    // Disable remove button for original rows
    $('tr[data-original=\"1\"]').find('.remove').prop('disabled', true).css('opacity','0.5');

    // ========== Remove Row ==========
    $(document).on('click', '.remove', function() {
        var tr = $(this).closest('tr');
        if(tr.attr('data-original') != '1') {
            tr.remove();
            recalculateGrandTotal();
        }
    });

    // ========== Add Row ==========
    $(document).on('click', '.addRow', function() {
        var currentRow = $(this).closest('tr');
        var oldBalance = parseFloat(currentRow.find('[name=\"balaceqty[]\"]').val()) || 0;
        var enteredQty = parseFloat(currentRow.find('[name=\"qty[]\"]').val()) || 0;
        var newBalance = oldBalance - enteredQty;
        if (newBalance < 0) newBalance = 0;

        if (oldBalance <= 0) {
            alert('No balance quantity available to add a new row!');
            return false;
        }
        if (newBalance <= 0) {
            alert('You have reached the full Purchase Order quantity.');
            currentRow.find('.addRow').prop('disabled', true)
                .css({'opacity':'0.5','cursor':'not-allowed'});
        }

        if (newBalance > 0) {
            var newRow = currentRow.clone();
            var newIndex = $('table tbody tr').length;
            newRow.removeAttr('data-original');

            // Update all IDs & data-id
            newRow.find('input,select,textarea').each(function() {
                var oldId = $(this).attr('id');
                if(oldId){
                    var newId = oldId.replace(/[0-9]+$/, newIndex);
                    $(this).attr('id', newId);
                    $(this).attr('data-id', newIndex);
                }
            });

            // Clear numeric fields
            newRow.find('input[type=text]').each(function() {
                var name = $(this).attr('name');
                if(name == 'heatno[]' || name == 'qty[]' || name == 'amount[]' || 
                   name == 'taxableamount[]' || name == 'cgstamount[]' || 
                   name == 'sgstamount[]' || name == 'igstamount[]' || name == 'total[]') {
                    $(this).val('');
                }
            });

            // Update balance qty
            newRow.find('[name=\"balaceqty[]\"]').val(newBalance);
            newRow.find('div:contains(\"Purchase Order Qty\")').html('Purchase Order Qty : <span class=\"balLabel\">' + newBalance + '</span>');
            newRow.find('.remove').prop('disabled', false).css('opacity','1');
            newRow.insertAfter(currentRow);
        }

        currentRow.find('[name=\"balaceqty[]\"]').val(newBalance);
        currentRow.find('div:contains(\"Purchase Order Qty\")').html('Purchase Order Qty : <span class=\"balLabel\">' + newBalance + '</span>');
    });

    // ========== Live Calculation ==========
    $(document).on('keyup change', '.qty_class, .rate_class, .discount_class', function() {
        var row = $(this).closest('tr');
        calculateRow(row);
        recalculateGrandTotal();
    });

    function calculateRow(row){
        var qty = parseFloat(row.find('[name=\"qty[]\"]').val()) || 0;
        var rate = parseFloat(row.find('[name=\"rate[]\"]').val()) || 0;
        var discount = parseFloat(row.find('[name=\"discount[]\"]').val()) || 0;
        var weight = parseFloat(row.find('[name=\"weight[]\"]').val()) || 0;

        var cgst = parseFloat(row.find('[name=\"cgst[]\"]').val()) || 0;
        var sgst = parseFloat(row.find('[name=\"sgst[]\"]').val()) || 0;
        var igst = parseFloat(row.find('[name=\"igst[]\"]').val()) || 0;

        var gsttype = $('#gsttype').val();
     

        var amount = weight * qty * rate;
        var discountAmount = (amount * discount) / 100;
        var taxable = amount - discountAmount;

        var cgstAmount = (taxable * cgst) / 100;
        var sgstAmount = (taxable * sgst) / 100;
        var igstAmount = (taxable * igst) / 100;


           if(gsttype == 'intrastate')
           {
              var total = taxable + cgstAmount + sgstAmount;
            }
            else{
                var total = taxable + igstAmount;
            }
 

        row.find('[name=\"amount[]\"]').val(amount.toFixed(2));
        row.find('[name=\"discountamount[]\"]').val(discountAmount.toFixed(2));
        row.find('[name=\"taxableamount[]\"]').val(taxable.toFixed(2));
        row.find('[name=\"cgstamount[]\"]').val(cgstAmount.toFixed(2));
        row.find('[name=\"sgstamount[]\"]').val(sgstAmount.toFixed(2));
        row.find('[name=\"igstamount[]\"]').val(igstAmount.toFixed(2));
        row.find('[name=\"total[]\"]').val(total.toFixed(2));
    }

    function recalculateGrandTotal(){
        var grand = 0;
        $('[name=\"total[]\"]').each(function(){
            grand += parseFloat($(this).val()) || 0;
        });
        $('#grandTotal').val(grand.toFixed(2));
    }

});
</script>";
    }

    echo $html;
}





		// public function getpodetails()
		// {
		// 	$gsttype=$this->input->post('gsttype');
		
        //     $supplierid=$this->input->post('supplierid');
		// 	$purchaseOrder=$this->input->post('purchaseOrder');
		// 	// print_r($purchaseOrder);die;
		// 	if($purchaseOrder=='')
		// 	{
		// 		$html='<div class="text-center" style="color:red;font-weight:bold;"><span>Please Select PO No</span></div>';
		// 	    echo $html;
		// 	}
		// 	else
		// 	{
		// 		$data['purchaseOrder']=$purchaseOrder;
		// 		$data['gsttype']=$gsttype;
		// 		$data['supplierid']=$supplierid;
		// 		$this->load->view('against_supplierpo',$data);
		// 	}
		// }




		public function purchaseorderpending()
		{
		  $this->load->view('header');
		  $this->load->view('purchaseorder_pending');
		  $this->load->view('footer1');
		}


		public function get_hsnnos()
		{
			$grade = $this->input->post('grade');
			$gethsn = $this->db->where('id',$grade)->get('grade')->row();
			echo json_encode($gethsn);
		}

}

ob_flush();
?>
